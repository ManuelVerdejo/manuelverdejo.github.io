"""
Setup script for Neural Dynamics project
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="neural-dynamics",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Generative Neural Model for Chaotic Physical Systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/neural-dynamics-chaotic-systems",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.10",
    install_requires=[
        "numpy>=1.26.0",
        "scipy>=1.11.0",
        "jax>=0.4.20",
        "jaxlib>=0.4.20",
        "diffrax>=0.4.1",
        "equinox>=0.11.2",
        "optax>=0.1.7",
        "tensorflow>=2.15.0",
        "keras>=3.0.0",
        "matplotlib>=3.8.0",
        "plotly>=5.18.0",
        "tqdm>=4.66.0",
        "scikit-learn>=1.3.0",
    ],
    extras_require={
        "dev": [
            "jupyter>=1.0.0",
            "black>=23.12.0",
            "flake8>=7.0.0",
            "pytest>=7.4.0",
            "mypy>=1.7.0",
        ],
        "gpu": [
            "jax[cuda12_pip]>=0.4.20",
        ],
    },
    entry_points={
        "console_scripts": [
            "neural-dynamics-train=training.train_autoencoder:main",
            "neural-dynamics-simulate=simulators.lorenz:main",
        ],
    },
)