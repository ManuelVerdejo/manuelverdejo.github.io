#!/usr/bin/env python3
"""
Animation Generator for Neural Dynamics
Creates animated GIFs and videos of the attractors
"""

import os
import sys
sys.path.insert(0, 'src')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation, PillowWriter
from PIL import Image

from models.autoencoder import ChaoticAutoencoder, prepare_sequences


def load_data():
    """Load model and data"""
    print("Loading data...")
    
    autoencoder = ChaoticAutoencoder(
        input_dim=3,
        seq_length=100,
        latent_dim=3,
        encoder_type='hybrid'
    )
    
    try:
        autoencoder.load('models/autoencoder_best.weights.h5')
    except:
        autoencoder.load('models/autoencoder_final.weights.h5')
    
    norm_data = np.load('models/autoencoder_norm.npz')
    mean, std = norm_data['mean'], norm_data['std']
    
    data = np.load('data/lorenz_train.npz')
    trajectories = data['trajectories']
    
    test_trajectories = trajectories[-10:]
    test_trajectories_norm = (test_trajectories - mean) / (std + 1e-8)
    test_sequences = prepare_sequences(test_trajectories_norm, seq_length=100, stride=50)
    X_test = test_sequences[:5]
    X_recon = autoencoder.reconstruct(X_test)
    
    X_test_denorm = X_test * (std + 1e-8) + mean
    X_recon_denorm = X_recon * (std + 1e-8) + mean
    
    print(f"✓ Loaded {len(X_test)} samples")
    return X_test_denorm, X_recon_denorm


def anim_1_rotating_attractor(X_test, X_recon, output_dir):
    """Create rotating 3D attractor animation"""
    print("Creating rotating attractor animation...")
    
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Plot trajectories
    traj_true = X_test[0]
    traj_pred = X_recon[0]
    
    line_true, = ax.plot(traj_true[:, 0], traj_true[:, 1], traj_true[:, 2],
                         'c-', linewidth=2, alpha=0.7, label='True')
    line_pred, = ax.plot(traj_pred[:, 0], traj_pred[:, 1], traj_pred[:, 2],
                         'm--', linewidth=2, alpha=0.7, label='Predicted')
    
    ax.set_xlabel('X', fontsize=12)
    ax.set_ylabel('Y', fontsize=12)
    ax.set_zlabel('Z', fontsize=12)
    ax.set_title('Lorenz Attractor - Rotating View', fontsize=16, fontweight='bold')
    ax.legend(fontsize=12)
    
    def update(frame):
        ax.view_init(elev=20, azim=frame)
        return line_true, line_pred
    
    # Create animation
    anim = FuncAnimation(fig, update, frames=np.arange(0, 360, 2), 
                        interval=50, blit=False)
    
    # Save as GIF
    writer = PillowWriter(fps=20)
    anim.save(f'{output_dir}/rotating_attractor.gif', writer=writer, dpi=80)
    
    plt.close()
    print("  ✓ Saved rotating_attractor.gif")


def anim_2_trajectory_growth(X_test, X_recon, output_dir):
    """Animate trajectory drawing over time"""
    print("Creating trajectory growth animation...")
    
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    traj_true = X_test[0]
    traj_pred = X_recon[0]
    
    ax.set_xlabel('X', fontsize=12)
    ax.set_ylabel('Y', fontsize=12)
    ax.set_zlabel('Z', fontsize=12)
    ax.set_title('Trajectory Evolution', fontsize=16, fontweight='bold')
    ax.view_init(elev=20, azim=45)
    
    # Set limits
    ax.set_xlim([traj_true[:, 0].min()-5, traj_true[:, 0].max()+5])
    ax.set_ylim([traj_true[:, 1].min()-5, traj_true[:, 1].max()+5])
    ax.set_zlim([traj_true[:, 2].min()-5, traj_true[:, 2].max()+5])
    
    line_true, = ax.plot([], [], [], 'c-', linewidth=2, alpha=0.7, label='True')
    line_pred, = ax.plot([], [], [], 'm--', linewidth=2, alpha=0.7, label='Predicted')
    ax.legend(fontsize=12)
    
    def init():
        line_true.set_data([], [])
        line_true.set_3d_properties([])
        line_pred.set_data([], [])
        line_pred.set_3d_properties([])
        return line_true, line_pred
    
    def update(frame):
        line_true.set_data(traj_true[:frame, 0], traj_true[:frame, 1])
        line_true.set_3d_properties(traj_true[:frame, 2])
        line_pred.set_data(traj_pred[:frame, 0], traj_pred[:frame, 1])
        line_pred.set_3d_properties(traj_pred[:frame, 2])
        return line_true, line_pred
    
    anim = FuncAnimation(fig, update, init_func=init,
                        frames=len(traj_true), interval=20, blit=False)
    
    writer = PillowWriter(fps=30)
    anim.save(f'{output_dir}/trajectory_growth.gif', writer=writer, dpi=80)
    
    plt.close()
    print("  ✓ Saved trajectory_growth.gif")


def anim_3_side_by_side_comparison(X_test, X_recon, output_dir):
    """Side-by-side rotating comparison"""
    print("Creating side-by-side comparison animation...")
    
    fig = plt.figure(figsize=(18, 8))
    
    # True trajectory
    ax1 = fig.add_subplot(121, projection='3d')
    traj_true = X_test[0]
    line1, = ax1.plot(traj_true[:, 0], traj_true[:, 1], traj_true[:, 2],
                     'c-', linewidth=2, alpha=0.7)
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('Z')
    ax1.set_title('True Trajectory', fontsize=14, fontweight='bold')
    
    # Predicted trajectory
    ax2 = fig.add_subplot(122, projection='3d')
    traj_pred = X_recon[0]
    line2, = ax2.plot(traj_pred[:, 0], traj_pred[:, 1], traj_pred[:, 2],
                     'm-', linewidth=2, alpha=0.7)
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_zlabel('Z')
    ax2.set_title('Predicted Trajectory', fontsize=14, fontweight='bold')
    
    plt.suptitle('Neural Dynamics: True vs Predicted', fontsize=16, fontweight='bold')
    
    def update(frame):
        ax1.view_init(elev=20, azim=frame)
        ax2.view_init(elev=20, azim=frame)
        return line1, line2
    
    anim = FuncAnimation(fig, update, frames=np.arange(0, 360, 2),
                        interval=50, blit=False)
    
    writer = PillowWriter(fps=20)
    anim.save(f'{output_dir}/side_by_side_comparison.gif', writer=writer, dpi=80)
    
    plt.close()
    print("  ✓ Saved side_by_side_comparison.gif")


def anim_4_phase_space_evolution(X_test, X_recon, output_dir):
    """Animate phase space projections"""
    print("Creating phase space evolution...")
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    traj_true = X_test[0]
    traj_pred = X_recon[0]
    
    # Setup plots
    projections = [(0, 1), (0, 2), (1, 2)]
    titles = ['X-Y Plane', 'X-Z Plane', 'Y-Z Plane']
    
    lines_true = []
    lines_pred = []
    
    for ax, proj, title in zip(axes, projections, titles):
        ax.set_xlabel(['X', 'Y', 'Z'][proj[0]], fontsize=11)
        ax.set_ylabel(['X', 'Y', 'Z'][proj[1]], fontsize=11)
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # Set limits
        ax.set_xlim([traj_true[:, proj[0]].min()-5, traj_true[:, proj[0]].max()+5])
        ax.set_ylim([traj_true[:, proj[1]].min()-5, traj_true[:, proj[1]].max()+5])
        
        line_true, = ax.plot([], [], 'c-', linewidth=2, alpha=0.7, label='True')
        line_pred, = ax.plot([], [], 'm--', linewidth=2, alpha=0.7, label='Predicted')
        
        lines_true.append(line_true)
        lines_pred.append(line_pred)
        
        if ax == axes[0]:
            ax.legend(fontsize=10)
    
    plt.suptitle('Phase Space Evolution', fontsize=16, fontweight='bold')
    plt.tight_layout()
    
    def init():
        for line in lines_true + lines_pred:
            line.set_data([], [])
        return lines_true + lines_pred
    
    def update(frame):
        for i, proj in enumerate(projections):
            lines_true[i].set_data(traj_true[:frame, proj[0]], traj_true[:frame, proj[1]])
            lines_pred[i].set_data(traj_pred[:frame, proj[0]], traj_pred[:frame, proj[1]])
        return lines_true + lines_pred
    
    anim = FuncAnimation(fig, update, init_func=init,
                        frames=len(traj_true), interval=20, blit=False)
    
    writer = PillowWriter(fps=30)
    anim.save(f'{output_dir}/phase_space_evolution.gif', writer=writer, dpi=80)
    
    plt.close()
    print("  ✓ Saved phase_space_evolution.gif")


def anim_5_error_accumulation(X_test, X_recon, output_dir):
    """Animate error accumulation over time"""
    print("Creating error accumulation animation...")
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    traj_true = X_test[0]
    traj_pred = X_recon[0]
    errors = np.linalg.norm(traj_true - traj_pred, axis=1)
    t = np.arange(len(errors)) * 0.01
    
    # Time series
    ax1.set_xlim([0, t[-1]])
    ax1.set_ylim([traj_true[:, 0].min()-5, traj_true[:, 0].max()+5])
    ax1.set_xlabel('Time', fontsize=12)
    ax1.set_ylabel('X', fontsize=12)
    ax1.set_title('X Dimension Evolution', fontsize=13, fontweight='bold')
    ax1.grid(True, alpha=0.3)
    
    line_true, = ax1.plot([], [], 'b-', linewidth=2, alpha=0.7, label='True')
    line_pred, = ax1.plot([], [], 'r--', linewidth=2, alpha=0.7, label='Predicted')
    ax1.legend(fontsize=11)
    
    # Error
    ax2.set_xlim([0, t[-1]])
    ax2.set_ylim([0, errors.max() * 1.1])
    ax2.set_xlabel('Time', fontsize=12)
    ax2.set_ylabel('Error Norm', fontsize=12)
    ax2.set_title('Reconstruction Error', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    
    line_error, = ax2.plot([], [], 'r-', linewidth=2)
    fill = ax2.fill_between([], 0, [], alpha=0.3, color='red')
    
    plt.suptitle('Error Accumulation Analysis', fontsize=16, fontweight='bold')
    plt.tight_layout()
    
    def init():
        line_true.set_data([], [])
        line_pred.set_data([], [])
        line_error.set_data([], [])
        return line_true, line_pred, line_error
    
    def update(frame):
        line_true.set_data(t[:frame], traj_true[:frame, 0])
        line_pred.set_data(t[:frame], traj_pred[:frame, 0])
        line_error.set_data(t[:frame], errors[:frame])
        return line_true, line_pred, line_error
    
    anim = FuncAnimation(fig, update, init_func=init,
                        frames=len(t), interval=20, blit=False)
    
    writer = PillowWriter(fps=30)
    anim.save(f'{output_dir}/error_accumulation.gif', writer=writer, dpi=80)
    
    plt.close()
    print("  ✓ Saved error_accumulation.gif")


def create_thumbnail_grid(output_dir):
    """Create a grid thumbnail of all animations"""
    print("Creating thumbnail grid...")
    
    # Load first frame of each GIF
    gifs = [
        'rotating_attractor.gif',
        'trajectory_growth.gif',
        'side_by_side_comparison.gif',
        'phase_space_evolution.gif',
        'error_accumulation.gif'
    ]
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()
    
    for i, gif_name in enumerate(gifs):
        gif_path = f'{output_dir}/{gif_name}'
        if os.path.exists(gif_path):
            img = Image.open(gif_path)
            axes[i].imshow(np.array(img))
            axes[i].axis('off')
            axes[i].set_title(gif_name.replace('_', ' ').replace('.gif', '').title(),
                            fontsize=12, fontweight='bold')
    
    # Hide last subplot
    axes[-1].axis('off')
    
    plt.suptitle('Animation Gallery', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{output_dir}/animation_gallery.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved animation_gallery.png")


def main():
    """Main execution"""
    print("\n" + "="*80)
    print("ANIMATION GENERATOR")
    print("="*80 + "\n")
    
    # Setup
    output_dir = 'results/figures/animations'
    os.makedirs(output_dir, exist_ok=True)
    
    # Load data
    X_test, X_recon = load_data()
    
    # Generate animations
    print("\nGenerating animations...\n")
    
    anim_1_rotating_attractor(X_test, X_recon, output_dir)
    anim_2_trajectory_growth(X_test, X_recon, output_dir)
    anim_3_side_by_side_comparison(X_test, X_recon, output_dir)
    anim_4_phase_space_evolution(X_test, X_recon, output_dir)
    anim_5_error_accumulation(X_test, X_recon, output_dir)
    
    # Create thumbnail
    create_thumbnail_grid(output_dir)
    
    # Summary
    print("\n" + "="*80)
    print("ANIMATION GENERATION COMPLETE!")
    print("="*80)
    print(f"\nGenerated 5 animated GIFs:")
    print(f"  1. rotating_attractor.gif (360° rotation)")
    print(f"  2. trajectory_growth.gif (drawing animation)")
    print(f"  3. side_by_side_comparison.gif (true vs predicted)")
    print(f"  4. phase_space_evolution.gif (2D projections)")
    print(f"  5. error_accumulation.gif (error over time)")
    print(f"\nBonus: animation_gallery.png (thumbnail grid)")
    print(f"\nSaved to: {output_dir}/")
    print("\nThese GIFs are perfect for:")
    print("  • GitHub README")
    print("  • Portfolio websites")
    print("  • LinkedIn posts")
    print("  • Presentations")
    print("\n" + "="*80 + "\n")


if __name__ == '__main__':
    main()