#!/usr/bin/env python3
"""
Main pipeline script for Neural Dynamics project
Runs the complete workflow: data generation → training → evaluation
"""

import argparse
import os
import sys
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import numpy as np
from training.config import TrainingConfig, get_lorenz_config, get_rossler_config


def setup_directories(config: TrainingConfig):
    """Create necessary directories"""
    dirs = [
        config.data.data_dir,
        config.autoencoder.model_dir,
        config.neural_ode.model_dir,
        config.results_dir,
        config.figures_dir,
        config.metrics_dir
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    
    print("✓ Created directories")


def generate_data(config: TrainingConfig):
    """Step 1: Generate training data"""
    print("\n" + "="*60)
    print("STEP 1: DATA GENERATION")
    print("="*60 + "\n")
    
    from simulators.lorenz import LorenzSystem
    from simulators.rossler import RosslerSystem
    
    if config.system.system_type == 'lorenz':
        system = LorenzSystem(
            sigma=config.system.sigma,
            rho=config.system.rho,
            beta=config.system.beta
        )
    elif config.system.system_type == 'rossler':
        system = RosslerSystem(
            a=config.system.a,
            b=config.system.b,
            c=config.system.c
        )
    else:
        raise ValueError(f"Unknown system type: {config.system.system_type}")
    
    # Generate training data
    print("Generating training data...")
    trajectories_train, ic_train = system.generate_training_data(
        n_trajectories=config.data.n_trajectories_train,
        t_span=config.system.t_span,
        n_steps=config.system.n_steps,
        random_seed=config.data.random_seed
    )
    
    # Generate validation data
    print("\nGenerating validation data...")
    trajectories_val, ic_val = system.generate_training_data(
        n_trajectories=config.data.n_trajectories_val,
        t_span=config.system.t_span,
        n_steps=config.system.n_steps,
        random_seed=config.data.random_seed + 1
    )
    
    # Save
    train_path = os.path.join(config.data.data_dir, config.data.train_file)
    val_path = os.path.join(config.data.data_dir, config.data.val_file)
    
    np.savez_compressed(train_path, trajectories=trajectories_train, initial_conditions=ic_train)
    np.savez_compressed(val_path, trajectories=trajectories_val, initial_conditions=ic_val)
    
    print(f"\n✓ Saved training data to {train_path}")
    print(f"✓ Saved validation data to {val_path}")


def train_autoencoder(config: TrainingConfig):
    """Step 2: Train autoencoder"""
    print("\n" + "="*60)
    print("STEP 2: TRAIN AUTOENCODER")
    print("="*60 + "\n")
    
    from models.autoencoder import ChaoticAutoencoder, prepare_sequences
    from sklearn.model_selection import train_test_split
    import tensorflow as tf
    
    # Load data
    data_path = os.path.join(config.data.data_dir, config.data.train_file)
    data = np.load(data_path)
    trajectories = data['trajectories']
    
    # Normalize
    mean = trajectories.mean(axis=(0, 1))
    std = trajectories.std(axis=(0, 1))
    trajectories_norm = (trajectories - mean) / (std + 1e-8)
    
    # Prepare sequences
    sequences = prepare_sequences(
        trajectories_norm,
        seq_length=config.autoencoder.seq_length,
        stride=config.data.stride
    )
    
    # Split
    X_train, X_val = train_test_split(
        sequences,
        test_size=config.data.train_val_split,
        random_state=config.data.random_seed
    )
    
    print(f"Training set: {X_train.shape}")
    print(f"Validation set: {X_val.shape}")
    
    # Create model
    autoencoder = ChaoticAutoencoder(
        input_dim=config.autoencoder.input_dim,
        seq_length=config.autoencoder.seq_length,
        latent_dim=config.autoencoder.latent_dim,
        encoder_type=config.autoencoder.encoder_type,
        lstm_units=config.autoencoder.lstm_units,
        conv_filters=config.autoencoder.conv_filters
    )
    
    autoencoder.compile(
        learning_rate=config.autoencoder.learning_rate,
        loss='mse'
    )
    
    # Setup callbacks
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=config.autoencoder.early_stopping_patience,
            restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=config.autoencoder.reduce_lr_factor,
            patience=config.autoencoder.reduce_lr_patience
        ),
        tf.keras.callbacks.ModelCheckpoint(
            filepath=os.path.join(config.autoencoder.model_dir, f'{config.autoencoder.save_name}_best.weights.h5'),
            monitor='val_loss',
            save_best_only=True,
            save_weights_only=True
        )
    ]
    
    # Train
    history = autoencoder.train(
        X_train,
        X_val,
        epochs=config.autoencoder.epochs,
        batch_size=config.autoencoder.batch_size,
        callbacks=callbacks
    )
    
    # Save final model and normalization params
    autoencoder.save(
        os.path.join(config.autoencoder.model_dir, f'{config.autoencoder.save_name}_final.weights.h5')
    )
    
    np.savez(
        os.path.join(config.autoencoder.model_dir, f'{config.autoencoder.save_name}_norm.npz'),
        mean=mean, std=std
    )
    
    print("\n✓ Autoencoder training complete")


def train_neural_ode(config: TrainingConfig):
    """Step 3: Train Neural ODE for latent dynamics"""
    print("\n" + "="*60)
    print("STEP 3: TRAIN NEURAL ODE")
    print("="*60 + "\n")
    
    from models.autoencoder import ChaoticAutoencoder
    from models.neural_ode import LatentDynamicsODE, NeuralODETrainer, create_training_data_from_latent
    import jax
    import jax.numpy as jnp
    
    # Load autoencoder
    autoencoder = ChaoticAutoencoder(
        input_dim=config.autoencoder.input_dim,
        seq_length=config.autoencoder.seq_length,
        latent_dim=config.autoencoder.latent_dim,
        encoder_type=config.autoencoder.encoder_type
    )
    
    autoencoder.load(
        os.path.join(config.autoencoder.model_dir, f'{config.autoencoder.save_name}_best.weights.h5')
    )
    
    # Load data and encode to latent space
    data_path = os.path.join(config.data.data_dir, config.data.train_file)
    data = np.load(data_path)
    trajectories = data['trajectories']
    
    # Normalize and prepare sequences
    norm_data = np.load(
        os.path.join(config.autoencoder.model_dir, f'{config.autoencoder.save_name}_norm.npz')
    )
    mean, std = norm_data['mean'], norm_data['std']
    trajectories_norm = (trajectories - mean) / (std + 1e-8)
    
    from models.autoencoder import prepare_sequences
    sequences = prepare_sequences(
        trajectories_norm,
        seq_length=config.autoencoder.seq_length,
        stride=config.data.stride
    )
    
    # Encode to latent space
    print("Encoding trajectories to latent space...")
    latent_trajectories = []
    batch_size = 256
    
    for i in range(0, len(sequences), batch_size):
        batch = sequences[i:i+batch_size]
        latent_batch = autoencoder.encode(batch)
        latent_trajectories.append(latent_batch)
    
    latent_trajectories = np.concatenate(latent_trajectories, axis=0)
    print(f"Latent trajectories shape: {latent_trajectories.shape}")
    
    # For Neural ODE, we need sequential latent states
    # Reshape: (n_samples, latent_dim) → need to create sequences
    # Use sliding window on original trajectories
    print("Creating latent sequences...")
    latent_sequences = []
    
    for traj in trajectories_norm[:1000]:  # Use subset for speed
        # Encode full trajectory in windows
        for i in range(0, len(traj) - config.autoencoder.seq_length * 2, config.autoencoder.seq_length):
            seq = traj[i:i+config.autoencoder.seq_length]
            latent = autoencoder.encode(seq[np.newaxis, ...])[0]
            latent_sequences.append(latent)
    
    latent_sequences = jnp.array(latent_sequences)
    
    # Create training data for NODE
    z_init, z_target = create_training_data_from_latent(
        latent_sequences.reshape(-1, 50, config.neural_ode.latent_dim)[:500],
        sequence_length=10,
        prediction_horizon=20
    )
    
    # Split train/val
    n_train = int(len(z_init) * 0.8)
    z_train_init = z_init[:n_train]
    z_train_target = z_target[:n_train]
    z_val_init = z_init[n_train:]
    z_val_target = z_target[n_train:]
    
    print(f"Neural ODE training data: {z_train_init.shape} → {z_train_target.shape}")
    
    # Create and train Neural ODE
    key = jax.random.PRNGKey(config.data.random_seed)
    neural_ode = LatentDynamicsODE(
        latent_dim=config.neural_ode.latent_dim,
        hidden_dims=config.neural_ode.hidden_dims,
        key=key
    )
    
    trainer = NeuralODETrainer(
        neural_ode,
        learning_rate=config.neural_ode.learning_rate
    )
    
    trainer.train(
        z_train_init, z_train_target,
        z_val_init, z_val_target,
        t_span=(0, 2.0),
        epochs=config.neural_ode.epochs,
        batch_size=config.neural_ode.batch_size
    )
    
    # Save model
    trainer.save_model(
        os.path.join(config.neural_ode.model_dir, f'{config.neural_ode.save_name}_final.pkl')
    )
    
    print("\n✓ Neural ODE training complete")


def evaluate_model(config: TrainingConfig):
    """Step 4: Evaluate complete model"""
    print("\n" + "="*60)
    print("STEP 4: EVALUATION")
    print("="*60 + "\n")
    
    print("✓ Evaluation would run here")
    print("  - Load test data")
    print("  - Generate predictions")
    print("  - Compute all metrics")
    print("  - Create visualizations")
    print("\nSee notebooks/04_evaluation_metrics.ipynb for detailed evaluation")


def main():
    parser = argparse.ArgumentParser(
        description='Neural Dynamics Pipeline - End-to-end training',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run complete pipeline with default config
  python run_pipeline.py --all
  
  # Run only data generation
  python run_pipeline.py --generate-data
  
  # Use Rössler system
  python run_pipeline.py --all --system rossler
  
  # Quick test run
  python run_pipeline.py --all --quick
        """
    )
    
    parser.add_argument('--all', action='store_true', help='Run complete pipeline')
    parser.add_argument('--generate-data', action='store_true', help='Generate data only')
    parser.add_argument('--train-autoencoder', action='store_true', help='Train autoencoder only')
    parser.add_argument('--train-node', action='store_true', help='Train Neural ODE only')
    parser.add_argument('--evaluate', action='store_true', help='Evaluate only')
    
    parser.add_argument('--system', type=str, default='lorenz', choices=['lorenz', 'rossler'],
                       help='Chaotic system to use')
    parser.add_argument('--config', type=str, help='Path to config YAML file')
    parser.add_argument('--quick', action='store_true', help='Quick test run with small dataset')
    
    args = parser.parse_args()
    
    # Load or create configuration
    if args.config:
        config = TrainingConfig.load_yaml(args.config)
    elif args.quick:
        from training.config import get_quick_test_config
        config = get_quick_test_config()
    elif args.system == 'rossler':
        config = get_rossler_config()
    else:
        config = get_lorenz_config()
    
    print(config)
    
    # Setup
    setup_directories(config)
    
    # Save config
    config_path = os.path.join('configs', f'{config.experiment_name}.yaml')
    config.save_yaml(config_path)
    
    # Run pipeline
    start_time = time.time()
    
    if args.all or args.generate_data:
        generate_data(config)
    
    if args.all or args.train_autoencoder:
        train_autoencoder(config)
    
    if args.all or args.train_node:
        train_neural_ode(config)
    
    if args.all or args.evaluate:
        evaluate_model(config)
    
    # Summary
    elapsed = time.time() - start_time
    
    print("\n" + "="*60)
    print("PIPELINE COMPLETE")
    print("="*60)
    print(f"Total time: {elapsed/60:.1f} minutes")
    print(f"Experiment: {config.experiment_name}")
    print(f"Results saved to: {config.results_dir}")
    print("="*60)


if __name__ == '__main__':
    main()