"""
Lorenz Attractor Simulator using JAX
Implements differentiable physics simulation with vectorization
"""

import jax
import jax.numpy as jnp
from jax import vmap, jit
from diffrax import diffeqsolve, ODETerm, Dopri5, Tsit5, SaveAt, PIDController
from typing import Tuple, Optional, Callable
import numpy as np


class LorenzSystem:
    """
    Lorenz attractor: chaotic system discovered by Edward Lorenz (1963)
    
    Equations:
        dx/dt = σ(y - x)
        dy/dt = x(ρ - z) - y
        dz/dt = xy - βz
    
    Parameters:
        σ (sigma): Prandtl number (default: 10)
        ρ (rho): Rayleigh number (default: 28)
        β (beta): Physical dimension parameter (default: 8/3)
    """
    
    def __init__(
        self, 
        sigma: float = 10.0, 
        rho: float = 28.0, 
        beta: float = 8.0/3.0
    ):
        self.sigma = sigma
        self.rho = rho
        self.beta = beta
        self.params = (sigma, rho, beta)
    
    def dynamics(self, t: float, state: jnp.ndarray, args: Tuple) -> jnp.ndarray:
        """
        Lorenz system differential equations
        
        Args:
            t: Current time
            state: Current state [x, y, z]
            args: System parameters (sigma, rho, beta)
        
        Returns:
            Derivatives [dx/dt, dy/dt, dz/dt]
        """
        x, y, z = state
        sigma, rho, beta = args
        
        dx_dt = sigma * (y - x)
        dy_dt = x * (rho - z) - y
        dz_dt = x * y - beta * z
        
        return jnp.array([dx_dt, dy_dt, dz_dt])
    
    def simulate_single(
        self,
        initial_state: jnp.ndarray,
        t_span: Tuple[float, float],
        dt: float = 0.01,
        solver = Dopri5(),
        saveat_steps: int = 1000
    ) -> jnp.ndarray:
        """
        Simulate a single trajectory
        
        Args:
            initial_state: Initial condition [x0, y0, z0]
            t_span: Time span (t_start, t_end)
            dt: Initial time step
            solver: Diffrax solver (default: Dopri5)
            saveat_steps: Number of points to save
        
        Returns:
            Trajectory array of shape (n_steps, 3)
        """
        term = ODETerm(self.dynamics)
        
        # Time points to save
        ts = jnp.linspace(t_span[0], t_span[1], saveat_steps)
        
        # Solve ODE with adaptive step size
        sol = diffeqsolve(
            term,
            solver,
            t0=t_span[0],
            t1=t_span[1],
            dt0=dt,
            y0=initial_state,
            args=self.params,
            saveat=SaveAt(ts=ts),
            stepsize_controller=PIDController(rtol=1e-5, atol=1e-7),
            max_steps=16**4
        )
        
        return sol.ys
    
    def simulate_batch(
        self,
        initial_states: jnp.ndarray,
        t_span: Tuple[float, float],
        dt: float = 0.01,
        saveat_steps: int = 1000
    ) -> jnp.ndarray:
        """
        Simulate multiple trajectories in parallel using jax.vmap
        
        Args:
            initial_states: Array of initial conditions (n_trajectories, 3)
            t_span: Time span (t_start, t_end)
            dt: Initial time step
            saveat_steps: Number of points to save per trajectory
        
        Returns:
            Trajectories array of shape (n_trajectories, n_steps, 3)
        """
        # Create a standalone function that captures params
        def solve_single_trajectory(ic):
            term = ODETerm(self.dynamics)
            ts = jnp.linspace(t_span[0], t_span[1], saveat_steps)
            
            sol = diffeqsolve(
                term,
                Dopri5(),
                t0=t_span[0],
                t1=t_span[1],
                dt0=dt,
                y0=ic,
                args=self.params,
                saveat=SaveAt(ts=ts),
                stepsize_controller=PIDController(rtol=1e-5, atol=1e-7),
                max_steps=16**4
            )
            return sol.ys
        
        # Vectorize over batch dimension
        return vmap(solve_single_trajectory)(initial_states)
    
    def compute_lyapunov_exponent(
        self,
        initial_state: jnp.ndarray,
        t_span: Tuple[float, float],
        dt: float = 0.01,
        n_iterations: int = 1000
    ) -> float:
        """
        Estimate largest Lyapunov exponent using the method of nearby trajectories
        
        Returns:
            Largest Lyapunov exponent (positive indicates chaos)
        """
        # Initial perturbation
        epsilon = 1e-8
        perturbed_state = initial_state + epsilon * jnp.array([1.0, 0.0, 0.0])
        
        trajectory = self.simulate_single(initial_state, t_span, dt, saveat_steps=n_iterations)
        perturbed_traj = self.simulate_single(perturbed_state, t_span, dt, saveat_steps=n_iterations)
        
        # Compute divergence
        distances = jnp.linalg.norm(trajectory - perturbed_traj, axis=1)
        
        # Lyapunov exponent is log of exponential growth rate
        valid_distances = distances[distances > epsilon]
        if len(valid_distances) > 10:
            lyapunov = jnp.mean(jnp.log(valid_distances / epsilon)) / (t_span[1] - t_span[0])
            return float(lyapunov)
        return 0.0
    
    def generate_training_data(
        self,
        n_trajectories: int = 1000,
        t_span: Tuple[float, float] = (0, 50),
        n_steps: int = 5000,
        random_seed: int = 42
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate training dataset with diverse initial conditions
        
        Args:
            n_trajectories: Number of trajectories to generate
            t_span: Time span for each trajectory
            n_steps: Number of time steps per trajectory
            random_seed: Random seed for reproducibility
        
        Returns:
            trajectories: Array (n_trajectories, n_steps, 3)
            initial_conditions: Array (n_trajectories, 3)
        """
        key = jax.random.PRNGKey(random_seed)
        
        # Sample initial conditions from region around attractor
        # Standard approach: sample from [-20, 20]³ or normal distribution
        initial_states = jax.random.normal(key, (n_trajectories, 3)) * 10
        
        print(f"Generating {n_trajectories} Lorenz trajectories...")
        print(f"Parameters: σ={self.sigma}, ρ={self.rho}, β={self.beta:.3f}")
        
        # Simulate all trajectories in parallel
        trajectories = self.simulate_batch(
            initial_states,
            t_span,
            saveat_steps=n_steps
        )
        
        print(f"✓ Generated trajectories with shape: {trajectories.shape}")
        
        return np.array(trajectories), np.array(initial_states)
    
    def energy(self, state: jnp.ndarray) -> float:
        """
        Compute energy-like quantity (not conserved for Lorenz, but useful metric)
        E = x² + y² + z²
        """
        return jnp.sum(state**2)


def main():
    """Example usage and data generation"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate Lorenz attractor training data')
    parser.add_argument('--num_trajectories', type=int, default=10000, help='Number of trajectories')
    parser.add_argument('--time_span', type=float, default=50.0, help='Time span per trajectory')
    parser.add_argument('--steps', type=int, default=5000, help='Time steps per trajectory')
    parser.add_argument('--output', type=str, default='data/lorenz_train.npz', help='Output file')
    parser.add_argument('--sigma', type=float, default=10.0, help='Sigma parameter')
    parser.add_argument('--rho', type=float, default=28.0, help='Rho parameter')
    parser.add_argument('--beta', type=float, default=8.0/3.0, help='Beta parameter')
    
    args = parser.parse_args()
    
    # Create system
    lorenz = LorenzSystem(sigma=args.sigma, rho=args.rho, beta=args.beta)
    
    # Generate data
    trajectories, initial_conditions = lorenz.generate_training_data(
        n_trajectories=args.num_trajectories,
        t_span=(0, args.time_span),
        n_steps=args.steps
    )
    
    # Compute Lyapunov exponent for reference
    lyapunov = lorenz.compute_lyapunov_exponent(
        initial_conditions[0],
        (0, 50),
        n_iterations=1000
    )
    print(f"Estimated Lyapunov exponent: {lyapunov:.4f}")
    
    # Save data
    import os
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    np.savez_compressed(
        args.output,
        trajectories=trajectories,
        initial_conditions=initial_conditions,
        params={'sigma': args.sigma, 'rho': args.rho, 'beta': args.beta},
        lyapunov_exponent=lyapunov
    )
    
    print(f"✓ Saved to {args.output}")
    print(f"  Shape: {trajectories.shape}")
    print(f"  Size: {os.path.getsize(args.output) / 1e6:.2f} MB")


if __name__ == '__main__':
    main()