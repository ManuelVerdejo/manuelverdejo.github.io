"""
Rössler Attractor Simulator using JAX
Another classic chaotic system with simpler topology than Lorenz
"""

import jax
import jax.numpy as jnp
from jax import vmap, jit
from diffrax import diffeqsolve, ODETerm, Dopri5, SaveAt, PIDController
from typing import Tuple
import numpy as np


class RosslerSystem:
    """
    Rössler attractor: chaotic system discovered by Otto Rössler (1976)
    
    Equations:
        dx/dt = -y - z
        dy/dt = x + ay
        dz/dt = b + z(x - c)
    
    Parameters:
        a: Default 0.2
        b: Default 0.2
        c: Default 5.7 (chaotic for c > 4)
    """
    
    def __init__(self, a: float = 0.2, b: float = 0.2, c: float = 5.7):
        self.a = a
        self.b = b
        self.c = c
        self.params = (a, b, c)
    
    def dynamics(self, t: float, state: jnp.ndarray, args: Tuple) -> jnp.ndarray:
        """Rössler system differential equations"""
        x, y, z = state
        a, b, c = args
        
        dx_dt = -y - z
        dy_dt = x + a * y
        dz_dt = b + z * (x - c)
        
        return jnp.array([dx_dt, dy_dt, dz_dt])
    
    def simulate_single(
        self,
        initial_state: jnp.ndarray,
        t_span: Tuple[float, float],
        dt: float = 0.01,
        saveat_steps: int = 1000
    ) -> jnp.ndarray:
        """Simulate single trajectory"""
        term = ODETerm(self.dynamics)
        ts = jnp.linspace(t_span[0], t_span[1], saveat_steps)
        
        sol = diffeqsolve(
            term,
            Dopri5(),
            t0=t_span[0],
            t1=t_span[1],
            dt0=dt,
            y0=initial_state,
            args=self.params,
            saveat=SaveAt(ts=ts),
            stepsize_controller=PIDController(rtol=1e-5, atol=1e-7),
            max_steps=16**4
        )
        
        return sol.ys
    
    @jit
    def simulate_batch(
        self,
        initial_states: jnp.ndarray,
        t_span: Tuple[float, float],
        dt: float = 0.01,
        saveat_steps: int = 1000
    ) -> jnp.ndarray:
        """Simulate multiple trajectories in parallel"""
        solve_fn = lambda ic: self.simulate_single(ic, t_span, dt, saveat_steps=saveat_steps)
        return vmap(solve_fn)(initial_states)
    
    def generate_training_data(
        self,
        n_trajectories: int = 1000,
        t_span: Tuple[float, float] = (0, 100),
        n_steps: int = 5000,
        random_seed: int = 42
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Generate training dataset"""
        key = jax.random.PRNGKey(random_seed)
        
        # Sample initial conditions
        initial_states = jax.random.normal(key, (n_trajectories, 3)) * 5
        
        print(f"Generating {n_trajectories} Rössler trajectories...")
        print(f"Parameters: a={self.a}, b={self.b}, c={self.c}")
        
        trajectories = self.simulate_batch(
            initial_states,
            t_span,
            saveat_steps=n_steps
        )
        
        print(f"✓ Generated trajectories with shape: {trajectories.shape}")
        
        return np.array(trajectories), np.array(initial_states)


def main():
    """Generate Rössler training data"""
    import argparse
    import os
    
    parser = argparse.ArgumentParser(description='Generate Rössler attractor training data')
    parser.add_argument('--num_trajectories', type=int, default=10000)
    parser.add_argument('--time_span', type=float, default=100.0)
    parser.add_argument('--steps', type=int, default=5000)
    parser.add_argument('--output', type=str, default='data/rossler_train.npz')
    parser.add_argument('--a', type=float, default=0.2)
    parser.add_argument('--b', type=float, default=0.2)
    parser.add_argument('--c', type=float, default=5.7)
    
    args = parser.parse_args()
    
    rossler = RosslerSystem(a=args.a, b=args.b, c=args.c)
    
    trajectories, initial_conditions = rossler.generate_training_data(
        n_trajectories=args.num_trajectories,
        t_span=(0, args.time_span),
        n_steps=args.steps
    )
    
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    np.savez_compressed(
        args.output,
        trajectories=trajectories,
        initial_conditions=initial_conditions,
        params={'a': args.a, 'b': args.b, 'c': args.c}
    )
    
    print(f"✓ Saved to {args.output}")


if __name__ == '__main__':
    main()