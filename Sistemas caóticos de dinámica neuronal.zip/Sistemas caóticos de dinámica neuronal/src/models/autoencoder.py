"""
Autoencoder for Chaotic Systems
Encodes trajectories into low-dimensional latent space
Supports LSTM, Conv1D, and hybrid architectures
"""

import tensorflow as tf
from tensorflow import keras
from keras import layers, Model
import numpy as np
from typing import Tuple, Optional


class ChaoticAutoencoder:
    """
    Autoencoder for learning latent representations of chaotic trajectories
    
    Architecture:
        Encoder: Conv1D + LSTM → Latent space
        Decoder: LSTM + Dense → Reconstructed trajectory
    """
    
    def __init__(
        self,
        input_dim: int = 3,
        seq_length: int = 100,
        latent_dim: int = 3,
        encoder_type: str = 'lstm',
        lstm_units: int = 64,
        conv_filters: int = 32
    ):
        """
        Args:
            input_dim: Dimension of state space (e.g., 3 for Lorenz)
            seq_length: Length of input sequences
            latent_dim: Dimension of latent space
            encoder_type: 'lstm', 'conv', or 'hybrid'
            lstm_units: Number of LSTM units
            conv_filters: Number of convolutional filters
        """
        self.input_dim = input_dim
        self.seq_length = seq_length
        self.latent_dim = latent_dim
        self.encoder_type = encoder_type
        self.lstm_units = lstm_units
        self.conv_filters = conv_filters
        
        self.encoder = None
        self.decoder = None
        self.autoencoder = None
        
        self._build_model()
    
    def _build_encoder(self) -> Model:
        """Build encoder network"""
        inputs = layers.Input(shape=(self.seq_length, self.input_dim))
        
        if self.encoder_type == 'lstm':
            # Pure LSTM encoder
            x = layers.LSTM(self.lstm_units, return_sequences=True)(inputs)
            x = layers.LSTM(self.lstm_units // 2, return_sequences=False)(x)
            
        elif self.encoder_type == 'conv':
            # Convolutional encoder
            x = layers.Conv1D(self.conv_filters, 3, activation='relu', padding='same')(inputs)
            x = layers.Conv1D(self.conv_filters * 2, 3, activation='relu', padding='same')(x)
            x = layers.GlobalAveragePooling1D()(x)
            
        elif self.encoder_type == 'hybrid':
            # Hybrid: Conv1D → LSTM
            x = layers.Conv1D(self.conv_filters, 5, activation='relu', padding='same')(inputs)
            x = layers.Conv1D(self.conv_filters, 3, activation='relu', padding='same')(x)
            x = layers.LSTM(self.lstm_units, return_sequences=True)(x)
            x = layers.LSTM(self.lstm_units // 2, return_sequences=False)(x)
        
        else:
            raise ValueError(f"Unknown encoder_type: {self.encoder_type}")
        
        # Bottleneck to latent space
        x = layers.Dense(self.lstm_units // 2, activation='relu')(x)
        latent = layers.Dense(self.latent_dim, name='latent')(x)
        
        encoder = Model(inputs, latent, name='encoder')
        return encoder
    
    def _build_decoder(self) -> Model:
        """Build decoder network"""
        latent_inputs = layers.Input(shape=(self.latent_dim,))
        
        # Expand latent to sequence
        x = layers.Dense(self.lstm_units // 2, activation='relu')(latent_inputs)
        x = layers.Dense(self.lstm_units, activation='relu')(x)
        x = layers.RepeatVector(self.seq_length)(x)
        
        # LSTM decoder
        x = layers.LSTM(self.lstm_units, return_sequences=True)(x)
        x = layers.LSTM(self.lstm_units // 2, return_sequences=True)(x)
        
        # Output layer
        outputs = layers.TimeDistributed(
            layers.Dense(self.input_dim)
        )(x)
        
        decoder = Model(latent_inputs, outputs, name='decoder')
        return decoder
    
    def _build_model(self):
        """Build complete autoencoder"""
        self.encoder = self._build_encoder()
        self.decoder = self._build_decoder()
        
        # Connect encoder and decoder
        inputs = layers.Input(shape=(self.seq_length, self.input_dim))
        latent = self.encoder(inputs)
        reconstructed = self.decoder(latent)
        
        self.autoencoder = Model(inputs, reconstructed, name='autoencoder')
        
        print(f"✓ Built {self.encoder_type} autoencoder")
        print(f"  Encoder params: {self.encoder.count_params():,}")
        print(f"  Decoder params: {self.decoder.count_params():,}")
        print(f"  Total params: {self.autoencoder.count_params():,}")
    
    def compile(
        self,
        optimizer: str = 'adam',
        learning_rate: float = 1e-3,
        loss: str = 'mse'
    ):
        """Compile the autoencoder"""
        opt = keras.optimizers.Adam(learning_rate=learning_rate)
        self.autoencoder.compile(optimizer=opt, loss=loss, metrics=['mae'])
    
    def train(
        self,
        X_train: np.ndarray,
        X_val: Optional[np.ndarray] = None,
        epochs: int = 100,
        batch_size: int = 256,
        callbacks: Optional[list] = None
    ) -> keras.callbacks.History:
        """
        Train the autoencoder
        
        Args:
            X_train: Training data (n_samples, seq_length, input_dim)
            X_val: Validation data (optional)
            epochs: Number of training epochs
            batch_size: Batch size
            callbacks: List of Keras callbacks
        
        Returns:
            Training history
        """
        if callbacks is None:
            callbacks = [
                keras.callbacks.EarlyStopping(
                    monitor='val_loss' if X_val is not None else 'loss',
                    patience=20,
                    restore_best_weights=True
                ),
                keras.callbacks.ReduceLROnPlateau(
                    monitor='val_loss' if X_val is not None else 'loss',
                    factor=0.5,
                    patience=10
                )
            ]
        
        validation_data = (X_val, X_val) if X_val is not None else None
        
        history = self.autoencoder.fit(
            X_train, X_train,
            validation_data=validation_data,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=1
        )
        
        return history
    
    def encode(self, X: np.ndarray) -> np.ndarray:
        """Encode trajectories to latent space"""
        return self.encoder.predict(X, verbose=0)
    
    def decode(self, Z: np.ndarray) -> np.ndarray:
        """Decode latent vectors to trajectories"""
        return self.decoder.predict(Z, verbose=0)
    
    def reconstruct(self, X: np.ndarray) -> np.ndarray:
        """Encode and decode (full reconstruction)"""
        return self.autoencoder.predict(X, verbose=0)
    
    def save(self, filepath: str):
        """Save model weights"""
        self.autoencoder.save_weights(filepath)
        print(f"✓ Saved model to {filepath}")
    
    def load(self, filepath: str):
        """Load model weights"""
        self.autoencoder.load_weights(filepath)
        print(f"✓ Loaded model from {filepath}")
    
    def summary(self):
        """Print model summaries"""
        print("\n" + "="*60)
        print("ENCODER")
        print("="*60)
        self.encoder.summary()
        
        print("\n" + "="*60)
        print("DECODER")
        print("="*60)
        self.decoder.summary()
        
        print("\n" + "="*60)
        print("AUTOENCODER")
        print("="*60)
        self.autoencoder.summary()


class PhysicsInformedAutoencoder(ChaoticAutoencoder):
    """
    Autoencoder with physics-informed regularization
    Adds constraints to preserve physical properties
    """
    
    def __init__(self, *args, energy_weight: float = 0.1, **kwargs):
        super().__init__(*args, **kwargs)
        self.energy_weight = energy_weight
    
    def physics_loss(self, y_true, y_pred):
        """
        Physics-informed loss term
        Penalizes violations of energy conservation (for conservative systems)
        """
        # Mean squared error (reconstruction)
        mse_loss = tf.reduce_mean(tf.square(y_true - y_pred))
        
        # Energy difference penalty
        energy_true = tf.reduce_sum(tf.square(y_true), axis=-1)
        energy_pred = tf.reduce_sum(tf.square(y_pred), axis=-1)
        energy_loss = tf.reduce_mean(tf.square(energy_true - energy_pred))
        
        # Combined loss
        total_loss = mse_loss + self.energy_weight * energy_loss
        
        return total_loss
    
    def compile(self, optimizer='adam', learning_rate=1e-3, loss=None):
        """Compile with physics-informed loss"""
        opt = keras.optimizers.Adam(learning_rate=learning_rate)
        self.autoencoder.compile(
            optimizer=opt,
            loss=self.physics_loss,
            metrics=['mae']
        )


def prepare_sequences(
    trajectories: np.ndarray,
    seq_length: int = 100,
    stride: int = 10
) -> np.ndarray:
    """
    Convert trajectories into overlapping sequences for training
    
    Args:
        trajectories: Array (n_traj, n_steps, n_dim)
        seq_length: Length of each sequence
        stride: Stride between sequences
    
    Returns:
        sequences: Array (n_sequences, seq_length, n_dim)
    """
    n_traj, n_steps, n_dim = trajectories.shape
    sequences = []
    
    for traj in trajectories:
        for i in range(0, n_steps - seq_length, stride):
            sequences.append(traj[i:i+seq_length])
    
    sequences = np.array(sequences)
    print(f"✓ Created {len(sequences)} sequences of length {seq_length}")
    
    return sequences


if __name__ == '__main__':
    # Example usage
    print("Testing Chaotic Autoencoder...")
    
    # Dummy data
    X_train = np.random.randn(1000, 100, 3)
    X_val = np.random.randn(200, 100, 3)
    
    # Create and train model
    ae = ChaoticAutoencoder(
        input_dim=3,
        seq_length=100,
        latent_dim=3,
        encoder_type='hybrid'
    )
    
    ae.summary()
    ae.compile()
    
    # Train (just 1 epoch for testing)
    history = ae.train(X_train, X_val, epochs=1, batch_size=32)
    
    # Test encoding
    latent = ae.encode(X_val[:5])
    print(f"\nLatent shape: {latent.shape}")
    print(f"Latent values:\n{latent}")