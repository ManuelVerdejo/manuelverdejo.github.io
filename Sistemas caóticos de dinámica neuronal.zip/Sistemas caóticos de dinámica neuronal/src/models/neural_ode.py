"""
Neural ODE for Latent Dynamics
Learns continuous-time evolution in latent space using Equinox + Diffrax
"""

import jax
import jax.numpy as jnp
from jax import vmap, jit
import equinox as eqx
from diffrax import diffeqsolve, ODETerm, Dopri5, SaveAt, PIDController
import optax
from typing import Callable, Tuple
import pickle


class LatentDynamicsODE(eqx.Module):
    """
    Neural ODE that learns latent space dynamics
    
    dz/dt = f_θ(z, t)
    
    where f_θ is a neural network
    """
    
    layers: list
    
    def __init__(self, latent_dim: int, hidden_dims: list = [64, 64], key=None):
        """
        Args:
            latent_dim: Dimension of latent space
            hidden_dims: List of hidden layer dimensions
            key: JAX random key
        """
        if key is None:
            key = jax.random.PRNGKey(0)
        
        # Build MLP: latent_dim → hidden → ... → latent_dim
        dims = [latent_dim] + hidden_dims + [latent_dim]
        
        layers = []
        for i in range(len(dims) - 1):
            key, subkey = jax.random.split(key)
            layers.append(eqx.nn.Linear(dims[i], dims[i+1], key=subkey))
        
        self.layers = layers
    
    def __call__(self, t: float, z: jnp.ndarray) -> jnp.ndarray:
        """
        Compute dz/dt = f(z, t)
        
        Args:
            t: Current time (not used explicitly, but required by Diffrax)
            z: Current latent state
        
        Returns:
            dz/dt: Time derivative of latent state
        """
        x = z
        
        # Forward through network
        for i, layer in enumerate(self.layers[:-1]):
            x = layer(x)
            x = jax.nn.tanh(x)  # Smooth activation for stability
        
        # Output layer (no activation)
        x = self.layers[-1](x)
        
        return x
    
    def integrate(
        self,
        z0: jnp.ndarray,
        t_span: Tuple[float, float],
        n_steps: int = 100,
        dt0: float = 0.01
    ) -> jnp.ndarray:
        """
        Integrate ODE from initial condition z0
        
        Args:
            z0: Initial latent state
            t_span: (t_start, t_end)
            n_steps: Number of evaluation points
            dt0: Initial step size
        
        Returns:
            trajectory: Latent trajectory (n_steps, latent_dim)
        """
        term = ODETerm(lambda t, z, args: self(t, z))
        
        ts = jnp.linspace(t_span[0], t_span[1], n_steps)
        
        sol = diffeqsolve(
            term,
            Dopri5(),
            t0=t_span[0],
            t1=t_span[1],
            dt0=dt0,
            y0=z0,
            saveat=SaveAt(ts=ts),
            stepsize_controller=PIDController(rtol=1e-5, atol=1e-7),
            max_steps=16**4
        )
        
        return sol.ys
    
    def integrate_batch(
        self,
        z0_batch: jnp.ndarray,
        t_span: Tuple[float, float],
        n_steps: int = 100
    ) -> jnp.ndarray:
        """
        Integrate multiple initial conditions in parallel
        
        Args:
            z0_batch: Batch of initial states (batch_size, latent_dim)
        
        Returns:
            trajectories: (batch_size, n_steps, latent_dim)
        """
        integrate_fn = lambda z0: self.integrate(z0, t_span, n_steps)
        return vmap(integrate_fn)(z0_batch)


class NeuralODETrainer:
    """Trainer for Neural ODE with JAX optimization"""
    
    def __init__(
        self,
        model: LatentDynamicsODE,
        learning_rate: float = 1e-3,
        optimizer: str = 'adam'
    ):
        self.model = model
        
        # Setup optimizer
        if optimizer == 'adam':
            self.optimizer = optax.adam(learning_rate)
        elif optimizer == 'adamw':
            self.optimizer = optax.adamw(learning_rate)
        else:
            raise ValueError(f"Unknown optimizer: {optimizer}")
        
        self.opt_state = self.optimizer.init(eqx.filter(model, eqx.is_array))
    
    @staticmethod
    def loss_fn(
        model: LatentDynamicsODE,
        z_init: jnp.ndarray,
        z_target: jnp.ndarray,
        t_span: Tuple[float, float]
    ) -> float:
        """
        Compute prediction loss
        
        Args:
            model: Neural ODE model
            z_init: Initial latent states (batch_size, latent_dim)
            z_target: Target latent trajectories (batch_size, n_steps, latent_dim)
            t_span: Time span
        
        Returns:
            loss: MSE between predicted and target trajectories
        """
        n_steps = z_target.shape[1]
        
        # Predict trajectories
        z_pred = model.integrate_batch(z_init, t_span, n_steps)
        
        # MSE loss
        loss = jnp.mean((z_pred - z_target) ** 2)
        
        return loss
    
    @eqx.filter_jit
    def train_step(
        self,
        model: LatentDynamicsODE,
        opt_state,
        z_init: jnp.ndarray,
        z_target: jnp.ndarray,
        t_span: Tuple[float, float]
    ) -> Tuple[LatentDynamicsODE, float]:
        """Single training step with gradient descent"""
        
        # Compute loss and gradients
        loss, grads = eqx.filter_value_and_grad(self.loss_fn)(
            model, z_init, z_target, t_span
        )
        
        # Update parameters
        updates, opt_state = self.optimizer.update(
            grads, opt_state, eqx.filter(model, eqx.is_array)
        )
        model = eqx.apply_updates(model, updates)
        
        return model, opt_state, loss
    
    def train(
        self,
        z_train_init: jnp.ndarray,
        z_train_target: jnp.ndarray,
        z_val_init: jnp.ndarray,
        z_val_target: jnp.ndarray,
        t_span: Tuple[float, float],
        epochs: int = 100,
        batch_size: int = 32,
        verbose: bool = True
    ):
        """
        Train Neural ODE
        
        Args:
            z_train_init: Training initial states
            z_train_target: Training target trajectories
            z_val_init: Validation initial states
            z_val_target: Validation target trajectories
            t_span: Time span
            epochs: Number of epochs
            batch_size: Batch size
            verbose: Print progress
        """
        n_train = len(z_train_init)
        n_batches = n_train // batch_size
        
        best_val_loss = float('inf')
        
        for epoch in range(epochs):
            # Shuffle training data
            key = jax.random.PRNGKey(epoch)
            perm = jax.random.permutation(key, n_train)
            z_train_init_shuffled = z_train_init[perm]
            z_train_target_shuffled = z_train_target[perm]
            
            # Training loop
            epoch_loss = 0.0
            for i in range(n_batches):
                start_idx = i * batch_size
                end_idx = start_idx + batch_size
                
                batch_init = z_train_init_shuffled[start_idx:end_idx]
                batch_target = z_train_target_shuffled[start_idx:end_idx]
                
                self.model, self.opt_state, loss = self.train_step(
                    self.model,
                    self.opt_state,
                    batch_init,
                    batch_target,
                    t_span
                )
                
                epoch_loss += loss
            
            epoch_loss /= n_batches
            
            # Validation
            val_loss = self.loss_fn(
                self.model,
                z_val_init,
                z_val_target,
                t_span
            )
            
            if verbose and (epoch % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch+1}/{epochs} - "
                      f"Train Loss: {epoch_loss:.6f} - "
                      f"Val Loss: {val_loss:.6f}")
            
            # Save best model
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                self.best_model = self.model
        
        if verbose:
            print(f"\n✓ Training complete. Best val loss: {best_val_loss:.6f}")
        
        return self.model
    
    def save_model(self, filepath: str):
        """Save model to file"""
        with open(filepath, 'wb') as f:
            pickle.dump(self.model, f)
        print(f"✓ Saved model to {filepath}")
    
    @staticmethod
    def load_model(filepath: str) -> LatentDynamicsODE:
        """Load model from file"""
        with open(filepath, 'rb') as f:
            model = pickle.load(f)
        print(f"✓ Loaded model from {filepath}")
        return model


def create_training_data_from_latent(
    latent_trajectories: jnp.ndarray,
    sequence_length: int = 50,
    prediction_horizon: int = 10
) -> Tuple[jnp.ndarray, jnp.ndarray]:
    """
    Prepare training data for Neural ODE
    
    Args:
        latent_trajectories: Encoded trajectories (n_traj, n_steps, latent_dim)
        sequence_length: Length of input sequence
        prediction_horizon: Number of steps to predict
    
    Returns:
        initial_states: Starting points (n_samples, latent_dim)
        target_trajectories: Future trajectories (n_samples, prediction_horizon, latent_dim)
    """
    n_traj, n_steps, latent_dim = latent_trajectories.shape
    
    initial_states = []
    target_trajectories = []
    
    for traj in latent_trajectories:
        for i in range(0, n_steps - prediction_horizon, sequence_length // 2):
            initial_states.append(traj[i])
            target_trajectories.append(traj[i:i+prediction_horizon])
    
    return jnp.array(initial_states), jnp.array(target_trajectories)


if __name__ == '__main__':
    print("Testing Neural ODE...")
    
    # Create model
    key = jax.random.PRNGKey(42)
    model = LatentDynamicsODE(latent_dim=3, hidden_dims=[64, 64], key=key)
    
    # Test forward pass
    z0 = jnp.array([1.0, 0.0, 0.0])
    trajectory = model.integrate(z0, t_span=(0, 10), n_steps=100)
    
    print(f"✓ Integrated trajectory shape: {trajectory.shape}")
    
    # Test batch integration
    z0_batch = jax.random.normal(key, (10, 3))
    trajectories = model.integrate_batch(z0_batch, t_span=(0, 10), n_steps=100)
    
    print(f"✓ Batch trajectories shape: {trajectories.shape}")
    
    # Test training
    z_train_init = jax.random.normal(key, (100, 3))
    z_train_target = jax.random.normal(key, (100, 50, 3))
    z_val_init = jax.random.normal(key, (20, 3))
    z_val_target = jax.random.normal(key, (20, 50, 3))
    
    trainer = NeuralODETrainer(model, learning_rate=1e-3)
    trainer.train(
        z_train_init, z_train_target,
        z_val_init, z_val_target,
        t_span=(0, 5),
        epochs=5,
        batch_size=32
    )
    
    print("✓ All tests passed!")