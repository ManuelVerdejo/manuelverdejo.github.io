"""
Training script for Chaotic System Autoencoder
Handles data loading, training, and model saving
"""

import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import tensorflow as tf

# Add parent directory to path
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.autoencoder import ChaoticAutoencoder, PhysicsInformedAutoencoder, prepare_sequences


def load_trajectory_data(filepath: str) -> tuple:
    """Load trajectory data from npz file"""
    print(f"Loading data from {filepath}...")
    data = np.load(filepath)
    
    trajectories = data['trajectories']
    initial_conditions = data['initial_conditions']
    
    print(f"✓ Loaded {len(trajectories)} trajectories")
    print(f"  Shape: {trajectories.shape}")
    
    return trajectories, initial_conditions


def normalize_data(trajectories: np.ndarray) -> tuple:
    """Normalize trajectories to zero mean and unit variance"""
    mean = trajectories.mean(axis=(0, 1))
    std = trajectories.std(axis=(0, 1))
    
    normalized = (trajectories - mean) / (std + 1e-8)
    
    print(f"✓ Normalized data")
    print(f"  Mean: {mean}")
    print(f"  Std: {std}")
    
    return normalized, mean, std


def plot_training_history(history, save_path: str):
    """Plot and save training history"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    
    # Loss
    axes[0].plot(history.history['loss'], label='Train Loss')
    if 'val_loss' in history.history:
        axes[0].plot(history.history['val_loss'], label='Val Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss (MSE)')
    axes[0].set_title('Training History')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # MAE
    if 'mae' in history.history:
        axes[1].plot(history.history['mae'], label='Train MAE')
        if 'val_mae' in history.history:
            axes[1].plot(history.history['val_mae'], label='Val MAE')
        axes[1].set_xlabel('Epoch')
        axes[1].set_ylabel('MAE')
        axes[1].set_title('Mean Absolute Error')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    print(f"✓ Saved training history to {save_path}")
    plt.close()


def visualize_reconstructions(
    autoencoder: ChaoticAutoencoder,
    X_test: np.ndarray,
    n_samples: int = 5,
    save_path: str = None
):
    """Visualize original vs reconstructed trajectories"""
    # Sample random trajectories
    indices = np.random.choice(len(X_test), n_samples, replace=False)
    X_sample = X_test[indices]
    
    # Reconstruct
    X_recon = autoencoder.reconstruct(X_sample)
    
    # Plot
    fig, axes = plt.subplots(n_samples, 3, figsize=(15, 3*n_samples))
    
    if n_samples == 1:
        axes = axes.reshape(1, -1)
    
    for i in range(n_samples):
        for dim in range(3):
            axes[i, dim].plot(X_sample[i, :, dim], label='Original', alpha=0.7)
            axes[i, dim].plot(X_recon[i, :, dim], label='Reconstructed', linestyle='--', alpha=0.7)
            axes[i, dim].set_xlabel('Time step')
            axes[i, dim].set_ylabel(f'Dimension {dim}')
            axes[i, dim].legend()
            axes[i, dim].grid(True, alpha=0.3)
            
            if i == 0:
                axes[i, dim].set_title(f'Dimension {dim}')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"✓ Saved reconstructions to {save_path}")
    
    plt.close()


def main():
    parser = argparse.ArgumentParser(description='Train Autoencoder for Chaotic Systems')
    
    # Data arguments
    parser.add_argument('--data', type=str, required=True, help='Path to trajectory data (.npz)')
    parser.add_argument('--seq_length', type=int, default=100, help='Sequence length')
    parser.add_argument('--stride', type=int, default=20, help='Stride for sequence extraction')
    
    # Model arguments
    parser.add_argument('--latent_dim', type=int, default=3, help='Latent space dimension')
    parser.add_argument('--encoder_type', type=str, default='hybrid', 
                       choices=['lstm', 'conv', 'hybrid'], help='Encoder architecture')
    parser.add_argument('--lstm_units', type=int, default=64, help='LSTM units')
    parser.add_argument('--conv_filters', type=int, default=32, help='Conv filters')
    parser.add_argument('--physics_informed', action='store_true', help='Use physics-informed loss')
    
    # Training arguments
    parser.add_argument('--epochs', type=int, default=100, help='Training epochs')
    parser.add_argument('--batch_size', type=int, default=256, help='Batch size')
    parser.add_argument('--learning_rate', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--val_split', type=float, default=0.2, help='Validation split')
    
    # Output arguments
    parser.add_argument('--output_dir', type=str, default='models', help='Output directory')
    parser.add_argument('--save_name', type=str, default='autoencoder', help='Model save name')
    
    args = parser.parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    results_dir = os.path.join('results', 'figures')
    os.makedirs(results_dir, exist_ok=True)
    
    # Load data
    trajectories, initial_conditions = load_trajectory_data(args.data)
    
    # Normalize
    trajectories_norm, mean, std = normalize_data(trajectories)
    
    # Prepare sequences
    sequences = prepare_sequences(
        trajectories_norm,
        seq_length=args.seq_length,
        stride=args.stride
    )
    
    # Train/val split
    X_train, X_val = train_test_split(
        sequences,
        test_size=args.val_split,
        random_state=42
    )
    
    print(f"\nTraining set: {X_train.shape}")
    print(f"Validation set: {X_val.shape}")
    
    # Create model
    print(f"\nBuilding {args.encoder_type} autoencoder...")
    
    if args.physics_informed:
        print("Using Physics-Informed Autoencoder")
        autoencoder = PhysicsInformedAutoencoder(
            input_dim=3,
            seq_length=args.seq_length,
            latent_dim=args.latent_dim,
            encoder_type=args.encoder_type,
            lstm_units=args.lstm_units,
            conv_filters=args.conv_filters
        )
    else:
        autoencoder = ChaoticAutoencoder(
            input_dim=3,
            seq_length=args.seq_length,
            latent_dim=args.latent_dim,
            encoder_type=args.encoder_type,
            lstm_units=args.lstm_units,
            conv_filters=args.conv_filters
        )
    
    autoencoder.summary()
    
    # Compile
    autoencoder.compile(
        optimizer='adam',
        learning_rate=args.learning_rate,
        loss='mse'
    )
    
    # Setup callbacks
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=20,
            restore_best_weights=True,
            verbose=1
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=10,
            verbose=1
        ),
        tf.keras.callbacks.ModelCheckpoint(
            filepath=os.path.join(args.output_dir, f'{args.save_name}_best.weights.h5'),
            monitor='val_loss',
            save_best_only=True,
            save_weights_only=True,
            verbose=1
        )
    ]
    
    # Train
    print(f"\n{'='*60}")
    print("TRAINING")
    print(f"{'='*60}\n")
    
    history = autoencoder.train(
        X_train,
        X_val,
        epochs=args.epochs,
        batch_size=args.batch_size,
        callbacks=callbacks
    )
    
    # Save final model
    model_path = os.path.join(args.output_dir, f'{args.save_name}_final.h5')
    autoencoder.save(model_path)
    
    # Save normalization parameters
    norm_path = os.path.join(args.output_dir, f'{args.save_name}_norm.npz')
    np.savez(norm_path, mean=mean, std=std)
    print(f"✓ Saved normalization params to {norm_path}")
    
    # Plot training history
    history_plot_path = os.path.join(results_dir, f'{args.save_name}_history.png')
    plot_training_history(history, history_plot_path)
    
    # Visualize reconstructions
    recon_plot_path = os.path.join(results_dir, f'{args.save_name}_reconstructions.png')
    visualize_reconstructions(autoencoder, X_val, n_samples=5, save_path=recon_plot_path)
    
    # Evaluate final performance
    print(f"\n{'='*60}")
    print("FINAL EVALUATION")
    print(f"{'='*60}\n")
    
    train_loss = autoencoder.autoencoder.evaluate(X_train, X_train, verbose=0)[0]
    val_loss = autoencoder.autoencoder.evaluate(X_val, X_val, verbose=0)[0]
    
    print(f"Final Training Loss: {train_loss:.6f}")
    print(f"Final Validation Loss: {val_loss:.6f}")
    
    # Compute compression ratio
    original_size = X_train.size * 4  # float32
    latent_size = len(X_train) * args.latent_dim * 4
    compression_ratio = 1 - (latent_size / original_size)
    
    print(f"\nCompression Ratio: {compression_ratio*100:.2f}%")
    print(f"Original size: {original_size/1e6:.2f} MB")
    print(f"Latent size: {latent_size/1e6:.2f} MB")
    
    print(f"\n{'='*60}")
    print("✓ Training Complete!")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()