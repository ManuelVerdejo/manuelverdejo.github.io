"""
Configuration file for training and experiments
Centralized configuration management
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple
import yaml
import os


@dataclass
class SystemConfig:
    """Configuration for chaotic system simulation"""
    system_type: str = 'lorenz'  # 'lorenz', 'rossler', 'double_pendulum'
    
    # Lorenz parameters
    sigma: float = 10.0
    rho: float = 28.0
    beta: float = 8.0 / 3.0
    
    # Rössler parameters
    a: float = 0.2
    b: float = 0.2
    c: float = 5.7
    
    # Simulation parameters
    t_span: Tuple[float, float] = (0.0, 50.0)
    n_steps: int = 5000
    dt: float = 0.01


@dataclass
class DataConfig:
    """Configuration for data generation and processing"""
    n_trajectories_train: int = 1000
    n_trajectories_val: int = 200
    n_trajectories_test: int = 100
    
    seq_length: int = 100
    stride: int = 20
    
    normalize: bool = True
    train_val_split: float = 0.2
    
    random_seed: int = 42
    
    data_dir: str = 'data'
    train_file: str = 'lorenz_train.npz'
    val_file: str = 'lorenz_val.npz'
    test_file: str = 'lorenz_test.npz'


@dataclass
class AutoencoderConfig:
    """Configuration for autoencoder model"""
    input_dim: int = 3
    seq_length: int = 100
    latent_dim: int = 3
    
    encoder_type: str = 'hybrid'  # 'lstm', 'conv', 'hybrid'
    lstm_units: int = 64
    conv_filters: int = 32
    
    # Physics-informed options
    physics_informed: bool = False
    energy_weight: float = 0.1
    
    # Training
    batch_size: int = 256
    epochs: int = 10
    learning_rate: float = 1e-3
    optimizer: str = 'adam'
    
    # Callbacks
    early_stopping_patience: int = 20
    reduce_lr_patience: int = 10
    reduce_lr_factor: float = 0.5
    
    # Paths
    model_dir: str = 'models'
    save_name: str = 'autoencoder'


@dataclass
class NeuralODEConfig:
    """Configuration for Neural ODE latent dynamics"""
    latent_dim: int = 3
    hidden_dims: List[int] = field(default_factory=lambda: [64, 64])
    
    # Training
    batch_size: int = 32
    epochs: int = 200
    learning_rate: float = 1e-3
    optimizer: str = 'adam'
    
    # ODE solver
    solver: str = 'dopri5'  # 'dopri5', 'tsit5'
    dt0: float = 0.01
    rtol: float = 1e-5
    atol: float = 1e-7
    
    # Paths
    model_dir: str = 'models'
    save_name: str = 'neural_ode'


@dataclass
class TrainingConfig:
    """Complete training configuration"""
    system: SystemConfig = field(default_factory=SystemConfig)
    data: DataConfig = field(default_factory=DataConfig)
    autoencoder: AutoencoderConfig = field(default_factory=AutoencoderConfig)
    neural_ode: NeuralODEConfig = field(default_factory=NeuralODEConfig)
    
    # Experiment tracking
    experiment_name: str = 'lorenz_baseline'
    use_wandb: bool = False
    wandb_project: str = 'neural-dynamics'
    
    # Hardware
    use_gpu: bool = True
    mixed_precision: bool = False
    
    # Paths
    results_dir: str = 'results'
    figures_dir: str = 'results/figures'
    metrics_dir: str = 'results/metrics'
    
    def save_yaml(self, filepath: str):
        """Save configuration to YAML file"""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        config_dict = {
            'system': vars(self.system),
            'data': vars(self.data),
            'autoencoder': vars(self.autoencoder),
            'neural_ode': vars(self.neural_ode),
            'experiment_name': self.experiment_name,
            'use_wandb': self.use_wandb,
            'wandb_project': self.wandb_project,
            'use_gpu': self.use_gpu,
            'mixed_precision': self.mixed_precision,
        }
        
        with open(filepath, 'w') as f:
            yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)
        
        print(f"✓ Saved configuration to {filepath}")
    
    @classmethod
    def load_yaml(cls, filepath: str) -> 'TrainingConfig':
        """Load configuration from YAML file"""
        with open(filepath, 'r') as f:
            config_dict = yaml.safe_load(f)
        
        system = SystemConfig(**config_dict['system'])
        data = DataConfig(**config_dict['data'])
        autoencoder = AutoencoderConfig(**config_dict['autoencoder'])
        neural_ode = NeuralODEConfig(**config_dict['neural_ode'])
        
        return cls(
            system=system,
            data=data,
            autoencoder=autoencoder,
            neural_ode=neural_ode,
            experiment_name=config_dict['experiment_name'],
            use_wandb=config_dict['use_wandb'],
            wandb_project=config_dict['wandb_project'],
            use_gpu=config_dict['use_gpu'],
            mixed_precision=config_dict['mixed_precision']
        )
    
    def __str__(self) -> str:
        """Pretty print configuration"""
        lines = [
            "="*60,
            "TRAINING CONFIGURATION",
            "="*60,
            f"\nExperiment: {self.experiment_name}",
            f"\nSystem: {self.system.system_type}",
            f"  Parameters: σ={self.system.sigma}, ρ={self.system.rho}, β={self.system.beta:.3f}",
            f"\nData:",
            f"  Train trajectories: {self.data.n_trajectories_train:,}",
            f"  Sequence length: {self.data.seq_length}",
            f"\nAutoencoder:",
            f"  Type: {self.autoencoder.encoder_type}",
            f"  Latent dim: {self.autoencoder.latent_dim}",
            f"  Batch size: {self.autoencoder.batch_size}",
            f"  Epochs: {self.autoencoder.epochs}",
            f"\nNeural ODE:",
            f"  Hidden dims: {self.neural_ode.hidden_dims}",
            f"  Learning rate: {self.neural_ode.learning_rate}",
            f"\nHardware:",
            f"  GPU: {self.use_gpu}",
            f"  Mixed precision: {self.mixed_precision}",
            "="*60
        ]
        return "\n".join(lines)


# Default configurations
def get_lorenz_config() -> TrainingConfig:
    """Get default configuration for Lorenz system"""
    config = TrainingConfig(
        experiment_name='lorenz_baseline',
        system=SystemConfig(system_type='lorenz')
    )
    return config


def get_rossler_config() -> TrainingConfig:
    """Get default configuration for Rössler system"""
    config = TrainingConfig(
        experiment_name='rossler_baseline',
        system=SystemConfig(
            system_type='rossler',
            t_span=(0.0, 100.0)
        )
    )
    config.data.train_file = 'rossler_train.npz'
    return config


def get_quick_test_config() -> TrainingConfig:
    """Get quick test configuration (small dataset, few epochs)"""
    config = TrainingConfig(
        experiment_name='quick_test'
    )
    config.data.n_trajectories_train = 100
    config.data.n_trajectories_val = 20
    config.autoencoder.epochs = 5
    config.neural_ode.epochs = 5
    return config


if __name__ == '__main__':
    # Example: Create and save default config
    config = get_lorenz_config()
    print(config)
    
    # Save to YAML
    os.makedirs('configs', exist_ok=True)
    config.save_yaml('configs/lorenz_default.yaml')
    
    # Load back
    loaded_config = TrainingConfig.load_yaml('configs/lorenz_default.yaml')
    print("\n✓ Configuration saved and loaded successfully!")