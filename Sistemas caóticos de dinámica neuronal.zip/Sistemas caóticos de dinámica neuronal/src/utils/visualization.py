"""
Visualization utilities for chaotic systems
3D attractor plots, phase space, and comparative visualizations
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from typing import Optional, List


def plot_attractor_3d(
    trajectory: np.ndarray,
    title: str = "Chaotic Attractor",
    save_path: Optional[str] = None,
    color_by_time: bool = True
):
    """
    Plot 3D attractor using Plotly
    
    Args:
        trajectory: Trajectory data (n_steps, 3)
        title: Plot title
        save_path: Path to save HTML file
        color_by_time: Color points by time index
    """
    x, y, z = trajectory[:, 0], trajectory[:, 1], trajectory[:, 2]
    
    if color_by_time:
        colors = np.arange(len(x))
        colorscale = 'Viridis'
    else:
        colors = 'blue'
        colorscale = None
    
    fig = go.Figure(data=[go.Scatter3d(
        x=x, y=y, z=z,
        mode='lines',
        line=dict(
            color=colors if color_by_time else None,
            colorscale=colorscale,
            width=2
        ),
        name='Trajectory'
    )])
    
    fig.update_layout(
        title=title,
        scene=dict(
            xaxis_title='X',
            yaxis_title='Y',
            zaxis_title='Z',
            camera=dict(
                eye=dict(x=1.5, y=1.5, z=1.5)
            )
        ),
        width=800,
        height=600
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved 3D plot to {save_path}")
    
    fig.show()
    return fig


def plot_comparison_3d(
    trajectory_true: np.ndarray,
    trajectory_pred: np.ndarray,
    title: str = "True vs Predicted Attractor",
    save_path: Optional[str] = None
):
    """
    Plot true and predicted trajectories side by side
    
    Args:
        trajectory_true: True trajectory (n_steps, 3)
        trajectory_pred: Predicted trajectory (n_steps, 3)
        title: Plot title
        save_path: Save path
    """
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=('True Trajectory', 'Predicted Trajectory'),
        specs=[[{'type': 'scatter3d'}, {'type': 'scatter3d'}]]
    )
    
    # True trajectory
    fig.add_trace(
        go.Scatter3d(
            x=trajectory_true[:, 0],
            y=trajectory_true[:, 1],
            z=trajectory_true[:, 2],
            mode='lines',
            line=dict(color='cyan', width=2),
            name='True'
        ),
        row=1, col=1
    )
    
    # Predicted trajectory
    fig.add_trace(
        go.Scatter3d(
            x=trajectory_pred[:, 0],
            y=trajectory_pred[:, 1],
            z=trajectory_pred[:, 2],
            mode='lines',
            line=dict(color='magenta', width=2),
            name='Predicted'
        ),
        row=1, col=2
    )
    
    fig.update_layout(
        title=title,
        width=1400,
        height=600
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved comparison plot to {save_path}")
    
    fig.show()
    return fig


def plot_phase_space_2d(
    trajectory: np.ndarray,
    dims: tuple = (0, 1),
    title: str = "Phase Space",
    save_path: Optional[str] = None
):
    """
    Plot 2D phase space projection
    
    Args:
        trajectory: Trajectory data (n_steps, n_dim)
        dims: Dimensions to plot (e.g., (0, 1) for x-y)
        title: Plot title
        save_path: Save path
    """
    dim_labels = ['X', 'Y', 'Z', 'W']
    
    fig = go.Figure(data=[go.Scatter(
        x=trajectory[:, dims[0]],
        y=trajectory[:, dims[1]],
        mode='lines',
        line=dict(
            color=np.arange(len(trajectory)),
            colorscale='Viridis',
            width=1
        ),
        name='Trajectory'
    )])
    
    fig.update_layout(
        title=title,
        xaxis_title=dim_labels[dims[0]],
        yaxis_title=dim_labels[dims[1]],
        width=700,
        height=600
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved phase space plot to {save_path}")
    
    fig.show()
    return fig


def plot_time_series(
    trajectory: np.ndarray,
    dt: float = 0.01,
    title: str = "Time Series",
    save_path: Optional[str] = None
):
    """
    Plot time series of all dimensions
    
    Args:
        trajectory: Trajectory data (n_steps, n_dim)
        dt: Time step
        title: Plot title
        save_path: Save path
    """
    n_steps, n_dim = trajectory.shape
    t = np.arange(n_steps) * dt
    
    dim_labels = ['X', 'Y', 'Z', 'W'][:n_dim]
    
    fig = go.Figure()
    
    for i in range(n_dim):
        fig.add_trace(go.Scatter(
            x=t,
            y=trajectory[:, i],
            mode='lines',
            name=dim_labels[i],
            line=dict(width=1.5)
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title='Time',
        yaxis_title='Value',
        width=1000,
        height=400,
        hovermode='x unified'
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved time series plot to {save_path}")
    
    fig.show()
    return fig


def plot_error_heatmap(
    true_trajectory: np.ndarray,
    pred_trajectory: np.ndarray,
    dt: float = 0.01,
    title: str = "Prediction Error Heatmap",
    save_path: Optional[str] = None
):
    """
    Plot heatmap of prediction errors over time and dimensions
    
    Args:
        true_trajectory: True trajectory (n_steps, n_dim)
        pred_trajectory: Predicted trajectory (n_steps, n_dim)
        dt: Time step
        title: Plot title
        save_path: Save path
    """
    error = np.abs(true_trajectory - pred_trajectory)
    
    n_steps, n_dim = error.shape
    t = np.arange(n_steps) * dt
    dim_labels = ['X', 'Y', 'Z', 'W'][:n_dim]
    
    fig = go.Figure(data=go.Heatmap(
        z=error.T,
        x=t,
        y=dim_labels,
        colorscale='Reds',
        colorbar=dict(title='Absolute Error')
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title='Time',
        yaxis_title='Dimension',
        width=1000,
        height=400
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved error heatmap to {save_path}")
    
    fig.show()
    return fig


def plot_latent_space(
    latent_codes: np.ndarray,
    labels: Optional[np.ndarray] = None,
    method: str = 'scatter',
    title: str = "Latent Space",
    save_path: Optional[str] = None
):
    """
    Visualize latent space
    
    Args:
        latent_codes: Latent representations (n_samples, latent_dim)
        labels: Optional labels for coloring
        method: 'scatter' or 'density'
        title: Plot title
        save_path: Save path
    """
    latent_dim = latent_codes.shape[1]
    
    if latent_dim == 2:
        # 2D scatter
        fig = go.Figure(data=[go.Scatter(
            x=latent_codes[:, 0],
            y=latent_codes[:, 1],
            mode='markers',
            marker=dict(
                color=labels if labels is not None else 'blue',
                colorscale='Viridis' if labels is not None else None,
                size=3,
                opacity=0.6
            )
        )])
        
        fig.update_layout(
            title=title,
            xaxis_title='Latent Dim 1',
            yaxis_title='Latent Dim 2',
            width=700,
            height=600
        )
        
    elif latent_dim == 3:
        # 3D scatter
        fig = go.Figure(data=[go.Scatter3d(
            x=latent_codes[:, 0],
            y=latent_codes[:, 1],
            z=latent_codes[:, 2],
            mode='markers',
            marker=dict(
                color=labels if labels is not None else 'blue',
                colorscale='Viridis' if labels is not None else None,
                size=2,
                opacity=0.6
            )
        )])
        
        fig.update_layout(
            title=title,
            scene=dict(
                xaxis_title='Latent Dim 1',
                yaxis_title='Latent Dim 2',
                zaxis_title='Latent Dim 3'
            ),
            width=800,
            height=600
        )
    
    else:
        # High-dimensional: plot pairwise
        print(f"Latent dimension {latent_dim} > 3, plotting first 3 dimensions only")
        return plot_latent_space(latent_codes[:, :3], labels, method, title, save_path)
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved latent space plot to {save_path}")
    
    fig.show()
    return fig


def plot_multiple_trajectories(
    trajectories: List[np.ndarray],
    labels: List[str],
    title: str = "Multiple Trajectories",
    save_path: Optional[str] = None,
    dim: int = 0
):
    """
    Plot multiple trajectories for comparison
    
    Args:
        trajectories: List of trajectory arrays
        labels: List of labels for each trajectory
        title: Plot title
        save_path: Save path
        dim: Dimension to plot
    """
    fig = go.Figure()
    
    colors = px.colors.qualitative.Plotly
    
    for i, (traj, label) in enumerate(zip(trajectories, labels)):
        t = np.arange(len(traj)) * 0.01
        fig.add_trace(go.Scatter(
            x=t,
            y=traj[:, dim],
            mode='lines',
            name=label,
            line=dict(color=colors[i % len(colors)], width=2)
        ))
    
    fig.update_layout(
        title=title,
        xaxis_title='Time',
        yaxis_title=f'Dimension {dim}',
        width=1000,
        height=500,
        hovermode='x unified'
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved multi-trajectory plot to {save_path}")
    
    fig.show()
    return fig


def create_dashboard(
    true_trajectory: np.ndarray,
    pred_trajectory: np.ndarray,
    latent_codes: Optional[np.ndarray] = None,
    metrics: Optional[dict] = None,
    save_path: Optional[str] = None
):
    """
    Create comprehensive dashboard with all visualizations
    
    Args:
        true_trajectory: True trajectory
        pred_trajectory: Predicted trajectory
        latent_codes: Latent space representations
        metrics: Dictionary of evaluation metrics
        save_path: Save path for HTML dashboard
    """
    fig = make_subplots(
        rows=3, cols=2,
        subplot_titles=(
            'True Attractor 3D',
            'Predicted Attractor 3D',
            'Time Series Comparison',
            'Error Over Time',
            'Phase Space (X-Y)',
            'Phase Space (Y-Z)'
        ),
        specs=[
            [{'type': 'scatter3d'}, {'type': 'scatter3d'}],
            [{'type': 'scatter'}, {'type': 'scatter'}],
            [{'type': 'scatter'}, {'type': 'scatter'}]
        ],
        vertical_spacing=0.12,
        horizontal_spacing=0.1
    )
    
    # 3D attractors
    fig.add_trace(go.Scatter3d(
        x=true_trajectory[:, 0], y=true_trajectory[:, 1], z=true_trajectory[:, 2],
        mode='lines', line=dict(color='cyan', width=2), name='True'
    ), row=1, col=1)
    
    fig.add_trace(go.Scatter3d(
        x=pred_trajectory[:, 0], y=pred_trajectory[:, 1], z=pred_trajectory[:, 2],
        mode='lines', line=dict(color='magenta', width=2), name='Predicted'
    ), row=1, col=2)
    
    # Time series
    t = np.arange(len(true_trajectory)) * 0.01
    fig.add_trace(go.Scatter(x=t, y=true_trajectory[:, 0], name='True X', line=dict(color='blue')), row=2, col=1)
    fig.add_trace(go.Scatter(x=t, y=pred_trajectory[:, 0], name='Pred X', line=dict(color='red', dash='dash')), row=2, col=1)
    
    # Error
    error = np.linalg.norm(true_trajectory - pred_trajectory, axis=1)
    fig.add_trace(go.Scatter(x=t, y=error, name='Error', line=dict(color='red')), row=2, col=2)
    
    # Phase spaces
    fig.add_trace(go.Scatter(x=true_trajectory[:, 0], y=true_trajectory[:, 1], mode='lines', name='True XY', line=dict(color='cyan')), row=3, col=1)
    fig.add_trace(go.Scatter(x=pred_trajectory[:, 0], y=pred_trajectory[:, 1], mode='lines', name='Pred XY', line=dict(color='magenta', dash='dash')), row=3, col=1)
    
    fig.add_trace(go.Scatter(x=true_trajectory[:, 1], y=true_trajectory[:, 2], mode='lines', name='True YZ', line=dict(color='cyan')), row=3, col=2)
    fig.add_trace(go.Scatter(x=pred_trajectory[:, 1], y=pred_trajectory[:, 2], mode='lines', name='Pred YZ', line=dict(color='magenta', dash='dash')), row=3, col=2)
    
    # Add metrics as annotation if provided
    if metrics:
        metrics_text = f"MSE: {metrics.get('mse', 0):.6f}<br>"
        metrics_text += f"Lyapunov Corr: {metrics.get('lyapunov_correlation', 0):.4f}"
        
        fig.add_annotation(
            text=metrics_text,
            xref="paper", yref="paper",
            x=0.5, y=0.98,
            showarrow=False,
            font=dict(size=12),
            bgcolor="rgba(255, 255, 255, 0.8)"
        )
    
    fig.update_layout(
        title="Chaotic System Evaluation Dashboard",
        height=1200,
        width=1400,
        showlegend=True
    )
    
    if save_path:
        fig.write_html(save_path)
        print(f"✓ Saved dashboard to {save_path}")
    
    fig.show()
    return fig


if __name__ == '__main__':
    # Test visualizations
    print("Testing visualization utilities...")
    
    # Generate dummy Lorenz-like data
    t = np.linspace(0, 50, 5000)
    x = 10 * np.sin(t)
    y = 15 * np.cos(t * 1.1)
    z = 5 * np.sin(t * 0.9) + 20
    
    trajectory = np.column_stack([x, y, z])
    
    # Test 3D plot
    plot_attractor_3d(trajectory, title="Test Attractor")
    
    print("✓ Visualization tests complete!")