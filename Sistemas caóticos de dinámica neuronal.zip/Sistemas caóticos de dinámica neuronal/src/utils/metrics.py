"""
Evaluation metrics for chaotic systems
Includes reconstruction error, Lyapunov exponents, attractor metrics
"""

import numpy as np
from scipy.spatial.distance import cdist
from scipy.stats import wasserstein_distance
from typing import Tuple, Optional
import warnings


def reconstruction_mse(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray
) -> float:
    """
    Mean Squared Error between trajectories
    
    Args:
        true_trajectories: Ground truth (n_samples, n_steps, n_dim)
        predicted_trajectories: Predictions (n_samples, n_steps, n_dim)
    
    Returns:
        MSE value
    """
    return np.mean((true_trajectories - predicted_trajectories) ** 2)


def reconstruction_mae(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray
) -> float:
    """Mean Absolute Error between trajectories"""
    return np.mean(np.abs(true_trajectories - predicted_trajectories))


def temporal_correlation(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray
) -> float:
    """
    Compute average temporal correlation coefficient
    
    Returns:
        Average correlation across all dimensions and samples
    """
    n_samples, n_steps, n_dim = true_trajectories.shape
    
    correlations = []
    for i in range(n_samples):
        for d in range(n_dim):
            corr = np.corrcoef(
                true_trajectories[i, :, d],
                predicted_trajectories[i, :, d]
            )[0, 1]
            if not np.isnan(corr):
                correlations.append(corr)
    
    return np.mean(correlations)


def compute_lyapunov_exponent(
    trajectory: np.ndarray,
    dt: float = 0.01,
    max_lag: int = 100
) -> float:
    """
    Estimate largest Lyapunov exponent from trajectory
    Using Rosenstein's algorithm (1993)
    
    Args:
        trajectory: Time series (n_steps, n_dim)
        dt: Time step
        max_lag: Maximum lag for computation
    
    Returns:
        Largest Lyapunov exponent
    """
    n_steps, n_dim = trajectory.shape
    
    # Find nearest neighbors
    distances = cdist(trajectory[:-max_lag], trajectory[:-max_lag])
    np.fill_diagonal(distances, np.inf)
    
    nearest_idx = np.argmin(distances, axis=1)
    
    # Track divergence
    divergences = []
    
    for lag in range(1, max_lag):
        valid_pairs = (nearest_idx + lag < n_steps) & (np.arange(len(nearest_idx)) + lag < n_steps)
        
        if not valid_pairs.any():
            break
        
        current_idx = np.arange(len(nearest_idx))[valid_pairs]
        neighbor_idx = nearest_idx[valid_pairs]
        
        current_points = trajectory[current_idx + lag]
        neighbor_points = trajectory[neighbor_idx + lag]
        
        dists = np.linalg.norm(current_points - neighbor_points, axis=1)
        
        # Filter out zero distances
        valid_dists = dists[dists > 1e-10]
        
        if len(valid_dists) > 0:
            divergences.append(np.mean(np.log(valid_dists)))
    
    if len(divergences) < 10:
        warnings.warn("Not enough valid divergence points for Lyapunov computation")
        return 0.0
    
    # Linear fit to get exponent
    lags = np.arange(1, len(divergences) + 1) * dt
    lyapunov = np.polyfit(lags, divergences, 1)[0]
    
    return lyapunov


def lyapunov_preservation_score(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray,
    dt: float = 0.01,
    n_samples: int = 10
) -> Tuple[float, float, float]:
    """
    Compare Lyapunov exponents between true and predicted trajectories
    
    Args:
        true_trajectories: Ground truth (n_traj, n_steps, n_dim)
        predicted_trajectories: Predictions (n_traj, n_steps, n_dim)
        dt: Time step
        n_samples: Number of trajectories to sample
    
    Returns:
        mean_true_lyap: Average Lyapunov from true data
        mean_pred_lyap: Average Lyapunov from predictions
        correlation: Correlation between the two
    """
    n_traj = min(len(true_trajectories), n_samples)
    indices = np.random.choice(len(true_trajectories), n_traj, replace=False)
    
    true_lyaps = []
    pred_lyaps = []
    
    for idx in indices:
        try:
            true_lyap = compute_lyapunov_exponent(true_trajectories[idx], dt)
            pred_lyap = compute_lyapunov_exponent(predicted_trajectories[idx], dt)
            
            true_lyaps.append(true_lyap)
            pred_lyaps.append(pred_lyap)
        except:
            continue
    
    if len(true_lyaps) == 0:
        return 0.0, 0.0, 0.0
    
    mean_true = np.mean(true_lyaps)
    mean_pred = np.mean(pred_lyaps)
    
    correlation = np.corrcoef(true_lyaps, pred_lyaps)[0, 1] if len(true_lyaps) > 1 else 0.0
    
    return mean_true, mean_pred, correlation


def attractor_distance(
    true_points: np.ndarray,
    predicted_points: np.ndarray,
    metric: str = 'hausdorff'
) -> float:
    """
    Measure distance between two attractors
    
    Args:
        true_points: Points from true attractor (n_points, n_dim)
        predicted_points: Points from predicted attractor (n_points, n_dim)
        metric: 'hausdorff' or 'wasserstein'
    
    Returns:
        Distance between attractors
    """
    if metric == 'hausdorff':
        # Hausdorff distance
        d1 = cdist(true_points, predicted_points).min(axis=1).max()
        d2 = cdist(predicted_points, true_points).min(axis=1).max()
        return max(d1, d2)
    
    elif metric == 'wasserstein':
        # 1D Wasserstein distance (per dimension, then average)
        distances = []
        for dim in range(true_points.shape[1]):
            dist = wasserstein_distance(true_points[:, dim], predicted_points[:, dim])
            distances.append(dist)
        return np.mean(distances)
    
    else:
        raise ValueError(f"Unknown metric: {metric}")


def energy_conservation_error(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray
) -> float:
    """
    Measure energy conservation error
    Energy defined as E = sum(x_i^2)
    
    Returns:
        Average relative energy difference
    """
    true_energy = np.sum(true_trajectories ** 2, axis=-1)
    pred_energy = np.sum(predicted_trajectories ** 2, axis=-1)
    
    relative_error = np.abs(true_energy - pred_energy) / (true_energy + 1e-8)
    
    return np.mean(relative_error)


def prediction_horizon(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray,
    threshold: float = 0.1,
    dt: float = 0.01
) -> float:
    """
    Compute valid prediction horizon
    Time until error exceeds threshold
    
    Args:
        true_trajectories: Ground truth (n_samples, n_steps, n_dim)
        predicted_trajectories: Predictions (n_samples, n_steps, n_dim)
        threshold: Error threshold
        dt: Time step
    
    Returns:
        Average prediction horizon in time units
    """
    errors = np.linalg.norm(
        true_trajectories - predicted_trajectories,
        axis=-1
    )
    
    horizons = []
    
    for error_series in errors:
        # Find first time error exceeds threshold
        exceed_idx = np.where(error_series > threshold)[0]
        
        if len(exceed_idx) > 0:
            horizon = exceed_idx[0] * dt
        else:
            horizon = len(error_series) * dt
        
        horizons.append(horizon)
    
    return np.mean(horizons)


def compute_all_metrics(
    true_trajectories: np.ndarray,
    predicted_trajectories: np.ndarray,
    dt: float = 0.01,
    verbose: bool = True
) -> dict:
    """
    Compute all evaluation metrics
    
    Returns:
        Dictionary of metrics
    """
    metrics = {}
    
    # Reconstruction metrics
    metrics['mse'] = reconstruction_mse(true_trajectories, predicted_trajectories)
    metrics['mae'] = reconstruction_mae(true_trajectories, predicted_trajectories)
    metrics['temporal_correlation'] = temporal_correlation(true_trajectories, predicted_trajectories)
    
    # Lyapunov preservation
    true_lyap, pred_lyap, lyap_corr = lyapunov_preservation_score(
        true_trajectories, predicted_trajectories, dt
    )
    metrics['true_lyapunov'] = true_lyap
    metrics['pred_lyapunov'] = pred_lyap
    metrics['lyapunov_correlation'] = lyap_corr
    
    # Attractor distance
    true_flat = true_trajectories.reshape(-1, true_trajectories.shape[-1])
    pred_flat = predicted_trajectories.reshape(-1, predicted_trajectories.shape[-1])
    
    # Sample for computational efficiency
    n_sample = min(10000, len(true_flat))
    sample_idx = np.random.choice(len(true_flat), n_sample, replace=False)
    
    metrics['hausdorff_distance'] = attractor_distance(
        true_flat[sample_idx], pred_flat[sample_idx], 'hausdorff'
    )
    metrics['wasserstein_distance'] = attractor_distance(
        true_flat[sample_idx], pred_flat[sample_idx], 'wasserstein'
    )
    
    # Energy conservation
    metrics['energy_error'] = energy_conservation_error(
        true_trajectories, predicted_trajectories
    )
    
    # Prediction horizon
    metrics['prediction_horizon'] = prediction_horizon(
        true_trajectories, predicted_trajectories, threshold=0.1, dt=dt
    )
    
    if verbose:
        print("\n" + "="*60)
        print("EVALUATION METRICS")
        print("="*60)
        print(f"Reconstruction MSE:        {metrics['mse']:.6f}")
        print(f"Reconstruction MAE:        {metrics['mae']:.6f}")
        print(f"Temporal Correlation:      {metrics['temporal_correlation']:.4f}")
        print(f"\nTrue Lyapunov Exponent:    {metrics['true_lyapunov']:.4f}")
        print(f"Predicted Lyapunov Exp:    {metrics['pred_lyapunov']:.4f}")
        print(f"Lyapunov Correlation:      {metrics['lyapunov_correlation']:.4f}")
        print(f"\nHausdorff Distance:        {metrics['hausdorff_distance']:.6f}")
        print(f"Wasserstein Distance:      {metrics['wasserstein_distance']:.6f}")
        print(f"\nEnergy Conservation Err:   {metrics['energy_error']:.6f}")
        print(f"Prediction Horizon:        {metrics['prediction_horizon']:.2f} time units")
        print("="*60)
    
    return metrics


if __name__ == '__main__':
    # Test metrics
    print("Testing evaluation metrics...")
    
    # Generate dummy data
    n_samples, n_steps, n_dim = 10, 100, 3
    true_traj = np.random.randn(n_samples, n_steps, n_dim)
    pred_traj = true_traj + np.random.randn(*true_traj.shape) * 0.1
    
    # Compute metrics
    metrics = compute_all_metrics(true_traj, pred_traj, dt=0.01, verbose=True)
    
    print("\n✓ All metrics computed successfully!")