#!/usr/bin/env python3
"""
Advanced Visualization Generator
Creates comprehensive visualizations for the Neural Dynamics project
"""

import os
import sys
sys.path.insert(0, 'src')

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
from matplotlib.animation import FuncAnimation
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json

from models.autoencoder import ChaoticAutoencoder, prepare_sequences
from utils.metrics import compute_all_metrics
from utils.visualization import plot_comparison_3d


def setup_style():
    """Configure plotting style"""
    plt.style.use('seaborn-v0_8-darkgrid')
    sns.set_palette("husl")
    
    # Custom colors
    colors = {
        'primary': '#00BFFF',    # Deep Sky Blue
        'secondary': '#FF1493',  # Deep Pink
        'accent': '#32CD32',     # Lime Green
        'background': '#0F1419', # Dark background
        'text': '#E6EDF3'        # Light text
    }
    return colors


def create_output_dirs():
    """Create output directories"""
    dirs = [
        'results/figures/3d',
        'results/figures/2d',
        'results/figures/comparisons',
        'results/figures/analysis',
        'results/figures/interactive'
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)


def load_data_and_model():
    """Load trained model and data"""
    print("Loading model and data...")
    
    # Load autoencoder
    autoencoder = ChaoticAutoencoder(
        input_dim=3,
        seq_length=100,
        latent_dim=3,
        encoder_type='hybrid'
    )
    
    try:
        autoencoder.load('models/autoencoder_best.weights.h5')
    except:
        autoencoder.load('models/autoencoder_final.weights.h5')
    
    # Load normalization
    norm_data = np.load('models/autoencoder_norm.npz')
    mean, std = norm_data['mean'], norm_data['std']
    
    # Load data
    data = np.load('data/lorenz_train.npz')
    trajectories = data['trajectories']
    
    # Prepare test data
    test_trajectories = trajectories[-10:]
    test_trajectories_norm = (test_trajectories - mean) / (std + 1e-8)
    test_sequences = prepare_sequences(test_trajectories_norm, seq_length=100, stride=50)
    X_test = test_sequences[:10]
    
    # Generate predictions
    X_recon = autoencoder.reconstruct(X_test)
    
    # Denormalize
    X_test_denorm = X_test * (std + 1e-8) + mean
    X_recon_denorm = X_recon * (std + 1e-8) + mean
    
    # Get latent codes
    latent_codes = autoencoder.encode(X_test)
    
    print(f"✓ Loaded {len(X_test)} test samples")
    
    return autoencoder, X_test_denorm, X_recon_denorm, latent_codes, mean, std


def viz_1_multi_angle_3d(X_test, X_recon, save_dir):
    """Multiple viewing angles of the attractor"""
    print("Creating multi-angle 3D views...")
    
    fig = plt.figure(figsize=(20, 15))
    
    angles = [
        (30, 45, "Default View"),
        (0, 0, "Front View (YZ plane)"),
        (0, 90, "Side View (XZ plane)"),
        (90, 0, "Top View (XY plane)")
    ]
    
    for idx, (elev, azim, title) in enumerate(angles, 1):
        ax = fig.add_subplot(2, 2, idx, projection='3d')
        
        # Plot true
        traj_true = X_test[0]
        ax.plot(traj_true[:, 0], traj_true[:, 1], traj_true[:, 2],
                color='cyan', linewidth=1.5, alpha=0.7, label='True')
        
        # Plot reconstructed
        traj_recon = X_recon[0]
        ax.plot(traj_recon[:, 0], traj_recon[:, 1], traj_recon[:, 2],
                color='magenta', linewidth=1.5, alpha=0.7, linestyle='--', label='Predicted')
        
        ax.view_init(elev=elev, azim=azim)
        ax.set_xlabel('X', fontsize=10)
        ax.set_ylabel('Y', fontsize=10)
        ax.set_zlabel('Z', fontsize=10)
        ax.set_title(title, fontsize=12, fontweight='bold')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
    
    plt.suptitle('Lorenz Attractor - Multiple Viewing Angles', 
                 fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/3d/multi_angle_attractor.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved multi_angle_attractor.png")


def viz_2_phase_portraits(X_test, X_recon, save_dir):
    """2D phase portraits for all dimension pairs"""
    print("Creating phase portraits...")
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    
    dim_pairs = [(0, 1), (0, 2), (1, 2)]
    dim_names = [('X', 'Y'), ('X', 'Z'), ('Y', 'Z')]
    
    for i, (pair, names) in enumerate(zip(dim_pairs, dim_names)):
        # True
        ax = axes[0, i]
        for traj in X_test[:5]:
            ax.plot(traj[:, pair[0]], traj[:, pair[1]], 
                   linewidth=1, alpha=0.6)
        ax.set_xlabel(names[0], fontsize=12, fontweight='bold')
        ax.set_ylabel(names[1], fontsize=12, fontweight='bold')
        ax.set_title(f'True: {names[0]}-{names[1]} Plane', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # Predicted
        ax = axes[1, i]
        for traj in X_recon[:5]:
            ax.plot(traj[:, pair[0]], traj[:, pair[1]], 
                   linewidth=1, alpha=0.6)
        ax.set_xlabel(names[0], fontsize=12, fontweight='bold')
        ax.set_ylabel(names[1], fontsize=12, fontweight='bold')
        ax.set_title(f'Predicted: {names[0]}-{names[1]} Plane', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3)
    
    plt.suptitle('Phase Space Portraits - All Projections', 
                 fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/2d/phase_portraits.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved phase_portraits.png")


def viz_3_trajectory_ensemble(X_test, X_recon, save_dir):
    """Ensemble of multiple trajectories"""
    print("Creating trajectory ensemble...")
    
    fig = plt.figure(figsize=(16, 12))
    ax = fig.add_subplot(111, projection='3d')
    
    # True trajectories
    colors_true = plt.cm.Blues(np.linspace(0.3, 0.9, len(X_test)))
    for i, traj in enumerate(X_test):
        ax.plot(traj[:, 0], traj[:, 1], traj[:, 2],
               color=colors_true[i], linewidth=1.5, alpha=0.5)
    
    # Predicted trajectories
    colors_pred = plt.cm.Reds(np.linspace(0.3, 0.9, len(X_recon)))
    for i, traj in enumerate(X_recon):
        ax.plot(traj[:, 0], traj[:, 1], traj[:, 2],
               color=colors_pred[i], linewidth=1.5, alpha=0.5, linestyle='--')
    
    # Legend
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], color='blue', linewidth=2, label='True (10 samples)'),
        Line2D([0], [0], color='red', linewidth=2, linestyle='--', label='Predicted (10 samples)')
    ]
    ax.legend(handles=legend_elements, fontsize=12)
    
    ax.set_xlabel('X', fontsize=12)
    ax.set_ylabel('Y', fontsize=12)
    ax.set_zlabel('Z', fontsize=12)
    ax.set_title('Trajectory Ensemble: True vs Predicted', fontsize=16, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig(f'{save_dir}/3d/trajectory_ensemble.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved trajectory_ensemble.png")


def viz_4_error_evolution(X_test, X_recon, save_dir):
    """Error evolution over time"""
    print("Creating error evolution plots...")
    
    # Compute errors
    errors = np.abs(X_test - X_recon)
    error_norms = np.linalg.norm(errors, axis=2)
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # Individual trajectories
    ax = axes[0, 0]
    t = np.arange(errors.shape[1]) * 0.01
    for i in range(min(5, len(error_norms))):
        ax.plot(t, error_norms[i], linewidth=2, alpha=0.7, label=f'Traj {i+1}')
    ax.set_xlabel('Time', fontsize=12)
    ax.set_ylabel('Error Norm', fontsize=12)
    ax.set_title('Error Evolution per Trajectory', fontsize=13, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    
    # Average error with std
    ax = axes[0, 1]
    mean_error = error_norms.mean(axis=0)
    std_error = error_norms.std(axis=0)
    ax.plot(t, mean_error, linewidth=2, color='red', label='Mean')
    ax.fill_between(t, mean_error - std_error, mean_error + std_error,
                    alpha=0.3, color='red', label='±1 STD')
    ax.set_xlabel('Time', fontsize=12)
    ax.set_ylabel('Error Norm', fontsize=12)
    ax.set_title('Average Error with Uncertainty', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    
    # Cumulative error
    ax = axes[1, 0]
    cumulative_error = np.cumsum(error_norms, axis=1)
    ax.plot(t, cumulative_error.T, linewidth=1, alpha=0.5)
    ax.set_xlabel('Time', fontsize=12)
    ax.set_ylabel('Cumulative Error', fontsize=12)
    ax.set_title('Cumulative Error Growth', fontsize=13, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Error per dimension
    ax = axes[1, 1]
    for dim, name in enumerate(['X', 'Y', 'Z']):
        dim_error = errors[:, :, dim].mean(axis=0)
        ax.plot(t, dim_error, linewidth=2, label=f'{name} dimension')
    ax.set_xlabel('Time', fontsize=12)
    ax.set_ylabel('Mean Absolute Error', fontsize=12)
    ax.set_title('Error by Dimension', fontsize=13, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.suptitle('Error Analysis', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/analysis/error_evolution.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved error_evolution.png")


def viz_5_correlation_matrices(X_test, X_recon, save_dir):
    """Correlation analysis"""
    print("Creating correlation matrices...")
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # True correlations
    true_flat = X_test.reshape(-1, 3)
    corr_true = np.corrcoef(true_flat.T)
    
    im = axes[0].imshow(corr_true, cmap='coolwarm', vmin=-1, vmax=1)
    axes[0].set_title('True Correlations', fontsize=13, fontweight='bold')
    axes[0].set_xticks([0, 1, 2])
    axes[0].set_yticks([0, 1, 2])
    axes[0].set_xticklabels(['X', 'Y', 'Z'])
    axes[0].set_yticklabels(['X', 'Y', 'Z'])
    for i in range(3):
        for j in range(3):
            axes[0].text(j, i, f'{corr_true[i, j]:.2f}',
                       ha="center", va="center", color="black", fontsize=12)
    
    # Predicted correlations
    pred_flat = X_recon.reshape(-1, 3)
    corr_pred = np.corrcoef(pred_flat.T)
    
    axes[1].imshow(corr_pred, cmap='coolwarm', vmin=-1, vmax=1)
    axes[1].set_title('Predicted Correlations', fontsize=13, fontweight='bold')
    axes[1].set_xticks([0, 1, 2])
    axes[1].set_yticks([0, 1, 2])
    axes[1].set_xticklabels(['X', 'Y', 'Z'])
    axes[1].set_yticklabels(['X', 'Y', 'Z'])
    for i in range(3):
        for j in range(3):
            axes[1].text(j, i, f'{corr_pred[i, j]:.2f}',
                       ha="center", va="center", color="black", fontsize=12)
    
    # Difference
    corr_diff = np.abs(corr_true - corr_pred)
    im = axes[2].imshow(corr_diff, cmap='Reds', vmin=0, vmax=0.5)
    axes[2].set_title('Absolute Difference', fontsize=13, fontweight='bold')
    axes[2].set_xticks([0, 1, 2])
    axes[2].set_yticks([0, 1, 2])
    axes[2].set_xticklabels(['X', 'Y', 'Z'])
    axes[2].set_yticklabels(['X', 'Y', 'Z'])
    for i in range(3):
        for j in range(3):
            axes[2].text(j, i, f'{corr_diff[i, j]:.2f}',
                       ha="center", va="center", color="black", fontsize=12)
    
    plt.colorbar(im, ax=axes[2])
    plt.suptitle('Correlation Analysis', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/analysis/correlation_matrices.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved correlation_matrices.png")


def viz_6_poincare_sections(X_test, X_recon, save_dir):
    """Poincaré sections"""
    print("Creating Poincaré sections...")
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Function to compute Poincaré section (Z = 27 plane)
    def compute_poincare(trajectories, z_plane=27):
        points = []
        for traj in trajectories:
            # Find crossings
            for i in range(len(traj)-1):
                if (traj[i, 2] < z_plane and traj[i+1, 2] >= z_plane):
                    # Linear interpolation
                    alpha = (z_plane - traj[i, 2]) / (traj[i+1, 2] - traj[i, 2])
                    x = traj[i, 0] + alpha * (traj[i+1, 0] - traj[i, 0])
                    y = traj[i, 1] + alpha * (traj[i+1, 1] - traj[i, 1])
                    points.append([x, y])
        return np.array(points)
    
    # True
    poincare_true = compute_poincare(X_test)
    axes[0].scatter(poincare_true[:, 0], poincare_true[:, 1], 
                   s=10, alpha=0.6, c='cyan')
    axes[0].set_xlabel('X', fontsize=12)
    axes[0].set_ylabel('Y', fontsize=12)
    axes[0].set_title('True Poincaré Section (Z=27)', fontsize=13, fontweight='bold')
    axes[0].grid(True, alpha=0.3)
    
    # Predicted
    poincare_pred = compute_poincare(X_recon)
    axes[1].scatter(poincare_pred[:, 0], poincare_pred[:, 1], 
                   s=10, alpha=0.6, c='magenta')
    axes[1].set_xlabel('X', fontsize=12)
    axes[1].set_ylabel('Y', fontsize=12)
    axes[1].set_title('Predicted Poincaré Section (Z=27)', fontsize=13, fontweight='bold')
    axes[1].grid(True, alpha=0.3)
    
    plt.suptitle('Poincaré Sections Analysis', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/analysis/poincare_sections.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved poincare_sections.png")


def viz_7_power_spectra(X_test, X_recon, save_dir):
    """Power spectral density analysis"""
    print("Creating power spectra...")
    
    fig, axes = plt.subplots(3, 2, figsize=(16, 14))
    
    dt = 0.01
    dim_names = ['X', 'Y', 'Z']
    
    for dim in range(3):
        # True spectrum
        ax = axes[dim, 0]
        for traj in X_test[:5]:
            freqs = np.fft.rfftfreq(len(traj), dt)
            spectrum = np.abs(np.fft.rfft(traj[:, dim]))
            ax.semilogy(freqs, spectrum, linewidth=1, alpha=0.6)
        ax.set_xlabel('Frequency (Hz)', fontsize=11)
        ax.set_ylabel('Power', fontsize=11)
        ax.set_title(f'True - {dim_names[dim]} Dimension', fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 5)
        
        # Predicted spectrum
        ax = axes[dim, 1]
        for traj in X_recon[:5]:
            freqs = np.fft.rfftfreq(len(traj), dt)
            spectrum = np.abs(np.fft.rfft(traj[:, dim]))
            ax.semilogy(freqs, spectrum, linewidth=1, alpha=0.6)
        ax.set_xlabel('Frequency (Hz)', fontsize=11)
        ax.set_ylabel('Power', fontsize=11)
        ax.set_title(f'Predicted - {dim_names[dim]} Dimension', fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 5)
    
    plt.suptitle('Power Spectral Density Analysis', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/analysis/power_spectra.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved power_spectra.png")


def viz_8_interactive_3d_comparison(X_test, X_recon, save_dir):
    """Interactive 3D comparison with Plotly"""
    print("Creating interactive 3D comparison...")
    
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=('True Trajectory', 'Predicted Trajectory'),
        specs=[[{'type': 'scatter3d'}, {'type': 'scatter3d'}]]
    )
    
    # True
    for i in range(min(3, len(X_test))):
        traj = X_test[i]
        fig.add_trace(
            go.Scatter3d(
                x=traj[:, 0], y=traj[:, 1], z=traj[:, 2],
                mode='lines',
                line=dict(width=2, color=f'rgb({i*80}, {200-i*50}, 255)'),
                name=f'True {i+1}',
                showlegend=True
            ),
            row=1, col=1
        )
    
    # Predicted
    for i in range(min(3, len(X_recon))):
        traj = X_recon[i]
        fig.add_trace(
            go.Scatter3d(
                x=traj[:, 0], y=traj[:, 1], z=traj[:, 2],
                mode='lines',
                line=dict(width=2, color=f'rgb(255, {i*80}, {200-i*50})'),
                name=f'Pred {i+1}',
                showlegend=True
            ),
            row=1, col=2
        )
    
    fig.update_layout(
        title='Interactive 3D Attractor Comparison',
        height=700,
        scene=dict(
            xaxis_title='X',
            yaxis_title='Y',
            zaxis_title='Z'
        ),
        scene2=dict(
            xaxis_title='X',
            yaxis_title='Y',
            zaxis_title='Z'
        )
    )
    
    fig.write_html(f'{save_dir}/interactive/3d_comparison.html')
    print("  ✓ Saved 3d_comparison.html")


def viz_9_statistical_summary(X_test, X_recon, save_dir):
    """Statistical summary dashboard"""
    print("Creating statistical summary...")
    
    fig = plt.figure(figsize=(20, 12))
    gs = fig.add_gridspec(3, 4, hspace=0.3, wspace=0.3)
    
    # 1. Mean values
    ax = fig.add_subplot(gs[0, 0])
    means_true = X_test.mean(axis=(0, 1))
    means_pred = X_recon.mean(axis=(0, 1))
    x_pos = np.arange(3)
    width = 0.35
    ax.bar(x_pos - width/2, means_true, width, label='True', alpha=0.8)
    ax.bar(x_pos + width/2, means_pred, width, label='Predicted', alpha=0.8)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(['X', 'Y', 'Z'])
    ax.set_ylabel('Mean Value')
    ax.set_title('Mean Values by Dimension', fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 2. Standard deviations
    ax = fig.add_subplot(gs[0, 1])
    stds_true = X_test.std(axis=(0, 1))
    stds_pred = X_recon.std(axis=(0, 1))
    ax.bar(x_pos - width/2, stds_true, width, label='True', alpha=0.8)
    ax.bar(x_pos + width/2, stds_pred, width, label='Predicted', alpha=0.8)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(['X', 'Y', 'Z'])
    ax.set_ylabel('Standard Deviation')
    ax.set_title('Standard Deviations', fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 3. Min/Max ranges
    ax = fig.add_subplot(gs[0, 2])
    ranges_true = X_test.max(axis=(0, 1)) - X_test.min(axis=(0, 1))
    ranges_pred = X_recon.max(axis=(0, 1)) - X_recon.min(axis=(0, 1))
    ax.bar(x_pos - width/2, ranges_true, width, label='True', alpha=0.8)
    ax.bar(x_pos + width/2, ranges_pred, width, label='Predicted', alpha=0.8)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(['X', 'Y', 'Z'])
    ax.set_ylabel('Range')
    ax.set_title('Value Ranges', fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 4. Error distribution
    ax = fig.add_subplot(gs[0, 3])
    errors = np.abs(X_test - X_recon).flatten()
    ax.hist(errors, bins=50, alpha=0.7, edgecolor='black')
    ax.axvline(errors.mean(), color='red', linestyle='--', linewidth=2, label=f'Mean: {errors.mean():.3f}')
    ax.set_xlabel('Absolute Error')
    ax.set_ylabel('Frequency')
    ax.set_title('Overall Error Distribution', fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 5-7. Distribution comparisons
    for dim, name in enumerate(['X', 'Y', 'Z']):
        ax = fig.add_subplot(gs[1, dim])
        ax.hist(X_test[:, :, dim].flatten(), bins=50, alpha=0.5, label='True', density=True)
        ax.hist(X_recon[:, :, dim].flatten(), bins=50, alpha=0.5, label='Predicted', density=True)
        ax.set_xlabel(f'{name} Value')
        ax.set_ylabel('Density')
        ax.set_title(f'{name} Distribution', fontweight='bold')
        ax.legend()
        ax.grid(True, alpha=0.3)
    
    # 8. Q-Q plot
    ax = fig.add_subplot(gs[1, 3])
    from scipy import stats
    for dim, name, color in zip([0, 1, 2], ['X', 'Y', 'Z'], ['red', 'green', 'blue']):
        true_sorted = np.sort(X_test[:, :, dim].flatten())
        pred_sorted = np.sort(X_recon[:, :, dim].flatten())
        ax.scatter(true_sorted[::10], pred_sorted[::10], s=1, alpha=0.5, label=name, color=color)
    ax.plot([-20, 20], [-20, 20], 'k--', linewidth=2, label='Perfect')
    ax.set_xlabel('True Values')
    ax.set_ylabel('Predicted Values')
    ax.set_title('Q-Q Plot', fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 9-11. Box plots
    for dim, name in enumerate(['X', 'Y', 'Z']):
        ax = fig.add_subplot(gs[2, dim])
        data = [X_test[:, :, dim].flatten(), X_recon[:, :, dim].flatten()]
        bp = ax.boxplot(data, labels=['True', 'Predicted'], patch_artist=True)
        for patch, color in zip(bp['boxes'], ['cyan', 'magenta']):
            patch.set_facecolor(color)
            patch.set_alpha(0.6)
        ax.set_ylabel(f'{name} Value')
        ax.set_title(f'{name} Box Plot', fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')
    
    # 12. Skewness and Kurtosis
    ax = fig.add_subplot(gs[2, 3])
    from scipy.stats import skew, kurtosis
    metrics = []
    for dim in range(3):
        skew_true = skew(X_test[:, :, dim].flatten())
        skew_pred = skew(X_recon[:, :, dim].flatten())
        kurt_true = kurtosis(X_test[:, :, dim].flatten())
        kurt_pred = kurtosis(X_recon[:, :, dim].flatten())
        metrics.append([skew_true, skew_pred, kurt_true, kurt_pred])
    
    metrics = np.array(metrics)
    x_pos = np.arange(3)
    width = 0.2
    ax.bar(x_pos - 1.5*width, metrics[:, 0], width, label='Skew True', alpha=0.8)
    ax.bar(x_pos - 0.5*width, metrics[:, 1], width, label='Skew Pred', alpha=0.8)
    ax.bar(x_pos + 0.5*width, metrics[:, 2], width, label='Kurt True', alpha=0.8)
    ax.bar(x_pos + 1.5*width, metrics[:, 3], width, label='Kurt Pred', alpha=0.8)
    ax.set_xticks(x_pos)
    ax.set_xticklabels(['X', 'Y', 'Z'])
    ax.set_ylabel('Value')
    ax.set_title('Skewness & Kurtosis', fontweight='bold')
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    
    plt.suptitle('Statistical Summary Dashboard', fontsize=18, fontweight='bold')
    plt.savefig(f'{save_dir}/analysis/statistical_summary.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved statistical_summary.png")


def viz_10_latent_space_analysis(latent_codes, save_dir):
    """Comprehensive latent space analysis"""
    print("Creating latent space analysis...")
    
    fig = plt.figure(figsize=(18, 12))
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
    
    # 3D scatter
    if latent_codes.shape[1] >= 3:
        ax = fig.add_subplot(gs[0:2, 0:2], projection='3d')
        scatter = ax.scatter(latent_codes[:, 0], latent_codes[:, 1], latent_codes[:, 2],
                           c=np.arange(len(latent_codes)), cmap='viridis', s=20, alpha=0.6)
        ax.set_xlabel('Latent 1', fontsize=11)
        ax.set_ylabel('Latent 2', fontsize=11)
        ax.set_zlabel('Latent 3', fontsize=11)
        ax.set_title('Latent Space 3D', fontsize=13, fontweight='bold')
        plt.colorbar(scatter, ax=ax, label='Sample Index')
    
    # 2D projections
    projections = [(0, 1), (0, 2), (1, 2)]
    labels = [('L1', 'L2'), ('L1', 'L3'), ('L2', 'L3')]
    
    for idx, (proj, lab) in enumerate(zip(projections, labels)):
        ax = fig.add_subplot(gs[0, 2])
        if idx == 0:
            ax.scatter(latent_codes[:, proj[0]], latent_codes[:, proj[1]], 
                      s=10, alpha=0.5, c=np.arange(len(latent_codes)), cmap='viridis')
            ax.set_xlabel(lab[0], fontsize=10)
            ax.set_ylabel(lab[1], fontsize=10)
            ax.set_title(f'{lab[0]}-{lab[1]} Projection', fontsize=11, fontweight='bold')
            ax.grid(True, alpha=0.3)
    
    # Histograms for each dimension
    for dim in range(min(3, latent_codes.shape[1])):
        ax = fig.add_subplot(gs[1, 2] if dim == 1 else (gs[2, 0] if dim == 0 else gs[2, 1]))
        ax.hist(latent_codes[:, dim], bins=50, alpha=0.7, edgecolor='black')
        ax.set_xlabel(f'Latent Dim {dim+1}', fontsize=10)
        ax.set_ylabel('Frequency', fontsize=10)
        ax.set_title(f'Distribution - Dim {dim+1}', fontsize=11, fontweight='bold')
        ax.grid(True, alpha=0.3)
    
    # Correlation heatmap
    ax = fig.add_subplot(gs[2, 2])
    corr_latent = np.corrcoef(latent_codes.T)
    im = ax.imshow(corr_latent, cmap='coolwarm', vmin=-1, vmax=1)
    ax.set_title('Latent Correlations', fontsize=11, fontweight='bold')
    ax.set_xticks(range(latent_codes.shape[1]))
    ax.set_yticks(range(latent_codes.shape[1]))
    ax.set_xticklabels([f'L{i+1}' for i in range(latent_codes.shape[1])], fontsize=9)
    ax.set_yticklabels([f'L{i+1}' for i in range(latent_codes.shape[1])], fontsize=9)
    for i in range(latent_codes.shape[1]):
        for j in range(latent_codes.shape[1]):
            ax.text(j, i, f'{corr_latent[i, j]:.2f}',
                   ha="center", va="center", color="black", fontsize=9)
    plt.colorbar(im, ax=ax)
    
    plt.suptitle('Latent Space Analysis', fontsize=18, fontweight='bold')
    plt.savefig(f'{save_dir}/analysis/latent_space_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved latent_space_analysis.png")


def viz_11_reconstruction_quality_grid(X_test, X_recon, save_dir):
    """Grid of reconstruction quality samples"""
    print("Creating reconstruction quality grid...")
    
    n_samples = min(6, len(X_test))
    fig = plt.figure(figsize=(20, 3*n_samples))
    
    for i in range(n_samples):
        # 3D true
        ax = fig.add_subplot(n_samples, 4, i*4+1, projection='3d')
        traj = X_test[i]
        ax.plot(traj[:, 0], traj[:, 1], traj[:, 2], linewidth=1, color='cyan')
        ax.set_xlabel('X', fontsize=8)
        ax.set_ylabel('Y', fontsize=8)
        ax.set_zlabel('Z', fontsize=8)
        if i == 0:
            ax.set_title('True 3D', fontsize=10, fontweight='bold')
        ax.view_init(elev=20, azim=45)
        ax.text(0.02, 0.98, 0, f'Sample {i+1}', transform=ax.transAxes,
                fontsize=10, fontweight='bold', va='top')
        
        # 3D predicted
        ax = fig.add_subplot(n_samples, 4, i*4+2, projection='3d')
        traj = X_recon[i]
        ax.plot(traj[:, 0], traj[:, 1], traj[:, 2], linewidth=1, color='magenta')
        ax.set_xlabel('X', fontsize=8)
        ax.set_ylabel('Y', fontsize=8)
        ax.set_zlabel('Z', fontsize=8)
        if i == 0:
            ax.set_title('Predicted 3D', fontsize=10, fontweight='bold')
        ax.view_init(elev=20, azim=45)
        
        # Time series overlay
        ax = fig.add_subplot(n_samples, 4, i*4+3)
        t = np.arange(len(X_test[i])) * 0.01
        ax.plot(t, X_test[i, :, 0], 'b-', linewidth=1.5, alpha=0.7, label='True')
        ax.plot(t, X_recon[i, :, 0], 'r--', linewidth=1.5, alpha=0.7, label='Pred')
        ax.set_xlabel('Time', fontsize=8)
        ax.set_ylabel('X', fontsize=8)
        if i == 0:
            ax.set_title('X Time Series', fontsize=10, fontweight='bold')
            ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        
        # Error
        ax = fig.add_subplot(n_samples, 4, i*4+4)
        error = np.linalg.norm(X_test[i] - X_recon[i], axis=1)
        ax.plot(t, error, 'r-', linewidth=1.5)
        ax.fill_between(t, 0, error, alpha=0.3, color='red')
        ax.set_xlabel('Time', fontsize=8)
        ax.set_ylabel('Error Norm', fontsize=8)
        if i == 0:
            ax.set_title('Reconstruction Error', fontsize=10, fontweight='bold')
        ax.grid(True, alpha=0.3)
    
    plt.suptitle('Reconstruction Quality Grid', fontsize=18, fontweight='bold')
    plt.tight_layout()
    plt.savefig(f'{save_dir}/comparisons/reconstruction_grid.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("  ✓ Saved reconstruction_grid.png")


def viz_12_interactive_dashboard(X_test, X_recon, latent_codes, save_dir):
    """Interactive Plotly dashboard"""
    print("Creating interactive dashboard...")
    
    from plotly.subplots import make_subplots
    
    fig = make_subplots(
        rows=2, cols=3,
        subplot_titles=('3D Attractor', 'Phase Portrait XY', 'Time Series X',
                       'Latent Space', 'Error Evolution', 'Error Histogram'),
        specs=[
            [{'type': 'scatter3d'}, {'type': 'scatter'}, {'type': 'scatter'}],
            [{'type': 'scatter3d'}, {'type': 'scatter'}, {'type': 'histogram'}]
        ],
        vertical_spacing=0.12,
        horizontal_spacing=0.08
    )
    
    # 1. 3D Attractor
    for i in range(min(2, len(X_test))):
        fig.add_trace(
            go.Scatter3d(
                x=X_test[i, :, 0], y=X_test[i, :, 1], z=X_test[i, :, 2],
                mode='lines',
                line=dict(width=2, color='cyan'),
                name=f'True {i+1}',
                showlegend=True
            ),
            row=1, col=1
        )
        fig.add_trace(
            go.Scatter3d(
                x=X_recon[i, :, 0], y=X_recon[i, :, 1], z=X_recon[i, :, 2],
                mode='lines',
                line=dict(width=2, color='magenta', dash='dash'),
                name=f'Pred {i+1}',
                showlegend=True
            ),
            row=1, col=1
        )
    
    # 2. Phase Portrait XY
    fig.add_trace(
        go.Scatter(
            x=X_test[0, :, 0], y=X_test[0, :, 1],
            mode='lines',
            line=dict(width=2, color='cyan'),
            name='True',
            showlegend=False
        ),
        row=1, col=2
    )
    fig.add_trace(
        go.Scatter(
            x=X_recon[0, :, 0], y=X_recon[0, :, 1],
            mode='lines',
            line=dict(width=2, color='magenta', dash='dash'),
            name='Predicted',
            showlegend=False
        ),
        row=1, col=2
    )
    
    # 3. Time Series X
    t = np.arange(len(X_test[0])) * 0.01
    fig.add_trace(
        go.Scatter(
            x=t, y=X_test[0, :, 0],
            mode='lines',
            line=dict(width=2, color='cyan'),
            name='True',
            showlegend=False
        ),
        row=1, col=3
    )
    fig.add_trace(
        go.Scatter(
            x=t, y=X_recon[0, :, 0],
            mode='lines',
            line=dict(width=2, color='magenta', dash='dash'),
            name='Predicted',
            showlegend=False
        ),
        row=1, col=3
    )
    
    # 4. Latent Space
    if latent_codes.shape[1] >= 3:
        fig.add_trace(
            go.Scatter3d(
                x=latent_codes[:, 0], 
                y=latent_codes[:, 1], 
                z=latent_codes[:, 2],
                mode='markers',
                marker=dict(
                    size=3,
                    color=np.arange(len(latent_codes)),
                    colorscale='Viridis',
                    showscale=True
                ),
                name='Latent',
                showlegend=False
            ),
            row=2, col=1
        )
    
    # 5. Error Evolution
    errors = np.linalg.norm(X_test - X_recon, axis=2)
    for i in range(min(3, len(errors))):
        fig.add_trace(
            go.Scatter(
                x=t, y=errors[i],
                mode='lines',
                name=f'Sample {i+1}',
                showlegend=False
            ),
            row=2, col=2
        )
    
    # 6. Error Histogram
    fig.add_trace(
        go.Histogram(
            x=errors.flatten(),
            nbinsx=50,
            name='Error',
            showlegend=False,
            marker=dict(color='red', opacity=0.7)
        ),
        row=2, col=3
    )
    
    # Update layout
    fig.update_layout(
        title='Neural Dynamics - Interactive Dashboard',
        height=900,
        showlegend=True
    )
    
    fig.write_html(f'{save_dir}/interactive/dashboard.html')
    print("  ✓ Saved dashboard.html")


def create_summary_report(X_test, X_recon, latent_codes, save_dir):
    """Create comprehensive text report"""
    print("Creating summary report...")
    
    errors = np.abs(X_test - X_recon)
    error_norms = np.linalg.norm(errors, axis=2)
    
    report = f"""
{'='*80}
NEURAL DYNAMICS - COMPREHENSIVE VISUALIZATION REPORT
{'='*80}

Generated: {np.datetime64('now')}

DATA SUMMARY
{'='*80}
Total test samples: {len(X_test)}
Sequence length: {X_test.shape[1]}
Dimensions: {X_test.shape[2]} (X, Y, Z)
Latent dimension: {latent_codes.shape[1]}

RECONSTRUCTION METRICS
{'='*80}
Mean Absolute Error:
  X dimension: {errors[:, :, 0].mean():.6f} ± {errors[:, :, 0].std():.6f}
  Y dimension: {errors[:, :, 1].mean():.6f} ± {errors[:, :, 1].std():.6f}
  Z dimension: {errors[:, :, 2].mean():.6f} ± {errors[:, :, 2].std():.6f}
  Overall: {errors.mean():.6f} ± {errors.std():.6f}

Error Norm Statistics:
  Mean: {error_norms.mean():.6f}
  Median: {np.median(error_norms):.6f}
  Min: {error_norms.min():.6f}
  Max: {error_norms.max():.6f}
  90th percentile: {np.percentile(error_norms, 90):.6f}
  95th percentile: {np.percentile(error_norms, 95):.6f}

STATISTICAL COMPARISON
{'='*80}
               True          Predicted     Difference
Mean:
  X:          {X_test[:,:,0].mean():>8.4f}    {X_recon[:,:,0].mean():>8.4f}    {abs(X_test[:,:,0].mean()-X_recon[:,:,0].mean()):>8.4f}
  Y:          {X_test[:,:,1].mean():>8.4f}    {X_recon[:,:,1].mean():>8.4f}    {abs(X_test[:,:,1].mean()-X_recon[:,:,1].mean()):>8.4f}
  Z:          {X_test[:,:,2].mean():>8.4f}    {X_recon[:,:,2].mean():>8.4f}    {abs(X_test[:,:,2].mean()-X_recon[:,:,2].mean()):>8.4f}

Std Dev:
  X:          {X_test[:,:,0].std():>8.4f}    {X_recon[:,:,0].std():>8.4f}    {abs(X_test[:,:,0].std()-X_recon[:,:,0].std()):>8.4f}
  Y:          {X_test[:,:,1].std():>8.4f}    {X_recon[:,:,1].std():>8.4f}    {abs(X_test[:,:,1].std()-X_recon[:,:,1].std()):>8.4f}
  Z:          {X_test[:,:,2].std():>8.4f}    {X_recon[:,:,2].std():>8.4f}    {abs(X_test[:,:,2].std()-X_recon[:,:,2].std()):>8.4f}

LATENT SPACE STATISTICS
{'='*80}
Latent dimensions: {latent_codes.shape[1]}
Mean: {latent_codes.mean(axis=0)}
Std:  {latent_codes.std(axis=0)}
Range: [{latent_codes.min(axis=0)}, {latent_codes.max(axis=0)}]

GENERATED VISUALIZATIONS
{'='*80}
3D Visualizations:
  ✓ multi_angle_attractor.png
  ✓ trajectory_ensemble.png
  ✓ 3d_comparison.html (interactive)

2D Visualizations:
  ✓ phase_portraits.png

Analysis Plots:
  ✓ error_evolution.png
  ✓ correlation_matrices.png
  ✓ poincare_sections.png
  ✓ power_spectra.png
  ✓ statistical_summary.png
  ✓ latent_space_analysis.png

Comparison Plots:
  ✓ reconstruction_grid.png

Interactive Dashboards:
  ✓ dashboard.html

{'='*80}
END OF REPORT
{'='*80}
"""
    
    with open(f'{save_dir}/VISUALIZATION_REPORT.txt', 'w', encoding='utf-8') as f:
        f.write(report)
    
    print("  ✓ Saved VISUALIZATION_REPORT.txt")


def main():
    """Main execution"""
    print("\n" + "="*80)
    print("ADVANCED VISUALIZATION GENERATOR")
    print("="*80 + "\n")
    
    # Setup
    colors = setup_style()
    create_output_dirs()
    
    # Load data
    autoencoder, X_test, X_recon, latent_codes, mean, std = load_data_and_model()
    
    save_dir = 'results/figures'
    
    # Generate all visualizations
    print("\nGenerating visualizations...\n")
    
    viz_1_multi_angle_3d(X_test, X_recon, save_dir)
    viz_2_phase_portraits(X_test, X_recon, save_dir)
    viz_3_trajectory_ensemble(X_test, X_recon, save_dir)
    viz_4_error_evolution(X_test, X_recon, save_dir)
    viz_5_correlation_matrices(X_test, X_recon, save_dir)
    viz_6_poincare_sections(X_test, X_recon, save_dir)
    viz_7_power_spectra(X_test, X_recon, save_dir)
    viz_8_interactive_3d_comparison(X_test, X_recon, save_dir)
    viz_9_statistical_summary(X_test, X_recon, save_dir)
    viz_10_latent_space_analysis(latent_codes, save_dir)
    viz_11_reconstruction_quality_grid(X_test, X_recon, save_dir)
    viz_12_interactive_dashboard(X_test, X_recon, latent_codes, save_dir)
    
    # Create summary
    create_summary_report(X_test, X_recon, latent_codes, save_dir)
    
    # Summary
    print("\n" + "="*80)
    print("VISUALIZATION GENERATION COMPLETE!")
    print("="*80)
    print(f"\nGenerated 12 visualization sets:")
    print(f"  📊 Static plots: 11 files")
    print(f"  🌐 Interactive: 2 HTML files")
    print(f"  📄 Report: 1 text file")
    print(f"\nTotal files in results/figures/: ~14 files")
    print("\nOrganized in:")
    print("  - results/figures/3d/")
    print("  - results/figures/2d/")
    print("  - results/figures/analysis/")
    print("  - results/figures/comparisons/")
    print("  - results/figures/interactive/")
    print("\n" + "="*80 + "\n")


if __name__ == '__main__':
    main()