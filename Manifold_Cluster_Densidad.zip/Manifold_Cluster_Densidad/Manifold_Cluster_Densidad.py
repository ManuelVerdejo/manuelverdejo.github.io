"""
Sistema Avanzado de Análisis No Supervisado
===========================================
Implementación completa de Manifold Learning, Clustering Comparativo y Validación por Densidad

Requisitos:
pip install numpy pandas matplotlib seaborn scikit-learn umap-learn hdbscan plotly scipy

Para GPU (opcional):
pip install cuml-cu11  # RAPIDS cuML para NVIDIA GPUs
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import make_blobs, make_moons, make_circles
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, SpectralClustering, MiniBatchKMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import (silhouette_score, davies_bouldin_score, 
                             calinski_harabasz_score, adjusted_rand_score, 
                             normalized_mutual_info_score, confusion_matrix)
from sklearn.neighbors import KernelDensity
from scipy.spatial.distance import cdist
import warnings
warnings.filterwarnings('ignore')

# Importaciones avanzadas
try:
    import umap
    UMAP_AVAILABLE = True
except ImportError:
    print("✗ UMAP no disponible. Instalar con: pip install umap-learn")
    UMAP_AVAILABLE = False

try:
    import hdbscan
    HDBSCAN_AVAILABLE = True
except ImportError:
    print("✗ HDBSCAN no disponible. Instalar con: pip install hdbscan")
    HDBSCAN_AVAILABLE = False

try:
    import plotly.graph_objects as go
    import plotly.express as px
    from plotly.subplots import make_subplots
    PLOTLY_AVAILABLE = True
except ImportError:
    print("✗ Plotly no disponible. Instalar con: pip install plotly")
    PLOTLY_AVAILABLE = False

# Configuración de estilo
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

class AdvancedUnsupervisedAnalysis:
    """
    Sistema completo de análisis no supervisado con:
    - Manifold Learning (UMAP, t-SNE, PCA)
    - Clustering Comparativo (K-means, Spectral, HDBSCAN, GMM)
    - Validación por Densidad (KDE, GLOSH)
    - Optimización de hiperparámetros
    """
    
    def __init__(self, n_clusters=5, random_state=42):
        self.n_clusters = n_clusters
        self.random_state = random_state
        self.data = None
        self.labels_true = None
        self.embeddings = {}
        self.clustering_results = {}
        self.metrics = {}
        
    def generate_synthetic_data(self, n_samples=1000, dataset_type='blobs', noise=0.05):
        """
        Genera datos sintéticos para análisis
        
        Parámetros:
        -----------
        n_samples : int
            Número de muestras
        dataset_type : str
            'blobs', 'moons', 'circles', 'varied'
        noise : float
            Nivel de ruido
        """
        print(f"\n{'='*60}")
        print(f"Generando dataset: {dataset_type}")
        print(f"{'='*60}")
        
        if dataset_type == 'blobs':
            X, y = make_blobs(n_samples=n_samples, n_features=10, 
                             centers=self.n_clusters, cluster_std=1.5,
                             random_state=self.random_state)
        elif dataset_type == 'moons':
            X, y = make_moons(n_samples=n_samples, noise=noise, 
                             random_state=self.random_state)
            # A√±adir dimensiones extra
            X = np.hstack([X, np.random.randn(n_samples, 8)])
        elif dataset_type == 'circles':
            X, y = make_circles(n_samples=n_samples, noise=noise, factor=0.5,
                               random_state=self.random_state)
            X = np.hstack([X, np.random.randn(n_samples, 8)])
        elif dataset_type == 'varied':
            # Clusters con diferentes densidades y formas
            X1, y1 = make_blobs(n_samples=n_samples//3, n_features=10, 
                               centers=2, cluster_std=[1.0, 2.5],
                               random_state=self.random_state)
            X2, y2 = make_blobs(n_samples=n_samples//3, n_features=10, 
                               centers=2, cluster_std=0.5,
                               random_state=self.random_state+1)
            X2 += 10  # Desplazar
            X3, _ = make_moons(n_samples=n_samples//3, noise=0.1,
                              random_state=self.random_state)
            X3 = np.hstack([X3 + 5, np.random.randn(n_samples//3, 8)])
            
            X = np.vstack([X1, X2, X3])
            y = np.hstack([y1, y2+2, np.full(n_samples//3, 4)])
        
        # Normalizar
        X = StandardScaler().fit_transform(X)
        
        # A√±adir outliers
        n_outliers = int(n_samples * 0.03)
        outliers = np.random.uniform(-4, 4, size=(n_outliers, X.shape[1]))
        X = np.vstack([X, outliers])
        y = np.hstack([y, np.full(n_outliers, -1)])
        
        self.data = X
        self.labels_true = y
        
        print(f"✓ Datos generados: {X.shape[0]} muestras, {X.shape[1]} características")
        print(f"✓ Clusters verdaderos: {len(np.unique(y[y != -1]))}")
        print(f"✓ Outliers: {n_outliers}")
        
        return X, y
    
    def perform_manifold_learning(self, methods=['pca', 'umap']):
        """
        Aplica técnicas de reducción de dimensionalidad
        
        Parámetros:
        -----------
        methods : list
            Lista de métodos: 'pca', 'umap', 'tsne'
        """
        print(f"\n{'='*60}")
        print("MANIFOLD LEARNING - Reducción de Dimensionalidad")
        print(f"{'='*60}")
        
        X = self.data
        
        for method in methods:
            print(f"\n→ Aplicando {method.upper()}...")
            
            if method == 'pca':
                from sklearn.decomposition import PCA
                reducer = PCA(n_components=2, random_state=self.random_state)
                embedding = reducer.fit_transform(X)
                explained_var = reducer.explained_variance_ratio_.sum()
                print(f"  Varianza explicada: {explained_var:.2%}")
                
            elif method == 'umap' and UMAP_AVAILABLE:
                reducer = umap.UMAP(n_components=2, n_neighbors=30, 
                                   min_dist=0.1, metric='euclidean',
                                   random_state=self.random_state)
                embedding = reducer.fit_transform(X)
                print(f"  Hiperparámetros: n_neighbors=30, min_dist=0.1")
                
            elif method == 'tsne':
                from sklearn.manifold import TSNE
                reducer = TSNE(n_components=2, perplexity=30, n_iter=1000,
                              random_state=self.random_state)
                embedding = reducer.fit_transform(X)
                print(f"  Hiperparámetros: perplexity=30, n_iter=1000")
            else:
                print(f"  ✗ Método {method} no disponible")
                continue
            
            self.embeddings[method] = embedding
            print(f"  ✓ Embedding generado: {embedding.shape}")
    
    def optimize_umap_parameters(self, n_neighbors_range=[5, 15, 30, 50, 100]):
        """
        Optimiza hiperparámetros de UMAP usando métricas de clustering
        """
        if not UMAP_AVAILABLE:
            print("✗ UMAP no disponible")
            return
        
        print(f"\n{'='*60}")
        print("OPTIMIZACI√ìN DE HIPERPAR√ÅMETROS UMAP")
        print(f"{'='*60}")
        
        results = []
        X = self.data
        
        for n_neighbors in n_neighbors_range:
            print(f"\n→ Probando n_neighbors={n_neighbors}...")
            
            reducer = umap.UMAP(n_components=2, n_neighbors=n_neighbors,
                               min_dist=0.1, random_state=self.random_state)
            embedding = reducer.fit_transform(X)
            
            # Evaluar con K-means temporal
            kmeans = KMeans(n_clusters=self.n_clusters, random_state=self.random_state)
            labels = kmeans.fit_predict(embedding)
            
            sil = silhouette_score(embedding, labels)
            dbi = davies_bouldin_score(embedding, labels)
            chi = calinski_harabasz_score(embedding, labels)
            
            results.append({
                'n_neighbors': n_neighbors,
                'silhouette': sil,
                'dbi': dbi,
                'chi': chi
            })
            
            print(f"  Silhouette: {sil:.3f}, DBI: {dbi:.3f}, CHI: {chi:.1f}")
        
        # Visualizar resultados
        df_results = pd.DataFrame(results)
        
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        
        axes[0].plot(df_results['n_neighbors'], df_results['silhouette'], 
                    marker='o', linewidth=2, markersize=8)
        axes[0].set_xlabel('n_neighbors', fontsize=12)
        axes[0].set_ylabel('Silhouette Score', fontsize=12)
        axes[0].set_title('Optimización: Silhouette Score', fontsize=13, fontweight='bold')
        axes[0].grid(True, alpha=0.3)
        
        axes[1].plot(df_results['n_neighbors'], df_results['dbi'], 
                    marker='s', linewidth=2, markersize=8, color='coral')
        axes[1].set_xlabel('n_neighbors', fontsize=12)
        axes[1].set_ylabel('Davies-Bouldin Index', fontsize=12)
        axes[1].set_title('Optimización: DBI (menor es mejor)', fontsize=13, fontweight='bold')
        axes[1].grid(True, alpha=0.3)
        
        axes[2].plot(df_results['n_neighbors'], df_results['chi'], 
                    marker='^', linewidth=2, markersize=8, color='green')
        axes[2].set_xlabel('n_neighbors', fontsize=12)
        axes[2].set_ylabel('Calinski-Harabasz Index', fontsize=12)
        axes[2].set_title('Optimización: CHI (mayor es mejor)', fontsize=13, fontweight='bold')
        axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # Mejor configuración
        best_idx = df_results['silhouette'].idxmax()
        best_n_neighbors = df_results.loc[best_idx, 'n_neighbors']
        print(f"\n✓ Mejor n_neighbors: {best_n_neighbors}")
        
        return df_results
    
    def compute_eigengap(self, max_k=10):
        """
        Calcula la heurística Eigengap para Spectral Clustering
        """
        print(f"\n{'='*60}")
        print("HEUR√çSTICA EIGENGAP - Selección de K √ìptimo")
        print(f"{'='*60}")
        
        from sklearn.neighbors import kneighbors_graph
        from scipy.sparse.linalg import eigsh
        from scipy.sparse import csgraph
        
        X = self.embeddings.get('umap', self.embeddings.get('pca', self.data))
        
        # Construir grafo de k-vecinos
        connectivity = kneighbors_graph(X, n_neighbors=10, include_self=False)
        affinity = 0.5 * (connectivity + connectivity.T)
        
        # Calcular Laplaciano normalizado
        laplacian = csgraph.laplacian(affinity, normed=True)
        
        # Calcular eigenvalues
        eigenvalues, _ = eigsh(laplacian, k=max_k, which='SM')
        eigenvalues = np.sort(eigenvalues)
        
        # Calcular gaps
        gaps = np.diff(eigenvalues)
        
        # Visualizar
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
        
        k_range = np.arange(1, max_k + 1)
        ax1.plot(k_range, eigenvalues, marker='o', linewidth=2, markersize=8)
        ax1.set_xlabel('K (número de clusters)', fontsize=12)
        ax1.set_ylabel('Eigenvalue Œªk', fontsize=12)
        ax1.set_title('Eigenvalues del Laplaciano', fontsize=13, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        gap_k_range = np.arange(1, max_k)
        ax2.bar(gap_k_range, gaps, alpha=0.7, color='coral', edgecolor='black')
        ax2.set_xlabel('K', fontsize=12)
        ax2.set_ylabel('Gap (Œªk+1 - Œªk)', fontsize=12)
        ax2.set_title('Eigengap (seleccionar K con máximo gap)', fontsize=13, fontweight='bold')
        ax2.grid(True, alpha=0.3, axis='y')
        
        # Marcar el máximo gap
        max_gap_idx = np.argmax(gaps)
        optimal_k = max_gap_idx + 1
        ax2.bar(optimal_k, gaps[max_gap_idx], color='red', alpha=0.9, 
               label=f'K óptimo = {optimal_k}')
        ax2.legend()
        
        plt.tight_layout()
        plt.show()
        
        print(f"\n✓ K óptimo según Eigengap: {optimal_k}")
        print(f"✓ Gap máximo: {gaps[max_gap_idx]:.4f}")
        
        return optimal_k, eigenvalues, gaps
    
    def perform_clustering(self, embedding_method='umap', 
                          algorithms=['kmeans', 'spectral', 'hdbscan', 'gmm']):
        """
        Aplica diferentes algoritmos de clustering
        """
        print(f"\n{'='*60}")
        print("CLUSTERING COMPARATIVO")
        print(f"{'='*60}")
        
        X = self.embeddings.get(embedding_method, self.data)
        
        for algorithm in algorithms:
            print(f"\n→ {algorithm.upper()}...")
            
            if algorithm == 'kmeans':
                clusterer = MiniBatchKMeans(n_clusters=self.n_clusters, 
                                           init='k-means++',
                                           random_state=self.random_state,
                                           batch_size=256)
                labels = clusterer.fit_predict(X)
                
            elif algorithm == 'spectral':
                clusterer = SpectralClustering(n_clusters=self.n_clusters,
                                              affinity='rbf',
                                              random_state=self.random_state)
                labels = clusterer.fit_predict(X)
                
            elif algorithm == 'hdbscan' and HDBSCAN_AVAILABLE:
                clusterer = hdbscan.HDBSCAN(min_cluster_size=15,
                                           min_samples=5,
                                           gen_min_span_tree=True)
                labels = clusterer.fit_predict(X)
                
                # Obtener outlier scores (GLOSH)
                outlier_scores = clusterer.outlier_scores_
                self.clustering_results[f'{algorithm}_outlier_scores'] = outlier_scores
                
                n_clusters_found = len(np.unique(labels[labels != -1]))
                n_outliers = np.sum(labels == -1)
                print(f"  Clusters encontrados: {n_clusters_found}")
                print(f"  Outliers detectados: {n_outliers}")
                
            elif algorithm == 'gmm':
                clusterer = GaussianMixture(n_components=self.n_clusters,
                                           covariance_type='full',
                                           random_state=self.random_state)
                clusterer.fit(X)
                labels = clusterer.predict(X)
                probs = clusterer.predict_proba(X)
                self.clustering_results[f'{algorithm}_probs'] = probs
                
            else:
                print(f"  ✗ Algoritmo {algorithm} no disponible")
                continue
            
            self.clustering_results[algorithm] = labels
            
            # Calcular métricas
            self._compute_metrics(X, labels, algorithm)
    
    def _compute_metrics(self, X, labels, algorithm_name):
        """
        Calcula métricas de evaluación para clustering
        """
        # Filtrar outliers para métricas (si existen)
        mask = labels != -1
        X_filtered = X[mask]
        labels_filtered = labels[mask]
        
        if len(np.unique(labels_filtered)) < 2:
            print(f"  ✗ No hay suficientes clusters para evaluar")
            return
        
        # Métricas intrínsecas
        sil = silhouette_score(X_filtered, labels_filtered)
        dbi = davies_bouldin_score(X_filtered, labels_filtered)
        chi = calinski_harabasz_score(X_filtered, labels_filtered)
        
        metrics_dict = {
            'silhouette': sil,
            'davies_bouldin': dbi,
            'calinski_harabasz': chi
        }
        
        # Métricas extrínsecas (si hay labels verdaderas)
        if self.labels_true is not None:
            labels_true_filtered = self.labels_true[mask]
            
            # Solo calcular si no todos son outliers
            if len(np.unique(labels_true_filtered[labels_true_filtered != -1])) > 1:
                ari = adjusted_rand_score(labels_true_filtered, labels_filtered)
                nmi = normalized_mutual_info_score(labels_true_filtered, labels_filtered)
                
                metrics_dict['ari'] = ari
                metrics_dict['nmi'] = nmi
                
                print(f"  ARI: {ari:.3f}, NMI: {nmi:.3f}")
        
        self.metrics[algorithm_name] = metrics_dict
        
        print(f"  Silhouette: {sil:.3f}, DBI: {dbi:.3f}, CHI: {chi:.1f}")
    
    def visualize_manifold(self, embedding_method='umap', show_all_algorithms=True):
        """
        Visualiza proyecciones del manifold con resultados de clustering
        """
        if embedding_method not in self.embeddings:
            print(f"✗ Embedding {embedding_method} no disponible")
            return
        
        X_2d = self.embeddings[embedding_method]
        
        # Determinar número de subplots
        n_plots = 1 + len(self.clustering_results)
        n_cols = min(3, n_plots)
        n_rows = (n_plots + n_cols - 1) // n_cols
        
        fig = plt.figure(figsize=(6 * n_cols, 5 * n_rows))
        
        # Plot 1: Labels verdaderas
        ax1 = plt.subplot(n_rows, n_cols, 1)
        scatter1 = ax1.scatter(X_2d[:, 0], X_2d[:, 1], 
                              c=self.labels_true, cmap='tab10',
                              s=30, alpha=0.6, edgecolors='black', linewidth=0.5)
        ax1.set_title('Labels Verdaderas (Ground Truth)', 
                     fontsize=13, fontweight='bold')
        ax1.set_xlabel(f'{embedding_method.upper()}-1', fontsize=11)
        ax1.set_ylabel(f'{embedding_method.upper()}-2', fontsize=11)
        plt.colorbar(scatter1, ax=ax1)
        
        # Plots de clustering
        plot_idx = 2
        for alg_name, labels in self.clustering_results.items():
            if '_outlier_scores' in alg_name or '_probs' in alg_name:
                continue
            
            ax = plt.subplot(n_rows, n_cols, plot_idx)
            
            # Colorear outliers diferente
            colors = labels.copy().astype(float)
            outlier_mask = labels == -1
            
            scatter = ax.scatter(X_2d[:, 0], X_2d[:, 1], 
                               c=colors, cmap='tab10',
                               s=30, alpha=0.6, edgecolors='black', linewidth=0.5)
            
            # Destacar outliers
            if outlier_mask.any():
                ax.scatter(X_2d[outlier_mask, 0], X_2d[outlier_mask, 1],
                          c='red', s=50, alpha=0.8, marker='x', linewidth=2,
                          label='Outliers')
                ax.legend()
            
            title = f'{alg_name.upper()}'
            if alg_name in self.metrics:
                sil = self.metrics[alg_name]['silhouette']
                title += f'\nSilhouette: {sil:.3f}'
            
            ax.set_title(title, fontsize=13, fontweight='bold')
            ax.set_xlabel(f'{embedding_method.upper()}-1', fontsize=11)
            ax.set_ylabel(f'{embedding_method.upper()}-2', fontsize=11)
            plt.colorbar(scatter, ax=ax)
            
            plot_idx += 1
        
        plt.tight_layout()
        plt.show()
    
    def visualize_outlier_scores(self):
        """
        Visualiza distribución de scores GLOSH de HDBSCAN
        """
        if 'hdbscan_outlier_scores' not in self.clustering_results:
            print("✗ HDBSCAN outlier scores no disponibles")
            return
        
        scores = self.clustering_results['hdbscan_outlier_scores']
        labels = self.clustering_results['hdbscan']
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Histograma de scores
        axes[0].hist(scores, bins=50, alpha=0.7, color='steelblue', edgecolor='black')
        axes[0].axvline(np.percentile(scores, 95), color='red', linestyle='--', 
                       linewidth=2, label='Percentil 95')
        axes[0].set_xlabel('GLOSH Outlier Score', fontsize=12)
        axes[0].set_ylabel('Frecuencia', fontsize=12)
        axes[0].set_title('Distribución de Scores de Anomalía (GLOSH)', 
                         fontsize=13, fontweight='bold')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Top outliers
        top_n = 50
        sorted_indices = np.argsort(scores)[::-1][:top_n]
        top_scores = scores[sorted_indices]
        
        colors = ['red' if labels[i] == -1 else 'steelblue' for i in sorted_indices]
        
        axes[1].bar(range(top_n), top_scores, color=colors, alpha=0.7, edgecolor='black')
        axes[1].set_xlabel('√çndice de Punto', fontsize=12)
        axes[1].set_ylabel('GLOSH Score', fontsize=12)
        axes[1].set_title(f'Top {top_n} Puntos con Mayor Score de Anomalía', 
                         fontsize=13, fontweight='bold')
        axes[1].grid(True, alpha=0.3, axis='y')
        
        # Leyenda
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor='red', alpha=0.7, label='Outliers'),
                          Patch(facecolor='steelblue', alpha=0.7, label='Puntos Normales')]
        axes[1].legend(handles=legend_elements)
        
        plt.tight_layout()
        plt.show()
        
        # Estadísticas
        n_outliers = np.sum(labels == -1)
        threshold_95 = np.percentile(scores, 95)
        high_scores = np.sum(scores > threshold_95)
        
        print(f"\n✨ Estadísticas de Outliers:")
        print(f"  • Outliers detectados por HDBSCAN: {n_outliers}")
        print(f"  • Puntos con GLOSH > percentil 95: {high_scores}")
        print(f"  • Threshold percentil 95: {threshold_95:.4f}")
        print(f"  • Score máximo: {scores.max():.4f}")
        print(f"  • Score promedio: {scores.mean():.4f}")
    
    def visualize_density_estimation(self, embedding_method='umap'):
        """
        Visualiza estimación de densidad con KDE
        """
        if embedding_method not in self.embeddings:
            print(f"✗ Embedding {embedding_method} no disponible")
            return
        
        X_2d = self.embeddings[embedding_method]
        
        # Calcular KDE
        kde = KernelDensity(bandwidth=0.5, kernel='gaussian')
        kde.fit(X_2d)
        
        # Crear grid
        x_min, x_max = X_2d[:, 0].min() - 1, X_2d[:, 0].max() + 1
        y_min, y_max = X_2d[:, 1].min() - 1, X_2d[:, 1].max() + 1
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                            np.linspace(y_min, y_max, 200))
        
        # Evaluar densidad
        Z = kde.score_samples(np.c_[xx.ravel(), yy.ravel()])
        Z = Z.reshape(xx.shape)
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        
        # Contour plot
        levels = 20
        contour = axes[0].contourf(xx, yy, np.exp(Z), levels=levels, cmap='viridis', alpha=0.8)
        axes[0].scatter(X_2d[:, 0], X_2d[:, 1], c='white', s=5, alpha=0.3, edgecolors='black')
        axes[0].set_title('Estimación de Densidad (KDE) - Contour Plot', 
                         fontsize=13, fontweight='bold')
        axes[0].set_xlabel(f'{embedding_method.upper()}-1', fontsize=11)
        axes[0].set_ylabel(f'{embedding_method.upper()}-2', fontsize=11)
        plt.colorbar(contour, ax=axes[0], label='Densidad')
        
        # 3D surface plot
        from mpl_toolkits.mplot3d import Axes3D
        ax3d = fig.add_subplot(122, projection='3d')
        surf = ax3d.plot_surface(xx, yy, np.exp(Z), cmap='viridis', alpha=0.8,
                                edgecolor='none', antialiased=True)
        ax3d.set_title('Estimación de Densidad (KDE) - 3D', 
                      fontsize=13, fontweight='bold')
        ax3d.set_xlabel(f'{embedding_method.upper()}-1', fontsize=10)
        ax3d.set_ylabel(f'{embedding_method.upper()}-2', fontsize=10)
        ax3d.set_zlabel('Densidad', fontsize=10)
        ax3d.view_init(elev=30, azim=45)
        plt.colorbar(surf, ax=ax3d, shrink=0.5, aspect=5)
        
        plt.tight_layout()
        plt.show()
    
    def compare_algorithms(self):
        """
        Genera visualizaciones comparativas de todos los algoritmos
        """
        if not self.metrics:
            print("✗ No hay métricas calculadas. Ejecutar perform_clustering primero.")
            return
        
        print(f"\n{'='*60}")
        print("COMPARACI√ìN DE ALGORITMOS")
        print(f"{'='*60}")
        
        # Preparar datos
        df_metrics = pd.DataFrame(self.metrics).T
        print("\n", df_metrics.round(3))
        
        # Visualizaciones
        fig = plt.figure(figsize=(16, 10))
        
        # 1. Métricas intrínsecas
        ax1 = plt.subplot(2, 3, 1)
        df_metrics[['silhouette', 'davies_bouldin', 'calinski_harabasz']].plot(
            kind='bar', ax=ax1, rot=45)
        ax1.set_title('Métricas Intrínsecas', fontsize=13, fontweight='bold')
        ax1.set_ylabel('Score', fontsize=11)
        ax1.legend(loc='best')
        ax1.grid(True, alpha=0.3, axis='y')
        
        # 2. Silhouette comparison
        ax2 = plt.subplot(2, 3, 2)
        algorithms = list(df_metrics.index)
        silhouette_scores = df_metrics['silhouette'].values
        colors = plt.cm.viridis(np.linspace(0, 1, len(algorithms)))
        bars = ax2.barh(algorithms, silhouette_scores, color=colors, alpha=0.8, edgecolor='black')
        ax2.set_xlabel('Silhouette Score', fontsize=11)
        ax2.set_title('Comparación Silhouette Score', fontsize=13, fontweight='bold')
        ax2.grid(True, alpha=0.3, axis='x')
        ax2.axvline(0.5, color='red', linestyle='--', alpha=0.5, label='Threshold 0.5')
        ax2.legend()
        
        # 3. Davies-Bouldin Index (menor es mejor)
        ax3 = plt.subplot(2, 3, 3)
        dbi_scores = df_metrics['davies_bouldin'].values
        colors_dbi = ['green' if x < 1.0 else 'orange' if x < 1.5 else 'red' for x in dbi_scores]
        bars = ax3.barh(algorithms, dbi_scores, color=colors_dbi, alpha=0.8, edgecolor='black')
        ax3.set_xlabel('Davies-Bouldin Index', fontsize=11)
        ax3.set_title('DBI - Menor es Mejor', fontsize=13, fontweight='bold')
        ax3.grid(True, alpha=0.3, axis='x')
        ax3.invert_xaxis()
        
        # 4. Métricas extrínsecas (si existen)
        if 'ari' in df_metrics.columns and 'nmi' in df_metrics.columns:
            ax4 = plt.subplot(2, 3, 4)
            df_metrics[['ari', 'nmi']].plot(kind='bar', ax=ax4, rot=45, color=['skyblue', 'coral'])
            ax4.set_title('Métricas Extrínsecas (vs Ground Truth)', fontsize=13, fontweight='bold')
            ax4.set_ylabel('Score', fontsize=11)
            ax4.legend(['ARI', 'NMI'])
            ax4.grid(True, alpha=0.3, axis='y')
            ax4.set_ylim([0, 1])
        
        # 5. Radar chart
        if 'ari' in df_metrics.columns:
            ax5 = plt.subplot(2, 3, 5, projection='polar')
            
            metrics_to_plot = ['silhouette', 'ari', 'nmi']
            available_metrics = [m for m in metrics_to_plot if m in df_metrics.columns]
            
            angles = np.linspace(0, 2 * np.pi, len(available_metrics), endpoint=False).tolist()
            angles += angles[:1]
            
            for alg in algorithms[:3]:  # Mostrar solo primeros 3 para claridad
                values = df_metrics.loc[alg, available_metrics].values.tolist()
                values += values[:1]
                ax5.plot(angles, values, 'o-', linewidth=2, label=alg)
                ax5.fill(angles, values, alpha=0.15)
            
            ax5.set_xticks(angles[:-1])
            ax5.set_xticklabels(available_metrics)
            ax5.set_ylim(0, 1)
            ax5.set_title('Comparación Multidimensional', fontsize=13, fontweight='bold', pad=20)
            ax5.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
            ax5.grid(True)
        
        # 6. Ranking general
        ax6 = plt.subplot(2, 3, 6)
        
        # Calcular score combinado (normalizado)
        df_norm = df_metrics.copy()
        df_norm['silhouette_norm'] = df_norm['silhouette']
        df_norm['dbi_norm'] = 1 - (df_norm['davies_bouldin'] / df_norm['davies_bouldin'].max())
        df_norm['chi_norm'] = df_norm['calinski_harabasz'] / df_norm['calinski_harabasz'].max()
        
        if 'ari' in df_norm.columns:
            df_norm['overall_score'] = (df_norm['silhouette_norm'] + df_norm['dbi_norm'] + 
                                       df_norm['chi_norm'] + df_norm['ari'] + df_norm['nmi']) / 5
        else:
            df_norm['overall_score'] = (df_norm['silhouette_norm'] + df_norm['dbi_norm'] + 
                                       df_norm['chi_norm']) / 3
        
        overall_sorted = df_norm['overall_score'].sort_values(ascending=True)
        colors_rank = plt.cm.RdYlGn(np.linspace(0.3, 0.9, len(overall_sorted)))
        
        bars = ax6.barh(overall_sorted.index, overall_sorted.values, color=colors_rank, 
                       alpha=0.8, edgecolor='black')
        ax6.set_xlabel('Score Combinado (normalizado)', fontsize=11)
        ax6.set_title('Ranking General de Algoritmos', fontsize=13, fontweight='bold')
        ax6.grid(True, alpha=0.3, axis='x')
        
        # A√±adir valores en las barras
        for i, (idx, val) in enumerate(overall_sorted.items()):
            ax6.text(val + 0.01, i, f'{val:.3f}', va='center', fontsize=10, fontweight='bold')
        
        plt.tight_layout()
        plt.show()
        
        # Imprimir ranking
        print(f"\n👑 RANKING DE ALGORITMOS:")
        for i, (alg, score) in enumerate(list(overall_sorted.items())[::-1], 1):
            print(f"  {i}. {alg.upper()}: {score:.3f}")
    
    def analyze_stability(self, n_iterations=10, noise_levels=[0.0, 0.1, 0.2, 0.3]):
        """
        Analiza la estabilidad de los algoritmos con diferentes niveles de ruido
        """
        print(f"\n{'='*60}")
        print("AN√ÅLISIS DE ROBUSTEZ Y ESTABILIDAD")
        print(f"{'='*60}")
        
        X_original = self.embeddings.get('umap', self.data)
        results = {alg: {noise: [] for noise in noise_levels} 
                  for alg in ['kmeans', 'spectral', 'hdbscan']}
        
        for noise_level in noise_levels:
            print(f"\n→ Nivel de ruido: {noise_level:.1f}")
            
            for iteration in range(n_iterations):
                # A√±adir ruido
                X_noisy = X_original + np.random.normal(0, noise_level, X_original.shape)
                
                # K-means
                kmeans = MiniBatchKMeans(n_clusters=self.n_clusters, 
                                        random_state=self.random_state + iteration)
                labels_km = kmeans.fit_predict(X_noisy)
                
                if len(np.unique(labels_km)) > 1:
                    ari_km = adjusted_rand_score(self.labels_true, labels_km)
                    results['kmeans'][noise_level].append(ari_km)
                
                # Spectral
                spectral = SpectralClustering(n_clusters=self.n_clusters,
                                             random_state=self.random_state + iteration)
                labels_sp = spectral.fit_predict(X_noisy)
                
                if len(np.unique(labels_sp)) > 1:
                    ari_sp = adjusted_rand_score(self.labels_true, labels_sp)
                    results['spectral'][noise_level].append(ari_sp)
                
                # HDBSCAN
                if HDBSCAN_AVAILABLE:
                    hdb = hdbscan.HDBSCAN(min_cluster_size=15)
                    labels_hdb = hdb.fit_predict(X_noisy)
                    
                    mask = labels_hdb != -1
                    if mask.sum() > 0 and len(np.unique(labels_hdb[mask])) > 1:
                        ari_hdb = adjusted_rand_score(self.labels_true[mask], labels_hdb[mask])
                        results['hdbscan'][noise_level].append(ari_hdb)
            
            print(f"  Iteraciones completadas: {n_iterations}")
        
        # Visualizar resultados
        fig, axes = plt.subplots(1, 2, figsize=(15, 5))
        
        # Plot 1: Media con barras de error
        ax1 = axes[0]
        for alg in results.keys():
            means = [np.mean(results[alg][noise]) if results[alg][noise] else 0 
                    for noise in noise_levels]
            stds = [np.std(results[alg][noise]) if results[alg][noise] else 0 
                   for noise in noise_levels]
            
            ax1.errorbar(noise_levels, means, yerr=stds, marker='o', linewidth=2, 
                        markersize=8, capsize=5, label=alg.upper())
        
        ax1.set_xlabel('Nivel de Ruido', fontsize=12)
        ax1.set_ylabel('ARI Score (media ¬± std)', fontsize=12)
        ax1.set_title('Robustez ante Ruido', fontsize=13, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.set_ylim([0, 1])
        
        # Plot 2: Boxplots para cada nivel de ruido
        ax2 = axes[1]
        positions = np.arange(len(noise_levels))
        width = 0.25
        
        for i, alg in enumerate(results.keys()):
            data = [results[alg][noise] for noise in noise_levels]
            bp = ax2.boxplot(data, positions=positions + i * width, widths=width * 0.8,
                            patch_artist=True, labels=[f'{n:.1f}' if i == 0 else '' 
                                                       for n in noise_levels])
            for patch in bp['boxes']:
                patch.set_facecolor(plt.cm.Set3(i))
        
        ax2.set_xlabel('Nivel de Ruido', fontsize=12)
        ax2.set_ylabel('ARI Score', fontsize=12)
        ax2.set_title('Distribución de ARI por Nivel de Ruido', fontsize=13, fontweight='bold')
        ax2.legend([plt.Line2D([0], [0], color=plt.cm.Set3(i), linewidth=5) 
                   for i in range(len(results))], 
                  [alg.upper() for alg in results.keys()])
        ax2.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        plt.show()
        
        # Estadísticas de degradación
        print(f"\nüìâ DEGRADACI√ìN DE PERFORMANCE:")
        for alg in results.keys():
            score_clean = np.mean(results[alg][0.0]) if results[alg][0.0] else 0
            score_noisy = np.mean(results[alg][max(noise_levels)]) if results[alg][max(noise_levels)] else 0
            degradation = (score_clean - score_noisy) / score_clean * 100 if score_clean > 0 else 0
            print(f"  {alg.upper()}: {degradation:.1f}% (de {score_clean:.3f} a {score_noisy:.3f})")
    
    def create_confusion_matrix(self, algorithm='spectral'):
        """
        Crea matriz de confusión comparando con ground truth
        """
        if algorithm not in self.clustering_results:
            print(f"✗ Algoritmo {algorithm} no disponible")
            return
        
        labels_pred = self.clustering_results[algorithm]
        labels_true = self.labels_true
        
        # Filtrar outliers
        mask = (labels_pred != -1) & (labels_true != -1)
        labels_pred_filtered = labels_pred[mask]
        labels_true_filtered = labels_true[mask]
        
        # Crear matriz de confusión
        cm = confusion_matrix(labels_true_filtered, labels_pred_filtered)
        
        # Visualizar
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar_kws={'label': 'Frecuencia'},
                   linewidths=1, linecolor='black')
        plt.xlabel('Clusters Predichos', fontsize=12)
        plt.ylabel('Clusters Verdaderos', fontsize=12)
        plt.title(f'Matriz de Confusión - {algorithm.upper()}', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.show()
        
        # Calcular métricas por clase
        from sklearn.metrics import precision_recall_fscore_support
        precision, recall, f1, support = precision_recall_fscore_support(
            labels_true_filtered, labels_pred_filtered, average=None)
        
        print(f"\n✨ M√âTRICAS POR CLUSTER ({algorithm.upper()}):")
        print(f"{'Cluster':<10} {'Precision':<12} {'Recall':<12} {'F1-Score':<12} {'Support':<10}")
        print("-" * 60)
        for i in range(len(precision)):
            print(f"{i:<10} {precision[i]:<12.3f} {recall[i]:<12.3f} {f1[i]:<12.3f} {support[i]:<10}")
        
        # Métricas globales
        accuracy = np.sum(np.diag(cm)) / np.sum(cm)
        print(f"\n✓ Precisión Global: {accuracy:.3f}")
    
    def plot_interactive_3d(self, embedding_method='umap'):
        """
        Crea visualización interactiva 3D con Plotly (si está disponible)
        """
        if not PLOTLY_AVAILABLE:
            print("✗ Plotly no disponible. Instalar con: pip install plotly")
            return
        
        # Generar embedding 3D si no existe
        if embedding_method == 'umap' and UMAP_AVAILABLE:
            print("→ Generando embedding 3D con UMAP...")
            reducer = umap.UMAP(n_components=3, n_neighbors=30, min_dist=0.1,
                               random_state=self.random_state)
            X_3d = reducer.fit_transform(self.data)
        else:
            print("→ Usando PCA para reducción 3D...")
            from sklearn.decomposition import PCA
            pca = PCA(n_components=3, random_state=self.random_state)
            X_3d = pca.fit_transform(self.data)
        
        # Crear figura con subplots
        algorithms = list(self.clustering_results.keys())
        algorithms = [alg for alg in algorithms if '_outlier' not in alg and '_probs' not in alg]
        
        fig = make_subplots(
            rows=1, cols=len(algorithms) + 1,
            subplot_titles=['Ground Truth'] + [alg.upper() for alg in algorithms],
            specs=[[{'type': 'scatter3d'}] * (len(algorithms) + 1)],
            horizontal_spacing=0.05
        )
        
        # Plot ground truth
        scatter_true = go.Scatter3d(
            x=X_3d[:, 0], y=X_3d[:, 1], z=X_3d[:, 2],
            mode='markers',
            marker=dict(size=3, color=self.labels_true, colorscale='Viridis', 
                       showscale=True, colorbar=dict(x=-0.1)),
            text=[f'Label: {l}' for l in self.labels_true],
            hoverinfo='text',
            name='Ground Truth'
        )
        fig.add_trace(scatter_true, row=1, col=1)
        
        # Plot clustering results
        for i, alg in enumerate(algorithms, 2):
            labels = self.clustering_results[alg]
            
            scatter = go.Scatter3d(
                x=X_3d[:, 0], y=X_3d[:, 1], z=X_3d[:, 2],
                mode='markers',
                marker=dict(size=3, color=labels, colorscale='Plotly3',
                           showscale=False),
                text=[f'Cluster: {l}' for l in labels],
                hoverinfo='text',
                name=alg.upper()
            )
            fig.add_trace(scatter, row=1, col=i)
        
        # Configuración
        fig.update_layout(
            title_text="Visualización Interactiva 3D - Manifold Learning",
            title_font_size=16,
            showlegend=False,
            height=600,
            margin=dict(l=0, r=0, b=0, t=40)
        )
        
        fig.show()
        print("✓ Visualización 3D interactiva generada")
    
    def generate_full_report(self):
        """
        Genera un reporte completo del análisis
        """
        print(f"\n{'='*60}")
        print("REPORTE COMPLETO DE AN√ÅLISIS")
        print(f"{'='*60}")
        
        report = []
        report.append(f"\n1. DATOS:")
        report.append(f"   • Muestras: {self.data.shape[0]}")
        report.append(f"   • Características: {self.data.shape[1]}")
        report.append(f"   • Clusters verdaderos: {len(np.unique(self.labels_true[self.labels_true != -1]))}")
        
        report.append(f"\n2. MANIFOLD LEARNING:")
        for method, embedding in self.embeddings.items():
            report.append(f"   • {method.upper()}: {embedding.shape}")
        
        report.append(f"\n3. ALGORITMOS DE CLUSTERING:")
        for alg in self.clustering_results.keys():
            if '_outlier' in alg or '_probs' in alg:
                continue
            labels = self.clustering_results[alg]
            n_clusters = len(np.unique(labels[labels != -1]))
            n_outliers = np.sum(labels == -1)
            report.append(f"   • {alg.upper()}: {n_clusters} clusters, {n_outliers} outliers")
        
        report.append(f"\n4. M√âTRICAS DE EVALUACI√ìN:")
        if self.metrics:
            df_metrics = pd.DataFrame(self.metrics).T
            report.append("\n" + df_metrics.round(3).to_string())
        
        report.append(f"\n5. MEJOR ALGORITMO:")
        if self.metrics:
            best_alg = max(self.metrics.keys(), 
                          key=lambda k: self.metrics[k].get('silhouette', 0))
            best_score = self.metrics[best_alg]['silhouette']
            report.append(f"   • {best_alg.upper()} (Silhouette: {best_score:.3f})")
        
        full_report = '\n'.join(report)
        print(full_report)
        
        # Guardar en archivo
        with open('unsupervised_analysis_report.txt', 'w', encoding='utf-8') as f:
            f.write(full_report)
        print(f"\n✓ Reporte guardado en: unsupervised_analysis_report.txt")
        
        return full_report


# =============================================================================
# PIPELINE PRINCIPAL DE EJECUCI√ìN
# =============================================================================

def main():
    """
    Pipeline completo de análisis no supervisado
    """
    print("""
    ‚ïî‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïó
    ‚ïë  SISTEMA AVANZADO DE AN√ÅLISIS NO SUPERVISADO                   ‚ïë
    ‚ïë  Manifold Learning • Clustering • Validación por Densidad      ‚ïë
    ‚ïö‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïê‚ïù
    """)
    
    # Inicializar sistema
    analyzer = AdvancedUnsupervisedAnalysis(n_clusters=5, random_state=42)
    
    # 1. Generar datos
    print("\n" + "="*60)
    print("PASO 1: GENERACI√ìN DE DATOS")
    print("="*60)
    X, y = analyzer.generate_synthetic_data(n_samples=1000, dataset_type='varied', noise=0.05)
    
    # 2. Manifold Learning
    print("\n" + "="*60)
    print("PASO 2: MANIFOLD LEARNING")
    print("="*60)
    analyzer.perform_manifold_learning(methods=['pca', 'umap'])
    
    # 3. Optimización de UMAP
    if UMAP_AVAILABLE:
        print("\n" + "="*60)
        print("PASO 3: OPTIMIZACI√ìN DE HIPERPAR√ÅMETROS")
        print("="*60)
        analyzer.optimize_umap_parameters(n_neighbors_range=[5, 15, 30, 50, 100])
    
    # 4. Heurística Eigengap
    print("\n" + "="*60)
    print("PASO 4: HEUR√çSTICA EIGENGAP")
    print("="*60)
    optimal_k, eigenvalues, gaps = analyzer.compute_eigengap(max_k=10)
    
    # 5. Clustering comparativo
    print("\n" + "="*60)
    print("PASO 5: CLUSTERING COMPARATIVO")
    print("="*60)
    algorithms = ['kmeans', 'spectral', 'gmm']
    if HDBSCAN_AVAILABLE:
        algorithms.append('hdbscan')
    analyzer.perform_clustering(embedding_method='umap', algorithms=algorithms)
    
    # 6. Visualizaciones
    print("\n" + "="*60)
    print("PASO 6: VISUALIZACIONES")
    print("="*60)
    
    # Manifold
    analyzer.visualize_manifold(embedding_method='umap')
    
    # Outlier scores
    if HDBSCAN_AVAILABLE:
        analyzer.visualize_outlier_scores()
    
    # Densidad
    analyzer.visualize_density_estimation(embedding_method='umap')
    
    # 7. Comparación de algoritmos
    print("\n" + "="*60)
    print("PASO 7: COMPARACI√ìN DE ALGORITMOS")
    print("="*60)
    analyzer.compare_algorithms()
    
    # 8. Análisis de estabilidad
    print("\n" + "="*60)
    print("PASO 8: AN√ÅLISIS DE ROBUSTEZ")
    print("="*60)
    analyzer.analyze_stability(n_iterations=5, noise_levels=[0.0, 0.1, 0.2, 0.3, 0.5])
    
    # 9. Matriz de confusión
    print("\n" + "="*60)
    print("PASO 9: MATRIZ DE CONFUSI√ìN")
    print("="*60)
    analyzer.create_confusion_matrix(algorithm='spectral')
    
    # 10. Visualización 3D interactiva
    if PLOTLY_AVAILABLE:
        print("\n" + "="*60)
        print("PASO 10: VISUALIZACI√ìN 3D INTERACTIVA")
        print("="*60)
        analyzer.plot_interactive_3d(embedding_method='umap')
    
    # 11. Reporte final
    print("\n" + "="*60)
    print("PASO 11: REPORTE FINAL")
    print("="*60)
    analyzer.generate_full_report()
    
    print(f"\n{'='*60}")
    print("✓ AN√ÅLISIS COMPLETADO EXITOSAMENTE")
    print(f"{'='*60}\n")
    
    return analyzer


# =============================================================================
# EJECUCI√ìN
# =============================================================================

if __name__ == "__main__":
    # Ejecutar pipeline completo
    analyzer = main()
    
    # El objeto analyzer ahora contiene todos los resultados
    # Puedes acceder a:
    # - analyzer.data (datos originales)
    # - analyzer.embeddings (proyecciones 2D/3D)
    # - analyzer.clustering_results (labels de cada algoritmo)
    # - analyzer.metrics (métricas de evaluación)