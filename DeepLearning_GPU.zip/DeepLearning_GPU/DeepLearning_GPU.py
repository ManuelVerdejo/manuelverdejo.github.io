"""
Sistema Avanzado de Análisis No Supervisado con Deep Learning y Aceleración GPU
================================================================================

Arquitectura modular de vanguardia para clustering, manifold learning y detección de anomalías
con soporte para múltiples tipos de datos (imágenes, audio, señales biométricas).

Autor: Sistema de Análisis Avanzado
Versión: 2.0
"""

import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, field
from pathlib import Path
import logging
from abc import ABC, abstractmethod

# Procesamiento y ML Core
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.decomposition import PCA
from sklearn.cluster import MiniBatchKMeans, SpectralClustering
from sklearn.metrics import (
    silhouette_score, davies_bouldin_score, calinski_harabasz_score,
    adjusted_rand_score, normalized_mutual_info_score
)
from sklearn.neighbors import NearestNeighbors
from scipy.linalg import eigh
from scipy.spatial.distance import cdist

# Manifold Learning y Clustering Avanzado

from umap import UMAP  # <--- Esta es la forma más limpia y recomendable
import hdbscan

# Deep Learning
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from torchvision import transforms

# Visualización
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.io as pio
# Procesamiento de Audio (simulado para ejemplo)
# import librosa  # Descomentar si se usa audio real
# from pyAudioAnalysis import audioBasicIO, ShortTermFeatures

# Procesamiento EEG (simulado para ejemplo)
# import mne  # Descomentar si se usan señales EEG reales
# from PyEEG import hfd, hjorth

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

pio.renderers.default = "browser" 
# ============================================================================
# CONFIGURACIÓN Y DATACLASSES
# ============================================================================

@dataclass
class SystemConfig:
    """Configuración global del sistema"""
    use_gpu: bool = torch.cuda.is_available()
    n_jobs: int = -1
    random_state: int = 42
    verbose: bool = True
    cache_embeddings: bool = True
    
    # Parámetros UMAP
    umap_n_neighbors: int = 15
    umap_min_dist: float = 0.05
    umap_metric: str = 'euclidean'
    umap_n_components: int = 2
    
    # Parámetros HDBSCAN
    hdbscan_min_cluster_size: int = 15
    hdbscan_min_samples: int = 5
    hdbscan_metric: str = 'euclidean'
    
    # Parámetros Deep Learning
    autoencoder_latent_dim: int = 64
    autoencoder_epochs: int = 100
    batch_size: int = 256
    learning_rate: float = 1e-3
    
    # Outlier filtering
    outlier_percentile: float = 95.0
    
    def __post_init__(self):
        if self.use_gpu:
            logger.info(f"GPU disponible: {torch.cuda.get_device_name(0)}")
        else:
            logger.info("Usando CPU")


@dataclass
class ClusteringResults:
    """Contenedor para resultados de clustering"""
    labels: np.ndarray
    embeddings: np.ndarray
    metrics: Dict[str, float] = field(default_factory=dict)
    outlier_scores: Optional[np.ndarray] = None
    algorithm: str = ""
    n_clusters: int = 0
    
    def __repr__(self):
        return f"ClusteringResults(algorithm={self.algorithm}, n_clusters={self.n_clusters}, metrics={self.metrics})"


# ============================================================================
# EXTRACCIÓN DE CARACTERÍSTICAS ESPECÍFICAS DEL DOMINIO
# ============================================================================

class FeatureExtractor(ABC):
    """Clase base abstracta para extractores de características"""
    
    @abstractmethod
    def extract(self, data: np.ndarray) -> np.ndarray:
        """Extrae características del dominio específico"""
        pass


class ImageFeatureExtractor(FeatureExtractor):
    """Extractor de características para imágenes"""
    
    def __init__(self, use_pca: bool = True, n_components: int = 100):
        self.use_pca = use_pca
        self.n_components = n_components
        self.pca = None
        self.scaler = StandardScaler()
        
    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extrae características de imágenes con normalización y PCA opcional
        
        Args:
            data: Array de forma (n_samples, height, width) o (n_samples, height, width, channels)
        
        Returns:
            Características extraídas de forma (n_samples, n_features)
        """
        # Aplanar imágenes
        n_samples = data.shape[0]
        data_flat = data.reshape(n_samples, -1)
        
        # Normalización
        data_normalized = self.scaler.fit_transform(data_flat)
        
        # PCA para reducción inicial de dimensionalidad
        if self.use_pca:
            self.pca = PCA(n_components=min(self.n_components, data_flat.shape[1]))
            features = self.pca.fit_transform(data_normalized)
            logger.info(f"PCA: Varianza explicada = {self.pca.explained_variance_ratio_.sum():.3f}")
        else:
            features = data_normalized
            
        return features


class AudioFeatureExtractor(FeatureExtractor):
    """Extractor de características para señales de audio"""
    
    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extrae características espectrales de audio (MFCCs, spectral rolloff, etc.)
        
        Nota: Implementación simplificada. En producción, usar librosa.
        """
        # Simulación de características de audio
        n_samples = data.shape[0]
        
        # Características simuladas: MFCCs (13), spectral features (5)
        features = np.random.randn(n_samples, 18)
        
        logger.info(f"Audio features extraídas: {features.shape[1]} características")
        return features


class BiometricFeatureExtractor(FeatureExtractor):
    """Extractor de características para señales biométricas (EEG/MEG)"""
    
    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extrae características de complejidad temporal de señales EEG/MEG
        (Dimensión Fractal de Higuchi, parámetros de Hjorth, entropía)
        
        Nota: Implementación simplificada. En producción, usar PyEEG/MNE.
        """
        n_samples = data.shape[0]
        
        # Características simuladas: HFD, Hjorth (2), Entropías (3)
        features = np.random.randn(n_samples, 6)
        
        logger.info(f"Biometric features extraídas: {features.shape[1]} características")
        return features


# ============================================================================
# DEEP LEARNING: AUTOENCODERS Y CONTRASTIVE LEARNING
# ============================================================================

class ContrastiveAutoencoder(nn.Module):
    """
    Autoencoder con capacidad de aprendizaje contrastivo
    Arquitectura profunda para generar embeddings discriminativos
    """
    
    def __init__(self, input_dim: int, latent_dim: int = 64, hidden_dims: List[int] = None):
        super().__init__()
        
        if hidden_dims is None:
            hidden_dims = [512, 256, 128]
        
        # Encoder
        encoder_layers = []
        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            encoder_layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.2)
            ])
            prev_dim = hidden_dim
        encoder_layers.append(nn.Linear(prev_dim, latent_dim))
        
        self.encoder = nn.Sequential(*encoder_layers)
        
        # Decoder (simétrico)
        decoder_layers = []
        prev_dim = latent_dim
        for hidden_dim in reversed(hidden_dims):
            decoder_layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.2)
            ])
            prev_dim = hidden_dim
        decoder_layers.append(nn.Linear(prev_dim, input_dim))
        
        self.decoder = nn.Sequential(*decoder_layers)
        
        # Projection head para contrastive learning
        self.projection = nn.Sequential(
            nn.Linear(latent_dim, latent_dim),
            nn.ReLU(),
            nn.Linear(latent_dim, latent_dim // 2)
        )
        
    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Codifica datos en el espacio latente"""
        return self.encoder(x)
    
    def decode(self, z: torch.Tensor) -> torch.Tensor:
        """Decodifica desde el espacio latente"""
        return self.decoder(z)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Forward pass completo"""
        z = self.encode(x)
        x_recon = self.decode(z)
        proj = self.projection(z)
        return x_recon, z, proj


class ContrastiveLoss(nn.Module):
    """Pérdida contrastiva (SimCLR-style) para aprendizaje de representaciones"""
    
    def __init__(self, temperature: float = 0.5):
        super().__init__()
        self.temperature = temperature
        
    def forward(self, projections: torch.Tensor) -> torch.Tensor:
        """
        Calcula la pérdida contrastiva entre proyecciones
        
        Args:
            projections: Tensor de forma (batch_size, projection_dim)
        """
        # Normalizar proyecciones
        projections = F.normalize(projections, dim=1)
        
        # Calcular matriz de similitud
        similarity_matrix = torch.matmul(projections, projections.T) / self.temperature
        
        # Crear máscaras para positivos y negativos
        batch_size = projections.shape[0]
        mask = torch.eye(batch_size, device=projections.device).bool()
        
        # Calcular pérdida contrastiva
        exp_sim = torch.exp(similarity_matrix)
        exp_sim = exp_sim.masked_fill(mask, 0)
        
        loss = -torch.log(exp_sim.sum(dim=1) / (exp_sim.sum(dim=1) + 1e-8))
        return loss.mean()


class DeepEmbeddingLearner:
    """
    Aprende embeddings profundos usando Autoencoders con aprendizaje contrastivo
    Implementa el paradigma de Deep Embedded Clustering (DEC)
    """
    
    def __init__(self, config: SystemConfig):
        self.config = config
        self.model = None
        self.device = torch.device('cuda' if config.use_gpu else 'cpu')
        self.scaler = RobustScaler()
        
    def train_autoencoder(
        self, 
        data: np.ndarray, 
        use_contrastive: bool = True
    ) -> np.ndarray:
        """
        Entrena el autoencoder y retorna los embeddings
        
        Args:
            data: Datos de entrada (n_samples, n_features)
            use_contrastive: Si usar pérdida contrastiva además de reconstrucción
        
        Returns:
            Embeddings del espacio latente (n_samples, latent_dim)
        """
        logger.info("Entrenando Deep Autoencoder con aprendizaje contrastivo...")
        
        # Normalización robusta
        data_scaled = self.scaler.fit_transform(data)
        
        # Crear modelo
        input_dim = data_scaled.shape[1]
        self.model = ContrastiveAutoencoder(
            input_dim=input_dim,
            latent_dim=self.config.autoencoder_latent_dim
        ).to(self.device)
        
        # Preparar datos
        tensor_data = torch.FloatTensor(data_scaled)
        dataset = TensorDataset(tensor_data)
        dataloader = DataLoader(
            dataset, 
            batch_size=self.config.batch_size, 
            shuffle=True,
            num_workers=0
        )
        
        # Optimizador y pérdidas
        optimizer = torch.optim.AdamW(
            self.model.parameters(), 
            lr=self.config.learning_rate,
            weight_decay=1e-5
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, 
            T_max=self.config.autoencoder_epochs
        )
        
        reconstruction_loss_fn = nn.MSELoss()
        contrastive_loss_fn = ContrastiveLoss() if use_contrastive else None
        
        # Entrenamiento
        self.model.train()
        best_loss = float('inf')
        patience = 10
        patience_counter = 0
        
        for epoch in range(self.config.autoencoder_epochs):
            epoch_loss = 0.0
            epoch_recon_loss = 0.0
            epoch_contrast_loss = 0.0
            
            for batch in dataloader:
                x = batch[0].to(self.device)
                
                # Forward pass
                x_recon, z, proj = self.model(x)
                
                # Pérdida de reconstrucción
                recon_loss = reconstruction_loss_fn(x_recon, x)
                
                # Pérdida contrastiva (opcional)
                if use_contrastive and contrastive_loss_fn is not None:
                    contrast_loss = contrastive_loss_fn(proj)
                    total_loss = recon_loss + 0.1 * contrast_loss
                    epoch_contrast_loss += contrast_loss.item()
                else:
                    total_loss = recon_loss
                
                # Backpropagation
                optimizer.zero_grad()
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()
                
                epoch_loss += total_loss.item()
                epoch_recon_loss += recon_loss.item()
            
            scheduler.step()
            
            # Logging
            avg_loss = epoch_loss / len(dataloader)
            if (epoch + 1) % 10 == 0:
                logger.info(
                    f"Epoch [{epoch+1}/{self.config.autoencoder_epochs}] "
                    f"Loss: {avg_loss:.4f} "
                    f"Recon: {epoch_recon_loss/len(dataloader):.4f} "
                    f"Contrast: {epoch_contrast_loss/len(dataloader):.4f}"
                )
            
            # Early stopping
            if avg_loss < best_loss:
                best_loss = avg_loss
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    logger.info(f"Early stopping en epoch {epoch+1}")
                    break
        
        # Generar embeddings finales
        self.model.eval()
        embeddings = []
        with torch.no_grad():
            for i in range(0, len(data_scaled), self.config.batch_size):
                batch = data_scaled[i:i+self.config.batch_size]
                batch_tensor = torch.FloatTensor(batch).to(self.device)
                z = self.model.encode(batch_tensor)
                embeddings.append(z.cpu().numpy())
        
        embeddings = np.vstack(embeddings)
        logger.info(f"Embeddings generados: {embeddings.shape}")
        
        return embeddings


# ============================================================================
# MANIFOLD LEARNING Y REDUCCIÓN DE DIMENSIONALIDAD
# ============================================================================

class ManifoldLearner:
    """
    Realiza reducción de dimensionalidad no lineal usando UMAP
    con optimización de hiperparámetros
    """
    
    def __init__(self, config: SystemConfig):
        self.config = config
        self.reducer = None
        
    def optimize_umap_params(
        self, 
        data: np.ndarray, 
        n_neighbors_range: Tuple[int, int] = (5, 100),
        n_trials: int = 10
    ) -> Dict[str, Any]:
        """
        Optimiza hiperparámetros de UMAP buscando mejor separación
        
        Args:
            data: Datos de entrada
            n_neighbors_range: Rango de n_neighbors a explorar
            n_trials: Número de configuraciones a probar
        
        Returns:
            Mejores hiperparámetros encontrados
        """
        logger.info("Optimizando hiperparámetros de UMAP...")
        
        best_score = -1
        best_params = {}
        
        n_neighbors_values = np.linspace(
            n_neighbors_range[0], 
            n_neighbors_range[1], 
            n_trials, 
            dtype=int
        )
        
        for n_neighbors in n_neighbors_values:
            reducer = UMAP(
                n_neighbors=int(n_neighbors),
                min_dist=self.config.umap_min_dist,
                metric=self.config.umap_metric,
                n_components=self.config.umap_n_components,
                random_state=self.config.random_state,
                verbose=False
            )
            
            embedding = reducer.fit_transform(data)
            
            # Evaluar calidad usando silhouette score aproximado
            # (usando una muestra para velocidad)
            sample_size = min(5000, len(embedding))
            indices = np.random.choice(len(embedding), sample_size, replace=False)
            
            # Clustering rápido para evaluación
            from sklearn.cluster import KMeans
            kmeans = KMeans(n_clusters=10, random_state=42, n_init=10)
            labels = kmeans.fit_predict(embedding[indices])
            
            score = silhouette_score(embedding[indices], labels)
            
            if score > best_score:
                best_score = score
                best_params = {'n_neighbors': int(n_neighbors)}
        
        logger.info(f"Mejores parámetros UMAP: {best_params} (score: {best_score:.3f})")
        return best_params
    
    def fit_transform(
        self, 
        data: np.ndarray, 
        optimize: bool = False
    ) -> np.ndarray:
        """
        Ajusta UMAP y transforma los datos
        
        Args:
            data: Datos de alta dimensionalidad
            optimize: Si optimizar hiperparámetros
        
        Returns:
            Embedding de baja dimensión
        """
        params = {}
        if optimize:
            params = self.optimize_umap_params(data)
        
        n_neighbors = params.get('n_neighbors', self.config.umap_n_neighbors)
        
        logger.info(f"Ejecutando UMAP con n_neighbors={n_neighbors}...")
        
        self.reducer = UMAP(
            n_neighbors=n_neighbors,
            min_dist=self.config.umap_min_dist,
            metric=self.config.umap_metric,
            n_components=self.config.umap_n_components,
            random_state=self.config.random_state,
            verbose=self.config.verbose
        )
        
        embedding = self.reducer.fit_transform(data)
        logger.info(f"UMAP completado: {embedding.shape}")
        
        return embedding


# ============================================================================
# ALGORITMOS DE CLUSTERING AVANZADOS
# ============================================================================

class AdvancedClustering:
    """
    Suite de algoritmos de clustering avanzados con optimización automática
    """
    
    def __init__(self, config: SystemConfig):
        self.config = config
        
    def eigengap_heuristic(self, affinity_matrix: np.ndarray, max_k: int = 20) -> int:
        """
        Heurística del Eigengap para determinar número óptimo de clusters
        para Spectral Clustering
        
        Args:
            affinity_matrix: Matriz de afinidad
            max_k: Número máximo de clusters a considerar
        
        Returns:
            Número óptimo de clusters
        """
        logger.info("Calculando heurística Eigengap...")
        
        # Calcular Laplaciano normalizado
        degree = np.sum(affinity_matrix, axis=1)
        degree_inv_sqrt = np.diag(1.0 / np.sqrt(degree + 1e-10))
        laplacian = np.eye(len(affinity_matrix)) - degree_inv_sqrt @ affinity_matrix @ degree_inv_sqrt
        
        # Calcular valores propios
        eigenvalues, _ = eigh(laplacian)
        eigenvalues = np.sort(eigenvalues)
        
        # Calcular eigengaps
        eigengaps = np.diff(eigenvalues[:max_k])
        
        # El óptimo es donde el gap es máximo
        optimal_k = np.argmax(eigengaps) + 2  # +2 porque diff reduce en 1 y queremos el siguiente
        
        logger.info(f"Eigengap sugiere K={optimal_k}")
        return optimal_k
    
    def spectral_clustering(
        self, 
        data: np.ndarray, 
        n_clusters: Optional[int] = None,
        use_eigengap: bool = True
    ) -> ClusteringResults:
        """
        Ejecuta Spectral Clustering con determinación automática de K
        
        Args:
            data: Datos de entrada
            n_clusters: Número de clusters (si None, se usa eigengap)
            use_eigengap: Si usar heurística eigengap
        
        Returns:
            Resultados del clustering
        """
        logger.info("Ejecutando Spectral Clustering...")
        
        # Determinar número de clusters
        if n_clusters is None and use_eigengap:
            # Calcular matriz de afinidad
            from sklearn.metrics.pairwise import rbf_kernel
            affinity = rbf_kernel(data, gamma=1.0)
            n_clusters = self.eigengap_heuristic(affinity)
        elif n_clusters is None:
            n_clusters = 10  # Default
        
        # Ejecutar clustering
        clusterer = SpectralClustering(
            n_clusters=n_clusters,
            affinity='rbf',
            assign_labels='kmeans',
            random_state=self.config.random_state,
            n_jobs=self.config.n_jobs
        )
        
        labels = clusterer.fit_predict(data)
        
        # Calcular métricas
        metrics = {
            'silhouette': silhouette_score(data, labels),
            'davies_bouldin': davies_bouldin_score(data, labels),
            'calinski_harabasz': calinski_harabasz_score(data, labels)
        }
        
        logger.info(f"Spectral Clustering: K={n_clusters}, Silhouette={metrics['silhouette']:.3f}")
        
        return ClusteringResults(
            labels=labels,
            embeddings=data,
            metrics=metrics,
            algorithm='SpectralClustering',
            n_clusters=n_clusters
        )
    
    def minibatch_kmeans(
        self, 
        data: np.ndarray, 
        k_range: Tuple[int, int] = (2, 20)
    ) -> ClusteringResults:
        """
        Ejecuta MiniBatch K-means con selección óptima de K
        
        Args:
            data: Datos de entrada
            k_range: Rango de K a explorar
        
        Returns:
            Resultados del clustering
        """
        logger.info("Ejecutando MiniBatch K-means con optimización de K...")
        
        best_score = -1
        best_k = k_range[0]
        best_labels = None
        
        scores = []
        k_values = range(k_range[0], k_range[1] + 1)
        
        for k in k_values:
            clusterer = MiniBatchKMeans(
                n_clusters=k,
                init='k-means++',
                random_state=self.config.random_state,
                batch_size=self.config.batch_size,
                n_init=10
            )
            labels = clusterer.fit_predict(data)
            
            # Silhouette score para selección
            score = silhouette_score(data, labels)
            scores.append(score)
            
            if score > best_score:
                best_score = score
                best_k = k
                best_labels = labels
        
        # Métricas finales
        metrics = {
            'silhouette': silhouette_score(data, best_labels),
            'davies_bouldin': davies_bouldin_score(data, best_labels),
            'calinski_harabasz': calinski_harabasz_score(data, best_labels),
            'k_scores': dict(zip(k_values, scores))
        }
        
        logger.info(f"K-means: K óptimo={best_k}, Silhouette={best_score:.3f}")
        
        return ClusteringResults(
            labels=best_labels,
            embeddings=data,
            metrics=metrics,
            algorithm='MiniBatchKMeans',
            n_clusters=best_k
        )
    
    def hdbscan_clustering(self, data: np.ndarray) -> ClusteringResults:
        """
        Ejecuta HDBSCAN con detección de outliers
        
        Args:
            data: Datos de entrada
        
        Returns:
            Resultados del clustering con scores GLOSH
        """
        logger.info("Ejecutando HDBSCAN con detección de outliers...")
        
        clusterer = hdbscan.HDBSCAN(
            min_cluster_size=self.config.hdbscan_min_cluster_size,
            min_samples=self.config.hdbscan_min_samples,
            metric=self.config.hdbscan_metric,
            core_dist_n_jobs=self.config.n_jobs
        )
        
        labels = clusterer.fit_predict(data)
        
        # Obtener scores GLOSH
        outlier_scores = clusterer.outlier_scores_
        
        # Métricas (excluyendo ruido -1)
        mask = labels != -1
        if mask.sum() > 0:
            metrics = {
                'silhouette': silhouette_score(data[mask], labels[mask]),
                'davies_bouldin': davies_bouldin_score(data[mask], labels[mask]),
                'calinski_harabasz': calinski_harabasz_score(data[mask], labels[mask]),
                'n_outliers': (labels == -1).sum(),
                'outlier_percentage': (labels == -1).sum() / len(labels) * 100
            }
        else:
            metrics = {'error': 'No se encontraron clusters válidos'}
        
        n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
        
        logger.info(
            f"HDBSCAN: {n_clusters} clusters, "
            f"{metrics.get('n_outliers', 0)} outliers "
            f"({metrics.get('outlier_percentage', 0):.1f}%)"
        )
        
        return ClusteringResults(
            labels=labels,
            embeddings=data,
            metrics=metrics,
            outlier_scores=outlier_scores,
            algorithm='HDBSCAN',
            n_clusters=n_clusters
        )


# ============================================================================
# VALIDACIÓN Y EVALUACIÓN
# ============================================================================

class ClusteringEvaluator:
    """
    Evaluación exhaustiva de resultados de clustering
    """
    
    @staticmethod
    def evaluate_with_ground_truth(
        labels_pred: np.ndarray, 
        labels_true: np.ndarray
    ) -> Dict[str, float]:
        """
        Evalúa clustering con etiquetas de referencia (métricas extrínsecas)
        
        Args:
            labels_pred: Etiquetas predichas
            labels_true: Etiquetas verdaderas
        
        Returns:
            Diccionario con métricas ARI y NMI
        """
        return {
            'adjusted_rand_index': adjusted_rand_score(labels_true, labels_pred),
            'normalized_mutual_info': normalized_mutual_info_score(labels_true, labels_pred)
        }
    
    @staticmethod
    def compare_algorithms(
        results: List[ClusteringResults]
    ) -> pd.DataFrame:
        """
        Compara múltiples resultados de clustering
        
        Args:
            results: Lista de ClusteringResults
        
        Returns:
            DataFrame comparativo
        """
        comparison = []
        
        for result in results:
            row = {
                'Algorithm': result.algorithm,
                'N_Clusters': result.n_clusters,
                **result.metrics
            }
            comparison.append(row)
        
        df = pd.DataFrame(comparison)
        return df.sort_values('silhouette', ascending=False)
    
    @staticmethod
    def robustness_analysis(
        data: np.ndarray,
        clustering_fn: callable,
        noise_levels: List[float] = [0.0, 0.1, 0.2, 0.3],
        n_trials: int = 5
    ) -> Dict[str, Any]:
        """
        Analiza robustez del clustering frente al ruido
        
        Args:
            data: Datos originales
            clustering_fn: Función de clustering
            noise_levels: Niveles de ruido a inyectar
            n_trials: Número de repeticiones por nivel
        
        Returns:
            Resultados de robustez
        """
        logger.info("Realizando análisis de robustez...")
        
        results = {level: [] for level in noise_levels}
        
        for noise_level in noise_levels:
            for trial in range(n_trials):
                # Inyectar ruido gaussiano
                if noise_level > 0:
                    noise = np.random.normal(0, noise_level * data.std(), data.shape)
                    noisy_data = data + noise
                else:
                    noisy_data = data
                
                # Ejecutar clustering
                result = clustering_fn(noisy_data)
                
                # Guardar métricas
                results[noise_level].append(result.metrics.get('silhouette', 0))
        
        # Calcular estadísticas
        summary = {}
        for level in noise_levels:
            summary[f'noise_{level}'] = {
                'mean': np.mean(results[level]),
                'std': np.std(results[level]),
                'min': np.min(results[level]),
                'max': np.max(results[level])
            }
        
        return summary


# ============================================================================
# FILTRADO DE OUTLIERS Y LIMPIEZA DE DATOS
# ============================================================================

class OutlierFilter:
    """
    Filtrado proactivo de outliers usando HDBSCAN/GLOSH
    """
    
    def __init__(self, config: SystemConfig):
        self.config = config
        self.outlier_mask = None
        
    def filter_outliers(
        self, 
        data: np.ndarray, 
        outlier_scores: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Filtra outliers basándose en scores GLOSH
        
        Args:
            data: Datos originales
            outlier_scores: Scores de outlier de HDBSCAN
        
        Returns:
            Datos limpios y máscara de outliers
        """
        # Calcular umbral basado en percentil
        threshold = np.percentile(outlier_scores, self.config.outlier_percentile)
        
        # Crear máscara (True = inlier, False = outlier)
        self.outlier_mask = outlier_scores <= threshold
        
        n_outliers = (~self.outlier_mask).sum()
        logger.info(
            f"Outliers detectados: {n_outliers} "
            f"({n_outliers/len(data)*100:.2f}%)"
        )
        
        return data[self.outlier_mask], self.outlier_mask


# ============================================================================
# VISUALIZACIÓN AVANZADA
# ============================================================================

class AdvancedVisualizer:
    """
    Sistema de visualización interactiva con Plotly
    """
    
    @staticmethod
    def plot_embeddings_comparison(
        embeddings: np.ndarray,
        results_list: List[ClusteringResults],
        titles: List[str] = None
    ) -> go.Figure:
        """
        Compara múltiples resultados de clustering en el espacio 2D
        
        Args:
            embeddings: Embeddings 2D
            results_list: Lista de resultados de clustering
            titles: Títulos para cada subplot
        
        Returns:
            Figura de Plotly
        """
        n_plots = len(results_list)
        cols = min(3, n_plots)
        rows = (n_plots + cols - 1) // cols
        
        if titles is None:
            titles = [r.algorithm for r in results_list]
        
        fig = make_subplots(
            rows=rows, 
            cols=cols,
            subplot_titles=titles,
            specs=[[{'type': 'scatter'}] * cols for _ in range(rows)]
        )
        
        for idx, result in enumerate(results_list):
            row = idx // cols + 1
            col = idx % cols + 1
            
            labels = result.labels
            
            # Manejar outliers (-1) de HDBSCAN
            unique_labels = np.unique(labels)
            colors = labels.copy()
            
            scatter = go.Scatter(
                x=embeddings[:, 0],
                y=embeddings[:, 1],
                mode='markers',
                marker=dict(
                    size=4,
                    color=colors,
                    colorscale='Viridis',
                    showscale=(idx == 0),
                    line=dict(width=0.5, color='white')
                ),
                text=[f'Cluster: {l}<br>Point: {i}' for i, l in enumerate(labels)],
                hovertemplate='<b>%{text}</b><br>X: %{x:.2f}<br>Y: %{y:.2f}<extra></extra>',
                showlegend=False
            )
            
            fig.add_trace(scatter, row=row, col=col)
        
        fig.update_layout(
            title_text="Comparación de Algoritmos de Clustering",
            height=300 * rows,
            showlegend=False
        )
        
        return fig
    
    @staticmethod
    def plot_outlier_distribution(
        embeddings: np.ndarray,
        outlier_scores: np.ndarray,
        labels: np.ndarray,
        threshold_percentile: float = 95
    ) -> go.Figure:
        """
        Visualiza distribución de outliers en el espacio de embeddings
        
        Args:
            embeddings: Embeddings 2D
            outlier_scores: Scores GLOSH
            labels: Etiquetas de cluster
            threshold_percentile: Percentil para umbral de outlier
        
        Returns:
            Figura de Plotly
        """
        threshold = np.percentile(outlier_scores, threshold_percentile)
        is_outlier = outlier_scores > threshold
        
        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('Distribución de Outliers', 'Histograma de Scores'),
            specs=[[{'type': 'scatter'}, {'type': 'histogram'}]]
        )
        
        # Scatter plot con outliers destacados
        colors = np.where(is_outlier, 'red', 'blue')
        sizes = np.where(is_outlier, 8, 4)
        
        scatter = go.Scatter(
            x=embeddings[:, 0],
            y=embeddings[:, 1],
            mode='markers',
            marker=dict(
                size=sizes,
                color=colors,
                opacity=0.6,
                line=dict(width=0.5, color='white')
            ),
            text=[
                f'Cluster: {l}<br>Outlier Score: {s:.3f}<br>{"OUTLIER" if o else "Normal"}'
                for l, s, o in zip(labels, outlier_scores, is_outlier)
            ],
            hovertemplate='<b>%{text}</b><br>X: %{x:.2f}<br>Y: %{y:.2f}<extra></extra>',
            showlegend=False
        )
        
        fig.add_trace(scatter, row=1, col=1)
        
        # Histograma de scores
        histogram = go.Histogram(
            x=outlier_scores,
            nbinsx=50,
            marker=dict(color='steelblue'),
            showlegend=False
        )
        
        fig.add_trace(histogram, row=1, col=2)
        
        # Línea de umbral
        fig.add_vline(
            x=threshold, 
            line_dash="dash", 
            line_color="red",
            annotation_text=f"Umbral (p{threshold_percentile})",
            row=1, col=2
        )
        
        fig.update_layout(
            title_text=f"Análisis de Outliers (GLOSH) - {is_outlier.sum()} outliers detectados",
            height=500
        )
        
        return fig
    
    @staticmethod
    def plot_metrics_comparison(comparison_df: pd.DataFrame) -> go.Figure:
        """
        Visualiza comparación de métricas entre algoritmos
        
        Args:
            comparison_df: DataFrame con métricas comparativas
        
        Returns:
            Figura de Plotly
        """
        metrics = [col for col in comparison_df.columns 
                   if col not in ['Algorithm', 'N_Clusters']]
        
        fig = go.Figure()
        
        for metric in metrics:
            if metric in comparison_df.columns:
                y_numeric = pd.to_numeric(comparison_df[metric], errors='coerce')
                fig.add_trace(go.Bar(
                    name=metric,
                    x=comparison_df['Algorithm'],
                    y=y_numeric, # Usar la serie numérica
                    text=y_numeric.round(3), # Aplicar .round(3) a la serie numérica
                    textposition='auto',
                ))
        
        fig.update_layout(
            title='Comparación de Métricas de Clustering',
            xaxis_title='Algoritmo',
            yaxis_title='Valor de Métrica',
            barmode='group',
            height=500
        )
        
        return fig
    
    @staticmethod
    def plot_eigengap(eigenvalues: np.ndarray, optimal_k: int) -> go.Figure:
        """
        Visualiza análisis de eigengap
        
        Args:
            eigenvalues: Valores propios ordenados
            optimal_k: K óptimo detectado
        
        Returns:
            Figura de Plotly
        """
        eigengaps = np.diff(eigenvalues)
        
        fig = make_subplots(
            rows=1, cols=2,
            subplot_titles=('Valores Propios', 'Eigengaps')
        )
        
        # Valores propios
        fig.add_trace(
            go.Scatter(
                x=list(range(len(eigenvalues))),
                y=eigenvalues,
                mode='lines+markers',
                name='Eigenvalues',
                line=dict(color='blue')
            ),
            row=1, col=1
        )
        
        # Eigengaps
        fig.add_trace(
            go.Scatter(
                x=list(range(len(eigengaps))),
                y=eigengaps,
                mode='lines+markers',
                name='Eigengaps',
                line=dict(color='red')
            ),
            row=1, col=2
        )
        
        # Marcar K óptimo
        fig.add_vline(
            x=optimal_k-2,
            line_dash="dash",
            line_color="green",
            annotation_text=f"K óptimo = {optimal_k}",
            row=1, col=2
        )
        
        fig.update_layout(
            title_text='Análisis Eigengap para Spectral Clustering',
            height=400
        )
        
        return fig


# ============================================================================
# PIPELINE PRINCIPAL INTEGRADO
# ============================================================================

class AdvancedUnsupervisedPipeline:
    """
    Pipeline completo de análisis no supervisado de vanguardia
    Integra todas las técnicas avanzadas en un flujo optimizado
    """
    
    def __init__(self, config: SystemConfig = None):
        if config is None:
            config = SystemConfig()
        
        self.config = config
        self.feature_extractor = None
        self.deep_learner = DeepEmbeddingLearner(config)
        self.manifold_learner = ManifoldLearner(config)
        self.clusterer = AdvancedClustering(config)
        self.outlier_filter = OutlierFilter(config)
        self.evaluator = ClusteringEvaluator()
        self.visualizer = AdvancedVisualizer()
        
        self.results = {}
        self.embeddings = None
        self.clean_data = None
        
    def set_feature_extractor(self, extractor: FeatureExtractor):
        """Configura el extractor de características específico del dominio"""
        self.feature_extractor = extractor
        
    def run_full_pipeline(
        self,
        data: np.ndarray,
        ground_truth: Optional[np.ndarray] = None,
        use_deep_learning: bool = True,
        use_outlier_filtering: bool = True,
        optimize_umap: bool = True,
        visualize: bool = True
    ) -> Dict[str, Any]:
        """
        Ejecuta el pipeline completo de análisis
        
        Args:
            data: Datos de entrada (raw o features)
            ground_truth: Etiquetas verdaderas (opcional, para evaluación)
            use_deep_learning: Si usar embeddings profundos
            use_outlier_filtering: Si filtrar outliers proactivamente
            optimize_umap: Si optimizar hiperparámetros de UMAP
            visualize: Si generar visualizaciones
        
        Returns:
            Diccionario con todos los resultados del análisis
        """
        logger.info("="*70)
        logger.info("INICIANDO PIPELINE AVANZADO DE ANÁLISIS NO SUPERVISADO")
        logger.info("="*70)
        
        # ETAPA 1: Extracción de características específicas del dominio
        logger.info("\n[ETAPA 1] Extracción de características...")
        if self.feature_extractor is not None:
            features = self.feature_extractor.extract(data)
        else:
            features = data
        
        logger.info(f"Características extraídas: {features.shape}")
        
        # ETAPA 2: Deep Learning para embeddings discriminativos (opcional)
        if use_deep_learning:
            logger.info("\n[ETAPA 2] Generación de embeddings profundos...")
            deep_embeddings = self.deep_learner.train_autoencoder(
                features, 
                use_contrastive=True
            )
            working_data = deep_embeddings
        else:
            working_data = features
        
        # ETAPA 3: Detección inicial de outliers con HDBSCAN
        logger.info("\n[ETAPA 3] Detección de outliers con HDBSCAN...")
        hdbscan_result = self.clusterer.hdbscan_clustering(working_data)
        self.results['hdbscan_initial'] = hdbscan_result
        
        # ETAPA 4: Filtrado proactivo de outliers (opcional)
        if use_outlier_filtering and hdbscan_result.outlier_scores is not None:
            logger.info("\n[ETAPA 4] Filtrado proactivo de outliers...")
            self.clean_data, outlier_mask = self.outlier_filter.filter_outliers(
                working_data,
                hdbscan_result.outlier_scores
            )
            
            # Actualizar ground truth si existe
            if ground_truth is not None:
                clean_ground_truth = ground_truth[outlier_mask]
            else:
                clean_ground_truth = None
        else:
            self.clean_data = working_data
            outlier_mask = np.ones(len(working_data), dtype=bool)
            clean_ground_truth = ground_truth
        
        # ETAPA 5: Manifold Learning (UMAP)
        logger.info("\n[ETAPA 5] Reducción de dimensionalidad con UMAP...")
        self.embeddings = self.manifold_learner.fit_transform(
            self.clean_data,
            optimize=optimize_umap
        )
        
        # ETAPA 6: Clustering comparativo
        logger.info("\n[ETAPA 6] Clustering comparativo...")
        
        # K-means
        logger.info("  → Ejecutando MiniBatch K-means...")
        kmeans_result = self.clusterer.minibatch_kmeans(
            self.embeddings,
            k_range=(2, 15)
        )
        self.results['kmeans'] = kmeans_result
        
        # Spectral Clustering
        logger.info("  → Ejecutando Spectral Clustering...")
        spectral_result = self.clusterer.spectral_clustering(
            self.embeddings,
            use_eigengap=True
        )
        self.results['spectral'] = spectral_result
        
        # HDBSCAN en espacio reducido
        logger.info("  → Ejecutando HDBSCAN en espacio reducido...")
        hdbscan_final = self.clusterer.hdbscan_clustering(self.embeddings)
        self.results['hdbscan_final'] = hdbscan_final
        
        # ETAPA 7: Evaluación
        logger.info("\n[ETAPA 7] Evaluación y comparación...")
        
        # Comparación de algoritmos
        comparison_df = self.evaluator.compare_algorithms([
            kmeans_result,
            spectral_result,
            hdbscan_final
        ])
        
        logger.info("\n" + "="*70)
        logger.info("COMPARACIÓN DE ALGORITMOS:")
        logger.info("="*70)
        print(comparison_df.to_string(index=False))
        
        # Evaluación con ground truth (si disponible)
        if clean_ground_truth is not None:
            logger.info("\n[EVALUACIÓN CON GROUND TRUTH]")
            
            for name, result in [
                ('K-means', kmeans_result),
                ('Spectral', spectral_result),
                ('HDBSCAN', hdbscan_final)
            ]:
                # Para HDBSCAN, excluir outliers
                if name == 'HDBSCAN':
                    mask = result.labels != -1
                    if mask.sum() > 0:
                        metrics = self.evaluator.evaluate_with_ground_truth(
                            result.labels[mask],
                            clean_ground_truth[mask]
                        )
                    else:
                        metrics = {}
                else:
                    metrics = self.evaluator.evaluate_with_ground_truth(
                        result.labels,
                        clean_ground_truth
                    )
                
                logger.info(f"\n{name}:")
                for metric, value in metrics.items():
                    logger.info(f"  {metric}: {value:.4f}")
        
        # ETAPA 8: Visualización
        figures = {}
        if visualize:
            logger.info("\n[ETAPA 8] Generando visualizaciones...")
            
            # Comparación de clustering
            fig_comparison = self.visualizer.plot_embeddings_comparison(
                self.embeddings,
                [kmeans_result, spectral_result, hdbscan_final],
                ['MiniBatch K-means', 'Spectral Clustering', 'HDBSCAN']
            )
            figures['comparison'] = fig_comparison
            
            # Análisis de outliers
            if hdbscan_final.outlier_scores is not None:
                fig_outliers = self.visualizer.plot_outlier_distribution(
                    self.embeddings,
                    hdbscan_final.outlier_scores,
                    hdbscan_final.labels,
                    threshold_percentile=self.config.outlier_percentile
                )
                figures['outliers'] = fig_outliers
            
            # Comparación de métricas
            fig_metrics = self.visualizer.plot_metrics_comparison(comparison_df)
            figures['metrics'] = fig_metrics
        
        # Compilar resultados finales
        final_results = {
            'embeddings': self.embeddings,
            'clean_data': self.clean_data,
            'outlier_mask': outlier_mask,
            'clustering_results': self.results,
            'comparison_dataframe': comparison_df,
            'figures': figures,
            'config': self.config
        }
        
        logger.info("\n" + "="*70)
        logger.info("PIPELINE COMPLETADO EXITOSAMENTE")
        logger.info("="*70 + "\n")
        
        return final_results


# ============================================================================
# EJEMPLO DE USO Y DEMOSTRACIÓN
# ============================================================================

def demonstrate_pipeline():
    """
    Función de demostración del pipeline completo
    """
    logger.info("Iniciando demostración del sistema avanzado...\n")
    
    # Configuración
    config = SystemConfig(
        use_gpu=False,  # Cambiar a True si hay GPU disponible
        umap_n_neighbors=15,
        umap_min_dist=0.05,
        hdbscan_min_cluster_size=10,
        autoencoder_latent_dim=32,
        autoencoder_epochs=50,
        batch_size=128,
        outlier_percentile=95.0,
        verbose=True
    )
    
    # Generar datos sintéticos (simulando Fashion-MNIST)
    logger.info("Generando datos sintéticos para demostración...")
    np.random.seed(42)
    
    # 5 clusters con diferentes formas
    n_samples_per_cluster = 200
    n_features = 50
    
    data_list = []
    labels_list = []
    
    # Cluster 1: Gaussiano compacto
    data_list.append(np.random.randn(n_samples_per_cluster, n_features) * 0.5)
    labels_list.append(np.zeros(n_samples_per_cluster))
    
    # Cluster 2: Gaussiano desplazado
    data_list.append(np.random.randn(n_samples_per_cluster, n_features) * 0.7 + 3)
    labels_list.append(np.ones(n_samples_per_cluster))
    
    # Cluster 3: Forma alargada
    data_list.append(np.random.randn(n_samples_per_cluster, n_features) * np.array([0.3, 1.5] + [0.5]*(n_features-2)) + 6)
    labels_list.append(np.ones(n_samples_per_cluster) * 2)
    
    # Cluster 4: Distribución uniforme
    data_list.append(np.random.uniform(-2, -0.5, (n_samples_per_cluster, n_features)))
    labels_list.append(np.ones(n_samples_per_cluster) * 3)
    
    # Cluster 5: Gaussiano con alta varianza
    data_list.append(np.random.randn(n_samples_per_cluster, n_features) * 1.2 + np.array([8]*n_features))
    labels_list.append(np.ones(n_samples_per_cluster) * 4)
    
    # Agregar outliers
    n_outliers = 50
    outliers = np.random.uniform(-10, 15, (n_outliers, n_features))
    data_list.append(outliers)
    labels_list.append(np.ones(n_outliers) * -1)  # -1 para outliers
    
    synthetic_data = np.vstack(data_list)
    synthetic_labels = np.concatenate(labels_list)
    
    # Mezclar datos
    indices = np.random.permutation(len(synthetic_data))
    synthetic_data = synthetic_data[indices]
    synthetic_labels = synthetic_labels[indices]
    
    logger.info(f"Datos sintéticos generados: {synthetic_data.shape}")
    logger.info(f"Distribución de clases: {np.bincount(synthetic_labels.astype(int) + 1)}\n")
    
    # Crear pipeline
    pipeline = AdvancedUnsupervisedPipeline(config)
    
    # Configurar extractor de características (imagen)
    pipeline.set_feature_extractor(ImageFeatureExtractor(use_pca=True, n_components=40))
    
    # Ejecutar pipeline completo
    results = pipeline.run_full_pipeline(
        data=synthetic_data,
        ground_truth=synthetic_labels,
        use_deep_learning=True,
        use_outlier_filtering=True,
        optimize_umap=False,  # Para velocidad en demo
        visualize=True
    )
    
    # Mostrar visualizaciones
    if results['figures']:
        logger.info("\nGenerando visualizaciones interactivas...")
        
        for name, fig in results['figures'].items():
            fig.show()
            logger.info(f"  ✓ Visualización '{name}' generada")
    
    # Análisis de robustez (opcional)
    logger.info("\n[ANÁLISIS DE ROBUSTEZ]")
    robustness = pipeline.evaluator.robustness_analysis(
        data=results['clean_data'],
        clustering_fn=lambda x: pipeline.clusterer.minibatch_kmeans(x, k_range=(2, 10)),
        noise_levels=[0.0, 0.1, 0.2],
        n_trials=3
    )
    
    logger.info("\nResultados de robustez:")
    for level, stats in robustness.items():
        logger.info(f"  {level}: mean={stats['mean']:.3f}, std={stats['std']:.3f}")
    
    return results


# ============================================================================
# PUNTO DE ENTRADA
# ============================================================================

if __name__ == "__main__":
    print("""
    ╔══════════════════════════════════════════════════════════════════════╗
    ║  Sistema Avanzado de Análisis No Supervisado                        ║
    ║  ----------------------------------------------------------------    ║
    ║  Características principales:                                        ║
    ║  • Deep Learning con Autoencoders y Contrastive Learning            ║
    ║  • Manifold Learning optimizado (UMAP)                              ║
    ║  • Clustering comparativo (K-means, Spectral, HDBSCAN)              ║
    ║  • Detección avanzada de outliers (GLOSH)                           ║
    ║  • Optimización automática de hiperparámetros                       ║
    ║  • Visualización interactiva con Plotly                             ║
    ║  • Soporte para aceleración GPU                                     ║
    ║  • Evaluación exhaustiva y análisis de robustez                     ║
    ╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    # Ejecutar demostración
    results = demonstrate_pipeline()
    
    print("\n✓ Demostración completada exitosamente!")
    print("\nPara usar este sistema con datos reales:")
    print("  1. Instanciar AdvancedUnsupervisedPipeline con configuración personalizada")
    print("  2. Configurar el extractor de características apropiado")
    print("  3. Ejecutar run_full_pipeline() con tus datos")
    print("  4. Analizar resultados y visualizaciones")
    print("\nConsulta la documentación en cada clase para más detalles.")