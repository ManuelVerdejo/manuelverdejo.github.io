"""
SIMULADOR DE CIVILIZACIONES AVANZADO V2.0
Extensión con:
- Clima dinámico (estaciones, eventos extremos)
- Eventos geológicos (volcanes, terremotos, tsunamis)
- Ciclos de recursos renovables
- Ecosistemas vivos (fauna, flora, plagas)
- Migraciones poblacionales
- Diplomacia entre civilizaciones
- Evolución tecnológica por eras
- Demografía detallada (edad, natalidad, mortalidad)
- Comercio internacional
- Religiones organizadas
- Conflictos y guerras dinámicas
- Métricas avanzadas y visualizaciones
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Set
from enum import Enum
from collections import defaultdict
import random
import math
from scipy.spatial import Voronoi
from scipy.ndimage import gaussian_filter
import json

# ==============================================================================
# CONFIGURACIÓN EXTENDIDA
# ==============================================================================

class Config:
    """Configuración global del simulador"""
    # Dimensiones
    WORLD_WIDTH = 500
    WORLD_HEIGHT = 500
    
    # Simulación básica
    MAX_AGENTS = 10000
    NUM_TECTONIC_PLATES = 12
    SIMULATION_SEED = 42
    
    # Economía
    INITIAL_WEALTH_MEAN = 200
    INITIAL_WEALTH_STD = 50
    MARKET_TAX_RATE = 0.02
    
    # Cultura
    MEME_MUTATION_RATE = 0.01
    SYNCRETISM_THRESHOLD = 0.3
    
    # Optimización
    GEOSPHERE_UPDATE_INTERVAL = 50
    CHUNK_SIZE = 500
    
    # NUEVO: Clima dinámico
    SEASON_LENGTH = 25
    WEATHER_EVENT_PROBABILITY = 0.08
    GEOLOGICAL_EVENT_PROBABILITY = 0.02
    
    # NUEVO: Demografía
    BIRTH_RATE_BASE = 0.4
    DEATH_RATE_BASE = 0.002
    MAX_AGE = 100
    MIN_REPRODUCTION_AGE = 14
    
    # NUEVO: Recursos renovables
    FOREST_REGENERATION_RATE = 0.02
    MINE_DEPLETION_RATE = 0.02
    SOIL_EROSION_RATE = 0.001
    
    # NUEVO: Ecosistema
    FAUNA_DENSITY = 0.1
    DOMESTICATION_THRESHOLD = 50
    PLAGUE_PROBABILITY = 0.01
    
    # NUEVO: Diplomacia
    WAR_DECLARATION_THRESHOLD = 0.25
    ALLIANCE_TRUST_THRESHOLD = 0.3
    TRADE_ROUTE_COST = 10
    
    # NUEVO: Tecnología
    TECH_DISCOVERY_RATE = 0.015
    TECH_DIFFUSION_RATE = 0.15

# ==============================================================================
# ENUMS EXTENDIDOS
# ==============================================================================

class Season(Enum):
    SPRING = "spring"
    SUMMER = "summer"
    AUTUMN = "autumn"
    WINTER = "winter"

class GeologicalEvent(Enum):
    EARTHQUAKE = "earthquake"
    VOLCANO = "volcano"
    TSUNAMI = "tsunami"
    GLACIATION = "glaciation"

class WeatherEvent(Enum):
    DROUGHT = "drought"
    FLOOD = "flood"
    HURRICANE = "hurricane"
    WILDFIRE = "wildfire"

class TechnologyEra(Enum):
    STONE_AGE = 0
    BRONZE_AGE = 1
    IRON_AGE = 2
    CLASSICAL_AGE = 3
    MEDIEVAL_AGE = 4
    
class AgentRole(Enum):
    FARMER = "farmer"
    WARRIOR = "warrior"
    SCHOLAR = "scholar"
    PRIEST = "priest"
    MERCHANT = "merchant"
    LEADER = "leader"
    
class DiplomacyRelation(Enum):
    WAR = -2
    HOSTILE = -1
    NEUTRAL = 0
    TRADE = 1
    ALLIANCE = 2

class BiomeType(Enum):
    OCEAN = 0
    TUNDRA = 1
    TAIGA = 2
    GRASSLAND = 3
    TEMPERATE_FOREST = 4
    TROPICAL_RAINFOREST = 5
    DESERT = 6
    SAVANNA = 7
    MOUNTAIN = 8

class ResourceType(Enum):
    FOOD = "food"
    WOOD = "wood"
    STONE = "stone"
    METAL = "metal"
    GOLD = "gold"
    KNOWLEDGE = "knowledge"

class MemeType(Enum):
    TECHNOLOGY = "tech"
    BELIEF = "belief"
    PRACTICE = "practice"
    VALUE = "value"
    LANGUAGE = "language"
    
class BuildingType(Enum):
    FARM = "farm"
    MINE = "mine"
    BARRACKS = "barracks"
    TEMPLE = "temple"
    MARKET = "market"
    LIBRARY = "library"

class GovernmentType(Enum):
    TRIBAL = "tribal"
    MONARCHY = "monarchy"
    REPUBLIC = "republic"
    THEOCRACY = "theocracy"
    
class SpatialGrid:
    """
    Grid espacial para optimizar búsquedas de vecinos
    Divide el mundo en celdas de 10x10 para acelerar queries
    """
    
    def __init__(self, width: int, height: int, cell_size: int = 10):
        self.cell_size = cell_size
        self.grid_width = width // cell_size + 1
        self.grid_height = height // cell_size + 1
        
        # Dict: (grid_y, grid_x) -> Set[agent_id]
        self.cells = defaultdict(set)
    
    def add_agent(self, agent_id: str, location: Tuple[int, int]):
        """Añade agente a su celda"""
        grid_pos = self._get_grid_pos(location)
        self.cells[grid_pos].add(agent_id)
    
    def remove_agent(self, agent_id: str, location: Tuple[int, int]):
        """Remueve agente de su celda"""
        grid_pos = self._get_grid_pos(location)
        self.cells[grid_pos].discard(agent_id)
    
    def move_agent(self, agent_id: str, old_loc: Tuple[int, int], 
                   new_loc: Tuple[int, int]):
        """Mueve agente entre celdas si cambió"""
        old_grid = self._get_grid_pos(old_loc)
        new_grid = self._get_grid_pos(new_loc)
        
        if old_grid != new_grid:
            self.cells[old_grid].discard(agent_id)
            self.cells[new_grid].add(agent_id)
    
    def get_nearby_agents(self, location: Tuple[int, int], 
                         radius: int = 1) -> Set[str]:
        """Obtiene agentes en celdas vecinas (mucho más rápido que buscar todos)"""
        grid_pos = self._get_grid_pos(location)
        gy, gx = grid_pos
        
        nearby = set()
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                cell_pos = (gy + dy, gx + dx)
                nearby.update(self.cells.get(cell_pos, set()))
        
        return nearby
    
    def get_agents_in_cell(self, location: Tuple[int, int]) -> Set[str]:
        """Obtiene agentes en una celda específica"""
        grid_pos = self._get_grid_pos(location)
        return self.cells.get(grid_pos, set())
    
    def _get_grid_pos(self, location: Tuple[int, int]) -> Tuple[int, int]:
        """Convierte coordenada mundial a coordenada de grid"""
        y, x = location
        return (y // self.cell_size, x // self.cell_size)
    
class ImprovedGeosphere:
    """Geosfera con generación procedural realista"""
    
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        
        # Generar heightmap con ruido Perlin simulado
        self.heightmap = self._generate_heightmap()
        
        # Generar biomas basados en altura, temperatura y precipitación
        self.temperature_map = self._calculate_temperature()
        self.precipitation_map = self._calculate_precipitation()
        self.biome_map = self._assign_biomes()
        
        # Fertilidad y erosión
        self.fertility_map = self._calculate_fertility()
        self.erosion_map = np.zeros((height, width))
        
        # Ríos
        self.river_map = np.zeros((height, width))
        self.water_flow = np.zeros((height, width))
        self.generate_rivers()
    
    def _generate_heightmap(self) -> np.ndarray:
        """Genera heightmap con múltiples octavas de ruido"""
        heightmap = np.zeros((self.height, self.width))
        
        # Simulación de ruido Perlin con múltiples frecuencias
        scales = [128, 64, 32, 16, 8]
        weights = [0.5, 0.25, 0.15, 0.07, 0.03]
        
        for scale, weight in zip(scales, weights):
            # Generar patrón de ruido a esta escala
            for y in range(self.height):
                for x in range(self.width):
                    # Hash simple para simular ruido coherente
                    seed_val = (x // scale + (y // scale) * 1000)
                    np.random.seed(seed_val)
                    noise = np.random.random()
                    heightmap[y, x] += noise * weight
        
        # Normalizar y aplicar gradiente de bordes
        heightmap = (heightmap - heightmap.min()) / (heightmap.max() - heightmap.min())
        
        # Hacer los bordes océano
        border_mask = self._create_border_mask()
        heightmap *= border_mask
        
        # Suavizar
        from scipy.ndimage import gaussian_filter
        heightmap = gaussian_filter(heightmap, sigma=2)
        
        return heightmap
    
    def _create_border_mask(self) -> np.ndarray:
        """Crea máscara que reduce altura en los bordes"""
        mask = np.ones((self.height, self.width))
        border_width = 50
        
        for y in range(self.height):
            for x in range(self.width):
                dist_to_edge = min(x, y, self.width - x - 1, self.height - y - 1)
                if dist_to_edge < border_width:
                    mask[y, x] = dist_to_edge / border_width
        
        return mask
    
    def _calculate_temperature(self) -> np.ndarray:
        """Temperatura basada en latitud y altitud"""
        temp_map = np.zeros((self.height, self.width))
        
        for y in range(self.height):
            # Latitud: más frío en los polos
            latitude_factor = abs(y - self.height / 2) / (self.height / 2)
            base_temp = 30 - (latitude_factor * 40)  # 30°C ecuador, -10°C polos
            
            for x in range(self.width):
                # Altitud: -6°C por cada 1000m (0.6 por cada 0.1 en heightmap)
                altitude_penalty = self.heightmap[y, x] * 20
                temp_map[y, x] = base_temp - altitude_penalty
        
        return gaussian_filter(temp_map, sigma=3)
    
    def _calculate_precipitation(self) -> np.ndarray:
        """Precipitación basada en latitud y proximidad al agua"""
        precip_map = np.zeros((self.height, self.width))
        
        # Zonas ecuatoriales y templadas húmedas
        for y in range(self.height):
            latitude = abs(y - self.height / 2) / (self.height / 2)
            
            if latitude < 0.15:  # Ecuador
                base_precip = 2500
            elif latitude < 0.35:  # Subtrópico seco
                base_precip = 500
            elif latitude < 0.6:  # Templado
                base_precip = 1000
            else:  # Polar
                base_precip = 300
            
            for x in range(self.width):
                # Más lluvia en montañas y costas
                if self.heightmap[y, x] > 0.6:
                    precip_map[y, x] = base_precip * 1.8
                elif self.heightmap[y, x] < 0.3:
                    precip_map[y, x] = base_precip * 0.5
                else:
                    precip_map[y, x] = base_precip
        
        return gaussian_filter(precip_map, sigma=4)
    
    def _assign_biomes(self) -> np.ndarray:
        """Asigna bioma según altura, temperatura y precipitación"""
        biome_map = np.zeros((self.height, self.width), dtype=int)
        
        for y in range(self.height):
            for x in range(self.width):
                h = self.heightmap[y, x]
                t = self.temperature_map[y, x]
                p = self.precipitation_map[y, x]
                
                if h < 0.25:  # Océano
                    biome_map[y, x] = 0
                elif h > 0.75:  # Montaña
                    biome_map[y, x] = 8
                elif t < -5:  # Tundra
                    biome_map[y, x] = 1
                elif t < 5 and p > 800:  # Taiga
                    biome_map[y, x] = 2
                elif t > 20 and p > 2000:  # Selva tropical
                    biome_map[y, x] = 5
                elif t > 25 and p < 500:  # Desierto
                    biome_map[y, x] = 6
                elif t > 15 and p < 800:  # Sabana
                    biome_map[y, x] = 7
                elif p > 800:  # Bosque templado
                    biome_map[y, x] = 4
                else:  # Pradera
                    biome_map[y, x] = 3
        
        return biome_map
    
    def _calculate_fertility(self) -> np.ndarray:
        """Fertilidad basada en bioma, altura y ríos"""
        fertility = np.zeros((self.height, self.width))
        
        # Fertilidad base por bioma
        biome_fertility = {
            0: 0.0,   # Océano
            1: 0.1,   # Tundra
            2: 0.3,   # Taiga
            3: 0.8,   # Pradera
            4: 0.7,   # Bosque templado
            5: 0.9,   # Selva
            6: 0.1,   # Desierto
            7: 0.6,   # Sabana
            8: 0.2    # Montaña
        }
        
        for y in range(self.height):
            for x in range(self.width):
                biome = self.biome_map[y, x]
                fertility[y, x] = biome_fertility.get(biome, 0.5)
        
        return fertility
    
    def generate_rivers(self):
        """Genera ríos realistas desde montañas"""
        # Encontrar picos montañosos
        peaks = []
        for y in range(10, self.height - 10, 15):
            for x in range(10, self.width - 10, 15):
                if self.heightmap[y, x] > 0.7:
                    peaks.append((y, x))
        
        # Generar río desde cada pico
        for peak_y, peak_x in peaks[:20]:  # Limitar número de ríos
            self._trace_river(peak_y, peak_x)
    
    def _trace_river(self, start_y: int, start_x: int):
        """Traza un río siguiendo la pendiente"""
        y, x = start_y, start_x
        flow = 1.0
        visited = set()
        
        for _ in range(300):
            if (y, x) in visited:
                break
            visited.add((y, x))
            
            # Marcar río
            self.river_map[y, x] = flow
            self.water_flow[y, x] += flow
            
            # Aumentar fertilidad
            for dy in range(-3, 4):
                for dx in range(-3, 4):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < self.height and 0 <= nx < self.width:
                        dist = max(abs(dy), abs(dx))
                        bonus = flow * 0.4 * (1 - dist / 4)
                        self.fertility_map[ny, nx] = min(1.0, 
                            self.fertility_map[ny, nx] + bonus)
            
            # Si llegamos al océano, terminar
            if self.heightmap[y, x] < 0.25:
                break
            
            # Buscar vecino más bajo
            neighbors = []
            for dy, dx in [(-1,0), (1,0), (0,-1), (0,1), 
                          (-1,-1), (-1,1), (1,-1), (1,1)]:
                ny, nx = y + dy, x + dx
                if (0 <= ny < self.height and 0 <= nx < self.width and
                    (ny, nx) not in visited):
                    neighbors.append((ny, nx, self.heightmap[ny, nx]))
            
            if not neighbors:
                break
            
            # Moverse al más bajo
            next_y, next_x, _ = min(neighbors, key=lambda n: n[2])
            y, x = next_y, next_x
            flow *= 1.03  # Acumular caudal
            

# ==============================================================================
# ESTRUCTURAS DE DATOS EXTENDIDAS
# ==============================================================================

@dataclass
class WeatherCondition:
    """Condición climática actual"""
    season: Season = Season.SPRING
    temperature_modifier: float = 0.0
    precipitation_modifier: float = 0.0
    active_events: List[WeatherEvent] = field(default_factory=list)

@dataclass
class Ecosystem:
    """Ecosistema local"""
    fauna_population: float = 100.0
    flora_density: float = 1.0
    domesticated_species: Set[str] = field(default_factory=set)
    plague_active: bool = False
    plague_severity: float = 0.0

@dataclass
class Technology:
    """Tecnología descubierta"""
    name: str
    era: TechnologyEra
    prerequisites: List[str] = field(default_factory=list)
    benefits: Dict[str, float] = field(default_factory=dict)

@dataclass
class TradeRoute:
    """Ruta comercial entre civilizaciones"""
    origin_civ: str
    destination_civ: str
    resources_traded: Dict[ResourceType, float] = field(default_factory=dict)
    profit_per_turn: float = 0.0
    established_turn: int = 0

@dataclass
class Religion:
    """Sistema religioso organizado"""
    name: str
    founder_civ: str
    core_beliefs: List[str] = field(default_factory=list)
    followers: int = 0
    temples_built: int = 0
    influence_score: float = 0.0

# ==============================================================================
# GESTOR CLIMÁTICO DINÁMICO (NUEVO)
# ==============================================================================

class ClimateManager:
    """Gestiona clima dinámico con estaciones y eventos extremos"""
    
    def __init__(self, width: int, height: int, geosphere):
        self.width = width
        self.height = height
        self.geosphere = geosphere  # ← AGREGAR ESTA LÍNEA
        self.current_season = Season.SPRING
        self.timestep_in_season = 0
        self.weather_condition = WeatherCondition()
        
        # Mapas de eventos activos
        self.drought_map = np.zeros((height, width), dtype=np.float64)
        self.flood_map = np.zeros((height, width), dtype=np.float64)
        self.wildfire_map = np.zeros((height, width), dtype=np.float64)
        
    def update(self, timestep: int):
        """Actualiza estación y genera eventos climáticos"""
        self.timestep_in_season += 1
        
        # Cambio de estación
        if self.timestep_in_season >= Config.SEASON_LENGTH:
            self._advance_season()
            self.timestep_in_season = 0
        
        # Modificadores estacionales
        self._apply_seasonal_effects()
        
        # Generar eventos extremos
        if random.random() < Config.WEATHER_EVENT_PROBABILITY:
            self._trigger_weather_event()
    
    def _advance_season(self):
        """Avanza a la siguiente estación"""
        seasons = list(Season)
        current_idx = seasons.index(self.current_season)
        self.current_season = seasons[(current_idx + 1) % len(seasons)]
    
    def _apply_seasonal_effects(self):
        """Aplica modificadores según la estación"""
        modifiers = {
            Season.SPRING: (5.0, 1.2),
            Season.SUMMER: (10.0, 0.8),
            Season.AUTUMN: (0.0, 1.1),
            Season.WINTER: (-10.0, 0.9)
        }
        temp_mod, precip_mod = modifiers[self.current_season]
        self.weather_condition.temperature_modifier = temp_mod
        self.weather_condition.precipitation_modifier = precip_mod
    
    def _trigger_weather_event(self):
        """Genera evento climático aleatorio"""
        event_type = random.choice(list(WeatherEvent))
        
        # Seleccionar área afectada
        center_y = random.randint(10, self.height - 10)
        center_x = random.randint(10, self.width - 10)
        radius = random.randint(5, 20)
        
        if event_type == WeatherEvent.DROUGHT:
            self._create_drought_zone(center_y, center_x, radius)
        elif event_type == WeatherEvent.FLOOD:
            self._create_flood_zone(center_y, center_x, radius)
        elif event_type == WeatherEvent.WILDFIRE:
            self._create_wildfire_zone(center_y, center_x, radius)
        
        self.weather_condition.active_events.append(event_type)
    
    def _create_drought_zone(self, cy: int, cx: int, radius: int):
        """Crea zona de sequía"""
        for y in range(max(0, cy - radius), min(self.height, cy + radius)):
            for x in range(max(0, cx - radius), min(self.width, cx + radius)):
                dist = np.sqrt((y - cy)**2 + (x - cx)**2)
                if dist < radius:
                    self.drought_map[y, x] = True
    
    def _create_flood_zone(self, cy: int, cx: int, radius: int):
        """Crea zona de inundación basada en topografía - CORREGIDO"""
        for y in range(max(0, cy - radius), min(self.height, cy + radius)):
            for x in range(max(0, cx - radius), min(self.width, cx + radius)):
                dist = np.sqrt((y - cy)**2 + (x - cx)**2)
                
                if dist < radius:
                    height = self.geosphere.heightmap[y, x]
                    near_river = self.geosphere.river_map[y, x] > 0
                    
                    # INDENTACIÓN CORRECTA: dentro del loop
                    if height < 0.35 and near_river:
                        intensity = (radius - dist) / radius
                        self.flood_map[y, x] = intensity
                    elif height < 0.4:
                        intensity = (radius - dist) / radius * 0.5
                        self.flood_map[y, x] = intensity
        
    def _create_wildfire_zone(self, cy: int, cx: int, radius: int):
        """Crea zona de incendio forestal"""
        for y in range(max(0, cy - radius), min(self.height, cy + radius)):
            for x in range(max(0, cx - radius), min(self.width, cx + radius)):
                dist = np.sqrt((y - cy)**2 + (x - cx)**2)
                if dist < radius:
                    self.wildfire_map[y, x] = True
    
    def decay_events(self):
        """Decae gradualmente los eventos climáticos"""
        self.drought_map *= 0.9
        self.flood_map *= 0.9
        self.wildfire_map *= 0.9

# ==============================================================================
# GESTOR DE EVENTOS GEOLÓGICOS (NUEVO)
# ==============================================================================

class GeologicalManager:
    """Gestiona eventos geológicos catastróficos"""
    
    def __init__(self, width: int, height: int, geosphere):
        self.width = width
        self.height = height
        self.geosphere = geosphere
        self.active_events = []
        
    def update(self, timestep: int):
        """Verifica y genera eventos geológicos"""
        if random.random() < Config.GEOLOGICAL_EVENT_PROBABILITY:
            event_type = random.choice(list(GeologicalEvent))
            self._trigger_event(event_type, timestep)
    
    def _trigger_event(self, event_type: GeologicalEvent, timestep: int):
        """Dispara un evento geológico"""
        epicenter_y = random.randint(0, self.height - 1)
        epicenter_x = random.randint(0, self.width - 1)
        
        if event_type == GeologicalEvent.EARTHQUAKE:
            magnitude = random.uniform(4.0, 8.0)
            self._simulate_earthquake(epicenter_y, epicenter_x, magnitude)
        
        elif event_type == GeologicalEvent.VOLCANO:
            self._simulate_volcano(epicenter_y, epicenter_x)
        
        elif event_type == GeologicalEvent.TSUNAMI:
            self._simulate_tsunami(epicenter_y, epicenter_x)
        
        self.active_events.append({
            'type': event_type.value,
            'location': (epicenter_y, epicenter_x),
            'timestep': timestep
        })
    
    def _simulate_earthquake(self, y: int, x: int, magnitude: float):
        """Simula terremoto con daño radial"""
        radius = int(magnitude * 5)
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                ny, nx = y + dy, x + dx
                if 0 <= ny < self.height and 0 <= nx < self.width:
                    dist = np.sqrt(dy**2 + dx**2)
                    if dist < radius:
                        damage = magnitude / (1 + dist)
                        self.geosphere.heightmap[ny, nx] += random.uniform(-0.01, 0.01) * damage
    
    def _simulate_volcano(self, y: int, x: int):
        """Simula erupción volcánica"""
        # Crear montaña volcánica
        radius = 10
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                ny, nx = y + dy, x + dx
                if 0 <= ny < self.height and 0 <= nx < self.width:
                    dist = np.sqrt(dy**2 + dx**2)
                    if dist < radius:
                        elevation_increase = (radius - dist) / radius * 0.3
                        self.geosphere.heightmap[ny, nx] += elevation_increase
                        self.geosphere.fertility_map[ny, nx] *= 0.1  # Lava destruye fertilidad
    
    def _simulate_tsunami(self, y: int, x: int):
        """Simula tsunami en zonas costeras"""
        # Afecta regiones oceánicas cercanas a costa
        radius = 30
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                ny, nx = y + dy, x + dx
                if 0 <= ny < self.height and 0 <= nx < self.width:
                    height = self.geosphere.heightmap[ny, nx]
                    if 0.25 < height < 0.35:  # Zona costera
                        self.geosphere.fertility_map[ny, nx] *= 0.5

# ==============================================================================
# GESTOR DE RECURSOS RENOVABLES (NUEVO)
# ==============================================================================

class ResourceManager:
    """Gestiona ciclos de recursos renovables"""
    
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        
        # Mapas de recursos
        self.forest_density = np.random.rand(height, width)
        self.mineral_deposits = np.random.rand(height, width) * 100
        self.soil_quality = np.ones((height, width))
        
    def update(self, geosphere, climate_manager):
        """Actualiza recursos según explotación y regeneración"""
        # Regeneración forestal
        self.forest_density += Config.FOREST_REGENERATION_RATE
        self.forest_density = np.clip(self.forest_density, 0, 1)
        
        # Los incendios reducen bosques
        wildfire_damage = climate_manager.wildfire_map * 0.5
        self.forest_density -= wildfire_damage
        
        # Erosión del suelo
        erosion = geosphere.erosion_map * Config.SOIL_EROSION_RATE
        self.soil_quality -= erosion
        self.soil_quality = np.clip(self.soil_quality, 0.1, 1.0)
        
        # Sequías reducen fertilidad
        drought_impact = climate_manager.drought_map * 0.01
        geosphere.fertility_map -= drought_impact
        geosphere.fertility_map = np.clip(geosphere.fertility_map, 0, 1)
    
    def extract_resources(self, location: Tuple[int, int], resource_type: ResourceType, amount: float):
        """Extrae recursos de una ubicación"""
        y, x = location
        
        if resource_type == ResourceType.WOOD:
            extracted = min(amount, self.forest_density[y, x] * 100)
            self.forest_density[y, x] -= extracted / 100
            return extracted
        
        elif resource_type == ResourceType.STONE or resource_type == ResourceType.METAL:
            extracted = min(amount, self.mineral_deposits[y, x])
            self.mineral_deposits[y, x] -= extracted * Config.MINE_DEPLETION_RATE
            return extracted
        
        return 0

# ==============================================================================
# GESTOR DE ECOSISTEMA (NUEVO)
# ==============================================================================

class EcosystemManager:
    """Gestiona fauna, flora y plagas"""
    
    def __init__(self, width: int, height: int):
        self.ecosystems = {}
        for y in range(0, height, 10):
            for x in range(0, width, 10):
                self.ecosystems[(y, x)] = Ecosystem(
                    fauna_population=random.uniform(50, 200),
                    flora_density=random.uniform(0.5, 1.0)
                )
    
    def update(self, agents: Dict, timestep: int):
        """Actualiza ecosistemas y verifica plagas"""
        for loc, ecosystem in self.ecosystems.items():
            # Crecimiento natural de fauna
            ecosystem.fauna_population *= 1.02
            ecosystem.fauna_population = min(ecosystem.fauna_population, 500)
            
            # Plaga aleatoria
            if random.random() < Config.PLAGUE_PROBABILITY:
                ecosystem.plague_active = True
                ecosystem.plague_severity = random.uniform(0.3, 0.8)
            
            # Decaimiento de plaga
            if ecosystem.plague_active:
                ecosystem.plague_severity *= 0.95
                if ecosystem.plague_severity < 0.1:
                    ecosystem.plague_active = False
    
    def get_hunting_yield(self, location: Tuple[int, int]) -> float:
        """Calcula recursos de caza disponibles"""
        nearest_eco = self._find_nearest_ecosystem(location)
        if nearest_eco:
            fauna = nearest_eco.fauna_population
            harvest = min(fauna * 0.1, 20)
            nearest_eco.fauna_population -= harvest
            return harvest
        return 0
    
    def _find_nearest_ecosystem(self, location: Tuple[int, int]) -> Optional[Ecosystem]:
        """Encuentra el ecosistema más cercano"""
        y, x = location
        eco_y, eco_x = (y // 10) * 10, (x // 10) * 10
        return self.ecosystems.get((eco_y, eco_x))
@dataclass
class Building:
    type: BuildingType
    location: Tuple[int, int]
    owner_civ: str
    level: int = 1
    production_per_turn: Dict[ResourceType, float] = field(default_factory=dict)
    
    def calculate_production(self, tech_bonuses: Dict[str, float]) -> Dict[ResourceType, float]:
        """Calcula producción con bonificaciones tecnológicas"""
        base_production = {
            BuildingType.FARM: {ResourceType.FOOD: 20.0},
            BuildingType.MINE: {ResourceType.STONE: 10.0, ResourceType.METAL: 5.0},
            BuildingType.LIBRARY: {ResourceType.KNOWLEDGE: 5.0},
            BuildingType.MARKET: {ResourceType.GOLD: 10.0}
        }.get(self.type, {})
        
        # Aplicar bonificaciones tecnológicas
        for resource, amount in base_production.items():
            bonus = tech_bonuses.get(resource.value, 1.0)
            self.production_per_turn[resource] = amount * bonus * self.level
        
        return self.production_per_turn
# ==============================================================================
# AGENTE EXTENDIDO CON DEMOGRAFÍA
# ==============================================================================

@dataclass
class Meme:
    """Unidad cultural transmisible"""
    id: str
    meme_type: MemeType
    strength: float = 1.0
    origin: Optional[str] = None
    age: int = 0
    
    def mutate(self):
        """Mutación del meme"""
        if random.random() < Config.MEME_MUTATION_RATE:
            self.strength = np.clip(self.strength + random.uniform(-0.1, 0.1), 0.1, 1.0)

@dataclass
class Agent:
    """Agente con demografía completa"""
    id: str
    location: Tuple[int, int]
    civilization_id: Optional[str] = None
    
    # Demografía
    age: int = 20
    is_alive: bool = True
    
    # Recursos
    wealth: float = 100.0
    resources: Dict[ResourceType, float] = field(default_factory=lambda: {
        ResourceType.FOOD: 50, ResourceType.WOOD: 20, ResourceType.STONE: 10
    })
    
    # Estado
    health: float = 1.0
    hunger: float = 0.0
    
    # Social
    culture_memes: Dict[str, Meme] = field(default_factory=dict)
    network_connections: Set[str] = field(default_factory=set)
    
    # Economía
    utility: float = 0.0
    trade_history: List[Dict] = field(default_factory=list)
    # NUEVO: Rol social
    role: AgentRole = AgentRole.FARMER
    role_experience: int = 0
    
    # NUEVO: Atributos de personalidad
    aggression: float = field(default_factory=lambda: random.uniform(0, 1))
    intelligence: float = field(default_factory=lambda: random.uniform(0, 1))
    charisma: float = field(default_factory=lambda: random.uniform(0, 1))

    needs: Dict[str, float] = field(default_factory=lambda: {
        'food': 1.0,
        'water': 1.0,
        'shelter': 1.0,
        'security': 1.0
    })
    def gather_resources(self, location: Tuple[int, int], 
                        resource_manager: ResourceManager,
                        ecosystem_manager: EcosystemManager,
                        geosphere) -> Dict[ResourceType, float]:
        """Recolecta recursos con acceso explícito a gestores"""
        gathered = {}
        multipliers = self.get_resource_multiplier()
        
        # Caza
        food_hunting = ecosystem_manager.get_hunting_yield(location)
        gathered[ResourceType.FOOD] = food_hunting * multipliers.get(ResourceType.FOOD, 1.0)
        
        # Madera
        wood = resource_manager.extract_resources(location, ResourceType.WOOD, 10)
        gathered[ResourceType.WOOD] = wood * multipliers.get(ResourceType.WOOD, 1.0)
        
        return gathered
    def update_needs(self, climate: WeatherCondition, near_river: bool):
        """Actualiza necesidades"""
        # Hambre
        self.needs['food'] -= 0.02
        if self.resources[ResourceType.FOOD] > 5:
            self.needs['food'] = min(1.0, self.needs['food'] + 0.1)
            self.resources[ResourceType.FOOD] -= 2
        
        # Sed (más en verano, menos cerca de ríos)
        water_demand = 0.03 if climate.season == Season.SUMMER else 0.02
        if near_river:
            self.needs['water'] = 1.0
        else:
            self.needs['water'] -= water_demand
        
        # Refugio (importante en invierno)
        if climate.season == Season.WINTER:
            self.needs['shelter'] -= 0.05
            if self.wealth > 100:
                self.needs['shelter'] = min(1.0, self.needs['shelter'] + 0.1)
        
        # Seguridad (reducida en guerra)
        self.needs['security'] = 1.0  # Actualizar según contexto
    
    def get_satisfaction(self) -> float:
        """Nivel de satisfacción general"""
        return sum(self.needs.values()) / len(self.needs)
    
    def should_migrate(self) -> bool:
        """Decide migrar si necesidades no satisfechas"""
        return self.get_satisfaction() < 0.4
    
    def get_resource_multiplier(self) -> Dict[ResourceType, float]:
        """Multiplicadores según rol"""
        multipliers = {
            AgentRole.FARMER: {ResourceType.FOOD: 2.0, ResourceType.WOOD: 1.2},
            AgentRole.WARRIOR: {ResourceType.FOOD: 0.5, ResourceType.STONE: 1.5},
            AgentRole.SCHOLAR: {ResourceType.KNOWLEDGE: 3.0, ResourceType.FOOD: 0.3},
            AgentRole.PRIEST: {ResourceType.KNOWLEDGE: 1.5},
            AgentRole.MERCHANT: {ResourceType.GOLD: 2.0},
            AgentRole.LEADER: {}
        }
        return multipliers.get(self.role, {})
    
    def contribute_to_military(self) -> float:
        """Contribución a fuerza militar"""
        if self.role == AgentRole.WARRIOR:
            return 2.0 + self.aggression
        return 0.5    
    def age_one_year(self):
        """Envejece un año"""
        self.age += 1
        if self.age > Config.MAX_AGE:
            self.is_alive = False
        
        # Salud disminuye con la edad
        if self.age > 50:
            self.health -= 0.01
    
    def can_reproduce(self) -> bool:
        """Verifica si puede reproducirse"""
        return (self.age >= Config.MIN_REPRODUCTION_AGE and 
                self.age < 45 and 
                self.health > 0.5 and 
                self.wealth > 50)

# ==============================================================================
# CIVILIZACIÓN CON DIPLOMACIA (NUEVO)
# ==============================================================================

@dataclass
class Civilization:
    """Civilización con diplomacia, tecnología y cultura"""
    id: str
    name: str
    capital_location: Tuple[int, int]
    
    # Miembros
    agent_ids: Set[str] = field(default_factory=set)
    
    # Tecnología
    discovered_technologies: Set[str] = field(default_factory=set)
    current_era: TechnologyEra = TechnologyEra.STONE_AGE
    
    # Diplomacia
    relations: Dict[str, DiplomacyRelation] = field(default_factory=dict)
    trade_routes: List[TradeRoute] = field(default_factory=list)
    
    # Cultura
    primary_religion: Optional[Religion] = None
    cultural_identity: str = "Generic"
    
    # Militar
    military_strength: float = 100.0
    at_war_with: Set[str] = field(default_factory=set)
    
    # Territorio
    controlled_tiles: Set[Tuple[int, int]] = field(default_factory=set)

    leader_id: Optional[str] = None
    buildings: List[Building] = field(default_factory=list)
    treasury_gold: float = 100.0
    
    research_focus: Optional[str] = None
    research_progress: float = 0.0    
    government_type: GovernmentType = GovernmentType.TRIBAL
    
    def get_efficiency_modifier(self) -> float:
        """Modificador de eficiencia según gobierno"""
        return {
            GovernmentType.TRIBAL: 0.8,
            GovernmentType.MONARCHY: 1.0,
            GovernmentType.REPUBLIC: 1.2,
            GovernmentType.THEOCRACY: 0.9
        }[self.government_type]
    
    def update_government(self):
        """Actualiza gobierno según tecnologías"""
        if 'democracy' in self.discovered_technologies:
            self.government_type = GovernmentType.REPUBLIC
        elif 'monarchy' in self.discovered_technologies:
            self.government_type = GovernmentType.MONARCHY
        elif len(self.discovered_technologies) > 5:
            self.government_type = GovernmentType.MONARCHY    
    def build_structure(self, building_type: BuildingType, location: Tuple[int, int], 
                       cost: Dict[ResourceType, float]) -> bool:
        """Construye edificio si hay recursos suficientes"""
        # Verificar costos (implementar lógica de deducción de recursos)
        
        building = Building(
            type=building_type,
            location=location,
            owner_civ=self.id
        )
        self.buildings.append(building)
        return True
    
    def collect_production(self, tech_manager: 'TechnologyManager'):
        """Recolecta producción de todos los edificios"""
        tech_bonuses = self._get_tech_bonuses(tech_manager)
        
        for building in self.buildings:
            production = building.calculate_production(tech_bonuses)
            # Distribuir a agentes o almacenar centralmente
    
    def _get_tech_bonuses(self, tech_manager) -> Dict[str, float]:
        """Obtiene bonificaciones de tecnologías"""
        bonuses = {}
        for tech_name in self.discovered_technologies:
            tech = tech_manager.tech_tree.get(tech_name)
            if tech:
                bonuses.update(tech.benefits)
        return bonuses    
    def elect_leader(self, agents: Dict[str, Agent]):
        """Elige líder basado en riqueza, edad y carisma"""
        candidates = [agents[aid] for aid in self.agent_ids if aid in agents]
        
        if not candidates:
            return
        
        # Puntaje: wealth + age*2 + charisma*50
        best_candidate = max(candidates, 
                            key=lambda a: a.wealth + a.age * 2 + a.charisma * 50)
        
        # Cambiar rol anterior líder
        if self.leader_id and self.leader_id in agents:
            old_leader = agents[self.leader_id]
            if old_leader.role == AgentRole.LEADER:
                old_leader.role = AgentRole.FARMER
        
        self.leader_id = best_candidate.id
        best_candidate.role = AgentRole.LEADER
    
    def get_diplomatic_tendency(self, agents: Dict[str, Agent]) -> float:
        """Retorna tendencia agresiva (-1) o pacífica (1) según líder"""
        if not self.leader_id or self.leader_id not in agents:
            return 0.0
        
        leader = agents[self.leader_id]
        return leader.charisma - leader.aggression
    
    def update_military_strength(self, agents: Dict[str, Agent]):
        """Calcula fuerza militar basada en población y tecnología"""
        population = len(self.agent_ids)
        tech_bonus = len(self.discovered_technologies) * 10
        self.military_strength = population * 0.5 + tech_bonus

@dataclass
class Battle:
    attacker_civ: str
    defender_civ: str
    location: Tuple[int, int]
    turn_started: int
    attacker_forces: float = 0.0
    defender_forces: float = 0.0
    
    def resolve_turn(self, geosphere, civilizations: Dict[str, Civilization], 
                     agents: Dict[str, Agent]) -> Tuple[float, float]:
        """Resuelve un turno de batalla"""
        attacker = civilizations[self.attacker_civ]
        defender = civilizations[self.defender_civ]
        
        # Calcular fuerzas
        att_strength = sum(agents[aid].contribute_to_military() 
                          for aid in attacker.agent_ids if aid in agents)
        def_strength = sum(agents[aid].contribute_to_military() 
                          for aid in defender.agent_ids if aid in agents)
        
        # Bonificación defensiva por terreno
        height = geosphere.heightmap[self.location[0], self.location[1]]
        if height > 0.6:  # Montañas
            def_strength *= 1.5
        
        # Combate
        att_casualties = def_strength * 0.1
        def_casualties = att_strength * 0.1
        
        # Remover agentes muertos
        self._apply_casualties(attacker, att_casualties, agents)
        self._apply_casualties(defender, def_casualties, agents)
        
        return att_casualties, def_casualties
    
    def _apply_casualties(self, civ: Civilization, casualties: float, agents: Dict[str, Agent]):
        """Aplica bajas a la civilización"""
        num_deaths = int(casualties)
        warriors = [aid for aid in civ.agent_ids 
                   if aid in agents and agents[aid].role == AgentRole.WARRIOR]
        
        for _ in range(min(num_deaths, len(warriors))):
            if warriors:
                victim_id = random.choice(warriors)
                warriors.remove(victim_id)
                civ.agent_ids.remove(victim_id)
                del agents[victim_id]
# ==============================================================================
# GESTOR DE DIPLOMACIA (NUEVO)
# ==============================================================================

class DiplomacyManager:
    """Gestiona relaciones entre civilizaciones"""
    
    def __init__(self):
        self.civilizations: Dict[str, Civilization] = {}
        self.wars_active: List[Dict] = []
        self.treaties: List[Dict] = []
    
    def update(self, timestep: int, agents: Dict[str, Agent]):
        """Actualiza relaciones diplomáticas"""
        civ_ids = list(self.civilizations.keys())
        
        for i, civ1_id in enumerate(civ_ids):
            for civ2_id in civ_ids[i+1:]:
                self._evaluate_relationship(civ1_id, civ2_id, timestep, agents)
    
    def _evaluate_relationship(self, civ1_id: str, civ2_id: str, timestep: int, agents: Dict[str, Agent]):
        """Evalúa y actualiza relación entre dos civilizaciones"""
        civ1 = self.civilizations[civ1_id]
        civ2 = self.civilizations[civ2_id]
        
        # Inicializar relación si no existe
        if civ2_id not in civ1.relations:
            civ1.relations[civ2_id] = DiplomacyRelation.NEUTRAL
            civ2.relations[civ1_id] = DiplomacyRelation.NEUTRAL
        
        current_relation = civ1.relations[civ2_id]
        
        # Factores que afectan la relación
        distance = self._calculate_distance(civ1.capital_location, civ2.capital_location)
        proximity_factor = 1.0 / (1.0 + distance / 50)
        
        # Competencia por recursos
        territory_overlap = len(civ1.controlled_tiles & civ2.controlled_tiles)
        competition = territory_overlap * 0.01
        
        # NUEVO: Considerar personalidad de líderes
        tendency1 = civ1.get_diplomatic_tendency(agents)
        tendency2 = civ2.get_diplomatic_tendency(agents)
        
        # Modificar umbral de guerra según líderes agresivos
        war_threshold = Config.WAR_DECLARATION_THRESHOLD
        if tendency1 < -0.5 and tendency2 < -0.5:
            war_threshold *= 1.5
        
        # Probabilidad de guerra
        if current_relation == DiplomacyRelation.HOSTILE and random.random() < war_threshold * proximity_factor:
            self._declare_war(civ1_id, civ2_id, timestep)
        
        # Probabilidad de alianza
        elif current_relation == DiplomacyRelation.TRADE and random.random() < Config.ALLIANCE_TRUST_THRESHOLD:
            self._form_alliance(civ1_id, civ2_id, timestep)
    
    def _declare_war(self, civ1_id: str, civ2_id: str, timestep: int):
        """Declara guerra entre dos civilizaciones"""
        civ1 = self.civilizations[civ1_id]
        civ2 = self.civilizations[civ2_id]
        
        civ1.relations[civ2_id] = DiplomacyRelation.WAR
        civ2.relations[civ1_id] = DiplomacyRelation.WAR
        
        civ1.at_war_with.add(civ2_id)
        civ2.at_war_with.add(civ1_id)
        
        self.wars_active.append({
            'civilizations': [civ1_id, civ2_id],
            'start_turn': timestep,
            'casualties': 0
        })
    
    def _form_alliance(self, civ1_id: str, civ2_id: str, timestep: int):
        """Forma alianza entre civilizaciones"""
        civ1 = self.civilizations[civ1_id]
        civ2 = self.civilizations[civ2_id]
        
        civ1.relations[civ2_id] = DiplomacyRelation.ALLIANCE
        civ2.relations[civ1_id] = DiplomacyRelation.ALLIANCE
        
        self.treaties.append({
            'civilizations': [civ1_id, civ2_id],
            'type': 'alliance',
            'established': timestep
        })
    
    def establish_trade_route(self, civ1_id: str, civ2_id: str, timestep: int):
        """Establece ruta comercial"""
        civ1 = self.civilizations[civ1_id]
        
        if civ2_id not in civ1.at_war_with:
            route = TradeRoute(
                origin_civ=civ1_id,
                destination_civ=civ2_id,
                established_turn=timestep
            )
            civ1.trade_routes.append(route)
            
            # Mejorar relaciones
            if civ1.relations.get(civ2_id) == DiplomacyRelation.NEUTRAL:
                civ1.relations[civ2_id] = DiplomacyRelation.TRADE
    
    def _calculate_distance(self, loc1: Tuple[int, int], loc2: Tuple[int, int]) -> float:
        """Calcula distancia entre ubicaciones"""
        return np.sqrt((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)
    
    def resolve_wars(self, timestep: int):
        """Resuelve conflictos bélicos activos"""
        for war in self.wars_active[:]:
            civ1_id, civ2_id = war['civilizations']
            civ1 = self.civilizations[civ1_id]
            civ2 = self.civilizations[civ2_id]
            
            # Simular batalla
            civ1_strength = civ1.military_strength
            civ2_strength = civ2.military_strength
            
            if civ1_strength > civ2_strength * 2:
                # Victoria decisiva de civ1
                self._end_war(civ1_id, civ2_id, civ1_id, timestep)
                self.wars_active.remove(war)
            elif civ2_strength > civ1_strength * 2:
                # Victoria decisiva de civ2
                self._end_war(civ1_id, civ2_id, civ2_id, timestep)
                self.wars_active.remove(war)
            else:
                # Guerra continúa, acumular bajas
                war['casualties'] += int(civ1_strength * 0.01 + civ2_strength * 0.01)
    
    def _end_war(self, civ1_id: str, civ2_id: str, winner_id: str, timestep: int):
        """Termina guerra con un ganador"""
        civ1 = self.civilizations[civ1_id]
        civ2 = self.civilizations[civ2_id]
        
        civ1.relations[civ2_id] = DiplomacyRelation.HOSTILE
        civ2.relations[civ1_id] = DiplomacyRelation.HOSTILE
        
        civ1.at_war_with.discard(civ2_id)
        civ2.at_war_with.discard(civ1_id)
        
        # El ganador absorbe territorio
        winner = self.civilizations[winner_id]
        loser = self.civilizations[civ2_id if winner_id == civ1_id else civ1_id]
        
        # Transferir 20% del territorio
        tiles_to_transfer = list(loser.controlled_tiles)[:len(loser.controlled_tiles) // 5]
        for tile in tiles_to_transfer:
            loser.controlled_tiles.remove(tile)
            winner.controlled_tiles.add(tile)
class TerritoryExpansionSystem:
    """
    Sistema que hace que las civilizaciones expandan territorio de forma visible
    """
    
    def __init__(self, geosphere):
        self.geosphere = geosphere
    
    def expand_civilization_territory(self, civilization: Civilization, 
                                     agents: Dict[str, Agent],
                                     spatial_grid: SpatialGrid):
        """
        Expande territorio basado en ubicación de agentes
        """
        if not civilization.agent_ids:
            return
        
        # Calcular centro de masa de la población
        agent_locations = [agents[aid].location for aid in civilization.agent_ids 
                          if aid in agents]
        
        if not agent_locations:
            return
        
        # Expandir desde cada agente
        new_tiles = set()
        
        for agent_id in list(civilization.agent_ids)[:50]:  # Muestreo
            if agent_id not in agents:
                continue
            
            agent_loc = agents[agent_id].location
            
            # Reclamar tiles en radio según población
            expansion_radius = min(5, int(len(civilization.agent_ids) / 20))
            
            for dy in range(-expansion_radius, expansion_radius + 1):
                for dx in range(-expansion_radius, expansion_radius + 1):
                    ny, nx = agent_loc[0] + dy, agent_loc[1] + dx
                    
                    if (0 <= ny < self.geosphere.height and 
                        0 <= nx < self.geosphere.width):
                        
                        # Solo reclamar tierra habitable
                        biome = self.geosphere.biome_map[ny, nx]
                        if biome not in [0, 8]:  # No océano ni alta montaña
                            dist = np.sqrt(dy**2 + dx**2)
                            if dist <= expansion_radius:
                                new_tiles.add((ny, nx))
        
        civilization.controlled_tiles.update(new_tiles)
        
        # Limitar tamaño total para evitar expansión infinita
        if len(civilization.controlled_tiles) > 2000:
            # Mantener solo tiles más cercanos al capital
            sorted_tiles = sorted(
                civilization.controlled_tiles,
                key=lambda t: np.sqrt(
                    (t[0] - civilization.capital_location[0])**2 + 
                    (t[1] - civilization.capital_location[1])**2
                )
            )
            civilization.controlled_tiles = set(sorted_tiles[:2000])
# ==============================================================================
# GESTOR DE TECNOLOGÍA (NUEVO)
# ==============================================================================
class IncrementalUpdateSystem:
    """
    Actualiza subsistemas de forma rotativa para distribuir carga computacional
    """
    
    def __init__(self):
        self.update_counter = 0
    
    def should_update_demography(self) -> bool:
        """Demografía cada turno"""
        return True
    
    def should_update_resources(self) -> bool:
        """Recursos cada turno"""
        return True
    
    def should_update_climate(self) -> bool:
        """Clima cada 5 turnos"""
        return self.update_counter % 5 == 0
    
    def should_update_geology(self) -> bool:
        """Geología cada 10 turnos"""
        return self.update_counter % 10 == 0
    
    def should_update_technology(self) -> bool:
        """Tecnología cada 3 turnos"""
        return self.update_counter % 3 == 0
    
    def should_update_diplomacy(self) -> bool:
        """Diplomacia cada 5 turnos"""
        return self.update_counter % 5 == 0
    
    def should_update_religion(self) -> bool:
        """Religión cada 10 turnos"""
        return self.update_counter % 10 == 0
    
    def should_expand_territory(self) -> bool:
        """Expansión territorial cada 5 turnos"""
        return self.update_counter % 5 == 0
    
    def increment(self):
        """Incrementa contador"""
        self.update_counter += 1
        
class OptimizedSimulationEngine:
    """
    Motor principal con optimizaciones críticas
    """
    
    def __init__(self, num_agents: int = 1000):
        np.random.seed(Config.SIMULATION_SEED)
        random.seed(Config.SIMULATION_SEED)
        
        self.timestep = 0
        
        # USAR GEOSFERA MEJORADA (del artifact anterior)
        print("Generando terreno realista...")
        self.geosphere = ImprovedGeosphere(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        
        # Grid espacial para optimización
        self.spatial_grid = SpatialGrid(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        
        # Sistemas
        self.climate_manager = ClimateManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT, 
                                             self.geosphere)
        self.geological_manager = GeologicalManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT, 
                                                     self.geosphere)
        self.resource_manager = ResourceManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        self.ecosystem_manager = EcosystemManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        self.diplomacy_manager = DiplomacyManager()
        self.technology_manager = TechnologyManager()
        self.religion_manager = ReligionManager()
        
        # NUEVO: Sistema de expansión territorial
        self.territory_system = TerritoryExpansionSystem(self.geosphere)
        
        # NUEVO: Sistema de actualización incremental
        self.update_schedule = IncrementalUpdateSystem()
        
        # Agentes
        self.agents: Dict[str, Agent] = {}
        self._initialize_agents_smart(num_agents)
        self._initialize_civilizations()
        
        # Métricas
        self.metrics_history = []
        self.demographic_data = []
        self.migration_matrix = np.zeros((9, 9))
        
        print(f"✓ Simulación inicializada: {len(self.agents)} agentes, "
              f"{len(self.diplomacy_manager.civilizations)} civilizaciones")
    
    def _initialize_agents_smart(self, num_agents: int):
        """Inicializa agentes en ubicaciones habitables (no en océano)"""
        print("Colocando agentes en zonas habitables...")
        
        # Encontrar tiles habitables
        habitable_tiles = []
        for y in range(self.geosphere.height):
            for x in range(self.geosphere.width):
                biome = self.geosphere.biome_map[y, x]
                fertility = self.geosphere.fertility_map[y, x]
                
                # Preferir zonas fértiles, evitar océano y montañas
                if biome not in [0, 8] and fertility > 0.3:
                    habitable_tiles.append((y, x))
        
        # Muestrear ubicaciones
        if len(habitable_tiles) < num_agents:
            print(f"ADVERTENCIA: Solo {len(habitable_tiles)} tiles habitables para {num_agents} agentes")
            num_agents = len(habitable_tiles)
        
        selected_locations = random.sample(habitable_tiles, num_agents)
        
        for i, location in enumerate(selected_locations):
            age = int(np.random.beta(2, 5) * 80)
            
            agent = Agent(
                id=f"agent_{i:06d}",
                location=location,
                age=random.randint(18, 60),
                wealth=max(10, np.random.normal(Config.INITIAL_WEALTH_MEAN, 
                                              Config.INITIAL_WEALTH_STD))
            )
            agent.resources[ResourceType.KNOWLEDGE] = random.uniform(0, 10)
            
            self.agents[agent.id] = agent
            self.spatial_grid.add_agent(agent.id, location)
    
    def _initialize_civilizations(self):
        """Crea civilizaciones agrupando agentes cercanos"""
        print("Formando civilizaciones iniciales...")
        
        # Usar clustering simple por ubicación
        num_civs = max(5, len(self.agents) // 200)
        
        # Seleccionar capitales en zonas de alta fertilidad
        capital_candidates = []
        for y in range(0, self.geosphere.height, 50):
            for x in range(0, self.geosphere.width, 50):
                if self.geosphere.fertility_map[y, x] > 0.6:
                    capital_candidates.append((y, x))
        
        capitals = random.sample(capital_candidates, min(num_civs, len(capital_candidates)))
        
        for i, capital_loc in enumerate(capitals):
            civ = Civilization(
                id=f"civ_{i}",
                name=f"Civilization_{i}",
                capital_location=capital_loc
            )
            
            # Asignar agentes cercanos (radio 100)
            for agent in self.agents.values():
                dist = np.sqrt((agent.location[0] - capital_loc[0])**2 + 
                             (agent.location[1] - capital_loc[1])**2)
                
                if dist < 100 and agent.civilization_id is None:
                    agent.civilization_id = civ.id
                    civ.agent_ids.add(agent.id)
            
            if len(civ.agent_ids) > 10:  # Solo guardar si tiene suficientes miembros
                self.diplomacy_manager.civilizations[civ.id] = civ
                
                # Reclamar territorio inicial
                self.territory_system.expand_civilization_territory(
                    civ, self.agents, self.spatial_grid
                )
        
        print(f"✓ {len(self.diplomacy_manager.civilizations)} civilizaciones creadas")
    
    def run_step(self):
        """Paso optimizado con actualización incremental"""
        self.timestep += 1
        
        # 1. Demografía (siempre)
        if self.update_schedule.should_update_demography():
            self._update_demography_optimized()
        
        # 2. Recursos (siempre)
        if self.update_schedule.should_update_resources():
            self._process_resource_gathering_batch()
        
        # 3. Clima (cada 5 turnos)
        if self.update_schedule.should_update_climate():
            self.climate_manager.update(self.timestep)
            self.climate_manager.decay_events()
        
        # 4. Geología (cada 10 turnos)
        if self.update_schedule.should_update_geology():
            self.geological_manager.update(self.timestep)
        
        # 5. Tecnología (cada 3 turnos)
        if self.update_schedule.should_update_technology():
            self._process_technology_research()
        
        # 6. Diplomacia (cada 5 turnos)
        if self.update_schedule.should_update_diplomacy():
            self.diplomacy_manager.update(self.timestep, self.agents)
            self.diplomacy_manager.resolve_wars(self.timestep)
        
        # 7. Religión (cada 10 turnos)
        if self.update_schedule.should_update_religion():
            self._process_religion()
        
        # 8. Expansión territorial (cada 5 turnos)
        if self.update_schedule.should_expand_territory():
            for civ in self.diplomacy_manager.civilizations.values():
                self.territory_system.expand_civilization_territory(
                    civ, self.agents, self.spatial_grid
                )
        
        # 9. Migraciones (muestra aleatoria)
        self._process_migrations_sample()
        
        # 10. Métricas
        if self.timestep % 5 == 0:
            self._collect_extended_metrics()
        
        # Incrementar contador de actualización
        self.update_schedule.increment()
        
        if self.timestep % 10 == 0:
            self._print_status()
    
    def _update_demography_optimized(self):
        """Demografía optimizada procesando por lotes"""
        new_agents = []
        dead_agents = []
        
        for agent in self.agents.values():
            agent.age_one_year()
            
            # Mortalidad
            death_prob = Config.DEATH_RATE_BASE * (1 + agent.age / Config.MAX_AGE)
            if agent.health < 0.3:
                death_prob *= 2
            
            if random.random() < death_prob or not agent.is_alive:
                dead_agents.append(agent.id)
                continue
            
            # Natalidad
            if agent.can_reproduce() and random.random() < Config.BIRTH_RATE_BASE:
                new_agent = Agent(
                    id=f"agent_{len(self.agents) + len(new_agents):06d}",
                    location=agent.location,
                    civilization_id=agent.civilization_id,
                    age=0,
                    wealth=agent.wealth * 0.1
                )
                new_agents.append(new_agent)
        
        # Remover muertos
        for agent_id in dead_agents:
            if agent_id in self.agents:
                agent = self.agents[agent_id]
                
                # Remover de civilización
                if agent.civilization_id:
                    civ = self.diplomacy_manager.civilizations.get(agent.civilization_id)
                    if civ:
                        civ.agent_ids.discard(agent_id)
                
                # Remover del grid espacial
                self.spatial_grid.remove_agent(agent_id, agent.location)
                
                del self.agents[agent_id]
        
        # Añadir nacimientos
        for new_agent in new_agents:
            self.agents[new_agent.id] = new_agent
            self.spatial_grid.add_agent(new_agent.id, new_agent.location)
            
            if new_agent.civilization_id:
                civ = self.diplomacy_manager.civilizations.get(new_agent.civilization_id)
                if civ:
                    civ.agent_ids.add(new_agent.id)
    
    def _process_resource_gathering_batch(self):
        """Procesa recolección en lotes para mejorar rendimiento"""
        # Procesar solo un subconjunto por turno
        sample_size = min(500, len(self.agents))
        sampled_agents = random.sample(list(self.agents.values()), sample_size)
        
        for agent in sampled_agents:
            y, x = agent.location
            
            # Verificar que no esté en océano
            if self.geosphere.biome_map[y, x] == 0:
                continue
            
            gathered = {}
            
            # Comida: de caza y agricultura
            food_from_hunting = self.ecosystem_manager.get_hunting_yield(agent.location)*2
            food_from_farming = self.geosphere.fertility_map[y, x] * 25
            gathered[ResourceType.FOOD] = food_from_hunting + food_from_farming
            
            # Madera: de bosques
            wood = self.resource_manager.extract_resources(
                agent.location, ResourceType.WOOD, 10
            )
            gathered[ResourceType.WOOD] = wood
            
            # Aplicar multiplicadores de rol
            multipliers = agent.get_resource_multiplier()
            for resource_type, amount in gathered.items():
                bonus = multipliers.get(resource_type, 1.0)
                agent.resources[resource_type] = agent.resources.get(resource_type, 0) + amount * bonus
            
            # Consumo de comida
            agent.resources[ResourceType.FOOD] = max(0, 
                agent.resources.get(ResourceType.FOOD, 0) - 2)
            
            # Actualizar salud según comida disponible
            if agent.resources.get(ResourceType.FOOD, 0) < 5:
                agent.health -= 0.05
            else:
                agent.health = min(1.0, agent.health + 0.02)
    
    def _process_migrations_sample(self):
        """Procesa migraciones en muestra pequeña"""
        # Solo procesar 50 agentes por turno
        sample = random.sample(list(self.agents.values()), 
                             min(50, len(self.agents)))
        
        for agent in sample:
            y, x = agent.location
            
            # Factores de migración
            should_migrate = False
            
            # Clima adverso
            if self.climate_manager.drought_map[y, x] > 0.5:
                should_migrate = random.random() < 0.4
            elif self.climate_manager.flood_map[y, x] > 0.5:
                should_migrate = random.random() < 0.6
            
            # Guerra
            if agent.civilization_id:
                civ = self.diplomacy_manager.civilizations.get(agent.civilization_id)
                if civ and len(civ.at_war_with) > 0:
                    should_migrate = random.random() < 0.3
            
            # Baja fertilidad
            if self.geosphere.fertility_map[y, x] < 0.2:
                should_migrate = random.random() < 0.2
            
            if should_migrate:
                old_biome = self.geosphere.biome_map[y, x]
                
                # Migrar hacia zona más fértil cercana
                best_location = self._find_better_location(agent.location)
                
                if best_location:
                    new_biome = self.geosphere.biome_map[best_location[0], best_location[1]]
                    self.migration_matrix[old_biome, new_biome] += 1
                    
                    # Actualizar grid espacial
                    self.spatial_grid.move_agent(agent.id, agent.location, best_location)
                    
                    agent.location = best_location
    
    def _find_better_location(self, current_loc: Tuple[int, int]) -> Optional[Tuple[int, int]]:
        """Encuentra ubicación mejor dentro de radio 30"""
        y, x = current_loc
        current_fertility = self.geosphere.fertility_map[y, x]
        
        best_loc = None
        best_fertility = current_fertility
        
        # Buscar en 10 ubicaciones aleatorias cercanas
        for _ in range(10):
            dy = random.randint(-30, 30)
            dx = random.randint(-30, 30)
            ny, nx = y + dy, x + dx
            
            if (0 <= ny < self.geosphere.height and 
                0 <= nx < self.geosphere.width):
                
                # Evitar océano
                if self.geosphere.biome_map[ny, nx] == 0:
                    continue
                
                fertility = self.geosphere.fertility_map[ny, nx]
                
                # Considerar fertilidad y eventos climáticos
                penalty = (self.climate_manager.drought_map[ny, nx] * 0.5 +
                          self.climate_manager.flood_map[ny, nx] * 0.3)
                
                effective_fertility = fertility - penalty
                
                if effective_fertility > best_fertility:
                    best_fertility = effective_fertility
                    best_loc = (ny, nx)
        
        return best_loc
    
    def _process_technology_research(self):
        """Investigación tecnológica"""
        for civ in self.diplomacy_manager.civilizations.values():
            civ.update_military_strength(self.agents)
            
            discovered = self.technology_manager.attempt_discovery(civ, self.agents)
            
            if discovered:
                print(f"  🔬 {civ.name} descubrió: {discovered}")
            
            # Difusión entre aliados
            for other_civ in self.diplomacy_manager.civilizations.values():
                if other_civ.id != civ.id:
                    self.technology_manager.diffuse_technology(civ, other_civ)
    
    def _process_religion(self):
        """Fundación y expansión religiosa"""
        for civ in self.diplomacy_manager.civilizations.values():
            founded = self.religion_manager.attempt_founding(civ, self.timestep)
            if founded:
                print(f"  ⛪ {civ.name} fundó religión: {founded.name}")
        
        self.religion_manager.spread_religion(self.diplomacy_manager.civilizations)
    
    def _collect_extended_metrics(self):
        """Recopila métricas (simplificado para rendimiento)"""
        if not self.agents:
            return
        
        agent_list = list(self.agents.values())
        
        # Métricas básicas
        ages = [a.age for a in agent_list]
        births_this_turn = sum(1 for a in agent_list if a.age == 0)
        
        # Recursos
        total_food = sum(a.resources.get(ResourceType.FOOD, 0) for a in agent_list)
        food_demand = len(agent_list) * 2
        
        # Ecología
        avg_forest = np.mean(self.resource_manager.forest_density)
        avg_soil = np.mean(self.resource_manager.soil_quality)
        
        # Civilizaciones
        num_wars = len(self.diplomacy_manager.wars_active)
        num_alliances = len(self.diplomacy_manager.treaties)
        
        total_techs = sum(len(civ.discovered_technologies) 
                         for civ in self.diplomacy_manager.civilizations.values())
        
        num_religions = len(self.religion_manager.religions)
        
        metrics = {
            'timestep': self.timestep,
            'population': len(self.agents),
            'avg_age': np.mean(ages) if ages else 0,
            'births': births_this_turn,
            'young_population': sum(1 for age in ages if age < 18),
            'working_age_population': sum(1 for age in ages if 18 <= age < 60),
            'elderly_population': sum(1 for age in ages if age >= 60),
            'total_food': total_food,
            'food_supply_demand_ratio': total_food / max(food_demand, 1),
            'avg_wealth': np.mean([a.wealth for a in agent_list]) if agent_list else 0,
            'avg_health': np.mean([a.health for a in agent_list]) if agent_list else 0,
            'avg_satisfaction': 0.0,
            'forest_coverage': avg_forest,
            'soil_quality': avg_soil,
            'most_attractive_biome': 0,
            'num_civilizations': len(self.diplomacy_manager.civilizations),
            'active_wars': num_wars,
            'war_intensity_index': 0,
            'alliances': num_alliances,
            'total_technologies': total_techs,
            'stone_age_pct': 100.0,
            'bronze_age_pct': 0.0,
            'iron_age_pct': 0.0,
            'classical_age_pct': 0.0,
            'medieval_age_pct': 0.0,
            'num_religions': num_religions,
            'dominant_religion_influence_pct': 0.0,
            'current_season': self.climate_manager.current_season.value,
            'geological_events': len(self.geological_manager.active_events)
        }
        
        self.metrics_history.append(metrics)
    
    def _print_status(self):
        """Imprime estado compacto"""
        if not self.metrics_history:
            return
        
        m = self.metrics_history[-1]
        print(f"\n⏱ T{self.timestep} [{m['current_season'].upper()}] | "
              f"👥 {m['population']:,} | 🏛 {m['num_civilizations']} civs | "
              f"⚔ {m['active_wars']} wars | 🔬 {m['total_technologies']} techs | "
              f"🌲 {m['forest_coverage']:.0%}")
    
    def export_metrics(self, filename: str = "metrics.csv"):
        """Exporta métricas"""
        if self.metrics_history:
            df = pd.DataFrame(self.metrics_history)
            df.to_csv(filename, index=False)
            print(f"\n📊 Métricas exportadas: {filename}")
            return df
        return None        
class TechnologyManager:
    """Gestiona investigación y difusión tecnológica"""
    
    def __init__(self):
        self.tech_tree = self._initialize_tech_tree()
    
    def _initialize_tech_tree(self) -> Dict[str, Technology]:
        """Inicializa árbol tecnológico"""
        return {
            'agriculture': Technology('agriculture', TechnologyEra.STONE_AGE, [], 
                                     {'food_production': 1.5}),
            'pottery': Technology('pottery', TechnologyEra.STONE_AGE, [],
                                 {'storage': 1.2}),
            'mining': Technology('mining', TechnologyEra.STONE_AGE, [],
                                {'stone': 1.3}),
            'bronze_working': Technology('bronze_working', TechnologyEra.BRONZE_AGE, 
                                        ['mining'], {'military': 1.3}),
            'iron_working': Technology('iron_working', TechnologyEra.IRON_AGE,
                                      ['bronze_working'], {'military': 1.5}),
            'writing': Technology('writing', TechnologyEra.BRONZE_AGE, [],
                                 {'knowledge': 2.0}),
            'mathematics': Technology('mathematics', TechnologyEra.CLASSICAL_AGE,
                                     ['writing'], {'knowledge': 1.5}),
            'astronomy': Technology('astronomy', TechnologyEra.BRONZE_AGE,
                                   ['writing'], {'knowledge': 1.3}),
            'navigation': Technology('navigation', TechnologyEra.CLASSICAL_AGE,
                                    ['astronomy'], {'trade': 1.5}),
            'philosophy': Technology('philosophy', TechnologyEra.CLASSICAL_AGE,
                                    ['writing'], {'culture': 1.4}),
            'engineering': Technology('engineering', TechnologyEra.CLASSICAL_AGE,
                                     ['mathematics'], {'construction': 1.5})
        }
    
    def _get_available_techs(self, civilization: Civilization) -> List[str]:
        """Obtiene tecnologías disponibles para investigar"""
        available = []
        
        for tech_name, tech in self.tech_tree.items():
            # Si ya fue descubierta, saltar
            if tech_name in civilization.discovered_technologies:
                continue
            
            # Verificar si todos los prerrequisitos están cumplidos
            prereqs_met = all(prereq in civilization.discovered_technologies 
                            for prereq in tech.prerequisites)
            
            if prereqs_met:
                available.append(tech_name)
        
        return available
    
    def attempt_discovery(self, civilization: Civilization, agents: Dict[str, Agent]) -> Optional[str]:
        """Investiga tecnología enfocada"""
        
        # Calcular conocimiento generado
        total_knowledge = sum(agents[aid].resources.get(ResourceType.KNOWLEDGE, 0) * 
                             agents[aid].get_resource_multiplier().get(ResourceType.KNOWLEDGE, 1.0)
                             for aid in civilization.agent_ids 
                             if aid in agents)
        
        # Si no hay foco, elegir uno disponible
        if not civilization.research_focus:
            available = self._get_available_techs(civilization)
            if available:
                civilization.research_focus = random.choice(available)
        
        if civilization.research_focus:
            # Acumular progreso
            civilization.research_progress += total_knowledge * Config.TECH_DISCOVERY_RATE
            
            # Costo de tecnología (aumenta por era)
            tech = self.tech_tree[civilization.research_focus]
            cost = 100 * (tech.era.value + 1)
            
            if civilization.research_progress >= cost:
                discovered = civilization.research_focus
                civilization.discovered_technologies.add(discovered)
                civilization.research_focus = None
                civilization.research_progress = 0.0
                self._update_era(civilization)
                return discovered
        
        return None
    
    def _update_era(self, civilization: Civilization):
        """Actualiza era tecnológica de la civilización"""
        tech_counts = {era: 0 for era in TechnologyEra}
        
        for tech_name in civilization.discovered_technologies:
            tech = self.tech_tree.get(tech_name)
            if tech:
                tech_counts[tech.era] += 1
        
        # Cambiar de era si se cumplen umbrales
        if tech_counts[TechnologyEra.MEDIEVAL_AGE] >= 2:
            civilization.current_era = TechnologyEra.MEDIEVAL_AGE
        elif tech_counts[TechnologyEra.CLASSICAL_AGE] >= 3:
            civilization.current_era = TechnologyEra.CLASSICAL_AGE
        elif tech_counts[TechnologyEra.IRON_AGE] >= 2:
            civilization.current_era = TechnologyEra.IRON_AGE
        elif tech_counts[TechnologyEra.BRONZE_AGE] >= 2:
            civilization.current_era = TechnologyEra.BRONZE_AGE
    
    def diffuse_technology(self, civ_from: Civilization, civ_to: Civilization):
        """Difunde tecnología entre civilizaciones aliadas"""
        if civ_to.id in civ_from.relations and civ_from.relations[civ_to.id] in [DiplomacyRelation.ALLIANCE, DiplomacyRelation.TRADE]:
            if random.random() < Config.TECH_DIFFUSION_RATE:
                # Transferir tecnología aleatoria
                transferable = civ_from.discovered_technologies - civ_to.discovered_technologies
                if transferable:
                    tech = random.choice(list(transferable))
                    civ_to.discovered_technologies.add(tech)
                    self._update_era(civ_to)

# ==============================================================================
# GESTOR DE RELIGIONES (NUEVO)
# ==============================================================================

class ReligionManager:
    """Gestiona aparición y expansión de religiones"""
    
    def __init__(self):
        self.religions: Dict[str, Religion] = {}
        self.religion_counter = 0
    
    def attempt_founding(self, civilization: Civilization, timestep: int) -> Optional[Religion]:
        """Intenta fundar nueva religión"""
        if civilization.primary_religion is None and len(civilization.agent_ids) > 50:
            if random.random() < 0.01:  # Probabilidad muy baja
                religion = self._create_religion(civilization, timestep)
                civilization.primary_religion = religion
                self.religions[religion.name] = religion
                return religion
        return None
    
    def _create_religion(self, civilization: Civilization, timestep: int) -> Religion:
        """Crea nueva religión"""
        self.religion_counter += 1
        
        belief_types = ['monotheism', 'polytheism', 'animism', 'ancestor_worship', 'philosophy']
        
        religion = Religion(
            name=f"Faith_{self.religion_counter}",
            founder_civ=civilization.id,
            core_beliefs=[random.choice(belief_types)],
            followers=len(civilization.agent_ids)
        )
        
        return religion
    
    def spread_religion(self, civilizations: Dict[str, Civilization]):
        """Propaga religiones entre civilizaciones"""
        for civ in civilizations.values():
            if civ.primary_religion:
                # Propagar a civilizaciones vecinas con relaciones comerciales
                for other_civ_id, relation in civ.relations.items():
                    if relation in [DiplomacyRelation.TRADE, DiplomacyRelation.ALLIANCE]:
                        other_civ = civilizations[other_civ_id]
                        if other_civ.primary_religion is None and random.random() < 0.05:
                            other_civ.primary_religion = civ.primary_religion
                            civ.primary_religion.followers += len(other_civ.agent_ids)

# ==============================================================================
# MOTOR DE SIMULACIÓN EXTENDIDO
# ==============================================================================

class ExtendedSimulationEngine:
    """Motor principal con todos los sistemas extendidos"""
    
    def __init__(self, num_agents: int = 1000):
        np.random.seed(Config.SIMULATION_SEED)
        random.seed(Config.SIMULATION_SEED)
        
        self.timestep = 0
        
        # Sistemas base
        from scipy.ndimage import gaussian_filter
        self.geosphere = ImprovedGeosphere(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        
        # NUEVOS SISTEMAS - CAMBIAR ESTA LÍNEA:
        self.climate_manager = ClimateManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT, self.geosphere)  # ← Pasar geosphere
        self.geological_manager = GeologicalManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT, self.geosphere)
        self.resource_manager = ResourceManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        self.ecosystem_manager = EcosystemManager(Config.WORLD_WIDTH, Config.WORLD_HEIGHT)
        self.diplomacy_manager = DiplomacyManager()
        self.technology_manager = TechnologyManager()
        self.religion_manager = ReligionManager()
        
        # Agentes y civilizaciones
        self.agents: Dict[str, Agent] = {}
        self._initialize_agents(num_agents)
        self._initialize_civilizations()
        
        # Métricas extendidas
        self.metrics_history = []
        self.demographic_data = []
        self.migration_matrix = np.zeros((9, 9))  # Entre biomas
        
        print(f"Simulación extendida inicializada: {num_agents} agentes, {len(self.diplomacy_manager.civilizations)} civilizaciones")
    
    def _create_simple_geosphere(self):
        """Crea geosfera simplificada para inicialización rápida"""
        
        class SimpleGeosphere:
            def __init__(self):
                self.width = Config.WORLD_WIDTH
                self.height = Config.WORLD_HEIGHT
                self.heightmap = np.random.rand(self.height, self.width)
                self.biome_map = np.random.randint(0, 9, (self.height, self.width))
                self.fertility_map = np.random.rand(self.height, self.width)
                self.erosion_map = np.zeros((self.height, self.width))
                
                # Temperatura y precipitación por latitud
                self.temperature_map = self._calculate_temperature_by_latitude()
                self.precipitation_map = self._calculate_precipitation_by_latitude()
                
                # Mapas de ríos
                self.river_map = np.zeros((self.height, self.width))
                self.water_flow = np.zeros((self.height, self.width))

            def _calculate_temperature_by_latitude(self):
                """Calcula temperatura basada en latitud"""
                temp_map = np.zeros((self.height, self.width))
                for y in range(self.height):
                    latitude = abs(y - self.height / 2) / (self.height / 2)
                    base_temp = 30 - (latitude * 35)
                    
                    for x in range(self.width):
                        altitude_penalty = self.heightmap[y, x] * 15
                        temp_map[y, x] = max(-20, base_temp - altitude_penalty)
                
                return gaussian_filter(temp_map, sigma=2)
            
            def _calculate_precipitation_by_latitude(self):
                """Calcula precipitación por latitud y topografía"""
                precip_map = np.zeros((self.height, self.width))
                for y in range(self.height):
                    latitude = abs(y - self.height / 2) / (self.height / 2)
                    
                    if latitude < 0.2:
                        base_precip = 2500
                    elif latitude < 0.5:
                        base_precip = 1000
                    elif latitude < 0.7:
                        base_precip = 300
                    else:
                        base_precip = 200
                    
                    for x in range(self.width):
                        if self.heightmap[y, x] > 0.6:
                            precip_map[y, x] = base_precip * 1.5
                        else:
                            precip_map[y, x] = base_precip
                
                return gaussian_filter(precip_map, sigma=3)
        
        # Crear y retornar instancia
        return SimpleGeosphere()
    
    def _initialize_agents(self, num_agents: int):
        """Inicializa agentes con demografía"""
        for i in range(num_agents):
            location = (random.randint(0, Config.WORLD_HEIGHT-1), 
                       random.randint(0, Config.WORLD_WIDTH-1))
            age = int(np.random.beta(2, 5) * 80)  # Más jóvenes que ancianos
            
            agent = Agent(
                id=f"agent_{i:06d}",
                location=location,
                age=random.randint(18, 60),
                wealth=max(10, np.random.normal(Config.INITIAL_WEALTH_MEAN, Config.INITIAL_WEALTH_STD))
            )
            agent.resources[ResourceType.KNOWLEDGE] = random.uniform(0, 10)
            self.agents[agent.id] = agent
    
    def _initialize_civilizations(self):
        """Crea civilizaciones iniciales"""
        num_civs = max(3, len(self.agents) // 200)
        
        for i in range(num_civs):
            location = (random.randint(0, Config.WORLD_HEIGHT-1),
                       random.randint(0, Config.WORLD_WIDTH-1))
            
            civ = Civilization(
                id=f"civ_{i}",
                name=f"Civilization_{i}",
                capital_location=location
            )
            
            # Asignar agentes cercanos
            for agent in list(self.agents.values()):
                dist = np.sqrt((agent.location[0] - location[0])**2 + 
                             (agent.location[1] - location[1])**2)
                if dist < 30 and agent.civilization_id is None:
                    agent.civilization_id = civ.id
                    civ.agent_ids.add(agent.id)
                    civ.controlled_tiles.add(agent.location)
            
            if len(civ.agent_ids) > 0:
                self.diplomacy_manager.civilizations[civ.id] = civ
    
    def run_step(self):
        """Ejecuta paso completo de simulación"""
        self.timestep += 1
        
        # 1. Actualizar sistemas ambientales
        self.climate_manager.update(self.timestep)
        self.geological_manager.update(self.timestep)
        self.resource_manager.update(self.geosphere, self.climate_manager)
        self.ecosystem_manager.update(self.agents, self.timestep)
        
        # 2. Demografía: envejecimiento y reproducción
        self._update_demography()
        
        # 3. Migraciones
        self._process_migrations()
        
        # 4. Economía y recursos
        self._process_resource_gathering()
        
        # 5. Diplomacia y guerras
        self.diplomacy_manager.update(self.timestep, self.agents)  # ← Pasar self.agents
        self.diplomacy_manager.resolve_wars(self.timestep)
        
        # 6. Tecnología
        self._process_technology_research()
        
        # 7. Religión
        self._process_religion()
        
        # 8. Decaimiento de eventos
        self.climate_manager.decay_events()
        
        # 9. Métricas
        self._collect_extended_metrics()
        
        if self.timestep % 10 == 0:
            self._print_status()
    
    def _update_demography(self):
        """Actualiza demografía: edad, natalidad, mortalidad"""
        new_agents = []
        
        for agent in list(self.agents.values()):
            agent.age_one_year()
            
            # Mortalidad
            death_prob = Config.DEATH_RATE_BASE * (1 + agent.age / Config.MAX_AGE)
            if agent.health < 0.3:
                death_prob *= 2
            
            if random.random() < death_prob or not agent.is_alive:
                # Remover de civilización si pertenece a una
                if agent.civilization_id:
                    civ = self.diplomacy_manager.civilizations.get(agent.civilization_id)
                    if civ and agent.id in civ.agent_ids:
                        civ.agent_ids.remove(agent.id)
                
                del self.agents[agent.id]
                continue
            
            # Natalidad
            if agent.can_reproduce() and random.random() < Config.BIRTH_RATE_BASE:
                new_agent = Agent(
                    id=f"agent_{len(self.agents) + len(new_agents):06d}",
                    location=agent.location,
                    civilization_id=agent.civilization_id,
                    age=0,
                    wealth=agent.wealth * 0.1
                )
                new_agents.append(new_agent)
        
        # Añadir nuevos agentes
        for new_agent in new_agents:
            self.agents[new_agent.id] = new_agent
            if new_agent.civilization_id:
                civ = self.diplomacy_manager.civilizations.get(new_agent.civilization_id)
                if civ:
                    civ.agent_ids.add(new_agent.id)
    
    def _process_migrations(self):
        """Procesa migraciones por condiciones ambientales"""
        for agent in list(self.agents.values())[:100]:  # Limitar por rendimiento
            y, x = agent.location
            
            # Factores de migración
            should_migrate = False
            
            # Sequía
            if self.climate_manager.drought_map[y, x]:
                should_migrate = random.random() < 0.3
            
            # Inundación
            if self.climate_manager.flood_map[y, x]:
                should_migrate = random.random() < 0.5
            
            # Guerra
            if agent.civilization_id:
                civ = self.diplomacy_manager.civilizations.get(agent.civilization_id)
                if civ and len(civ.at_war_with) > 0:
                    should_migrate = random.random() < 0.2
            
            if should_migrate:
                # Migrar a ubicación aleatoria cercana
                new_y = np.clip(y + random.randint(-20, 20), 0, Config.WORLD_HEIGHT-1)
                new_x = np.clip(x + random.randint(-20, 20), 0, Config.WORLD_WIDTH-1)
                
                old_biome = self.geosphere.biome_map[y, x]
                new_biome = self.geosphere.biome_map[new_y, new_x]
                
                agent.location = (new_y, new_x)
                self.migration_matrix[old_biome, new_biome] += 1
    
    def _process_resource_gathering(self):
        """Procesa recolección con inyección de dependencias"""
        for agent in list(self.agents.values())[:500]:
            gathered = agent.gather_resources(
                location=agent.location,
                resource_manager=self.resource_manager,
                ecosystem_manager=self.ecosystem_manager,
                geosphere=self.geosphere
            )
            
            for resource_type, amount in gathered.items():
                agent.resources[resource_type] = agent.resources.get(resource_type, 0) + amount
    
    def _process_technology_research(self):
        """Procesa investigación tecnológica"""
        for civ in self.diplomacy_manager.civilizations.values():
            civ.update_military_strength(self.agents)
            
            discovered = self.technology_manager.attempt_discovery(civ, self.agents)
            
            # Difusión entre aliados
            for other_civ in self.diplomacy_manager.civilizations.values():
                if other_civ.id != civ.id:
                    self.technology_manager.diffuse_technology(civ, other_civ)
    
    def _process_religion(self):
        """Procesa fundación y expansión religiosa"""
        for civ in self.diplomacy_manager.civilizations.values():
            self.religion_manager.attempt_founding(civ, self.timestep)
        
        self.religion_manager.spread_religion(self.diplomacy_manager.civilizations)
    
    def _collect_extended_metrics(self):
        """Recopila métricas extendidas y avanzadas"""
        if not self.agents:
            return
        
        agent_list = list(self.agents.values())
        
        # === DEMOGRAFÍA AVANZADA ===
        ages = [a.age for a in agent_list]
        births_this_turn = sum(1 for a in agent_list if a.age == 0)
        
        # Pirámide de edad por civilización
        age_pyramids = {}
        for civ_id, civ in self.diplomacy_manager.civilizations.items():
            civ_ages = [self.agents[aid].age for aid in civ.agent_ids if aid in self.agents]
            if civ_ages:
                age_pyramids[civ_id] = {
                    'young': sum(1 for age in civ_ages if age < 18),
                    'adults': sum(1 for age in civ_ages if 18 <= age < 60),
                    'elderly': sum(1 for age in civ_ages if age >= 60),
                    'avg_age': np.mean(civ_ages)
                }
        
        # === RECURSOS Y SOSTENIBILIDAD ===
        total_food = sum(a.resources.get(ResourceType.FOOD, 0) for a in agent_list)
        food_demand = len(agent_list) * 2  # 2 unidades por agente
        resource_supply_to_demand_ratio = total_food / max(food_demand, 1)
        
        # === ECOLOGÍA ===
        avg_forest = np.mean(self.resource_manager.forest_density)
        avg_soil = np.mean(self.resource_manager.soil_quality)
        
        # Bioma con más migración (attractiveness index)
        biome_attractiveness = {}
        if self.migration_matrix.sum() > 0:
            for biome_id in range(9):
                incoming = self.migration_matrix[:, biome_id].sum()
                outgoing = self.migration_matrix[biome_id, :].sum()
                net_migration = incoming - outgoing
                
                # Normalizar por población en ese bioma
                pop_in_biome = sum(1 for a in agent_list 
                                 if self.geosphere.biome_map[a.location[0], a.location[1]] == biome_id)
                biome_attractiveness[biome_id] = net_migration / max(pop_in_biome, 1)
        
        most_attractive_biome = max(biome_attractiveness.items(), 
                                    key=lambda x: x[1])[0] if biome_attractiveness else 0
        
        # === CIVILIZACIONES Y GUERRAS ===
        num_wars = len(self.diplomacy_manager.wars_active)
        num_alliances = len(self.diplomacy_manager.treaties)
        
        # War Intensity Index (ponderado por tamaño de civilizaciones)
        war_intensity_index = 0.0
        for war in self.diplomacy_manager.wars_active:
            civ1_id, civ2_id = war['civilizations']
            civ1 = self.diplomacy_manager.civilizations.get(civ1_id)
            civ2 = self.diplomacy_manager.civilizations.get(civ2_id)
            if civ1 and civ2:
                combined_strength = civ1.military_strength + civ2.military_strength
                war_intensity_index += combined_strength
        
        # === TECNOLOGÍA ===
        total_techs = sum(len(civ.discovered_technologies) 
                         for civ in self.diplomacy_manager.civilizations.values())
        
        # Prevalencia de eras tecnológicas
        era_prevalence = {era: 0 for era in TechnologyEra}
        for civ in self.diplomacy_manager.civilizations.values():
            era_prevalence[civ.current_era] += 1
        
        # Normalizar a porcentaje
        num_civs = len(self.diplomacy_manager.civilizations)
        era_prevalence_pct = {era.name: (count / max(num_civs, 1)) * 100 
                              for era, count in era_prevalence.items()}
        
        # === RELIGIÓN ===
        num_religions = len(self.religion_manager.religions)
        
        # Religión dominante (por extensión geográfica)
        dominant_religion_influence = 0.0
        if self.religion_manager.religions:
            religion_followers = {name: rel.followers 
                                for name, rel in self.religion_manager.religions.items()}
            if religion_followers:
                max_followers = max(religion_followers.values())
                total_population = len(agent_list)
                dominant_religion_influence = (max_followers / max(total_population, 1)) * 100
        
        # === SALUD Y SATISFACCIÓN ===
        avg_health = np.mean([a.health for a in agent_list]) if agent_list else 0
        avg_wealth = np.mean([a.wealth for a in agent_list]) if agent_list else 0
        
        # Satisfacción promedio (si hay sistema de necesidades)
        avg_satisfaction = 0.0
        if hasattr(agent_list[0], 'get_satisfaction'):
            satisfactions = [a.get_satisfaction() for a in agent_list[:100]]  # Sample
            avg_satisfaction = np.mean(satisfactions) if satisfactions else 0
        
        metrics = {
            'timestep': self.timestep,
            
            # Demografía
            'population': len(self.agents),
            'avg_age': np.mean(ages) if ages else 0,
            'births': births_this_turn,
            'young_population': sum(1 for age in ages if age < 18),
            'working_age_population': sum(1 for age in ages if 18 <= age < 60),
            'elderly_population': sum(1 for age in ages if age >= 60),
            
            # Economía y Recursos
            'total_food': total_food,
            'food_supply_demand_ratio': resource_supply_to_demand_ratio,
            'avg_wealth': avg_wealth,
            'avg_health': avg_health,
            'avg_satisfaction': avg_satisfaction,
            
            # Ecología
            'forest_coverage': avg_forest,
            'soil_quality': avg_soil,
            'most_attractive_biome': most_attractive_biome,
            
            # Civilización
            'num_civilizations': len(self.diplomacy_manager.civilizations),
            'active_wars': num_wars,
            'war_intensity_index': war_intensity_index,
            'alliances': num_alliances,
            
            # Tecnología
            'total_technologies': total_techs,
            'stone_age_pct': era_prevalence_pct.get('STONE_AGE', 0),
            'bronze_age_pct': era_prevalence_pct.get('BRONZE_AGE', 0),
            'iron_age_pct': era_prevalence_pct.get('IRON_AGE', 0),
            'classical_age_pct': era_prevalence_pct.get('CLASSICAL_AGE', 0),
            'medieval_age_pct': era_prevalence_pct.get('MEDIEVAL_AGE', 0),
            
            # Religión
            'num_religions': num_religions,
            'dominant_religion_influence_pct': dominant_religion_influence,
            
            # Clima
            'current_season': self.climate_manager.current_season.value,
            'geological_events': len(self.geological_manager.active_events)
        }
        
        self.metrics_history.append(metrics)
        
        # Guardar pirámides de edad por separado para análisis detallado
        if self.timestep % 10 == 0:
            self.demographic_data.append({
                'timestep': self.timestep,
                'pyramids': age_pyramids
            })
    
    def _print_status(self):
        """Imprime estado de la simulación"""
        if not self.metrics_history:
            return
        
        m = self.metrics_history[-1]
        print(f"\n=== Timestep {self.timestep} - {m['current_season'].upper()} ===")
        print(f"Población: {m['population']:,} | Edad promedio: {m['avg_age']:.1f} años")
        print(f"Civilizaciones: {m['num_civilizations']} | Guerras: {m['active_wars']} | Alianzas: {m['alliances']}")
        print(f"Tecnologías: {m['total_technologies']} | Religiones: {m['num_religions']}")
        print(f"Cobertura forestal: {m['forest_coverage']:.1%}")
    
    def export_metrics(self, filename: str = "extended_metrics.csv"):
        """Exporta métricas a CSV"""
        if self.metrics_history:
            df = pd.DataFrame(self.metrics_history)
            df.to_csv(filename, index=False)
            print(f"\nMétricas exportadas a {filename}")
            return df
        return None
# ==============================================================================
# VISUALIZADOR EXTENDIDO
# ==============================================================================

import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

class ExtendedVisualizer:
    """Visualizador con nuevos gráficos"""
    
    def __init__(self, sim: ExtendedSimulationEngine):
        self.sim = sim
    
    def plot_demographic_pyramid(self, save_path: Optional[str] = None):
        """Pirámide poblacional"""
        ages = [a.age for a in self.sim.agents.values()]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.hist(ages, bins=20, color='skyblue', edgecolor='black')
        ax.set_title('Pirámide Poblacional', fontsize=16, fontweight='bold')
        ax.set_xlabel('Edad')
        ax.set_ylabel('Población')
        ax.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
    
    def plot_migration_heatmap(self, save_path: Optional[str] = None):
        """Matriz de migraciones entre biomas"""
        fig, ax = plt.subplots(figsize=(10, 8))
        
        im = ax.imshow(self.sim.migration_matrix, cmap='YlOrRd', aspect='auto')
        ax.set_title('Matriz de Migraciones entre Biomas', fontsize=16, fontweight='bold')
        ax.set_xlabel('Bioma Destino')
        ax.set_ylabel('Bioma Origen')
        
        plt.colorbar(im, ax=ax, label='Número de Migraciones')
        
        if save_path:
            plt.savefig(save_path, dpi=150)
        else:
            plt.show()
    
    def plot_extended_dashboard(self, save_path: Optional[str] = None):
        """Dashboard completo extendido con TODAS las métricas"""
        if not self.sim.metrics_history:
            return
        
        df = pd.DataFrame(self.sim.metrics_history)
        
        fig = plt.figure(figsize=(24, 18))
        gs = GridSpec(4, 4, figure=fig, hspace=0.35, wspace=0.35)
        
        # === FILA 1: Demografía ===
        
        # 1. Población total y grupos etarios
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(df['timestep'], df['population'], 'b-', linewidth=2, label='Total')
        ax1.plot(df['timestep'], df['young_population'], 'g--', linewidth=1.5, label='Jóvenes')
        ax1.plot(df['timestep'], df['working_age_population'], 'orange', linewidth=1.5, label='Adultos')
        ax1.plot(df['timestep'], df['elderly_population'], 'r--', linewidth=1.5, label='Ancianos')
        ax1.set_title('Demografía por Grupos de Edad', fontweight='bold')
        ax1.legend(fontsize=8)
        ax1.grid(True, alpha=0.3)
        
        # 2. Edad promedio y nacimientos
        ax2 = fig.add_subplot(gs[0, 1])
        ax2_twin = ax2.twinx()
        ax2.plot(df['timestep'], df['avg_age'], 'purple', linewidth=2, label='Edad Promedio')
        ax2_twin.bar(df['timestep'], df['births'], color='lightblue', alpha=0.6, label='Nacimientos')
        ax2.set_ylabel('Edad Promedio', color='purple')
        ax2_twin.set_ylabel('Nacimientos', color='blue')
        ax2.set_title('Edad Promedio y Natalidad', fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        # 3. Salud y Riqueza promedio
        ax3 = fig.add_subplot(gs[0, 2])
        ax3_twin = ax3.twinx()
        ax3.plot(df['timestep'], df['avg_health'], 'green', linewidth=2, label='Salud')
        ax3_twin.plot(df['timestep'], df['avg_wealth'], 'gold', linewidth=2, label='Riqueza')
        ax3.set_ylabel('Salud Promedio', color='green')
        ax3_twin.set_ylabel('Riqueza Promedio', color='gold')
        ax3.set_title('Salud y Riqueza', fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        # 4. Ratio Oferta/Demanda de Comida
        ax4 = fig.add_subplot(gs[0, 3])
        ax4.plot(df['timestep'], df['food_supply_demand_ratio'], 'darkgreen', linewidth=2)
        ax4.axhline(y=1.0, color='red', linestyle='--', linewidth=1, label='Equilibrio')
        ax4.fill_between(df['timestep'], df['food_supply_demand_ratio'], 1.0, 
                         where=(df['food_supply_demand_ratio'] >= 1.0), alpha=0.3, color='green')
        ax4.fill_between(df['timestep'], df['food_supply_demand_ratio'], 1.0, 
                         where=(df['food_supply_demand_ratio'] < 1.0), alpha=0.3, color='red')
        ax4.set_title('Sostenibilidad Alimentaria', fontweight='bold')
        ax4.set_ylabel('Ratio Oferta/Demanda')
        ax4.legend(fontsize=8)
        ax4.grid(True, alpha=0.3)
        
        # === FILA 2: Civilización y Diplomacia ===
        
        # 5. Civilizaciones
        ax5 = fig.add_subplot(gs[1, 0])
        ax5.plot(df['timestep'], df['num_civilizations'], 'orange', linewidth=2, marker='o')
        ax5.set_title('Número de Civilizaciones', fontweight='bold')
        ax5.grid(True, alpha=0.3)
        
        # 6. Guerras y Alianzas
        ax6 = fig.add_subplot(gs[1, 1])
        ax6.plot(df['timestep'], df['active_wars'], 'r-', linewidth=2, label='Guerras')
        ax6.plot(df['timestep'], df['alliances'], 'g-', linewidth=2, label='Alianzas')
        ax6.set_title('Relaciones Diplomáticas', fontweight='bold')
        ax6.legend()
        ax6.grid(True, alpha=0.3)
        
        # 7. Índice de Intensidad de Guerra
        ax7 = fig.add_subplot(gs[1, 2])
        ax7.plot(df['timestep'], df['war_intensity_index'], 'darkred', linewidth=2)
        ax7.fill_between(df['timestep'], df['war_intensity_index'], alpha=0.3, color='red')
        ax7.set_title('Intensidad Bélica Global', fontweight='bold')
        ax7.set_ylabel('Índice de Intensidad')
        ax7.grid(True, alpha=0.3)
        
        # 8. Religiones
        ax8 = fig.add_subplot(gs[1, 3])
        ax8_twin = ax8.twinx()
        ax8.plot(df['timestep'], df['num_religions'], 'gold', linewidth=2, marker='s', label='Número')
        ax8_twin.plot(df['timestep'], df['dominant_religion_influence_pct'], 'purple', 
                     linewidth=2, label='Influencia %')
        ax8.set_ylabel('Número de Religiones', color='gold')
        ax8_twin.set_ylabel('Influencia Dominante %', color='purple')
        ax8.set_title('Religiones Fundadas e Influencia', fontweight='bold')
        ax8.grid(True, alpha=0.3)
        
        # === FILA 3: Tecnología ===
        
        # 9. Tecnologías totales
        ax9 = fig.add_subplot(gs[2, 0])
        ax9.plot(df['timestep'], df['total_technologies'], 'purple', linewidth=2)
        ax9.fill_between(df['timestep'], df['total_technologies'], alpha=0.3, color='purple')
        ax9.set_title('Tecnologías Descubiertas (Total)', fontweight='bold')
        ax9.grid(True, alpha=0.3)
        
        # 10. Prevalencia de Eras Tecnológicas (Stacked Area)
        ax10 = fig.add_subplot(gs[2, 1:3])
        ax10.stackplot(df['timestep'], 
                      df['stone_age_pct'], 
                      df['bronze_age_pct'], 
                      df['iron_age_pct'],
                      df['classical_age_pct'],
                      df['medieval_age_pct'],
                      labels=['Edad Piedra', 'Bronce', 'Hierro', 'Clásica', 'Medieval'],
                      colors=['gray', 'brown', 'silver', 'gold', 'darkblue'],
                      alpha=0.7)
        ax10.set_title('Distribución de Eras Tecnológicas (%)', fontweight='bold')
        ax10.set_ylabel('Porcentaje de Civilizaciones')
        ax10.legend(loc='upper left', fontsize=8)
        ax10.grid(True, alpha=0.3)
        
        # 11. Bioma más atractivo
        ax11 = fig.add_subplot(gs[2, 3])
        biome_counts = df['most_attractive_biome'].value_counts()
        ax11.bar(biome_counts.index.astype(str), biome_counts.values, color='teal')
        ax11.set_title('Biomas Más Atractivos', fontweight='bold')
        ax11.set_xlabel('ID Bioma')
        ax11.set_ylabel('Frecuencia')
        ax11.grid(True, alpha=0.3, axis='y')
        
        # === FILA 4: Ecología y Clima ===
        
        # 12. Cobertura forestal y calidad del suelo
        ax12 = fig.add_subplot(gs[3, 0])
        ax12.plot(df['timestep'], df['forest_coverage'] * 100, 'green', linewidth=2, label='Bosques')
        ax12.plot(df['timestep'], df['soil_quality'] * 100, 'brown', linewidth=2, label='Suelo')
        ax12.set_title('Salud Ecológica', fontweight='bold')
        ax12.set_ylabel('Porcentaje')
        ax12.legend()
        ax12.grid(True, alpha=0.3)
        
        # 13. Eventos geológicos acumulados
        ax13 = fig.add_subplot(gs[3, 1])
        ax13.plot(df['timestep'], df['geological_events'].cumsum(), 'brown', linewidth=2)
        ax13.fill_between(df['timestep'], df['geological_events'].cumsum(), alpha=0.3, color='brown')
        ax13.set_title('Eventos Geológicos Acumulados', fontweight='bold')
        ax13.grid(True, alpha=0.3)
        
        # 14. Ciclo Estacional
        ax14 = fig.add_subplot(gs[3, 2])
        season_codes = {'spring': 0, 'summer': 1, 'autumn': 2, 'winter': 3}
        seasons_numeric = [season_codes.get(s, 0) for s in df['current_season']]
        ax14.plot(df['timestep'], seasons_numeric, 'c-', linewidth=2)
        ax14.set_yticks([0, 1, 2, 3])
        ax14.set_yticklabels(['Primavera', 'Verano', 'Otoño', 'Invierno'])
        ax14.set_title('Ciclo Estacional', fontweight='bold')
        ax14.grid(True, alpha=0.3)
        
        # 15. Satisfacción promedio (si existe)
        ax15 = fig.add_subplot(gs[3, 3])
        if 'avg_satisfaction' in df.columns and df['avg_satisfaction'].sum() > 0:
            ax15.plot(df['timestep'], df['avg_satisfaction'], 'pink', linewidth=2)
            ax15.fill_between(df['timestep'], df['avg_satisfaction'], alpha=0.3, color='pink')
            ax15.set_title('Satisfacción Promedio', fontweight='bold')
            ax15.set_ylabel('Nivel de Satisfacción')
        else:
            ax15.text(0.5, 0.5, 'Sistema de\nNecesidades\nNo Implementado', 
                     ha='center', va='center', fontsize=12, transform=ax15.transAxes)
            ax15.set_title('Satisfacción Promedio', fontweight='bold')
        ax15.grid(True, alpha=0.3)
        
        fig.suptitle(f'Dashboard Completo Extendido - Timestep {self.sim.timestep}', 
                    fontsize=20, fontweight='bold')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"Dashboard guardado en {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_wealth_vs_health_scatter(self, save_path: Optional[str] = None):
        """Gráfico de dispersión riqueza vs salud"""
        if not self.sim.agents:
            return
        
        wealths = [a.wealth for a in self.sim.agents.values()]
        healths = [a.health for a in self.sim.agents.values()]
        ages = [a.age for a in self.sim.agents.values()]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        scatter = ax.scatter(wealths, healths, c=ages, cmap='viridis', 
                           s=50, alpha=0.6, edgecolors='black', linewidth=0.5)
        
        ax.set_title('Riqueza vs Salud (color = edad)', fontsize=16, fontweight='bold')
        ax.set_xlabel('Riqueza')
        ax.set_ylabel('Salud')
        ax.grid(True, alpha=0.3)
        
        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('Edad', rotation=270, labelpad=20)
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
    
    def plot_climate_events_timeline(self, save_path: Optional[str] = None):
        """Timeline de eventos climáticos y geológicos"""
        if not self.sim.metrics_history:
            return
        
        df = pd.DataFrame(self.sim.metrics_history)
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 8), sharex=True)
        
        # Eventos geológicos
        ax1.plot(df['timestep'], df['geological_events'], 'ro-', linewidth=2, markersize=8)
        ax1.set_title('Eventos Geológicos por Timestep', fontweight='bold')
        ax1.set_ylabel('Número de Eventos')
        ax1.grid(True, alpha=0.3)
        
        # Cobertura forestal (proxy de eventos climáticos)
        ax2.plot(df['timestep'], df['forest_coverage'], 'g-', linewidth=2)
        ax2.set_title('Salud del Ecosistema (Cobertura Forestal)', fontweight='bold')
        ax2.set_xlabel('Timestep')
        ax2.set_ylabel('Cobertura')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
    
    def plot_technology_tree_progress(self, save_path: Optional[str] = None):
        """Progreso en el árbol tecnológico"""
        tech_by_civ = {}
        
        for civ_id, civ in self.sim.diplomacy_manager.civilizations.items():
            tech_by_civ[civ.name] = len(civ.discovered_technologies)
        
        if not tech_by_civ:
            return
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        civs = list(tech_by_civ.keys())
        techs = list(tech_by_civ.values())
        
        bars = ax.barh(civs, techs, color='steelblue', edgecolor='black')
        ax.set_xlabel('Tecnologías Descubiertas', fontsize=12)
        ax.set_title('Progreso Tecnológico por Civilización', fontsize=16, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='x')
        
        # Colorear barras por era
        for i, bar in enumerate(bars):
            civ = list(self.sim.diplomacy_manager.civilizations.values())[i]
            era_colors = {
                TechnologyEra.STONE_AGE: 'gray',
                TechnologyEra.BRONZE_AGE: 'brown',
                TechnologyEra.IRON_AGE: 'silver',
                TechnologyEra.CLASSICAL_AGE: 'gold',
                TechnologyEra.MEDIEVAL_AGE: 'darkblue'
            }
            bar.set_color(era_colors.get(civ.current_era, 'steelblue'))
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
    
    def plot_diplomatic_network(self, save_path: Optional[str] = None):
        """Red de relaciones diplomáticas"""
        try:
            import networkx as nx
            
            G = nx.Graph()
            
            # Añadir nodos (civilizaciones)
            for civ_id, civ in self.sim.diplomacy_manager.civilizations.items():
                G.add_node(civ_id, label=civ.name)
            
            # Añadir aristas (relaciones)
            for civ_id, civ in self.sim.diplomacy_manager.civilizations.items():
                for other_civ_id, relation in civ.relations.items():
                    if relation == DiplomacyRelation.ALLIANCE:
                        G.add_edge(civ_id, other_civ_id, color='green', weight=3)
                    elif relation == DiplomacyRelation.TRADE:
                        G.add_edge(civ_id, other_civ_id, color='blue', weight=2)
                    elif relation == DiplomacyRelation.WAR:
                        G.add_edge(civ_id, other_civ_id, color='red', weight=2)
            
            fig, ax = plt.subplots(figsize=(12, 10))
            pos = nx.spring_layout(G, k=1, iterations=50)
            
            # Dibujar nodos
            nx.draw_networkx_nodes(G, pos, node_color='lightblue', 
                                  node_size=1000, ax=ax)
            
            # Dibujar aristas por color
            edges = G.edges()
            colors = [G[u][v]['color'] for u, v in edges]
            weights = [G[u][v]['weight'] for u, v in edges]
            
            nx.draw_networkx_edges(G, pos, edge_color=colors, 
                                  width=weights, alpha=0.6, ax=ax)
            
            # Etiquetas
            labels = nx.get_node_attributes(G, 'label')
            nx.draw_networkx_labels(G, pos, labels, font_size=10, ax=ax)
            
            ax.set_title('Red Diplomática (Verde=Alianza, Azul=Comercio, Rojo=Guerra)',
                        fontsize=14, fontweight='bold')
            ax.axis('off')
            
            if save_path:
                plt.savefig(save_path, dpi=150, bbox_inches='tight')
            else:
                plt.show()
        
        except ImportError:
            print("NetworkX no disponible. Instalar con: pip install networkx")

class SpatialVisualizer:
    """Visualizador de mapas espaciales dinámicos"""
    
    def __init__(self, sim: ExtendedSimulationEngine):
        self.sim = sim
        
        # Paleta de colores para biomas
        self.biome_colors = {
            BiomeType.OCEAN.value: '#1e3a8a',
            BiomeType.TUNDRA.value: '#f0f9ff',
            BiomeType.TAIGA.value: '#134e4a',
            BiomeType.GRASSLAND.value: '#84cc16',
            BiomeType.TEMPERATE_FOREST.value: '#16a34a',
            BiomeType.TROPICAL_RAINFOREST.value: '#15803d',
            BiomeType.DESERT.value: '#fbbf24',
            BiomeType.SAVANNA.value: '#ca8a04',
            BiomeType.MOUNTAIN.value: '#78716c'
        }
    
    def plot_civilization_control_map(self, save_path: Optional[str] = None):
        """Mapa de control territorial por civilización"""
        control_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        
        # Asignar cada civilización a un número
        civ_ids = list(self.sim.diplomacy_manager.civilizations.keys())
        civ_to_num = {civ_id: idx + 1 for idx, civ_id in enumerate(civ_ids)}
        
        # Marcar territorios controlados
        for civ_id, civ in self.sim.diplomacy_manager.civilizations.items():
            for tile_y, tile_x in civ.controlled_tiles:
                control_map[tile_y, tile_x] = civ_to_num[civ_id]
        
        fig, ax = plt.subplots(figsize=(16, 10))
        
        # Mostrar mapa base (biomas) con transparencia
        biome_rgb = self._biome_map_to_rgb()
        ax.imshow(biome_rgb, alpha=0.3)
        
        # Superponer control territorial
        masked_control = np.ma.masked_where(control_map == 0, control_map)
        im = ax.imshow(masked_control, cmap='tab20', alpha=0.7, interpolation='nearest')
        
        # Marcar capitales
        for civ in self.sim.diplomacy_manager.civilizations.values():
            cy, cx = civ.capital_location
            ax.plot(cx, cy, 'r*', markersize=15, markeredgecolor='black', markeredgewidth=1)
            ax.text(cx, cy - 5, civ.name, fontsize=8, ha='center', 
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.7))
        
        ax.set_title(f'Control Territorial - Timestep {self.sim.timestep}', 
                    fontsize=16, fontweight='bold')
        ax.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        plt.close()
    
    def plot_agent_density_heatmap(self, save_path: Optional[str] = None):
        """Mapa de calor de densidad de agentes"""
        density_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        
        # Contar agentes por celda
        for agent in self.sim.agents.values():
            y, x = agent.location
            density_map[y, x] += 1
        
        # Suavizar con filtro gaussiano
        density_map = gaussian_filter(density_map, sigma=2)
        
        fig, ax = plt.subplots(figsize=(16, 10))
        
        # Mapa base
        biome_rgb = self._biome_map_to_rgb()
        ax.imshow(biome_rgb, alpha=0.5)
        
        # Superposición de densidad
        im = ax.imshow(density_map, cmap='YlOrRd', alpha=0.6, interpolation='bilinear')
        
        plt.colorbar(im, ax=ax, label='Densidad de Agentes', shrink=0.8)
        
        ax.set_title(f'Densidad Poblacional - Timestep {self.sim.timestep}', 
                    fontsize=16, fontweight='bold')
        ax.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        plt.close()
    
    def plot_environmental_stress_map(self, save_path: Optional[str] = None):
        """Mapa de estrés ambiental combinado"""
        stress_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        
        # Combinar factores de estrés
        stress_map += self.sim.climate_manager.drought_map * 2.0
        stress_map += self.sim.climate_manager.flood_map * 1.5
        stress_map += self.sim.climate_manager.wildfire_map * 3.0
        stress_map += self.sim.geosphere.erosion_map * 0.5
        
        fig, ax = plt.subplots(figsize=(16, 10))
        
        # Mapa base
        biome_rgb = self._biome_map_to_rgb()
        ax.imshow(biome_rgb, alpha=0.4)
        
        # Estrés ambiental
        im = ax.imshow(stress_map, cmap='hot', alpha=0.7, interpolation='bilinear', vmax=5)
        
        plt.colorbar(im, ax=ax, label='Índice de Estrés Ambiental', shrink=0.8)
        
        # Leyenda
        legend_text = f"Sequía activa: {self.sim.climate_manager.drought_map.sum():.0f} celdas\n"
        legend_text += f"Inundación: {self.sim.climate_manager.flood_map.sum():.0f} celdas\n"
        legend_text += f"Incendios: {self.sim.climate_manager.wildfire_map.sum():.0f} celdas"
        
        ax.text(0.02, 0.98, legend_text, transform=ax.transAxes, 
               fontsize=10, verticalalignment='top',
               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        ax.set_title(f'Estrés Ambiental - Timestep {self.sim.timestep} - {self.sim.climate_manager.current_season.value.upper()}', 
                    fontsize=16, fontweight='bold')
        ax.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        plt.close()
    
    def plot_religious_influence_map(self, save_path: Optional[str] = None):
        """Mapa de difusión religiosa por región"""
        religion_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        
        # Asignar religión dominante por civilización
        religion_to_num = {}
        counter = 1
        
        for civ in self.sim.diplomacy_manager.civilizations.values():
            if civ.primary_religion:
                if civ.primary_religion.name not in religion_to_num:
                    religion_to_num[civ.primary_religion.name] = counter
                    counter += 1
                
                rel_num = religion_to_num[civ.primary_religion.name]
                
                # Pintar territorio controlado
                for tile_y, tile_x in civ.controlled_tiles:
                    religion_map[tile_y, tile_x] = rel_num
        
        fig, ax = plt.subplots(figsize=(16, 10))
        
        # Mapa base
        biome_rgb = self._biome_map_to_rgb()
        ax.imshow(biome_rgb, alpha=0.3)
        
        # Influencia religiosa
        masked_religion = np.ma.masked_where(religion_map == 0, religion_map)
        im = ax.imshow(masked_religion, cmap='Spectral', alpha=0.7, interpolation='nearest')
        
        # Leyenda de religiones
        legend_text = "Religiones:\n"
        for rel_name, num in religion_to_num.items():
            religion = self.sim.religion_manager.religions[rel_name]
            legend_text += f"{num}. {rel_name} ({religion.followers} seguidores)\n"
        
        ax.text(0.02, 0.98, legend_text, transform=ax.transAxes, 
               fontsize=9, verticalalignment='top',
               bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
        
        ax.set_title(f'Difusión Religiosa - Timestep {self.sim.timestep}', 
                    fontsize=16, fontweight='bold')
        ax.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        else:
            plt.show()
        plt.close()
    
    def plot_complete_spatial_dashboard(self, save_path: Optional[str] = None):
        """Dashboard completo con 6 vistas espaciales"""
        fig = plt.figure(figsize=(24, 16))
        gs = GridSpec(3, 2, figure=fig, hspace=0.3, wspace=0.2)
        
        # 1. Terreno base
        ax1 = fig.add_subplot(gs[0, 0])
        biome_rgb = self._biome_map_to_rgb()
        ax1.imshow(biome_rgb)
        ax1.set_title('Terreno Base (Biomas)', fontweight='bold')
        ax1.axis('off')
        
        # 2. Control territorial
        ax2 = fig.add_subplot(gs[0, 1])
        control_map = self._get_control_map()
        masked_control = np.ma.masked_where(control_map == 0, control_map)
        ax2.imshow(biome_rgb, alpha=0.3)
        ax2.imshow(masked_control, cmap='tab20', alpha=0.7, interpolation='nearest')
        ax2.set_title('Control Territorial', fontweight='bold')
        ax2.axis('off')
        
        # 3. Densidad poblacional
        ax3 = fig.add_subplot(gs[1, 0])
        density = self._get_density_map()
        ax3.imshow(biome_rgb, alpha=0.5)
        im3 = ax3.imshow(density, cmap='YlOrRd', alpha=0.6, interpolation='bilinear')
        plt.colorbar(im3, ax=ax3, shrink=0.8)
        ax3.set_title('Densidad Poblacional', fontweight='bold')
        ax3.axis('off')
        
        # 4. Estrés ambiental
        ax4 = fig.add_subplot(gs[1, 1])
        stress = self._get_stress_map()
        ax4.imshow(biome_rgb, alpha=0.4)
        im4 = ax4.imshow(stress, cmap='hot', alpha=0.7, interpolation='bilinear', vmax=5)
        plt.colorbar(im4, ax=ax4, shrink=0.8)
        ax4.set_title('Estrés Ambiental', fontweight='bold')
        ax4.axis('off')
        
        # 5. Recursos forestales
        ax5 = fig.add_subplot(gs[2, 0])
        ax5.imshow(biome_rgb, alpha=0.3)
        im5 = ax5.imshow(self.sim.resource_manager.forest_density, cmap='Greens', alpha=0.7)
        plt.colorbar(im5, ax=ax5, shrink=0.8, label='Densidad Forestal')
        ax5.set_title('Cobertura Forestal', fontweight='bold')
        ax5.axis('off')
        
        # 6. Influencia religiosa
        ax6 = fig.add_subplot(gs[2, 1])
        religion_map = self._get_religion_map()
        masked_religion = np.ma.masked_where(religion_map == 0, religion_map)
        ax6.imshow(biome_rgb, alpha=0.3)
        ax6.imshow(masked_religion, cmap='Spectral', alpha=0.7, interpolation='nearest')
        ax6.set_title('Difusión Religiosa', fontweight='bold')
        ax6.axis('off')
        
        fig.suptitle(f'Dashboard Espacial Completo - Timestep {self.sim.timestep} - {self.sim.climate_manager.current_season.value.upper()}', 
                    fontsize=20, fontweight='bold')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"Dashboard espacial guardado en {save_path}")
        else:
            plt.show()
        plt.close()
    
    # Métodos auxiliares
    def _biome_map_to_rgb(self) -> np.ndarray:
        """Convierte mapa de biomas a RGB"""
        height, width = self.sim.geosphere.biome_map.shape
        rgb = np.zeros((height, width, 3))
        
        for y in range(height):
            for x in range(width):
                biome_id = self.sim.geosphere.biome_map[y, x]
                color_hex = list(self.biome_colors.values())[biome_id]
                rgb[y, x] = self._hex_to_rgb(color_hex)
        
        return rgb / 255.0
    
    def _hex_to_rgb(self, hex_color: str) -> np.ndarray:
        """Convierte color hexadecimal a RGB"""
        hex_color = hex_color.lstrip('#')
        return np.array([int(hex_color[i:i+2], 16) for i in (0, 2, 4)])
    
    def _get_control_map(self) -> np.ndarray:
        """Obtiene mapa de control territorial"""
        control_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        civ_ids = list(self.sim.diplomacy_manager.civilizations.keys())
        civ_to_num = {civ_id: idx + 1 for idx, civ_id in enumerate(civ_ids)}
        
        for civ_id, civ in self.sim.diplomacy_manager.civilizations.items():
            for tile_y, tile_x in civ.controlled_tiles:
                control_map[tile_y, tile_x] = civ_to_num[civ_id]
        
        return control_map
    
    def _get_density_map(self) -> np.ndarray:
        """Obtiene mapa de densidad de agentes"""
        density_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        for agent in self.sim.agents.values():
            y, x = agent.location
            density_map[y, x] += 1
        return gaussian_filter(density_map, sigma=2)
    
    def _get_stress_map(self) -> np.ndarray:
        """Obtiene mapa de estrés ambiental"""
        stress_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        stress_map += self.sim.climate_manager.drought_map * 2.0
        stress_map += self.sim.climate_manager.flood_map * 1.5
        stress_map += self.sim.climate_manager.wildfire_map * 3.0
        stress_map += self.sim.geosphere.erosion_map * 0.5
        return stress_map
    
    def _get_religion_map(self) -> np.ndarray:
        """Obtiene mapa de influencia religiosa"""
        religion_map = np.zeros((self.sim.geosphere.height, self.sim.geosphere.width))
        religion_to_num = {}
        counter = 1
        
        for civ in self.sim.diplomacy_manager.civilizations.values():
            if civ.primary_religion:
                if civ.primary_religion.name not in religion_to_num:
                    religion_to_num[civ.primary_religion.name] = counter
                    counter += 1
                
                rel_num = religion_to_num[civ.primary_religion.name]
                for tile_y, tile_x in civ.controlled_tiles:
                    religion_map[tile_y, tile_x] = rel_num
        
        return religion_map

# ==============================================================================
# FUNCIONES DE DEMOSTRACIÓN
# ==============================================================================

def run_extended_simulation(num_agents: int = 500, num_steps: int = 100):
    """Ejecuta simulación extendida completa"""
    print("=" * 80)
    print("SIMULADOR DE CIVILIZACIONES EXTENDIDO V2.0")
    print("=" * 80)
    print("\nCaracterísticas:")
    print("  ✓ Clima dinámico con estaciones")
    print("  ✓ Eventos geológicos (terremotos, volcanes, tsunamis)")
    print("  ✓ Ciclos de recursos renovables")
    print("  ✓ Ecosistemas vivos con fauna y plagas")
    print("  ✓ Migraciones poblacionales")
    print("  ✓ Diplomacia (guerras, alianzas, comercio)")
    print("  ✓ Evolución tecnológica por eras")
    print("  ✓ Demografía detallada")
    print("  ✓ Religiones organizadas")
    print("=" * 80)
    
    # Crear simulación
    sim = OptimizedSimulationEngine(num_agents=num_agents)  # ✅ Optimizada
    
    # Ejecutar
    print(f"\nEjecutando {num_steps} timesteps...")
    for i in range(num_steps):
        sim.run_step()
    
    # Resultados
    print("\n" + "=" * 80)
    print("RESUMEN FINAL")
    print("=" * 80)
    
    df = sim.export_metrics()
    
    if df is not None:
        print(f"\nPoblación final: {df['population'].iloc[-1]:,}")
        print(f"Edad promedio: {df['avg_age'].iloc[-1]:.1f} años")
        print(f"Civilizaciones: {df['num_civilizations'].iloc[-1]}")
        print(f"Guerras activas: {df['active_wars'].iloc[-1]}")
        print(f"Alianzas: {df['alliances'].iloc[-1]}")
        print(f"Tecnologías totales: {df['total_technologies'].iloc[-1]}")
        print(f"Religiones: {df['num_religions'].iloc[-1]}")
        print(f"Cobertura forestal: {df['forest_coverage'].iloc[-1]:.1%}")
        print(f"Eventos geológicos totales: {df['geological_events'].sum()}")
    
    return sim, df

def run_with_extended_visualization(num_agents: int = 500, num_steps: int = 100):
    """Ejecuta con visualizaciones extendidas"""
    print("\nMODO: Visualización Extendida\n")
    
    sim = OptimizedSimulationEngine(num_agents=num_agents)  # ✅ Optimizada
    viz = ExtendedVisualizer(sim)
    spatial_viz = SpatialVisualizer(sim)  # NUEVO
    
    # Ejecutar simulación
    for i in range(num_steps):
        sim.run_step()
        
    # Visualizaciones finales
    print("\nGenerando visualizaciones finales...")
    
    # Temporales
    viz.plot_extended_dashboard(save_path='final_dashboard.png')
    viz.plot_demographic_pyramid(save_path='demographic_pyramid.png')
    viz.plot_migration_heatmap(save_path='migration_heatmap.png')
    viz.plot_wealth_vs_health_scatter(save_path='wealth_vs_health.png')
    viz.plot_climate_events_timeline(save_path='climate_timeline.png')
    viz.plot_technology_tree_progress(save_path='tech_progress.png')
    viz.plot_diplomatic_network(save_path='diplomatic_network.png')
    
    # Espaciales (NUEVO)
    spatial_viz.plot_complete_spatial_dashboard(save_path='final_spatial_dashboard.png')
    spatial_viz.plot_civilization_control_map(save_path='territorial_control.png')
    spatial_viz.plot_agent_density_heatmap(save_path='population_density.png')
    spatial_viz.plot_environmental_stress_map(save_path='environmental_stress.png')
    spatial_viz.plot_religious_influence_map(save_path='religious_influence.png')
    
    print("\nTodas las visualizaciones guardadas!")
    
    return sim, viz, spatial_viz

# ==============================================================================
# EJECUCIÓN PRINCIPAL
# ==============================================================================

def interactive_menu_extended():
    """Menú interactivo para simulación extendida"""
    print("\n" + "=" * 80)
    print("SIMULADOR DE CIVILIZACIONES V2.0 - MENÚ PRINCIPAL")
    print("=" * 80)
    print("\nOpciones:")
    print("\n1. Simulación rápida (500 agentes, 100 pasos)")
    print("2. Simulación larga (1000 agentes, 200 pasos)")
    print("3. Simulación con visualizaciones completas")
    print("4. Modo personalizado")
    print("5. Salir")
    
    choice = input("\nSeleccione opción (1-5): ").strip()
    
    if choice == '1':
        sim, df = run_extended_simulation(500, 100)
        
        print("\n¿Generar visualizaciones? (s/n): ", end='')
        if input().lower() == 's':
            viz = ExtendedVisualizer(sim)
            viz.plot_extended_dashboard()
    
    elif choice == '2':
        sim, df = run_extended_simulation(1000, 200)
        
        print("\n¿Generar visualizaciones? (s/n): ", end='')
        if input().lower() == 's':
            viz = ExtendedVisualizer(sim)
            viz.plot_extended_dashboard()
    
    elif choice == '3':
        num_agents = int(input("Número de agentes (100-2000): ") or "500")
        num_steps = int(input("Número de pasos (50-500): ") or "100")
        sim, viz, spatial_viz = run_with_extended_visualization(num_agents, num_steps)
    
    elif choice == '4':
        num_agents = int(input("Número de agentes: "))
        num_steps = int(input("Número de pasos: "))
        
        print("\nOpciones avanzadas:")
        print(f"  Probabilidad eventos climáticos: {Config.WEATHER_EVENT_PROBABILITY}")
        print(f"  Probabilidad eventos geológicos: {Config.GEOLOGICAL_EVENT_PROBABILITY}")
        print(f"  Tasa de natalidad: {Config.BIRTH_RATE_BASE}")
        
        print("\n¿Modificar configuración? (s/n): ", end='')
        if input().lower() == 's':
            Config.WEATHER_EVENT_PROBABILITY = float(input("Nueva prob. eventos climáticos (0-1): ") or Config.WEATHER_EVENT_PROBABILITY)
            Config.GEOLOGICAL_EVENT_PROBABILITY = float(input("Nueva prob. eventos geológicos (0-1): ") or Config.GEOLOGICAL_EVENT_PROBABILITY)
        
        sim, df = run_extended_simulation(num_agents, num_steps)
    
    elif choice == '5':
        print("\n¡Gracias por usar el simulador!")
        return
    
    else:
        print("\nOpción inválida")
        interactive_menu_extended()


# ==============================================================================
# EJECUCIÓN PRINCIPAL
# ==============================================================================

if __name__ == "__main__":
    # Menú interactivo
    interactive_menu_extended()
    
    # O ejecutar directamente:
    # sim, df = run_extended_simulation(num_agents=500, num_steps=100)
    # sim, viz, spatial_viz = run_with_extended_visualization(num_agents=500, num_steps=100)
    
    # O ejecutar directamente:
    # sim, df = run_extended_simulation(num_agents=500, num_steps=100)
    # sim, viz = run_with_extended_visualization(num_agents=500, num_steps=100)