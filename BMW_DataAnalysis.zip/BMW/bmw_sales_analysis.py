"""
====================================================================
ANÁLISIS COMPLETO DE VENTAS BMW (2010-2024)
====================================================================
Script profesional y modular para análisis exhaustivo de datos
Autor: Sistema de Análisis Automatizado
Fecha: 2025
====================================================================
"""

# ============================================================================
# 1. IMPORTACIÓN DE LIBRERÍAS
# ============================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import os
from datetime import datetime

# Configuración visual
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")
warnings.filterwarnings('ignore')

# Machine Learning
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Estadística
from scipy import stats
from scipy.stats import pearsonr

# Configuración
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_rows', 100)

print("✓ Librerías importadas correctamente")
print("="*80)


# ============================================================================
# 2. FUNCIONES DE CONFIGURACIÓN Y LIMPIEZA
# ============================================================================

def crear_estructura_directorios():
    """Crea directorios necesarios para guardar resultados"""
    directories = ['BMW/figures', 'BMW/reports', 'BMW/data_cleaned', 'BMW/models']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print("✓ Estructura de directorios creada")
    return directories


def cargar_y_explorar_datos(filepath):
    """
    Carga el dataset y muestra información básica
    
    Args:
        filepath (str): Ruta al archivo CSV
        
    Returns:
        pd.DataFrame: Dataset cargado
    """
    print("\n📂 CARGANDO DATOS...")
    print("-" * 80)
    
    df = pd.read_csv(filepath)
    
    print(f"✓ Dataset cargado exitosamente")
    print(f"  - Filas: {df.shape[0]:,}")
    print(f"  - Columnas: {df.shape[1]}")
    print(f"\n📋 Columnas: {list(df.columns)}")
    print(f"\n📊 Primeras filas:")
    print(df.head())
    print(f"\n🔍 Información del dataset:")
    print(df.info())
    print(f"\n❓ Valores nulos por columna:")
    print(df.isnull().sum())
    
    return df


def limpiar_datos(df):
    """
    Limpia y prepara el dataset para análisis
    
    Args:
        df (pd.DataFrame): Dataset original
        
    Returns:
        pd.DataFrame: Dataset limpio
    """
    print("\n🧹 LIMPIANDO DATOS...")
    print("-" * 80)
    
    df_clean = df.copy()
    
    # Estandarizar nombres de columnas
    df_clean.columns = df_clean.columns.str.strip().str.replace(' ', '_')
    print("✓ Columnas estandarizadas")
    
    # Eliminar duplicados
    duplicados_antes = df_clean.shape[0]
    df_clean = df_clean.drop_duplicates()
    duplicados_despues = df_clean.shape[0]
    print(f"✓ Duplicados eliminados: {duplicados_antes - duplicados_despues}")
    
    # Convertir Year a numérico
    df_clean['Year'] = pd.to_numeric(df_clean['Year'], errors='coerce')
    
    # Convertir columnas numéricas
    numeric_cols = ['Price_USD', 'Mileage_KM', 'Engine_Size_L', 'Sales_Volume']
    for col in numeric_cols:
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
    
    print("✓ Tipos de datos convertidos")
    
    # Rellenar valores nulos en categóricas con 'Unknown'
    categorical_cols = ['Model', 'Region', 'Color', 'Fuel_Type', 'Transmission']
    for col in categorical_cols:
        if col in df_clean.columns:
            df_clean[col].fillna('Unknown', inplace=True)
    
    # Rellenar valores nulos en numéricas con la mediana
    for col in numeric_cols:
        if col in df_clean.columns:
            df_clean[col].fillna(df_clean[col].median(), inplace=True)
    
    print("✓ Valores nulos tratados")
    
    # Crear variables derivadas
    if 'Price_USD' in df_clean.columns and 'Engine_Size_L' in df_clean.columns:
        df_clean['Price_per_Liter'] = df_clean['Price_USD'] / df_clean['Engine_Size_L']
        print("✓ Variable derivada creada: Price_per_Liter")
    
    # Crear categoría de precio
    if 'Price_USD' in df_clean.columns:
        df_clean['Price_Category'] = pd.cut(df_clean['Price_USD'], 
                                             bins=[0, 30000, 60000, np.inf],
                                             labels=['Económico', 'Medio', 'Premium'])
        print("✓ Variable derivada creada: Price_Category")
    
    # Crear categoría de antigüedad
    current_year = 2024
    if 'Year' in df_clean.columns:
        df_clean['Vehicle_Age'] = current_year - df_clean['Year']
        print("✓ Variable derivada creada: Vehicle_Age")
    
    print(f"\n✓ Dataset limpio - Forma final: {df_clean.shape}")
    print(f"✓ Valores nulos restantes: {df_clean.isnull().sum().sum()}")
    
    return df_clean


# ============================================================================
# 3. ANÁLISIS DESCRIPTIVO
# ============================================================================

def analisis_descriptivo(df):
    """Genera estadísticas descriptivas completas"""
    print("\n📊 ANÁLISIS DESCRIPTIVO")
    print("=" * 80)
    
    # Estadísticas numéricas
    print("\n📈 Estadísticas Descriptivas (Numéricas):")
    print(df.describe().round(2))
    
    # Frecuencias de variables categóricas
    categorical_cols = ['Model', 'Region', 'Color', 'Fuel_Type', 'Transmission']
    
    print("\n📊 Frecuencias de Variables Categóricas:")
    for col in categorical_cols:
        if col in df.columns:
            print(f"\n{col}:")
            print(df[col].value_counts().head(10))
    
    # Guardar resumen
    with open('BMW/reports/descriptive_summary.txt', 'w', encoding='utf-8') as f:
        f.write("ANÁLISIS DESCRIPTIVO - BMW SALES DATA\n")
        f.write("=" * 80 + "\n\n")
        f.write("Estadísticas Descriptivas:\n")
        f.write(df.describe().to_string())
        f.write("\n\n")
        for col in categorical_cols:
            if col in df.columns:
                f.write(f"\n{col}:\n")
                f.write(df[col].value_counts().head(10).to_string())
                f.write("\n")
    
    print("\n✓ Resumen guardado en 'reports/descriptive_summary.txt'")


def detectar_outliers(df):
    """Detecta y visualiza outliers en variables numéricas"""
    print("\n🔍 DETECCIÓN DE OUTLIERS")
    print("-" * 80)
    
    numeric_cols = ['Price_USD', 'Mileage_KM', 'Engine_Size_L', 'Sales_Volume']
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    axes = axes.ravel()
    
    for idx, col in enumerate(numeric_cols):
        if col in df.columns:
            # Boxplot
            axes[idx].boxplot(df[col].dropna())
            axes[idx].set_title(f'Boxplot: {col}')
            axes[idx].set_ylabel(col)
            
            # Calcular outliers con IQR
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            outliers = df[(df[col] < Q1 - 1.5*IQR) | (df[col] > Q3 + 1.5*IQR)][col]
            
            print(f"  {col}: {len(outliers)} outliers detectados ({len(outliers)/len(df)*100:.2f}%)")
    
    plt.tight_layout()
    plt.savefig('BMW/figures/01_outliers_detection.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("✓ Gráfico guardado: figures/01_outliers_detection.png")


def visualizar_distribuciones(df):
    """Visualiza distribuciones de variables numéricas"""
    print("\n📊 VISUALIZACIÓN DE DISTRIBUCIONES")
    print("-" * 80)
    
    numeric_cols = ['Price_USD', 'Mileage_KM', 'Engine_Size_L', 'Sales_Volume']
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    axes = axes.ravel()
    
    for idx, col in enumerate(numeric_cols):
        if col in df.columns:
            axes[idx].hist(df[col].dropna(), bins=50, alpha=0.7, edgecolor='black')
            axes[idx].set_title(f'Distribución: {col}')
            axes[idx].set_xlabel(col)
            axes[idx].set_ylabel('Frecuencia')
            axes[idx].axvline(df[col].mean(), color='red', linestyle='--', 
                             label=f'Media: {df[col].mean():.2f}')
            axes[idx].legend()
    
    plt.tight_layout()
    plt.savefig('BMW/figures/02_distributions.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("✓ Gráfico guardado: figures/02_distributions.png")


# ============================================================================
# 4. ANÁLISIS DE CORRELACIONES
# ============================================================================

def analisis_correlaciones(df):
    """Genera matriz de correlación y visualización"""
    print("\n🔗 ANÁLISIS DE CORRELACIONES")
    print("-" * 80)
    
    # Seleccionar solo columnas numéricas
    numeric_df = df.select_dtypes(include=[np.number])
    
    # Calcular correlación
    corr_matrix = numeric_df.corr()
    
    # Visualizar
    plt.figure(figsize=(12, 10))
    sns.heatmap(corr_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
                center=0, square=True, linewidths=1)
    plt.title('Matriz de Correlación - Variables Numéricas', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.savefig('BMW/figures/03_correlation_matrix.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/03_correlation_matrix.png")
    
    # Correlaciones más fuertes con Price_USD y Sales_Volume
    if 'Price_USD' in corr_matrix.columns:
        print("\n📈 Correlaciones más fuertes con Price_USD:")
        price_corr = corr_matrix['Price_USD'].sort_values(ascending=False)
        print(price_corr.head(10))
    
    if 'Sales_Volume' in corr_matrix.columns:
        print("\n📈 Correlaciones más fuertes con Sales_Volume:")
        sales_corr = corr_matrix['Sales_Volume'].sort_values(ascending=False)
        print(sales_corr.head(10))
    
    return corr_matrix


# ============================================================================
# 5. ANÁLISIS TEMPORAL (2010-2024)
# ============================================================================

def analisis_temporal(df):
    """Analiza tendencias temporales en ventas y precios"""
    print("\n⏳ ANÁLISIS TEMPORAL (2010-2024)")
    print("=" * 80)
    
    # Ventas por año
    ventas_año = df.groupby('Year')['Sales_Volume'].sum().sort_index()
    
    # Precio promedio por año
    precio_año = df.groupby('Year')['Price_USD'].mean().sort_index()
    
    # Visualización
    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    
    # 1. Evolución de ventas totales
    axes[0, 0].plot(ventas_año.index, ventas_año.values, marker='o', linewidth=2, markersize=8)
    axes[0, 0].set_title('Evolución de Ventas Totales (2010-2024)', fontweight='bold')
    axes[0, 0].set_xlabel('Año')
    axes[0, 0].set_ylabel('Volumen de Ventas')
    axes[0, 0].grid(True, alpha=0.3)
    axes[0, 0].fill_between(ventas_año.index, ventas_año.values, alpha=0.3)
    
    # 2. Evolución de precio promedio
    axes[0, 1].plot(precio_año.index, precio_año.values, marker='s', 
                    linewidth=2, markersize=8, color='orange')
    axes[0, 1].set_title('Evolución del Precio Promedio', fontweight='bold')
    axes[0, 1].set_xlabel('Año')
    axes[0, 1].set_ylabel('Precio Promedio (USD)')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Participación de combustibles por año
    fuel_year = df.groupby(['Year', 'Fuel_Type'])['Sales_Volume'].sum().unstack(fill_value=0)
    fuel_year_pct = fuel_year.div(fuel_year.sum(axis=1), axis=0) * 100
    fuel_year_pct.plot(kind='area', stacked=True, ax=axes[1, 0], alpha=0.7)
    axes[1, 0].set_title('Participación de Tipos de Combustible (%)', fontweight='bold')
    axes[1, 0].set_xlabel('Año')
    axes[1, 0].set_ylabel('Porcentaje (%)')
    axes[1, 0].legend(title='Combustible', bbox_to_anchor=(1.05, 1), loc='upper left')
    
    # 4. Transmisión por año
    trans_year = df.groupby(['Year', 'Transmission'])['Sales_Volume'].sum().unstack(fill_value=0)
    trans_year.plot(kind='bar', ax=axes[1, 1], width=0.8)
    axes[1, 1].set_title('Ventas por Tipo de Transmisión', fontweight='bold')
    axes[1, 1].set_xlabel('Año')
    axes[1, 1].set_ylabel('Volumen de Ventas')
    axes[1, 1].legend(title='Transmisión')
    axes[1, 1].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/04_temporal_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/04_temporal_analysis.png")
    print(f"\n📊 Resumen Temporal:")
    print(f"  - Ventas totales 2010-2024: {ventas_año.sum():,.0f}")
    print(f"  - Año con más ventas: {ventas_año.idxmax()} ({ventas_año.max():,.0f})")
    print(f"  - Año con menos ventas: {ventas_año.idxmin()} ({ventas_año.min():,.0f})")
    print(f"  - Precio promedio global: ${precio_año.mean():,.2f}")


# ============================================================================
# 6. ANÁLISIS GEOGRÁFICO
# ============================================================================

def analisis_geografico(df):
    """Analiza patrones geográficos de ventas"""
    print("\n🌍 ANÁLISIS GEOGRÁFICO")
    print("=" * 80)
    
    # Ventas por región
    ventas_region = df.groupby('Region').agg({
        'Sales_Volume': 'sum',
        'Price_USD': 'mean'
    }).sort_values('Sales_Volume', ascending=False)
    
    print("\n📊 Ventas y Precio Promedio por Región:")
    print(ventas_region)
    
    # Modelos más vendidos por región
    print("\n🚗 Modelo más vendido por región:")
    for region in df['Region'].unique():
        if region != 'Unknown':
            top_model = df[df['Region'] == region].groupby('Model')['Sales_Volume'].sum().idxmax()
            ventas_top = df[df['Region'] == region].groupby('Model')['Sales_Volume'].sum().max()
            print(f"  {region}: {top_model} ({ventas_top:,.0f} unidades)")
    
    # Visualización
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Ventas totales por región
    ventas_region['Sales_Volume'].plot(kind='barh', ax=axes[0, 0], color='skyblue')
    axes[0, 0].set_title('Ventas Totales por Región', fontweight='bold')
    axes[0, 0].set_xlabel('Volumen de Ventas')
    
    # 2. Precio promedio por región
    ventas_region['Price_USD'].plot(kind='barh', ax=axes[0, 1], color='coral')
    axes[0, 1].set_title('Precio Promedio por Región', fontweight='bold')
    axes[0, 1].set_xlabel('Precio Promedio (USD)')
    
    # 3. Tipo de combustible por región
    fuel_region = df.groupby(['Region', 'Fuel_Type'])['Sales_Volume'].sum().unstack(fill_value=0)
    fuel_region.plot(kind='bar', stacked=True, ax=axes[1, 0], width=0.8)
    axes[1, 0].set_title('Distribución de Combustible por Región', fontweight='bold')
    axes[1, 0].set_xlabel('Región')
    axes[1, 0].set_ylabel('Volumen de Ventas')
    axes[1, 0].legend(title='Combustible', bbox_to_anchor=(1.05, 1))
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. Top 10 modelos por región (ejemplo con una región)
    top_region = ventas_region.index[0]
    top_models_region = df[df['Region'] == top_region].groupby('Model')['Sales_Volume'].sum().nlargest(10)
    top_models_region.plot(kind='barh', ax=axes[1, 1], color='lightgreen')
    axes[1, 1].set_title(f'Top 10 Modelos en {top_region}', fontweight='bold')
    axes[1, 1].set_xlabel('Volumen de Ventas')
    
    plt.tight_layout()
    plt.savefig('BMW/figures/05_geographic_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/05_geographic_analysis.png")


# ============================================================================
# 7. ANÁLISIS POR MODELO
# ============================================================================

def analisis_por_modelo(df):
    """Analiza tendencias y características por modelo"""
    print("\n🚗 ANÁLISIS POR MODELO")
    print("=" * 80)
    
    # Ranking de modelos más vendidos
    modelo_ventas = df.groupby('Model').agg({
        'Sales_Volume': 'sum',
        'Price_USD': 'mean',
        'Engine_Size_L': 'mean'
    }).sort_values('Sales_Volume', ascending=False)
    
    print("\n🏆 Top 15 Modelos Más Vendidos:")
    print(modelo_ventas.head(15))
    
    # Visualización
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Top 15 modelos más vendidos
    modelo_ventas['Sales_Volume'].head(15).plot(kind='barh', ax=axes[0, 0], color='steelblue')
    axes[0, 0].set_title('Top 15 Modelos Más Vendidos', fontweight='bold')
    axes[0, 0].set_xlabel('Volumen de Ventas')
    axes[0, 0].invert_yaxis()
    
    # 2. Precio promedio por modelo (top 15)
    modelo_ventas['Price_USD'].head(15).plot(kind='barh', ax=axes[0, 1], color='gold')
    axes[0, 1].set_title('Precio Promedio - Top 15 Modelos', fontweight='bold')
    axes[0, 1].set_xlabel('Precio Promedio (USD)')
    axes[0, 1].invert_yaxis()
    
    # 3. Relación Motor vs Precio (scatter)
    top_15_models = modelo_ventas.head(15).index
    df_top15 = df[df['Model'].isin(top_15_models)]
    
    for model in top_15_models[:5]:  # Solo los 5 primeros para claridad
        model_data = df_top15[df_top15['Model'] == model]
        axes[1, 0].scatter(model_data['Engine_Size_L'], model_data['Price_USD'], 
                          label=model, alpha=0.6, s=50)
    
    axes[1, 0].set_title('Relación Motor vs Precio (Top 5 Modelos)', fontweight='bold')
    axes[1, 0].set_xlabel('Tamaño del Motor (L)')
    axes[1, 0].set_ylabel('Precio (USD)')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Ventas por modelo a lo largo del tiempo (top 5)
    ventas_modelo_año = df.groupby(['Year', 'Model'])['Sales_Volume'].sum().unstack(fill_value=0)
    top_5_models = modelo_ventas.head(5).index
    ventas_modelo_año[top_5_models].plot(ax=axes[1, 1], marker='o', linewidth=2)
    axes[1, 1].set_title('Evolución de Ventas - Top 5 Modelos', fontweight='bold')
    axes[1, 1].set_xlabel('Año')
    axes[1, 1].set_ylabel('Volumen de Ventas')
    axes[1, 1].legend(title='Modelo', bbox_to_anchor=(1.05, 1))
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/06_model_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/06_model_analysis.png")


# ============================================================================
# 8. ANÁLISIS TÉCNICO
# ============================================================================

def analisis_tecnico(df):
    """Analiza características técnicas y su impacto"""
    print("\n⚙️ ANÁLISIS TÉCNICO")
    print("=" * 80)
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Motor vs Precio (regresión)
    x = df['Engine_Size_L'].values.reshape(-1, 1)
    y = df['Price_USD'].values
    
    # Eliminar NaN
    mask = ~np.isnan(x.flatten()) & ~np.isnan(y)
    x_clean = x[mask].reshape(-1, 1)
    y_clean = y[mask]
    
    model = LinearRegression()
    model.fit(x_clean, y_clean)
    y_pred = model.predict(x_clean)
    
    axes[0, 0].scatter(x_clean, y_clean, alpha=0.5, s=20)
    axes[0, 0].plot(x_clean, y_pred, color='red', linewidth=2, label='Regresión Lineal')
    axes[0, 0].set_title('Motor vs Precio (con Regresión)', fontweight='bold')
    axes[0, 0].set_xlabel('Tamaño del Motor (L)')
    axes[0, 0].set_ylabel('Precio (USD)')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    r2 = r2_score(y_clean, y_pred)
    axes[0, 0].text(0.05, 0.95, f'R² = {r2:.3f}', transform=axes[0, 0].transAxes,
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
                   verticalalignment='top')
    
    print(f"  Regresión Motor vs Precio - R²: {r2:.3f}")
    
    # 2. Kilometraje vs Precio (depreciación)
    axes[0, 1].scatter(df['Mileage_KM'], df['Price_USD'], alpha=0.3, s=20)
    axes[0, 1].set_title('Depreciación: Kilometraje vs Precio', fontweight='bold')
    axes[0, 1].set_xlabel('Kilometraje (KM)')
    axes[0, 1].set_ylabel('Precio (USD)')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Precio promedio por tipo de combustible
    fuel_price = df.groupby('Fuel_Type')['Price_USD'].mean().sort_values(ascending=False)
    fuel_price.plot(kind='bar', ax=axes[1, 0], color='lightcoral')
    axes[1, 0].set_title('Precio Promedio por Tipo de Combustible', fontweight='bold')
    axes[1, 0].set_xlabel('Tipo de Combustible')
    axes[1, 0].set_ylabel('Precio Promedio (USD)')
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. Ventas por tipo de transmisión
    trans_sales = df.groupby('Transmission')['Sales_Volume'].sum().sort_values(ascending=False)
    trans_sales.plot(kind='pie', ax=axes[1, 1], autopct='%1.1f%%', startangle=90)
    axes[1, 1].set_title('Distribución de Ventas por Transmisión', fontweight='bold')
    axes[1, 1].set_ylabel('')
    
    plt.tight_layout()
    plt.savefig('BMW/figures/07_technical_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/07_technical_analysis.png")


# ============================================================================
# 9. ANÁLISIS DE PREFERENCIAS DEL CLIENTE
# ============================================================================

def analisis_preferencias_cliente(df):
    """Analiza preferencias de color y combinaciones"""
    print("\n🎨 ANÁLISIS DE PREFERENCIAS DEL CLIENTE")
    print("=" * 80)
    
    # Colores más populares
    color_ventas = df.groupby('Color')['Sales_Volume'].sum().sort_values(ascending=False)
    
    print("\n🎨 Top 10 Colores Más Populares:")
    print(color_ventas.head(10))
    
    # Visualización
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Top 10 colores
    color_ventas.head(10).plot(kind='barh', ax=axes[0, 0], color='purple')
    axes[0, 0].set_title('Top 10 Colores Más Vendidos', fontweight='bold')
    axes[0, 0].set_xlabel('Volumen de Ventas')
    axes[0, 0].invert_yaxis()
    
    # 2. Precio promedio por color
    color_precio = df.groupby('Color')['Price_USD'].mean().sort_values(ascending=False).head(10)
    color_precio.plot(kind='barh', ax=axes[0, 1], color='teal')
    axes[0, 1].set_title('Precio Promedio por Color (Top 10)', fontweight='bold')
    axes[0, 1].set_xlabel('Precio Promedio (USD)')
    axes[0, 1].invert_yaxis()
    
    # 3. Colores por región
    color_region = df.groupby(['Region', 'Color'])['Sales_Volume'].sum().unstack(fill_value=0)
    top_colors = color_ventas.head(5).index
    color_region[top_colors].plot(kind='bar', ax=axes[1, 0], width=0.8)
    axes[1, 0].set_title('Top 5 Colores por Región', fontweight='bold')
    axes[1, 0].set_xlabel('Región')
    axes[1, 0].set_ylabel('Volumen de Ventas')
    axes[1, 0].legend(title='Color', bbox_to_anchor=(1.05, 1))
    axes[1, 0].tick_params(axis='x', rotation=45)
    
    # 4. Tendencia de colores a lo largo del tiempo
    color_year = df.groupby(['Year', 'Color'])['Sales_Volume'].sum().unstack(fill_value=0)
    color_year[top_colors].plot(ax=axes[1, 1], marker='o', linewidth=2)
    axes[1, 1].set_title('Tendencia de Colores Populares (2010-2024)', fontweight='bold')
    axes[1, 1].set_xlabel('Año')
    axes[1, 1].set_ylabel('Volumen de Ventas')
    axes[1, 1].legend(title='Color', bbox_to_anchor=(1.05, 1))
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/08_customer_preferences.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/08_customer_preferences.png")


# ============================================================================
# 10. ANÁLISIS DE PRECIO Y DEMANDA
# ============================================================================

def analisis_precio_demanda(df):
    """Analiza la relación entre precio y demanda"""
    print("\n💰 ANÁLISIS DE PRECIO Y DEMANDA")
    print("=" * 80)
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Curva de demanda: Precio vs Volumen
    precio_bins = pd.cut(df['Price_USD'], bins=20)
    demanda = df.groupby(precio_bins)['Sales_Volume'].sum()
    precio_medio = df.groupby(precio_bins)['Price_USD'].mean()
    
    axes[0, 0].scatter(precio_medio, demanda, s=100, alpha=0.6)
    axes[0, 0].set_title('Curva de Demanda: Precio vs Volumen', fontweight='bold')
    axes[0, 0].set_xlabel('Precio Promedio (USD)')
    axes[0, 0].set_ylabel('Volumen de Ventas')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Scatter detallado Precio vs Ventas
    axes[0, 1].scatter(df['Price_USD'], df['Sales_Volume'], alpha=0.3, s=20)
    axes[0, 1].set_title('Dispersión: Precio vs Volumen de Ventas', fontweight='bold')
    axes[0, 1].set_xlabel('Precio (USD)')
    axes[0, 1].set_ylabel('Volumen de Ventas')
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Distribución de precios por categoría
    if 'Price_Category' in df.columns:
        df.boxplot(column='Price_USD', by='Price_Category', ax=axes[1, 0])
        axes[1, 0].set_title('Distribución de Precios por Categoría', fontweight='bold')
        axes[1, 0].set_xlabel('Categoría de Precio')
        axes[1, 0].set_ylabel('Precio (USD)')
        plt.sca(axes[1, 0])
        plt.xticks(rotation=0)
    
    # 4. Volumen por categoría de precio
    if 'Price_Category' in df.columns:
        categoria_ventas = df.groupby('Price_Category')['Sales_Volume'].sum()
        categoria_ventas.plot(kind='bar', ax=axes[1, 1], color='orange')
        axes[1, 1].set_title('Volumen de Ventas por Categoría de Precio', fontweight='bold')
        axes[1, 1].set_xlabel('Categoría de Precio')
        axes[1, 1].set_ylabel('Volumen de Ventas')
        axes[1, 1].tick_params(axis='x', rotation=0)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/09_price_demand_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/09_price_demand_analysis.png")
    
    # Calcular elasticidad precio-demanda
    try:
        x = df['Price_USD'].values.reshape(-1, 1)
        y = df['Sales_Volume'].values
        mask = ~np.isnan(x.flatten()) & ~np.isnan(y)
        x_clean = x[mask].reshape(-1, 1)
        y_clean = y[mask]
        
        model = LinearRegression()
        model.fit(x_clean, y_clean)
        elasticity = model.coef_[0]
        
        print(f"\n📊 Elasticidad Precio-Demanda: {elasticity:.6f}")
        if elasticity < 0:
            print("  → Relación negativa: A mayor precio, menor demanda (típico)")
        else:
            print("  → Relación positiva: Posible efecto de bienes de lujo")
    except:
        print("  No se pudo calcular la elasticidad")


# ============================================================================
# 11. SEGMENTACIÓN DE MERCADO (CLUSTERING)
# ============================================================================

def segmentacion_mercado(df):
    """Segmenta el mercado usando K-Means clustering"""
    print("\n🧩 SEGMENTACIÓN DE MERCADO (K-MEANS)")
    print("=" * 80)
    
    # Preparar datos para clustering
    features = ['Price_USD', 'Engine_Size_L', 'Mileage_KM', 'Sales_Volume']
    df_cluster = df[features].dropna()
    
    # Normalizar datos
    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df_cluster)
    
    # K-Means con 3 clusters (Económico, Medio, Premium)
    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(df_scaled)
    
    df_cluster['Cluster'] = clusters
    
    # Estadísticas por cluster
    print("\n📊 Características de cada Segmento:")
    cluster_stats = df_cluster.groupby('Cluster')[features].mean()
    cluster_stats['Count'] = df_cluster.groupby('Cluster').size()
    print(cluster_stats)
    
    # Visualización
    fig = plt.figure(figsize=(16, 10))
    
    # 1. PCA para visualización 2D
    ax1 = plt.subplot(2, 2, 1)
    pca = PCA(n_components=2)
    df_pca = pca.fit_transform(df_scaled)
    
    scatter = ax1.scatter(df_pca[:, 0], df_pca[:, 1], c=clusters, 
                         cmap='viridis', alpha=0.6, s=50)
    ax1.set_title('Segmentación de Mercado (PCA 2D)', fontweight='bold')
    ax1.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%})')
    ax1.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%})')
    plt.colorbar(scatter, ax=ax1, label='Cluster')
    
    # 2. Precio vs Motor por cluster
    ax2 = plt.subplot(2, 2, 2)
    for cluster in range(3):
        cluster_data = df_cluster[df_cluster['Cluster'] == cluster]
        ax2.scatter(cluster_data['Engine_Size_L'], cluster_data['Price_USD'],
                   label=f'Segmento {cluster}', alpha=0.6, s=50)
    ax2.set_title('Segmentos: Motor vs Precio', fontweight='bold')
    ax2.set_xlabel('Tamaño del Motor (L)')
    ax2.set_ylabel('Precio (USD)')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # 3. Distribución de clusters
    ax3 = plt.subplot(2, 2, 3)
    cluster_counts = df_cluster['Cluster'].value_counts().sort_index()
    cluster_counts.plot(kind='bar', ax=ax3, color=['green', 'blue', 'red'])
    ax3.set_title('Distribución de Vehículos por Segmento', fontweight='bold')
    ax3.set_xlabel('Segmento')
    ax3.set_ylabel('Número de Vehículos')
    ax3.tick_params(axis='x', rotation=0)
    
    # 4. Características promedio por cluster
    ax4 = plt.subplot(2, 2, 4)
    cluster_stats[features].T.plot(kind='bar', ax=ax4, width=0.8)
    ax4.set_title('Características Promedio por Segmento', fontweight='bold')
    ax4.set_ylabel('Valor Promedio')
    ax4.legend(title='Segmento', labels=['Seg 0', 'Seg 1', 'Seg 2'])
    ax4.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/10_market_segmentation.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/10_market_segmentation.png")


# ============================================================================
# 12. ANÁLISIS DE DEPRECIACIÓN
# ============================================================================

def analisis_depreciacion(df):
    """Analiza la depreciación de vehículos"""
    print("\n📉 ANÁLISIS DE DEPRECIACIÓN")
    print("=" * 80)
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 1. Kilometraje vs Precio (todos los modelos)
    axes[0, 0].scatter(df['Mileage_KM'], df['Price_USD'], alpha=0.3, s=20)
    axes[0, 0].set_title('Depreciación General: Kilometraje vs Precio', fontweight='bold')
    axes[0, 0].set_xlabel('Kilometraje (KM)')
    axes[0, 0].set_ylabel('Precio (USD)')
    axes[0, 0].grid(True, alpha=0.3)
    
    # 2. Depreciación por tipo de combustible
    for fuel in df['Fuel_Type'].unique()[:4]:  # Top 4 tipos
        fuel_data = df[df['Fuel_Type'] == fuel]
        axes[0, 1].scatter(fuel_data['Mileage_KM'], fuel_data['Price_USD'],
                          label=fuel, alpha=0.5, s=30)
    axes[0, 1].set_title('Depreciación por Tipo de Combustible', fontweight='bold')
    axes[0, 1].set_xlabel('Kilometraje (KM)')
    axes[0, 1].set_ylabel('Precio (USD)')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Edad vs Precio
    if 'Vehicle_Age' in df.columns:
        axes[1, 0].scatter(df['Vehicle_Age'], df['Price_USD'], alpha=0.3, s=20)
        axes[1, 0].set_title('Depreciación por Edad del Vehículo', fontweight='bold')
        axes[1, 0].set_xlabel('Edad del Vehículo (años)')
        axes[1, 0].set_ylabel('Precio (USD)')
        axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Tasa de depreciación por modelo (top 10)
    top_models = df.groupby('Model')['Sales_Volume'].sum().nlargest(10).index
    depreciation_rates = []
    
    for model in top_models:
        model_data = df[df['Model'] == model]
        if len(model_data) > 10:
            corr, _ = pearsonr(model_data['Mileage_KM'].dropna(), 
                              model_data['Price_USD'].dropna())
            depreciation_rates.append({'Model': model, 'Correlation': corr})
    
    if depreciation_rates:
        dep_df = pd.DataFrame(depreciation_rates).set_index('Model')
        dep_df.plot(kind='barh', ax=axes[1, 1], legend=False, color='crimson')
        axes[1, 1].set_title('Tasa de Depreciación (Top 10 Modelos)', fontweight='bold')
        axes[1, 1].set_xlabel('Correlación Kilometraje-Precio')
        axes[1, 1].axvline(x=0, color='black', linestyle='--', linewidth=1)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/11_depreciation_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/11_depreciation_analysis.png")


# ============================================================================
# 13. MACHINE LEARNING - PREDICCIÓN DE PRECIOS
# ============================================================================

def prediccion_precios(df):
    """Predice precios usando modelos de ML"""
    print("\n🤖 MACHINE LEARNING - PREDICCIÓN DE PRECIOS")
    print("=" * 80)
    
    # Preparar datos
    df_ml = df.copy()
    
    # Seleccionar features y target
    features = ['Year', 'Engine_Size_L', 'Mileage_KM', 'Sales_Volume']
    target = 'Price_USD'
    
    # Codificar variables categóricas
    le_model = LabelEncoder()
    le_region = LabelEncoder()
    le_fuel = LabelEncoder()
    le_trans = LabelEncoder()
    
    df_ml['Model_Encoded'] = le_model.fit_transform(df_ml['Model'])
    df_ml['Region_Encoded'] = le_region.fit_transform(df_ml['Region'])
    df_ml['Fuel_Encoded'] = le_fuel.fit_transform(df_ml['Fuel_Type'])
    df_ml['Trans_Encoded'] = le_trans.fit_transform(df_ml['Transmission'])
    
    features_full = features + ['Model_Encoded', 'Region_Encoded', 'Fuel_Encoded', 'Trans_Encoded']
    
    # Preparar X e y
    X = df_ml[features_full].dropna()
    y = df_ml.loc[X.index, target]
    
    # Split train/test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Normalizar
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Entrenar modelos
    models = {
        'Linear Regression': LinearRegression(),
        'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    }
    
    results = {}
    
    print("\n📊 Resultados de Modelos de Predicción:")
    print("-" * 60)
    
    for name, model in models.items():
        # Entrenar
        if name == 'Linear Regression':
            model.fit(X_train_scaled, y_train)
            y_pred = model.predict(X_test_scaled)
        else:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
        
        # Métricas
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2 = r2_score(y_test, y_pred)
        
        results[name] = {'MAE': mae, 'RMSE': rmse, 'R2': r2, 'predictions': y_pred}
        
        print(f"\n{name}:")
        print(f"  MAE:  ${mae:,.2f}")
        print(f"  RMSE: ${rmse:,.2f}")
        print(f"  R²:   {r2:.4f}")
    
    # Visualización
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    for idx, (name, res) in enumerate(results.items()):
        axes[idx].scatter(y_test, res['predictions'], alpha=0.5, s=20)
        axes[idx].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
                       'r--', lw=2, label='Predicción Perfecta')
        axes[idx].set_title(f'{name}\nR² = {res["R2"]:.4f}', fontweight='bold')
        axes[idx].set_xlabel('Precio Real (USD)')
        axes[idx].set_ylabel('Precio Predicho (USD)')
        axes[idx].legend()
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('BMW/figures/12_ml_price_prediction.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("\n✓ Gráfico guardado: figures/12_ml_price_prediction.png")
    
    return results


# ============================================================================
# 14. PREDICCIÓN DE VENTAS
# ============================================================================

def prediccion_ventas(df):
    """Predice volumen de ventas usando ML"""
    print("\n🤖 MACHINE LEARNING - PREDICCIÓN DE VENTAS")
    print("=" * 80)
    
    # Preparar datos
    df_ml = df.copy()
    
    # Codificar variables categóricas
    le_model = LabelEncoder()
    le_region = LabelEncoder()
    le_fuel = LabelEncoder()
    le_trans = LabelEncoder()
    le_color = LabelEncoder()
    
    df_ml['Model_Encoded'] = le_model.fit_transform(df_ml['Model'])
    df_ml['Region_Encoded'] = le_region.fit_transform(df_ml['Region'])
    df_ml['Fuel_Encoded'] = le_fuel.fit_transform(df_ml['Fuel_Type'])
    df_ml['Trans_Encoded'] = le_trans.fit_transform(df_ml['Transmission'])
    df_ml['Color_Encoded'] = le_color.fit_transform(df_ml['Color'])
    
    features = ['Year', 'Price_USD', 'Engine_Size_L', 'Mileage_KM',
                'Model_Encoded', 'Region_Encoded', 'Fuel_Encoded', 
                'Trans_Encoded', 'Color_Encoded']
    target = 'Sales_Volume'
    
    # Preparar X e y
    X = df_ml[features].dropna()
    y = df_ml.loc[X.index, target]
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Modelo
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    # Métricas
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    
    print(f"\n📊 Resultados del Modelo de Predicción de Ventas:")
    print(f"  MAE:  {mae:,.2f} unidades")
    print(f"  RMSE: {rmse:,.2f} unidades")
    print(f"  R²:   {r2:.4f}")
    
    # Feature Importance
    feature_importance = pd.DataFrame({
        'Feature': features,
        'Importance': model.feature_importances_
    }).sort_values('Importance', ascending=False)
    
    print("\n📊 Importancia de Variables:")
    print(feature_importance)
    
    # Visualización
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # 1. Predicciones vs Real
    axes[0].scatter(y_test, y_pred, alpha=0.5, s=20)
    axes[0].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
                 'r--', lw=2, label='Predicción Perfecta')
    axes[0].set_title(f'Predicción de Ventas\nR² = {r2:.4f}', fontweight='bold')
    axes[0].set_xlabel('Ventas Reales')
    axes[0].set_ylabel('Ventas Predichas')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # 2. Feature Importance
    feature_importance.head(10).plot(x='Feature', y='Importance', kind='barh', 
                                     ax=axes[1], legend=False, color='teal')
    axes[1].set_title('Top 10 Variables Más Importantes', fontweight='bold')
    axes[1].set_xlabel('Importancia')
    axes[1].invert_yaxis()
    
    plt.tight_layout()
    plt.savefig('BMW/figures/13_ml_sales_prediction.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/13_ml_sales_prediction.png")


# ============================================================================
# 15. ANÁLISIS PCA (COMPONENTES PRINCIPALES)
# ============================================================================

def analisis_pca(df):
    """Análisis de Componentes Principales"""
    print("\n🧬 ANÁLISIS DE COMPONENTES PRINCIPALES (PCA)")
    print("=" * 80)
    
    # Seleccionar variables numéricas
    numeric_cols = ['Price_USD', 'Engine_Size_L', 'Mileage_KM', 'Sales_Volume', 'Year']
    df_pca = df[numeric_cols].dropna()
    
    # Normalizar
    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df_pca)
    
    # PCA
    pca = PCA()
    pca_result = pca.fit_transform(df_scaled)
    
    # Varianza explicada
    explained_var = pca.explained_variance_ratio_
    cumulative_var = np.cumsum(explained_var)
    
    print(f"\n📊 Varianza Explicada por Componente:")
    for i, (var, cum_var) in enumerate(zip(explained_var, cumulative_var)):
        print(f"  PC{i+1}: {var:.4f} ({var*100:.2f}%) - Acumulada: {cum_var*100:.2f}%")
    
    # Visualización
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # 1. Varianza explicada
    axes[0].bar(range(1, len(explained_var)+1), explained_var, alpha=0.7, color='skyblue')
    axes[0].plot(range(1, len(cumulative_var)+1), cumulative_var, marker='o', 
                color='red', linewidth=2, markersize=8, label='Acumulada')
    axes[0].set_title('Varianza Explicada por Componente', fontweight='bold')
    axes[0].set_xlabel('Componente Principal')
    axes[0].set_ylabel('Varianza Explicada')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # 2. Biplot (PC1 vs PC2)
    axes[1].scatter(pca_result[:, 0], pca_result[:, 1], alpha=0.3, s=20)
    axes[1].set_title('PCA: Primeros Dos Componentes', fontweight='bold')
    axes[1].set_xlabel(f'PC1 ({explained_var[0]*100:.2f}%)')
    axes[1].set_ylabel(f'PC2 ({explained_var[1]*100:.2f}%)')
    axes[1].grid(True, alpha=0.3)
    
    # Añadir vectores de variables
    loadings = pca.components_[:2].T * np.sqrt(pca.explained_variance_[:2])
    for i, var in enumerate(numeric_cols):
        axes[1].arrow(0, 0, loadings[i, 0]*3, loadings[i, 1]*3, 
                     head_width=0.1, head_length=0.1, fc='red', ec='red')
        axes[1].text(loadings[i, 0]*3.5, loadings[i, 1]*3.5, var, 
                    fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('BMW/figures/14_pca_analysis.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("✓ Gráfico guardado: figures/14_pca_analysis.png")


# ============================================================================
# 16. GENERACIÓN DE INFORME FINAL
# ============================================================================

def generar_informe_final(df, resultados_ml=None):
    """Genera un informe resumen en formato texto y HTML"""
    print("\n📄 GENERANDO INFORME FINAL")
    print("=" * 80)
    
    # Crear informe de texto
    informe = []
    informe.append("=" * 80)
    informe.append("INFORME DE ANÁLISIS DE VENTAS BMW (2010-2024)")
    informe.append("=" * 80)
    informe.append(f"\nFecha de generación: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    informe.append(f"\n{'='*80}\n")
    
    # 1. RESUMEN EJECUTIVO
    informe.append("1. RESUMEN EJECUTIVO")
    informe.append("-" * 80)
    informe.append(f"Total de registros analizados: {len(df):,}")
    informe.append(f"Período de análisis: 2010-2024")
    informe.append(f"Regiones analizadas: {df['Region'].nunique()}")
    informe.append(f"Modelos únicos: {df['Model'].nunique()}")
    informe.append(f"\n")
    
    # 2. TOP 5 MODELOS MÁS VENDIDOS
    informe.append("2. TOP 5 MODELOS MÁS VENDIDOS")
    informe.append("-" * 80)
    top_models = df.groupby('Model')['Sales_Volume'].sum().nlargest(5)
    for idx, (model, ventas) in enumerate(top_models.items(), 1):
        informe.append(f"{idx}. {model}: {ventas:,.0f} unidades")
    informe.append("\n")
    
    # 3. VENTAS POR REGIÓN
    informe.append("3. ANÁLISIS POR REGIÓN")
    informe.append("-" * 80)
    ventas_region = df.groupby('Region')['Sales_Volume'].sum().sort_values(ascending=False)
    for region, ventas in ventas_region.items():
        porcentaje = (ventas / ventas_region.sum()) * 100
        informe.append(f"{region}: {ventas:,.0f} unidades ({porcentaje:.1f}%)")
    informe.append("\n")
    
    # 4. TIPOS DE COMBUSTIBLE
    informe.append("4. DISTRIBUCIÓN DE COMBUSTIBLE")
    informe.append("-" * 80)
    fuel_dist = df.groupby('Fuel_Type')['Sales_Volume'].sum().sort_values(ascending=False)
    for fuel, ventas in fuel_dist.items():
        porcentaje = (ventas / fuel_dist.sum()) * 100
        informe.append(f"{fuel}: {ventas:,.0f} unidades ({porcentaje:.1f}%)")
    informe.append("\n")
    
    # 5. TENDENCIAS DE PRECIO
    informe.append("5. ANÁLISIS DE PRECIOS")
    informe.append("-" * 80)
    informe.append(f"Precio promedio global: ${df['Price_USD'].mean():,.2f}")
    informe.append(f"Precio mínimo: ${df['Price_USD'].min():,.2f}")
    informe.append(f"Precio máximo: ${df['Price_USD'].max():,.2f}")
    informe.append(f"Mediana de precios: ${df['Price_USD'].median():,.2f}")
    
    precio_año = df.groupby('Year')['Price_USD'].mean()
    cambio_precio = ((precio_año.iloc[-1] - precio_año.iloc[0]) / precio_año.iloc[0]) * 100
    informe.append(f"Cambio de precio 2010-2024: {cambio_precio:+.1f}%")
    informe.append("\n")
    
    # 6. COLORES MÁS POPULARES
    informe.append("6. TOP 5 COLORES MÁS POPULARES")
    informe.append("-" * 80)
    top_colors = df.groupby('Color')['Sales_Volume'].sum().nlargest(5)
    for idx, (color, ventas) in enumerate(top_colors.items(), 1):
        informe.append(f"{idx}. {color}: {ventas:,.0f} unidades")
    informe.append("\n")
    
    # 7. TENDENCIA TEMPORAL
    informe.append("7. TENDENCIAS TEMPORALES")
    informe.append("-" * 80)
    ventas_año = df.groupby('Year')['Sales_Volume'].sum()
    mejor_año = ventas_año.idxmax()
    peor_año = ventas_año.idxmin()
    informe.append(f"Mejor año de ventas: {mejor_año} ({ventas_año[mejor_año]:,.0f} unidades)")
    informe.append(f"Peor año de ventas: {peor_año} ({ventas_año[peor_año]:,.0f} unidades)")
    
    cambio_ventas = ((ventas_año.iloc[-1] - ventas_año.iloc[0]) / ventas_año.iloc[0]) * 100
    informe.append(f"Cambio en ventas 2010-2024: {cambio_ventas:+.1f}%")
    informe.append("\n")
    
    # 8. CARACTERÍSTICAS TÉCNICAS
    informe.append("8. CARACTERÍSTICAS TÉCNICAS PROMEDIO")
    informe.append("-" * 80)
    informe.append(f"Tamaño de motor promedio: {df['Engine_Size_L'].mean():.2f}L")
    informe.append(f"Kilometraje promedio: {df['Mileage_KM'].mean():,.0f} KM")
    informe.append("\n")
    
    # 9. RESULTADOS DE MACHINE LEARNING
    if resultados_ml:
        informe.append("9. RESULTADOS DE MODELOS PREDICTIVOS")
        informe.append("-" * 80)
        for modelo, metricas in resultados_ml.items():
            informe.append(f"\n{modelo}:")
            informe.append(f"  R² Score: {metricas['R2']:.4f}")
            informe.append(f"  MAE: ${metricas['MAE']:,.2f}")
            informe.append(f"  RMSE: ${metricas['RMSE']:,.2f}")
        informe.append("\n")
    
    # 10. CONCLUSIONES
    informe.append("10. CONCLUSIONES CLAVE")
    informe.append("-" * 80)
    informe.append(f"• El modelo más vendido es {top_models.index[0]} con {top_models.iloc[0]:,.0f} unidades")
    informe.append(f"• La región con mayor volumen es {ventas_region.index[0]} ({(ventas_region.iloc[0]/ventas_region.sum()*100):.1f}%)")
    informe.append(f"• El tipo de combustible dominante es {fuel_dist.index[0]} ({(fuel_dist.iloc[0]/fuel_dist.sum()*100):.1f}%)")
    informe.append(f"• El precio promedio ha cambiado {cambio_precio:+.1f}% en el período analizado")
    informe.append(f"• Las ventas han experimentado un cambio de {cambio_ventas:+.1f}% desde 2010")
    informe.append("\n")
    
    informe.append("=" * 80)
    informe.append("FIN DEL INFORME")
    informe.append("=" * 80)
    
    # Guardar informe
    informe_texto = "\n".join(informe)
    
    with open('BMW/reports/BMW_Sales_Report.txt', 'w', encoding='utf-8') as f:
        f.write(informe_texto)
    
    print("✓ Informe de texto guardado: reports/BMW_Sales_Report.txt")
    
    # Generar HTML simple
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Informe de Análisis BMW</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }}
            h1 {{
                color: #1a73e8;
                border-bottom: 3px solid #1a73e8;
                padding-bottom: 10px;
            }}
            h2 {{
                color: #333;
                margin-top: 30px;
                border-left: 5px solid #1a73e8;
                padding-left: 10px;
            }}
            .section {{
                background-color: white;
                padding: 20px;
                margin: 20px 0;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }}
            .metric {{
                display: inline-block;
                margin: 10px 20px 10px 0;
                padding: 15px;
                background-color: #e8f0fe;
                border-radius: 5px;
            }}
            .metric-value {{
                font-size: 24px;
                font-weight: bold;
                color: #1a73e8;
            }}
            .metric-label {{
                font-size: 12px;
                color: #666;
            }}
            ul {{
                line-height: 1.8;
            }}
            .footer {{
                margin-top: 50px;
                text-align: center;
                color: #666;
                font-size: 12px;
            }}
        </style>
    </head>
    <body>
        <h1>📊 INFORME DE ANÁLISIS DE VENTAS BMW (2010-2024)</h1>
        <p><strong>Fecha de generación:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <div class="section">
            <h2>📈 Métricas Generales</h2>
            <div class="metric">
                <div class="metric-value">{len(df):,}</div>
                <div class="metric-label">Registros Analizados</div>
            </div>
            <div class="metric">
                <div class="metric-value">{df['Model'].nunique()}</div>
                <div class="metric-label">Modelos Únicos</div>
            </div>
            <div class="metric">
                <div class="metric-value">{df['Region'].nunique()}</div>
                <div class="metric-label">Regiones</div>
            </div>
            <div class="metric">
                <div class="metric-value">${df['Price_USD'].mean():,.0f}</div>
                <div class="metric-label">Precio Promedio</div>
            </div>
        </div>
        
        <div class="section">
            <h2>🏆 Top 5 Modelos Más Vendidos</h2>
            <ul>
    """
    
    for idx, (model, ventas) in enumerate(top_models.items(), 1):
        html_content += f"<li><strong>{model}:</strong> {ventas:,.0f} unidades</li>\n"
    
    html_content += """
            </ul>
        </div>
        
        <div class="section">
            <h2>🌍 Distribución por Región</h2>
            <ul>
    """
    
    for region, ventas in ventas_region.items():
        porcentaje = (ventas / ventas_region.sum()) * 100
        html_content += f"<li><strong>{region}:</strong> {ventas:,.0f} unidades ({porcentaje:.1f}%)</li>\n"
    
    html_content += f"""
            </ul>
        </div>
        
        <div class="section">
            <h2>⚡ Tipos de Combustible</h2>
            <ul>
    """
    
    for fuel, ventas in fuel_dist.items():
        porcentaje = (ventas / fuel_dist.sum()) * 100
        html_content += f"<li><strong>{fuel}:</strong> {ventas:,.0f} unidades ({porcentaje:.1f}%)</li>\n"
    
    html_content += f"""
            </ul>
        </div>
        
        <div class="section">
            <h2>🎨 Colores Más Populares</h2>
            <ul>
    """
    
    for idx, (color, ventas) in enumerate(top_colors.items(), 1):
        html_content += f"<li><strong>{color}:</strong> {ventas:,.0f} unidades</li>\n"
    
    html_content += f"""
            </ul>
        </div>
        
        <div class="section">
            <h2>💡 Conclusiones Clave</h2>
            <ul>
                <li>El modelo más vendido es <strong>{top_models.index[0]}</strong> con {top_models.iloc[0]:,.0f} unidades</li>
                <li>La región con mayor volumen es <strong>{ventas_region.index[0]}</strong> ({(ventas_region.iloc[0]/ventas_region.sum()*100):.1f}%)</li>
                <li>El tipo de combustible dominante es <strong>{fuel_dist.index[0]}</strong> ({(fuel_dist.iloc[0]/fuel_dist.sum()*100):.1f}%)</li>
                <li>El precio promedio ha cambiado <strong>{cambio_precio:+.1f}%</strong> en el período analizado</li>
                <li>Las ventas han experimentado un cambio de <strong>{cambio_ventas:+.1f}%</strong> desde 2010</li>
            </ul>
        </div>
        
        <div class="footer">
            <p>Análisis Automatizado de Ventas BMW • Generado con Python</p>
        </div>
    </body>
    </html>
    """
    
    with open('BMW/reports/BMW_Sales_Report.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print("✓ Informe HTML guardado: reports/BMW_Sales_Report.html")
    print("\n" + informe_texto)


# ============================================================================
# 17. FUNCIÓN PRINCIPAL (MAIN)
# ============================================================================

def main():
    """Función principal que ejecuta todo el análisis"""
    print("\n")
    print("="*80)
    print(" "*20 + "ANÁLISIS DE VENTAS BMW (2010-2024)")
    print("="*80)
    print("\n")
    
    # 1. Configuración inicial
    crear_estructura_directorios()
    
    # 2. Cargar datos
    filepath = 'BMW\Dataset.csv'
    
    try:
        df = cargar_y_explorar_datos(filepath)
    except FileNotFoundError:
        print(f"\n❌ ERROR: No se encontró el archivo '{filepath}'")
        print("   Por favor, asegúrate de que el archivo esté en el directorio actual.")
        return
    
    # 3. Limpieza de datos
    df_clean = limpiar_datos(df)
    
    # Guardar dataset limpio
    df_clean.to_csv('BMW/data_cleaned/BMW_cleaned.csv', index=False)
    print("\n✓ Dataset limpio guardado: data_cleaned/BMW_cleaned.csv")
    
    # 4. Análisis Descriptivo
    analisis_descriptivo(df_clean)
    detectar_outliers(df_clean)
    visualizar_distribuciones(df_clean)
    
    # 5. Análisis de Correlaciones
    analisis_correlaciones(df_clean)
    
    # 6. Análisis Temporal
    analisis_temporal(df_clean)
    
    # 7. Análisis Geográfico
    analisis_geografico(df_clean)
    
    # 8. Análisis por Modelo
    analisis_por_modelo(df_clean)
    
    # 9. Análisis Técnico
    analisis_tecnico(df_clean)
    
    # 10. Análisis de Preferencias
    analisis_preferencias_cliente(df_clean)
    
    # 11. Análisis Precio-Demanda
    analisis_precio_demanda(df_clean)
    
    # 12. Segmentación de Mercado
    segmentacion_mercado(df_clean)
    
    # 13. Análisis de Depreciación
    analisis_depreciacion(df_clean)
    
    # 14. PCA
    analisis_pca(df_clean)
    
    # 15. Machine Learning - Predicción de Precios
    resultados_ml = prediccion_precios(df_clean)
    
    # 16. Machine Learning - Predicción de Ventas
    prediccion_ventas(df_clean)
    
    # 17. Generar Informe Final
    generar_informe_final(df_clean, resultados_ml)
    
    # Resumen final
    print("\n")
    print("="*80)
    print(" "*25 + "✅ ANÁLISIS COMPLETADO")
    print("="*80)
    print("\n📁 Archivos generados:")
    print("   • Dataset limpio: data_cleaned/BMW_cleaned.csv")
    print("   • Gráficos: figures/ (14 visualizaciones)")
    print("   • Informes: reports/BMW_Sales_Report.txt y .html")
    print("\n💡 Próximos pasos sugeridos:")
    print("   1. Revisar los gráficos en la carpeta 'figures/'")
    print("   2. Abrir el informe HTML en tu navegador")
    print("   3. Analizar las métricas de los modelos predictivos")
    print("   4. Considerar análisis adicionales según hallazgos")
    print("\n" + "="*80 + "\n")


# ============================================================================
# EJECUTAR ANÁLISIS
# ============================================================================

if __name__ == "__main__":
    main()