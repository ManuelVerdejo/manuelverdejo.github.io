
library(shiny)
library(bslib)
library(plotly)
library(gt)
library(targets)
library(shinycssloaders)

# Tema moderno
theme <- bs_theme(
  version = 5,
  bg = "#0a0e27",
  fg = "#e8eaed",
  primary = "#4285f4",
  base_font = font_google("Inter")
)

# UI
ui <- page_navbar(
  title = "🌍 Global Happiness Platform",
  theme = theme,
  
  nav_panel(
    "Dashboard",
    layout_columns(
      card(
        card_header("Métricas de Modelos"),
        gt_output("metrics_table")
      ),
      card(
        card_header("Comparación Visual"),
        plotOutput("comparison_plot", height = "400px")
      )
    )
  ),
  
  nav_panel(
    "Variable Importance",
    card(
      full_screen = TRUE,
      card_header("Importancia de Features"),
      plotOutput("importance_plot", height = "600px")
    )
  ),
  
  nav_panel(
    "Data Explorer",
    card(
      card_header("Datos Procesados"),
      DT::dataTableOutput("data_table")
    )
  )
)

# Server
server <- function(input, output, session) {
  
  # Cargar datos
  dashboard_data <- reactive({
    tar_read(dashboard_data)
  })
  
  output$metrics_table <- render_gt({
    dashboard_data()$metrics %>%
      gt() %>%
      fmt_number(columns = where(is.numeric), decimals = 4) %>%
      tab_header(title = "Performance de Modelos")
  })
  
  output$comparison_plot <- renderPlot({
    tar_read(plot_metrics)
  })
  
  output$importance_plot <- renderPlot({
    tar_read(plot_importance)
  })
  
  output$data_table <- DT::renderDataTable({
    dashboard_data()$data %>%
      select(country_code, year, happiness_score, gdp_pc, social_support, freedom) %>%
      DT::datatable(options = list(pageLength = 25))
  })
}

shinyApp(ui, server)

