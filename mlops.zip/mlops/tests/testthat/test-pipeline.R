
library(testthat)
library(targets)

test_that("Pipeline ejecuta sin errores", {
  expect_error(tar_make(callr_function = NULL), NA)
})

test_that("Datos integrados tienen estructura correcta", {
  data <- tar_read(data_integrated)
  
  expect_s3_class(data, "data.frame")
  expect_true("happiness_score" %in% names(data))
  expect_true(nrow(data) > 0)
  expect_true(all(!is.na(data$happiness_score)))
})

test_that("Modelos tienen rendimiento aceptable", {
  metrics <- tar_read(accuracy_metrics)
  
  expect_s3_class(metrics, "data.frame")
  expect_true(all(metrics$rmse < 1.0))  # RMSE razonable
  expect_true(all(metrics$rsq > 0.5))   # R² aceptable
})

test_that("Features de interacción se crean correctamente", {
  data <- tar_read(data_integrated)
  result <- create_interaction_features(data, "happiness_score", max_interactions = 5)
  
  expect_gt(ncol(result), ncol(data))
  expect_true(any(grepl("_x_", names(result))))
})

test_that("Detección de drift funciona", {
  ref_data <- tar_read(data_splits)$train
  cur_data <- tar_read(data_splits)$test
  
  drift_result <- detect_data_drift(ref_data, cur_data)
  
  expect_type(drift_result, "list")
  expect_true("drift_summary" %in% names(drift_result))
  expect_s3_class(drift_result$drift_summary, "data.frame")
})

test_that("Métricas de fairness están dentro de umbrales", {
  fairness <- tar_read(fairness_audit)
  
  expect_s3_class(fairness, "data.frame")
  expect_true(all(abs(fairness$bias) < 0.5))  # Sesgo aceptable
})