library(plumber)
library(targets)
library(tidymodels)

#* @apiTitle Global Happiness Prediction API
#* @apiDescription API para servir predicciones del modelo de felicidad global
#* @apiVersion 1.0.0

# Cargar modelo al iniciar
model_loaded <- tar_read(best_model_xai)

#* Healthcheck endpoint
#* @get /health
function() {
  list(
    status = "healthy",
    timestamp = Sys.time(),
    version = "1.0.0"
  )
}

#* Obtener predicción de felicidad
#* @param gdp_pc:numeric PIB per cápita
#* @param social_support:numeric Soporte social (0-1)
#* @param freedom:numeric Libertad (0-1)
#* @param corruption:numeric Percepción de corrupción (0-1)
#* @param life_exp:numeric Expectativa de vida
#* @post /predict
function(gdp_pc, social_support, freedom, corruption, life_exp) {
  
  # Validación de inputs
  if (any(is.na(c(gdp_pc, social_support, freedom, corruption, life_exp)))) {
    return(list(
      error = "Todos los parámetros son requeridos",
      status = 400
    ))
  }
  
  # Crear data frame de entrada
  input_data <- tibble(
    gdp_pc = as.numeric(gdp_pc),
    social_support = as.numeric(social_support),
    freedom = as.numeric(freedom),
    corruption = as.numeric(corruption),
    life_exp = as.numeric(life_exp)
  )
  
  # Realizar predicción
  prediction <- predict(model_loaded, input_data)
  
  list(
    happiness_score = round(prediction$.pred[1], 3),
    confidence_interval_95 = c(
      round(prediction$.pred[1] - 1.96 * 0.35, 3),
      round(prediction$.pred[1] + 1.96 * 0.35, 3)
    ),
    timestamp = Sys.time(),
    model_version = "v1.0.0"
  )
}

#* Predicción batch (múltiples países)
#* @param data:object JSON array con múltiples observaciones
#* @post /predict_batch
function(data) {
  
  # Parsear JSON
  input_df <- jsonlite::fromJSON(data)
  
  # Validar estructura
  required_cols <- c("gdp_pc", "social_support", "freedom", "corruption", "life_exp")
  if (!all(required_cols %in% names(input_df))) {
    return(list(
      error = paste("Columnas requeridas:", paste(required_cols, collapse = ", ")),
      status = 400
    ))
  }
  
  # Predicciones
  predictions <- predict(model_loaded, input_df)
  
  input_df %>%
    mutate(
      happiness_prediction = round(predictions$.pred, 3),
      timestamp = Sys.time()
    )
}

#* Obtener importancia de features
#* @get /feature_importance
function() {
  tar_read(var_importance) %>%
    as_tibble() %>%
    arrange(desc(dropout_loss)) %>%
    head(10)
}

#* Verificar fairness del modelo
#* @get /fairness_report
function() {
  tar_read(fairness_audit)
}

#* Obtener métricas del modelo
#* @get /metrics
function() {
  tar_read(accuracy_metrics) %>%
    filter(.model_desc == "ensemble_stack") %>%
    select(rmse, mae, rsq, mape)
}

# Para ejecutar:
# pr <- plumber::plumb("api.R")
# pr$run(host = "0.0.0.0", port = 8000)