
library(rsconnect)
library(config)

#' Deploy completo a producción
#' @param environment Ambiente (development, staging, production)
deploy_to_production <- function(environment = "production") {
  
  log_info(glue("Iniciando deployment a {environment}"))
  
  # Cargar configuración
  cfg <- config::get(config = environment)
  
  # 1. Ejecutar pipeline completo
  log_info("Ejecutando pipeline targets...")
  tar_make()
  
  # 2. Validar datos
  log_info("Validando datos...")
  validation <- validate_and_report(tar_read(data_integrated))
  
  if (!validation$passed) {
    stop("❌ Validación de datos falló. Deployment abortado.")
  }
  
  # 3. Verificar métricas del modelo
  log_info("Verificando métricas del modelo...")
  metrics <- tar_read(accuracy_metrics) %>%
    filter(.model_desc == "ensemble_stack")
  
  if (metrics$rmse > 0.5) {
    warning("⚠ RMSE por encima del umbral. Considerar reentrenamiento.")
  }
  
  # 4. Generar reportes
  log_info("Generando reportes...")
  quarto::quarto_render("reports/technical_report.qmd")
  
  # 5. Deploy de la aplicación Shiny
  log_info("Deploying Shiny app...")
  rsconnect::deployApp(
    appDir = ".",
    appName = cfg$app_name,
    server = cfg$server,
    account = cfg$account,
    forceUpdate = TRUE
  )
  
  # 6. Deploy de la API
  log_info("Deploying API...")
  rsconnect::deployAPI(
    api = "api.R",
    server = cfg$server,
    account = cfg$account
  )
  
  # 7. Notificar éxito
  send_alert_email(
    subject = glue("✓ Deployment exitoso a {environment}"),
    body = glue("
El sistema ha sido desplegado exitosamente a **{environment}**

**Métricas del modelo**:
- RMSE: {round(metrics$rmse, 4)}
- R²: {round(metrics$rsq, 4)}

**Aplicaciones desplegadas**:
- Dashboard: {cfg$dashboard_url}
- API: {cfg$api_url}

**Timestamp**: {Sys.time()}
    "),
    recipients = cfg$notification_emails
  )
  
  log_info(glue("✓ Deployment completado exitosamente a {environment}"))
  
  invisible(TRUE)
}

