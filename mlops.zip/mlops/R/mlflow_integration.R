library(mlflow)

#' Registrar experimento en MLflow
#' @param model_name Nombre del modelo
#' @param model Modelo entrenado
#' @param metrics Métricas del modelo
#' @param params Hiperparámetros
log_experiment_to_mlflow <- function(model_name, model, metrics, params) {
  
  # Iniciar run
  with(mlflow_start_run(), {
    
    # Log de parámetros
    mlflow_log_param("model_type", model_name)
    walk2(names(params), params, mlflow_log_param)
    
    # Log de métricas
    walk2(names(metrics), metrics, mlflow_log_metric)
    
    # Log del modelo
    mlflow_log_model(model, artifact_path = "model")
    
    # Log de artefactos adicionales
    if (file.exists("plots/feature_importance.png")) {
      mlflow_log_artifact("plots/feature_importance.png")
    }
    
    # Tags
    mlflow_set_tag("framework", "tidymodels")
    mlflow_set_tag("project", "happiness_prediction")
    mlflow_set_tag("environment", Sys.getenv("ENV", "development"))
    
    log_info(glue("Experimento registrado en MLflow: {model_name}"))
  })
}

#' Comparar múltiples experimentos
#' @param metric_name Métrica para comparar (e.g., "rmse")
#' @return Data frame con comparación
compare_mlflow_experiments <- function(metric_name = "rmse") {
  
  runs <- mlflow_search_runs()
  
  runs %>%
    select(run_id, start_time, contains(metric_name), contains("param")) %>%
    arrange(across(contains(metric_name)))
}