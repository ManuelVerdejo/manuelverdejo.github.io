library(pointblank)

#' Crear agente de validación para datos de felicidad
#' @param data Data frame a validar
#' @return Objeto pointblank agent
create_validation_agent <- function(data) {
  
  agent <- create_agent(
    tbl = data,
    tbl_name = "happiness_data",
    label = "Validación de datos de felicidad global"
  ) %>%
    
    # Validaciones de completitud
    col_exists(columns = vars(country_code, year, happiness_score)) %>%
    col_is_character(columns = vars(country_code)) %>%
    col_is_numeric(columns = vars(year, happiness_score)) %>%
    
    # Validaciones de rango
    col_vals_between(
      columns = vars(happiness_score),
      left = 0, right = 10,
      na_pass = FALSE
    ) %>%
    col_vals_between(
      columns = vars(year),
      left = 2000, right = 2030
    ) %>%
    
    # Validaciones de valores específicos
    col_vals_in_set(
      columns = vars(country_code),
      set = c("USA", "DEU", "JPN", "BRA", "IND", "ZAF", "GBR", "FRA", "CHN", "RUS")
    ) %>%
    
    # Validaciones de unicidad
    rows_distinct(columns = vars(country_code, year)) %>%
    
    # Validaciones de nulls
    col_vals_not_null(columns = vars(happiness_score)) %>%
    
    # Validaciones de distribución
    col_vals_gt(columns = vars(gdp_pc), value = 0, na_pass = TRUE) %>%
    col_vals_between(
      columns = vars(social_support, freedom, corruption),
      left = 0, right = 1,
      na_pass = TRUE
    )
  
  agent
}

#' Ejecutar validación y generar reporte
#' @param data Data frame a validar
#' @param output_path Ruta del reporte HTML
validate_and_report <- function(data, output_path = "reports/validation_report.html") {
  
  agent <- create_validation_agent(data)
  
  # Ejecutar validaciones
  agent_interrogated <- interrogate(agent)
  
  # Generar reporte
  get_agent_report(agent_interrogated, arrange_by = "severity") %>%
    export_report(filename = output_path)
  
  # Verificar si pasó todas las validaciones
  validation_passed <- all_passed(agent_interrogated)
  
  if (!validation_passed) {
    warning("⚠ Algunas validaciones fallaron. Revisar reporte en: ", output_path)
    
    # Enviar alerta
    send_alert_email(
      subject = "⚠ Fallo en Validación de Datos",
      body = glue("
Se detectaron problemas en la validación de datos:

**Reporte completo**: {output_path}

**Timestamp**: {Sys.time()}

Por favor revisar inmediatamente.
      "),
      recipients = c("data-team@example.com")
    )
  }
  
  return(output_path) 
  
}