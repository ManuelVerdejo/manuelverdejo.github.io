# monitoring.R (Versión Editada Sin Prometheus)

library(logger)
library(glue) # Necesario para las funciones de logging con variables
library(purrr) # Necesario para 'walk' si se usa en otro lado, pero aquí lo sustituiremos

# --------------------------------------------------------------------------
# Inicializar métricas (Ahora solo configura el logger)
# --------------------------------------------------------------------------
initialize_metrics <- function() {
  # Contadores, Histogramas y Gauges de Prometheus eliminados.
  # Solo configuramos el formato de logger.
  log_formatter(formatter_glue)
  log_info("Se desactiva el monitoreo avanzado de Prometheus. Usando solo logger para eventos.")
}

#' Predicción con monitoreo (Sustituido por Logging de Eventos)
#' @param model Modelo entrenado
#' @param new_data Datos nuevos
#' @return Predicciones con logging
predict_with_monitoring <- function(model, new_data) {
  
  start_time <- Sys.time()
  
  tryCatch({
    # Realizar predicción
    preds <- predict(model, new_data)
    
    # --- CÓDIGO DE PROMETHEUS ELIMINADO ---
    # prediction_counter$inc()
    # prediction_duration$observe(duration)
    # walk(preds$.pred, ~ prediction_value$observe(.x))
    # -------------------------------------
    
    # Registrar duración (usando logger)
    duration <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
    log_info(glue("PREDICCIÓN EXITOSA: {nrow(new_data)} obs. en {round(duration, 4)}s"))
    
    preds
    
  }, error = function(e) {
    # --- CÓDIGO DE PROMETHEUS ELIMINADO ---
    # error_counter$inc()
    # -------------------------------------
    
    # Log de error
    log_error(glue("ERROR PREDICCIÓN: {e$message}"))
    
    # Re-lanzar error
    stop(e)
  })
}

#' Actualizar métricas del modelo (Sustituido por Logging de Valor)
#' @param model_metrics Métricas calculadas
update_model_metrics <- function(model_metrics) {
  # Antes: model_rmse$set(model_metrics$rmse)
  log_info(glue("MÉTRICAS MODELO: RMSE actualizado a {model_metrics$rmse}"))
}

#' Calcular y actualizar drift score (Sustituido por Logging de Valor y Alertas)
#' @param reference_data Datos de referencia
#' @param current_data Datos actuales
update_drift_metrics <- function(reference_data, current_data) {
  
  # Asumiendo que detect_data_drift y send_alert_email existen
  drift_result <- detect_data_drift(reference_data, current_data)
  
  # Calcular score agregado (proporción de variables con drift)
  drift_score <- drift_result$drift_count / nrow(drift_result$drift_summary)
  
  # Antes: data_drift_score$set(drift_score)
  
  if (drift_score > 0.3) {
    log_warn(glue("⚠ Data drift detectado: {round(drift_score * 100, 1)}% de variables afectadas"))
    
    # Se mantiene la alerta por correo ya que no depende de Prometheus
    send_alert_email(
      subject = "⚠ Data Drift Detectado",
      body = glue("
Se ha detectado drift significativo en los datos:

**Drift Score**: {round(drift_score * 100, 1)}%
**Variables afectadas**: {drift_result$drift_count}/{nrow(drift_result$drift_summary)}

**Variables con drift severo**:
{paste(drift_result$severe_drift$variable, collapse = ', ')}

Se recomienda reentrenar el modelo.

**Timestamp**: {Sys.time()}
      "),
      recipients = c("mlops-team@example.com")
    )
  }
  
  log_info(glue("Drift metrics actualizadas: Score = {round(drift_score, 3)}"))
}

#' Función mock para simular el envío de un correo de alerta
#' @param subject Asunto del correo
#' @param body Cuerpo del correo
#' @param recipients Lista de destinatarios
send_alert_email <- function(subject, body, recipients) {
  
  # Registrar la alerta como una advertencia en la consola
  log_warn(glue("ALERTA DE SISTEMA: {subject}"))
  log_info(glue("Destinatarios simulados: {paste(recipients, collapse = ', ')}"))
  log_info("--- Contenido del Cuerpo ---")
  log_info(body)
  log_info("--------------------------")
  
  # Devolver TRUE para que el código no falle (es lo que espera la llamada)
  return(TRUE)
}

