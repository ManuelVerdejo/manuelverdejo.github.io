
# Funciones auxiliares para el proyecto

#' Calcular métricas personalizadas
calculate_custom_metrics <- function(predictions, actuals) {
  tibble(
    rmse = sqrt(mean((predictions - actuals)^2)),
    mae = mean(abs(predictions - actuals)),
    mape = mean(abs((predictions - actuals) / actuals)) * 100,
    rsq = cor(predictions, actuals)^2
  )
}

#' Crear features de interacción
create_interactions <- function(data, vars, target) {
  combn(vars, 2, function(pair) {
    new_col <- paste0(pair[1], "_x_", pair[2])
    data[[new_col]] <<- data[[pair[1]]] * data[[pair[2]]]
  })
  data
}

#' Validar datos de entrada
validate_input_data <- function(data) {
  required_cols <- c("happiness_score", "gdp_pc", "social_support")
  
  missing_cols <- setdiff(required_cols, names(data))
  
  if (length(missing_cols) > 0) {
    stop("Columnas faltantes: ", paste(missing_cols, collapse = ", "))
  }
  
  if (any(is.na(data$happiness_score))) {
    stop("El target no puede contener NAs")
  }
  
  invisible(TRUE)
}

# Función wrapper para DALEX que maneja la conversión a xgb.DMatrix
# Necesaria para que DALEX pueda interpretar el modelo XGBoost de 'tidymodels'.
yhat_xgboost <- function(model, new_data) {
  
  # Asegurar que el target no esté en los datos de entrada
  target_var <- "happiness_score"
  
  if (target_var %in% names(new_data)) {
    # Usamos select(-!!sym()) para quitar la columna 'happiness_score' 
    # si está presente (dplyr/tidyverse)
    new_data <- new_data %>% dplyr::select(-dplyr::all_of(target_var))
  }
  
  # Convertir a matriz (formato requerido por el motor de XGBoost)
  x_matrix <- as.matrix(new_data)
  
  # Predicción
  predictions <- predict(model, x_matrix)
  
  # Devolver un vector de predicciones (lo que DALEX espera)
  return(predictions)
}