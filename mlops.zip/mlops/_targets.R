
# ============================================================================
# PIPELINE TARGETS - PREDICCIÓN FELICIDAD GLOBAL
# Versión optimizada sin dependencias problemáticas
# ============================================================================
# Añade esto en _targets.R ANTES de library(targets) o tar_option_set()
options(targets.storage = "custom", targets.loader = "custom")
library(targets)
library(tarchetypes)
library(qs)  
library(tidyverse)
library(tidymodels)

# Configuración global
tar_option_set(
  packages = c(
    "tidyverse", "tidymodels", "arrow", "qs",
    "modeltime", "timetk", "forecast",
    "xgboost", "ranger", "glmnet",
    "plotly", "echarts4r", "ggplot2",
    "shiny", "bslib", "gt",
    "mlflow", "DALEX", "iml" 
  ),
  format = "qs",
  memory = "transient",
  garbage_collection = TRUE
)

# Funciones auxiliares
source("R/functions.R")
source("R/data_validation.R")    # ¡AÑADIR!
source("R/mlflow_integration.R") # ¡AÑADIR!
source("R/monitoring.R")         # ¡AÑADIR!
# Pipeline
list(
  # -------------------------------------------------------------------------
  # DATOS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = raw_data,
    command = {
      # Datos simulados para demostración
      set.seed(123)
      expand_grid(
        country_code = c("USA", "DEU", "JPN", "BRA", "IND", "ZAF", "CHN", "GBR", "FRA", "CAN"),
        year = 2005:2024
      ) %>%
        mutate(
          happiness_score = 5 + 2 * rnorm(n()),
          gdp_pc = exp(rnorm(n(), 10, 1)),
          social_support = plogis(rnorm(n(), 0, 1)),
          freedom = plogis(rnorm(n(), 0, 1)),
          generosity = rnorm(n(), 0, 0.3),
          corruption = runif(n(), 0.1, 0.9),
          life_exp = 60 + 20 * runif(n()),
          gini = runif(n(), 0.25, 0.6),
          unemployment = rexp(n(), 0.1),
          co2_pc = rexp(n(), 0.5),
          temp_anomaly = rnorm(n(), 0.8, 0.5),
          gdelt_tone = rnorm(n(), 0, 3)
        ) %>%
        arrange(country_code, year)
    }
  ),
  
  # Feature engineering
  tar_target(
    name = engineered_data,
    command = {
      raw_data %>%
        group_by(country_code) %>%
        mutate(
          happiness_lag1 = lag(happiness_score, 1),
          gdp_growth = (gdp_pc - lag(gdp_pc, 1)) / lag(gdp_pc, 1),
          socio_climate_vuln = temp_anomaly * corruption,
          affect_positive = pmin(pmax((gdelt_tone + 5) / 10, 0), 1)
        ) %>%
        ungroup() %>%
        drop_na(happiness_score)
    }
  ),
  # VALIDACIÓN DE DATOS (pointblank)
  tar_target(
    name = validation_report,
    command = validate_and_report(engineered_data),
    # CAMBIAR 'file' a 'null'
    format = "file", 
    # Asegura que el target se ejecute siempre para revisar los datos
    cue = tar_cue(mode = "always")
  ),
  # Splits
  tar_target(
    name = data_splits,
    command = {
      initial_split(engineered_data, prop = 0.8, strata = happiness_score)
    }
  ),
  
  # -------------------------------------------------------------------------
  # RECIPES
  # -------------------------------------------------------------------------
  
  tar_target(
    name = recipe_base,
    command = {
      training(data_splits) %>%
        recipe(happiness_score ~ .) %>%
        update_role(country_code, year, new_role = "id") %>%
        step_impute_median(all_numeric_predictors()) %>%
        step_normalize(all_numeric_predictors()) %>%
        step_zv(all_predictors())
    }
  ),
  
  tar_target(
    name = recipe_pca,
    command = {
      training(data_splits) %>%
        recipe(happiness_score ~ .) %>%
        update_role(country_code, year, new_role = "id") %>%
        step_impute_median(all_numeric_predictors()) %>%
        step_normalize(all_numeric_predictors()) %>%
        step_pca(gdp_pc, life_exp, social_support, threshold = 0.95) %>%
        step_zv(all_predictors())
    }
  ),
  
  # -------------------------------------------------------------------------
  # MODELOS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = model_xgboost,
    command = {
      boost_tree(trees = 500, tree_depth = 6, learn_rate = 0.01) %>%
        set_engine("xgboost") %>%
        set_mode("regression")
    }
  ),
  
  tar_target(
    name = model_rf,
    command = {
      rand_forest(trees = 500, min_n = 5) %>%
        set_engine("ranger", importance = "permutation") %>%
        set_mode("regression")
    }
  ),
  
  tar_target(
    name = model_glmnet,
    command = {
      linear_reg(penalty = 0.01, mixture = 0.5) %>%
        set_engine("glmnet")
    }
  ),
  
  # -------------------------------------------------------------------------
  # ENTRENAMIENTO
  # -------------------------------------------------------------------------
  
  tar_target(
    name = fitted_xgboost,
    command = {
      workflow() %>%
        add_model(model_xgboost) %>%
        add_recipe(recipe_base) %>%
        fit(training(data_splits))
    }
  ),
  
  tar_target(
    name = fitted_rf,
    command = {
      workflow() %>%
        add_model(model_rf) %>%
        add_recipe(recipe_pca) %>%
        fit(training(data_splits))
    }
  ),
  
  tar_target(
    name = fitted_glmnet,
    command = {
      workflow() %>%
        add_model(model_glmnet) %>%
        add_recipe(recipe_base) %>%
        fit(training(data_splits))
    }
  ),
  
  # -------------------------------------------------------------------------
  # EVALUACIÓN
  # -------------------------------------------------------------------------
  
  tar_target(
    name = predictions,
    command = {
      test_data <- testing(data_splits)
      
      tibble(
        model = c("XGBoost", "Random Forest", "Elastic Net"),
        predictions = list(
          predict(fitted_xgboost, test_data),
          predict(fitted_rf, test_data),
          predict(fitted_glmnet, test_data)
        ),
        actual = list(test_data$happiness_score)
      )
    }
  ),
  
  tar_target(
    name = metrics,
    command = {
      predictions %>%
        mutate(
          rmse = map2_dbl(predictions, actual, ~sqrt(mean((.x$.pred - .y)^2))),
          mae = map2_dbl(predictions, actual, ~mean(abs(.x$.pred - .y))),
          rsq = map2_dbl(predictions, actual, ~cor(.x$.pred, .y)^2)
        ) %>%
        select(model, rmse, mae, rsq) %>%
        arrange(rmse)
    }
  ),
  # REGISTRO DE EXPERIMENTOS (MLflow)
  # _targets.R (La sección REGISTRO DE EXPERIMENTOS)
  
  # REGISTRO DE EXPERIMENTOS (MLflow)
  # tar_target( 
  #   name = log_mlflow_xgboost,
  #   command = {
  #     # 1. Obtener métricas específicas del modelo XGBoost
  #     model_metrics <- metrics %>% 
  #       # CORRECCIÓN: Filtrar por la columna 'model' y el valor 'XGBoost'
  #       dplyr::filter(model == "XGBoost") %>% 
  #       # Asegúrate de que las columnas rmse, mae, rsq existen en tu tabla metrics
  #       dplyr::select(rmse, mae, rsq) %>% 
  #       as.list()
  #       
  #     # 2. Parámetros (simulación, usa los reales si los tienes)
  #     params <- list(
  #       nrounds = 100, 
  #       max_depth = 6, 
  #       trees = "fitted_xgboost_trees"
  #     )
  #       
  #     # 3. Llamar a la función de logging de R/mlflow_integration.R
  #     log_experiment_to_mlflow(
  #       model_name = "XGBoost", 
  #       model = fitted_xgboost, 
  #       metrics = model_metrics, 
  #       params = params
  #     )
  #       
  #     # El target debe devolver algo (aunque sea TRUE)
  #     TRUE 
  #   },
  #   # El cue 'always' asegura que el log se ejecute cada vez, incluso si el modelo no cambió.
  #   cue = tar_cue(mode = "always"), 
  #   priority = 0.0 
  # ),
  # -------------------------------------------------------------------------
  # XAI
  # -------------------------------------------------------------------------
  
  tar_target(
    name = explainer,
    command = {
      DALEX::explain(
        model = extract_fit_engine(fitted_xgboost),
        data = testing(data_splits) %>% select(-happiness_score, -country_code, -year),
        y = testing(data_splits)$happiness_score,
        label = "XGBoost",
        
        # ¡Añade esta línea! Usa la función wrapper definida en R/functions.R
        predict_function = yhat_xgboost 
      )
    }
  ),
  
  tar_target(
    name = var_importance,
    command = {
      DALEX::model_parts(explainer)
    }
  ),
  
  # -------------------------------------------------------------------------
  # VISUALIZACIONES
  # -------------------------------------------------------------------------
  
  tar_target(
    name = plot_metrics,
    command = {
      p <- metrics %>%
        ggplot(aes(x = reorder(model, -rmse), y = rmse, fill = model)) +
        geom_col() +
        geom_text(aes(label = round(rmse, 3)), vjust = -0.5) +
        labs(
          title = "Comparación de Modelos",
          x = "Modelo",
          y = "RMSE"
        ) +
        theme_minimal() +
        theme(legend.position = "none")
      
      ggsave("plots/model_comparison.png", p, width = 10, height = 6)
      p
    }
  ),
  
  # En tu archivo _targets.R
  
  tar_target(
    name = plot_importance,
    command = {
      # 1. Acceder a los datos crudos de importancia (DALEX::model_parts retorna un data.frame)
      # y filtrar solo el 'drop_loss' (el cambio en el score)
      importance_data <- var_importance %>%
        # Filtra para quedarte solo con la pérdida al remover la variable (el resultado del drop)
        filter(variable != "_baseline_") %>% 
        # Calcular la pérdida absoluta o el valor absoluto de la diferencia con el baseline
        mutate(
          importance_value = abs(dropout_loss - min(dropout_loss))
        )
      
      p <- importance_data %>%
        # Usamos el valor calculado para plotear
        ggplot(aes(x = reorder(variable, importance_value), y = importance_value)) +
        geom_col(fill = "lightblue") +
        coord_flip() +
        labs(
          title = "Importancia de Variables (Drop Loss Absoluto)",
          x = "Variable",
          y = "Pérdida de Desempeño (MAE)" # Asumiendo que DALEX usa MAE o RMSE por defecto
        ) +
        theme_minimal()
      
      # Crear el directorio si no existe
      dir.create("plots", showWarnings = FALSE)
      
      ggsave("plots/variable_importance.png", p, width = 10, height = 6)
      p
    }
  ),
  
  # -------------------------------------------------------------------------
  # DASHBOARD DATA
  # -------------------------------------------------------------------------
  
  tar_target(
    name = dashboard_data,
    command = {
      list(
        data = engineered_data,
        metrics = metrics,
        predictions = predictions,
        importance = var_importance,
        best_model = fitted_xgboost
      )
    }
  )
)

