# ============================================================================
# SCRIPT DE INSTALACIÓN ROBUSTA - PREDICCIÓN FELICIDAD GLOBAL
# Versión corregida con gestión de dependencias mejorada
# ============================================================================

# Configurar directorio de trabajo
setwd("C:/Users/mverdejog/Proyectos_R/mlops")

# ----------------------------------------------------------------------------
# FASE 1: INSTALACIÓN DE DEPENDENCIAS CORE (SIN PROBLEMAS)
# ----------------------------------------------------------------------------

cat("📦 Instalando dependencias principales...\n")

# Paquetes CORE que funcionan sin problemas
core_pkgs <- c(
  # Orquestación
  "targets", "tarchetypes",
  
  # Ingesta
  "wbstats", "httr", "jsonlite", "rvest",
  
  # Almacenamiento
  "arrow", "qs",
  
  # Tidyverse
  "tidyverse", "lubridate", "glue",
  
  # Tidymodels
  "tidymodels", "recipes", "workflowsets", "tune", "rsample",
  "parsnip", "yardstick", "broom", "conflicted",
  
  # Modelos ML
  "xgboost", "ranger", "glmnet",
  
  # Series temporales (sin gluonts)
  "modeltime", "modeltime.ensemble", "timetk", "forecast",
  
  # XAI (sin fairmodels por ahora)
  "DALEX", "DALEXtra", "iml",
  
  # Visualización
  "ggplot2", "plotly", "echarts4r", "patchwork", "ggridges",
  
  # Dashboard
  "shiny", "bslib", "thematic", "shinyWidgets", "shinycssloaders",
  
  # Geoespacial
  "sf", "leaflet",
  
  # Reportes
  "gt", "DT",
  
  # Utilidades
  "janitor", "scales", "here"
)

# Instalar solo los faltantes
new_pkgs <- core_pkgs[!(core_pkgs %in% installed.packages()[,"Package"])]
if(length(new_pkgs)) {
  cat(sprintf("Instalando %d paquetes nuevos...\n", length(new_pkgs)))
  install.packages(new_pkgs, dependencies = TRUE)
}

# ----------------------------------------------------------------------------
# FASE 2: INSTALACIÓN DE PAQUETES OPCIONALES
# ----------------------------------------------------------------------------

cat("\n📦 Intentando instalar paquetes opcionales...\n")

# Función para instalar con manejo de errores
safe_install <- function(pkg) {
  tryCatch({
    if (!requireNamespace(pkg, quietly = TRUE)) {
      install.packages(pkg)
      cat(sprintf("✓ %s instalado\n", pkg))
      return(TRUE)
    }
    return(TRUE)
  }, error = function(e) {
    cat(sprintf("✗ %s no disponible: %s\n", pkg, e$message))
    return(FALSE)
  })
}

# Paquetes opcionales
optional_pkgs <- list(
  lightgbm = "lightgbm",
  prophet = "prophet",
  gganimate = "gganimate",
  quarto = "quarto",
  highcharter = "highcharter",
  leaflet.extras = "leaflet.extras",
  paletteer = "paletteer",
  gtExtras = "gtExtras"
)

# Instalar y registrar disponibilidad
pkg_availability <- sapply(optional_pkgs, safe_install)

# ----------------------------------------------------------------------------
# FASE 3: PAQUETES QUE REQUIEREN INSTALACIÓN ESPECIAL
# ----------------------------------------------------------------------------

cat("\n📦 Instalando paquetes especiales...\n")

# shapviz (puede requerir compilación)
if (!requireNamespace("shapviz", quietly = TRUE)) {
  tryCatch({
    install.packages("shapviz")
    cat("✓ shapviz instalado\n")
  }, error = function(e) {
    cat("✗ shapviz no disponible - SHAP plots deshabilitados\n")
  })
}

# fairmodels (puede tener dependencias complejas)
if (!requireNamespace("fairmodels", quietly = TRUE)) {
  tryCatch({
    install.packages("fairmodels")
    cat("✓ fairmodels instalado\n")
  }, error = function(e) {
    cat("✗ fairmodels no disponible - Fairness audit simplificado\n")
  })
}

# crew para paralelización (opcional)
if (!requireNamespace("crew", quietly = TRUE)) {
  tryCatch({
    install.packages("crew")
    cat("✓ crew instalado\n")
  }, error = function(e) {
    cat("✗ crew no disponible - Ejecución secuencial\n")
  })
}

# ----------------------------------------------------------------------------
# FASE 4: CARGAR PAQUETES CON RESOLUCIÓN DE CONFLICTOS
# ----------------------------------------------------------------------------

cat("\n📚 Cargando paquetes...\n")

# Cargar core
library(targets)
library(tarchetypes)
library(tidyverse)
library(tidymodels)
library(arrow)
library(qs)

# Resolver conflictos ANTES de cargar otros paquetes
library(conflicted)
conflicts_prefer(dplyr::filter)
conflicts_prefer(dplyr::lag)
conflicts_prefer(dplyr::select)
conflicts_prefer(recipes::step)
conflicts_prefer(purrr::map)
conflicts_prefer(scales::alpha)
conflicts_prefer(shiny::observe)

cat("✓ Paquetes core cargados\n")

# ----------------------------------------------------------------------------
# FASE 5: VERIFICACIÓN DE DEPENDENCIAS
# ----------------------------------------------------------------------------

cat("\n🔍 Verificando instalación...\n")

required_packages <- c("targets", "tidyverse", "tidymodels", "arrow", 
                       "shiny", "bslib", "plotly", "DALEX")

all_installed <- all(sapply(required_packages, function(pkg) {
  requireNamespace(pkg, quietly = TRUE)
}))

if (all_installed) {
  cat("✅ TODAS las dependencias críticas están instaladas!\n")
} else {
  missing <- required_packages[!sapply(required_packages, function(pkg) {
    requireNamespace(pkg, quietly = TRUE)
  })]
  cat("⚠ Faltan paquetes críticos:", paste(missing, collapse = ", "), "\n")
}

# Crear reporte de disponibilidad
cat("\n📊 Reporte de disponibilidad de features:\n")
cat(sprintf("  ├─ LightGBM: %s\n", ifelse(requireNamespace("lightgbm", quietly = TRUE), "✓", "✗")))
cat(sprintf("  ├─ Prophet: %s\n", ifelse(requireNamespace("prophet", quietly = TRUE), "✓", "✗")))
cat(sprintf("  ├─ SHAP (shapviz): %s\n", ifelse(requireNamespace("shapviz", quietly = TRUE), "✓", "✗")))
cat(sprintf("  ├─ Fairness (fairmodels): %s\n", ifelse(requireNamespace("fairmodels", quietly = TRUE), "✓", "✗")))
cat(sprintf("  ├─ Animaciones (gganimate): %s\n", ifelse(requireNamespace("gganimate", quietly = TRUE), "✓", "✗")))
cat(sprintf("  ├─ Quarto: %s\n", ifelse(requireNamespace("quarto", quietly = TRUE), "✓", "✗")))
cat(sprintf("  └─ Paralelización (crew): %s\n", ifelse(requireNamespace("crew", quietly = TRUE), "✓", "✗")))





# ============================================================================
# APLICACIÓN SHINY SIMPLIFICADA
# ============================================================================

cat("\n📝 Creando aplicación Shiny...\n")

shiny_app <- '
library(shiny)
library(bslib)
library(plotly)
library(gt)
library(targets)

# Tema moderno
theme <- bs_theme(
  version = 5,
  bg = "#0a0e27",
  fg = "#e8eaed",
  primary = "#4285f4",
  base_font = font_google("Inter")
)

# UI
ui <- page_navbar(
  title = "🌍 Global Happiness Platform",
  theme = theme,
  
  nav_panel(
    "Dashboard",
    layout_columns(
      card(
        card_header("Métricas de Modelos"),
        gt_output("metrics_table")
      ),
      card(
        card_header("Comparación Visual"),
        plotOutput("comparison_plot", height = "400px")
      )
    )
  ),
  
  nav_panel(
    "Variable Importance",
    card(
      full_screen = TRUE,
      card_header("Importancia de Features"),
      plotOutput("importance_plot", height = "600px")
    )
  ),
  
  nav_panel(
    "Data Explorer",
    card(
      card_header("Datos Procesados"),
      DT::dataTableOutput("data_table")
    )
  )
)

# Server
server <- function(input, output, session) {
  
  # Cargar datos
  dashboard_data <- reactive({
    tar_read(dashboard_data)
  })
  
  output$metrics_table <- render_gt({
    dashboard_data()$metrics %>%
      gt() %>%
      fmt_number(columns = where(is.numeric), decimals = 4) %>%
      tab_header(title = "Performance de Modelos")
  })
  
  output$comparison_plot <- renderPlot({
    tar_read(plot_metrics)
  })
  
  output$importance_plot <- renderPlot({
    tar_read(plot_importance)
  })
  
  output$data_table <- DT::renderDataTable({
    dashboard_data()$data %>%
      select(country_code, year, happiness_score, gdp_pc, social_support, freedom) %>%
      DT::datatable(options = list(pageLength = 25))
  })
}

shinyApp(ui, server)
'

writeLines(shiny_app, "app.R")
cat("✓ Aplicación Shiny creada\n")

# ============================================================================
# SCRIPT DE EJECUCIÓN RÁPIDA
# ============================================================================

cat("\n📝 Creando script de ejecución rápida...\n")

run_script <- '
# ============================================================================
# EJECUTAR PIPELINE COMPLETO
# ============================================================================

library(targets)

# Visualizar pipeline
cat("📊 Visualizando pipeline...\\n")
tar_visnetwork()

# Ejecutar pipeline
cat("🚀 Ejecutando pipeline...\\n")
tar_make()

# Ver resultados
cat("\\n📈 Resultados:\\n")
tar_read(metrics)

# Lanzar dashboard
cat("\\n🎯 Lanzando dashboard...\\n")
shiny::runApp("app.R")
'

writeLines(run_script, "run.R")
cat("✓ Script de ejecución creado\n")

# ============================================================================
# FINALIZACIÓN
# ============================================================================

cat("\n")
cat("═══════════════════════════════════════════════════════════════\n")
cat("✅ INSTALACIÓN COMPLETADA EXITOSAMENTE\n")
cat("═══════════════════════════════════════════════════════════════\n")
cat("\n")
cat("📁 Estructura del proyecto creada:\n")
cat("  ├── _targets.R (Pipeline principal)\n")
cat("  ├── R/functions.R (Funciones auxiliares)\n")
cat("  ├── app.R (Dashboard Shiny)\n")
cat("  ├── run.R (Script de ejecución)\n")
cat("  └── plots/ (Visualizaciones)\n")
cat("\n")
cat("🚀 Para comenzar:\n")
cat("  1. source(\"run.R\")  # Ejecuta todo el pipeline\n")
cat("  2. tar_make()        # Solo el pipeline\n")
cat("  3. shiny::runApp()   # Solo el dashboard\n")
cat("\n")
cat("📊 Para explorar:\n")
cat("  • tar_visnetwork()   # Ver gráfico de dependencias\n")
cat("  • tar_read(metrics)  # Ver métricas\n")
cat("  • tar_meta()         # Ver estado del pipeline\n")
cat("\n")
cat("═══════════════════════════════════════════════════════════════\n")


# ----------------------------------------------------------------------------
# ARCHIVO _targets.R - ORQUESTACIÓN COMPLETA DEL PIPELINE
# ----------------------------------------------------------------------------

# Este archivo debe guardarse como _targets.R en el directorio raíz del proyecto

library(targets)
library(tarchetypes)

# Configuración global de targets con optimización Arrow/Parquet
tar_option_set(
  packages = core_pkgs,
  format = "qs", # Serialización rápida por defecto
  memory = "transient",
  garbage_collection = TRUE,
  deployment = "main",
  workspace_on_error = TRUE,
  error = "continue",
  # Integración con renv para reproducibilidad
)

# Configuración de recursos para Big Data (Parquet)
tar_resources_parquet_global <- tar_resources(
  parquet = tar_resources_parquet(
    compression = "snappy",
    compression_level = NULL
  )
)

# Pipeline completo
list(
  # -------------------------------------------------------------------------
  # FASE 1: INGESTA DE DATOS ESTRUCTURADOS
  # -------------------------------------------------------------------------
  
  # Indicadores macroeconómicos del World Bank
  tar_target(
    name = wb_indicators,
    command = {
      indicators <- c(
        gdp_pc = "NY.GDP.PCAP.PP.KD",      # PIB per cápita PPP
        gini = "SI.POV.GINI",               # Índice GINI
        life_exp = "SP.DYN.LE00.IN",        # Expectativa de vida
        unemployment = "SL.UEM.TOTL.ZS",    # Tasa de desempleo
        health_exp = "SH.XPD.CHEX.GD.ZS",   # Gasto en salud (% GDP)
        edu_exp = "SE.XPD.TOTL.GD.ZS",      # Gasto en educación (% GDP)
        co2_pc = "EN.ATM.CO2E.PC",          # Emisiones CO2 per cápita
        urban_pop = "SP.URB.TOTL.IN.ZS"     # Población urbana (%)
      )
      
      wb_data <- wb_data(
        indicator = indicators,
        start_date = 2005,
        end_date = 2024,
        return_wide = TRUE
      ) %>%
        clean_names() %>%
        rename(year = date) %>%
        select(-iso2c, -country) %>%
        rename(country_code = iso3c)
      
      wb_data
    },
    format = "parquet"
  ),
  
  # World Happiness Report data (simulación de ingesta)
  tar_target(
    name = whr_data,
    command = {
      # En producción: leer desde archivo CSV o API
      # Simulación con datos estructurados
      tibble(
        country_code = rep(c("USA", "DEU", "JPN", "BRA", "IND", "ZAF"), each = 20),
        year = rep(2005:2024, 6),
        happiness_score = rnorm(120, mean = 6, sd = 1.5),
        social_support = runif(120, 0.6, 0.95),
        freedom = runif(120, 0.5, 0.9),
        generosity = rnorm(120, 0, 0.3),
        corruption = runif(120, 0.1, 0.8)
      )
    }
  ),
  
  # GDELT Tone data (proxy de bienestar afectivo)
  tar_target(
    name = gdelt_tone,
    command = {
      # En producción: API de GDELT o archivos CSV
      # Simulación: sentimiento agregado por país/año
      tibble(
        country_code = rep(c("USA", "DEU", "JPN", "BRA", "IND", "ZAF"), each = 20),
        year = rep(2005:2024, 6),
        avg_tone = rnorm(120, mean = 0, sd = 3),
        tone_volatility = rexp(120, rate = 0.5),
        event_count = rpois(120, lambda = 1000)
      )
    },
    format = "parquet"
  ),
  
  # Datos climáticos agregados
  tar_target(
    name = climate_data,
    command = {
      tibble(
        country_code = rep(c("USA", "DEU", "JPN", "BRA", "IND", "ZAF"), each = 20),
        year = rep(2005:2024, 6),
        temp_anomaly = rnorm(120, mean = 0.8, sd = 0.5),
        extreme_events = rpois(120, lambda = 3),
        climate_vulnerability = runif(120, 0.2, 0.8)
      )
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 2: INTEGRACIÓN Y FEATURE ENGINEERING
  # -------------------------------------------------------------------------
  
  # Unificación de fuentes de datos
  tar_target(
    name = data_integrated,
    command = {
      whr_data %>%
        left_join(wb_indicators, by = c("country_code", "year")) %>%
        left_join(gdelt_tone, by = c("country_code", "year")) %>%
        left_join(climate_data, by = c("country_code", "year")) %>%
        # Características derivadas
        mutate(
          # Vulnerabilidad socio-climática (interacción)
          socio_climate_vuln = climate_vulnerability * corruption,
          
          # Índice de desarrollo (combinación)
          dev_index = (scale(gdp_pc) + scale(life_exp) + scale(health_exp)) / 3,
          
          # Proxy de afecto positivo (normalizado)
          affect_positive = pmin(pmax((avg_tone + 5) / 10, 0), 1),
          
          # Features de lag para series temporales
          happiness_lag1 = lag(happiness_score, 1),
          happiness_lag2 = lag(happiness_score, 2),
          
          # Tendencia de felicidad (diferencia año a año)
          happiness_trend = happiness_score - lag(happiness_score, 1),
          
          # Features rolling (ventana móvil)
          gdp_growth_3y = (gdp_pc - lag(gdp_pc, 3)) / lag(gdp_pc, 3),
          
          # Características temporales
          year_scaled = scale(year)[,1],
          decade = floor(year / 10) * 10
        ) %>%
        arrange(country_code, year) %>%
        drop_na(happiness_score) # Target no puede ser NA
    }
  ),
  
  # Análisis exploratorio de multicolinealidad (VIF)
  tar_target(
    name = vif_analysis,
    command = {
      numeric_vars <- data_integrated %>%
        select(where(is.numeric), -happiness_score, -year) %>%
        select(-ends_with("_lag"), -ends_with("_trend"))
      
      # Calcular VIF (simplificado)
      cor_matrix <- cor(numeric_vars, use = "pairwise.complete.obs")
      
      list(
        correlation_matrix = cor_matrix,
        high_corr_pairs = which(abs(cor_matrix) > 0.8 & cor_matrix < 1, arr.ind = TRUE)
      )
    }
  ),
  
  # División temporal para series temporales
  tar_target(
    name = data_splits,
    command = {
      splits <- data_integrated %>%
        time_series_split(
          date_var = year,
          assess = "2 years",
          cumulative = TRUE
        )
      
      list(
        train = training(splits),
        test = testing(splits),
        splits = splits
      )
    }
  ),
  
  # Validación cruzada temporal
  tar_target(
    name = cv_folds,
    command = {
      data_splits$train %>%
        time_series_cv(
          date_var = year,
          initial = "10 years",
          assess = "2 years",
          skip = "1 year",
          cumulative = TRUE,
          slice_limit = 5
        )
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 3: ESPECIFICACIÓN DE RECIPES (PREPROCESAMIENTO)
  # -------------------------------------------------------------------------
  
  # Recipe Base: Variables originales + imputación robusta
  tar_target(
    name = recipe_base,
    command = {
      recipe(happiness_score ~ ., data = data_splits$train) %>%
        update_role(country_code, new_role = "id") %>%
        step_rm(year) %>% # Año como predictora directa puede causar leakage
        
        # Imputación robusta (MICE-like con KNN)
        step_impute_knn(all_numeric_predictors(), neighbors = 5) %>%
        
        # Normalización
        step_normalize(all_numeric_predictors()) %>%
        
        # One-hot encoding si hay categóricas
        step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
        
        # Remover predictoras de varianza cero
        step_zv(all_predictors())
    }
  ),
  
  # Recipe PCA: Mitigación de multicolinealidad
  tar_target(
    name = recipe_pca,
    command = {
      recipe(happiness_score ~ ., data = data_splits$train) %>%
        update_role(country_code, new_role = "id") %>%
        step_rm(year) %>%
        step_impute_knn(all_numeric_predictors(), neighbors = 5) %>%
        step_normalize(all_numeric_predictors()) %>%
        
        # PCA en variables macroeconómicas correlacionadas
        step_pca(
          gdp_pc, life_exp, health_exp, edu_exp,
          threshold = 0.95, # Retener 95% de varianza
          prefix = "PC_macro"
        ) %>%
        
        step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
        step_zv(all_predictors())
    }
  ),
  
  # Recipe Sintética: Features de interacción avanzadas
  tar_target(
    name = recipe_synthetic,
    command = {
      recipe(happiness_score ~ ., data = data_splits$train) %>%
        update_role(country_code, new_role = "id") %>%
        step_rm(year) %>%
        step_impute_knn(all_numeric_predictors(), neighbors = 5) %>%
        
        # Interacciones estratégicas
        step_interact(terms = ~ corruption:freedom) %>%
        step_interact(terms = ~ social_support:gdp_pc) %>%
        step_interact(terms = ~ climate_vulnerability:corruption) %>%
        
        # Transformaciones no lineales
        step_poly(gdp_pc, degree = 2) %>%
        step_sqrt(all_of(c("gini", "unemployment"))) %>%
        
        step_normalize(all_numeric_predictors()) %>%
        step_dummy(all_nominal_predictors(), one_hot = TRUE) %>%
        step_zv(all_predictors())
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 4: ESPECIFICACIÓN DE MODELOS
  # -------------------------------------------------------------------------
  
  # Modelo 1: ARIMA con regresores externos
  tar_target(
    name = model_arima,
    command = {
      arima_reg() %>%
        set_engine("auto_arima")
    }
  ),
  
  # Modelo 2: Prophet con regresores
  tar_target(
    name = model_prophet,
    command = {
      prophet_reg(
        changepoint_num = 25,
        changepoint_range = 0.8
      ) %>%
        set_engine("prophet")
    }
  ),
  
  # Modelo 3: LightGBM (Gradient Boosting optimizado)
  tar_target(
    name = model_lightgbm,
    command = {
      boost_tree(
        trees = tune(),
        tree_depth = tune(),
        learn_rate = tune(),
        min_n = tune()
      ) %>%
        set_engine("lightgbm", objective = "regression") %>%
        set_mode("regression")
    }
  ),
  
  # Modelo 4: XGBoost
  tar_target(
    name = model_xgboost,
    command = {
      boost_tree(
        trees = tune(),
        tree_depth = tune(),
        learn_rate = tune()
      ) %>%
        set_engine("xgboost") %>%
        set_mode("regression")
    }
  ),
  
  # Modelo 5: Random Forest
  tar_target(
    name = model_rf,
    command = {
      rand_forest(
        trees = 1000,
        min_n = tune(),
        mtry = tune()
      ) %>%
        set_engine("ranger", importance = "permutation") %>%
        set_mode("regression")
    }
  ),
  
  # Modelo 6: Elastic Net (regularización)
  tar_target(
    name = model_glmnet,
    command = {
      linear_reg(
        penalty = tune(),
        mixture = tune()
      ) %>%
        set_engine("glmnet")
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 5: WORKFLOW SETS - COMBINACIÓN RECIPES × MODELS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = workflow_set_all,
    command = {
      # Modelos clásicos de series temporales (solo con recipe base)
      wf_ts <- workflow_set(
        preproc = list(base = recipe_base),
        models = list(
          arima = model_arima,
          prophet = model_prophet
        ),
        cross = TRUE
      )
      
      # Modelos ML con todas las recipes
      wf_ml <- workflow_set(
        preproc = list(
          base = recipe_base,
          pca = recipe_pca,
          synthetic = recipe_synthetic
        ),
        models = list(
          lightgbm = model_lightgbm,
          xgboost = model_xgboost,
          rf = model_rf,
          glmnet = model_glmnet
        ),
        cross = TRUE
      )
      
      # Combinar todos los workflows
      bind_rows(wf_ts, wf_ml)
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 6: TUNING DE HIPERPARÁMETROS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = tuning_results,
    command = {
      # Grid de hiperparámetros
      grid_ctrl <- control_grid(
        save_pred = TRUE,
        save_workflow = TRUE,
        parallel_over = "everything"
      )
      
      # Tuning en paralelo
      workflow_set_all %>%
        workflow_map(
          fn = "tune_grid",
          resamples = cv_folds,
          grid = 20, # Latin Hypercube Sampling
          control = grid_ctrl,
          metrics = metric_set(rmse, rsq, mae),
          verbose = TRUE
        )
    }
  ),
  
  # Selección de mejores modelos
  tar_target(
    name = best_models,
    command = {
      tuning_results %>%
        rank_results(rank_metric = "rmse", select_best = TRUE) %>%
        filter(.metric == "rmse") %>%
        slice_min(mean, n = 5) # Top 5 modelos
    }
  ),
  
  # Finalizar workflows con mejores hiperparámetros
  tar_target(
    name = finalized_workflows,
    command = {
      best_ids <- best_models$wflow_id
      
      map(best_ids, function(id) {
        wf <- extract_workflow(tuning_results, id)
        best_params <- select_best(
          extract_workflow_set_result(tuning_results, id),
          metric = "rmse"
        )
        finalize_workflow(wf, best_params)
      }) %>%
        set_names(best_ids)
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 7: ENTRENAMIENTO FINAL Y MODELTIME TABLE
  # -------------------------------------------------------------------------
  
  # Entrenar modelos finalizados en todo el conjunto de entrenamiento
  tar_target(
    name = fitted_models,
    command = {
      map(finalized_workflows, function(wf) {
        fit(wf, data = data_splits$train)
      })
    }
  ),
  
  # Crear Modeltime Table
  tar_target(
    name = modeltime_tbl,
    command = {
      # Convertir modelos a formato modeltime
      mt_list <- imap(fitted_models, function(model, name) {
        model %>%
          modeltime_table() %>%
          mutate(.model_desc = name)
      })
      
      # Combinar en una sola tabla
      reduce(mt_list, bind_rows) %>%
        update_model_description(1:length(fitted_models), 
                                 names(fitted_models))
    }
  ),
  
  # Calibración con datos de test
  tar_target(
    name = calibrated_models,
    command = {
      modeltime_tbl %>%
        modeltime_calibrate(new_data = data_splits$test)
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 8: ENSEMBLE STACKING
  # -------------------------------------------------------------------------
  
  tar_target(
    name = ensemble_stack,
    command = {
      calibrated_models %>%
        ensemble_weighted(loadings = c(3, 3, 2, 1, 1)) %>% # Pesos basados en performance
        modeltime_calibrate(data_splits$test)
    }
  ),
  
  # Tabla unificada con ensemble
  tar_target(
    name = final_modeltime,
    command = {
      bind_rows(
        calibrated_models,
        ensemble_stack
      )
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 9: EVALUACIÓN Y MÉTRICAS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = accuracy_metrics,
    command = {
      final_modeltime %>%
        modeltime_accuracy() %>%
        arrange(rmse)
    }
  ),
  
  tar_target(
    name = forecast_future,
    command = {
      final_modeltime %>%
        modeltime_refit(data_integrated) %>%
        modeltime_forecast(
          h = "3 years",
          actual_data = data_integrated,
          conf_interval = 0.95
        )
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 10: EXPLAINABLE AI (XAI)
  # -------------------------------------------------------------------------
  
  # Extraer mejor modelo individual para XAI
  tar_target(
    name = best_model_xai,
    command = {
      best_id <- accuracy_metrics %>%
        slice_min(rmse, n = 1) %>%
        pull(.model_id)
      
      fitted_models[[best_id]]
    }
  ),
  
  # Crear explainer con DALEX
  tar_target(
    name = dalex_explainer,
    command = {
      explain_tidymodels(
        model = best_model_xai,
        data = data_splits$test %>% select(-happiness_score, -country_code),
        y = data_splits$test$happiness_score,
        label = "Best Happiness Model",
        verbose = FALSE
      )
    }
  ),
  
  # SHAP values
  tar_target(
    name = shap_values,
    command = {
      predict_parts(
        explainer = dalex_explainer,
        new_observation = data_splits$test[1:100,],
        type = "shap",
        B = 25
      )
    }
  ),
  
  # Variable importance
  tar_target(
    name = var_importance,
    command = {
      model_parts(
        explainer = dalex_explainer,
        loss_function = loss_root_mean_square,
        B = 50,
        type = "difference"
      )
    }
  ),
  
  # Partial Dependence Plots
  tar_target(
    name = pdp_plots,
    command = {
      key_vars <- c("gdp_pc", "social_support", "freedom", 
                    "corruption", "affect_positive")
      
      map(key_vars, function(var) {
        model_profile(
          explainer = dalex_explainer,
          variables = var,
          N = 500
        )
      }) %>%
        set_names(key_vars)
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 11: FAIRNESS ANALYSIS
  # -------------------------------------------------------------------------
  
  tar_target(
    name = fairness_audit,
    command = {
      # Crear variable protegida: región (simulada)
      test_with_region <- data_splits$test %>%
        mutate(
          region = case_when(
            country_code %in% c("USA", "DEU") ~ "Developed",
            country_code %in% c("BRA", "IND", "ZAF") ~ "Developing",
            TRUE ~ "Other"
          )
        )
      
      # Predicciones
      preds <- predict(best_model_xai, test_with_region)$.pred
      
      # Análisis de fairness (simplificado)
      test_with_region %>%
        mutate(prediction = preds) %>%
        group_by(region) %>%
        summarise(
          mean_prediction = mean(prediction),
          mean_actual = mean(happiness_score),
          bias = mean_prediction - mean_actual,
          rmse = sqrt(mean((prediction - happiness_score)^2))
        )
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 12: VISUALIZACIONES AVANZADAS
  # -------------------------------------------------------------------------
  
  # Gráfico de forecast interactivo
  tar_target(
    name = plot_forecast_interactive,
    command = {
      p <- forecast_future %>%
        plot_modeltime_forecast(
          .interactive = TRUE,
          .title = "Predicción de Felicidad Global (2025-2027)",
          .x_lab = "Año",
          .y_lab = "Happiness Score"
        )
      
      p %>%
        layout(
          hovermode = "x unified",
          legend = list(orientation = "h", y = -0.2)
        )
    }
  ),
  
  # Mapa coroplético de felicidad
  tar_target(
    name = plot_happiness_map,
    command = {
      # Datos del último año
      latest_data <- data_integrated %>%
        filter(year == max(year))
      
      # Crear mapa con echarts4r
      latest_data %>%
        e_charts(country_code) %>%
        e_map(happiness_score, map = "world") %>%
        e_visual_map(
          happiness_score,
          inRange = list(color = c('#313695', '#4575b4', '#74add1', 
                                   '#abd9e9', '#fee090', '#fdae61',
                                   '#f46d43', '#d73027', '#a50026'))
        ) %>%
        e_title("Distribución Global de Felicidad", "Año 2024") %>%
        e_tooltip(trigger = "item")
    }
  ),
  
  # Animación temporal de felicidad
  tar_target(
    name = plot_happiness_animation,
    command = {
      p <- data_integrated %>%
        ggplot(aes(x = gdp_pc, y = happiness_score, 
                   size = life_exp, color = social_support)) +
        geom_point(alpha = 0.7) +
        scale_x_log10() +
        scale_color_viridis_c(option = "plasma") +
        scale_size_continuous(range = c(2, 12)) +
        labs(
          title = 'Año: {frame_time}',
          x = 'PIB per cápita (log scale)',
          y = 'Happiness Score',
          size = 'Expectativa de Vida',
          color = 'Soporte Social'
        ) +
        theme_minimal(base_size = 14) +
        transition_time(year) +
        ease_aes('linear')
      
      animate(p, nframes = 100, duration = 10, 
              renderer = gifski_renderer())
    }
  ),
  
  # SHAP Summary Plot
  tar_target(
    name = plot_shap_summary,
    command = {
      plot(shap_values) +
        ggtitle("SHAP Values: Importancia Global de Features") +
        theme_minimal(base_size = 12)
    }
  ),
  
  # Variable Importance Plot
  tar_target(
    name = plot_var_importance,
    command = {
      plot(var_importance) +
        ggtitle("Importancia de Variables (Permutation)") +
        theme_minimal(base_size = 12)
    }
  ),
  
  # Partial Dependence Grid
  tar_target(
    name = plot_pdp_grid,
    command = {
      pdp_plots_list <- map(pdp_plots, plot)
      wrap_plots(pdp_plots_list, ncol = 2) +
        plot_annotation(
          title = "Partial Dependence Plots: Efectos Marginales",
          theme = theme(plot.title = element_text(size = 16, face = "bold"))
        )
    }
  ),
  
  # Ridge plot de distribuciones por región
  tar_target(
    name = plot_distribution_ridges,
    command = {
      data_integrated %>%
        mutate(
          region = case_when(
            country_code %in% c("USA", "DEU") ~ "Developed",
            country_code %in% c("BRA", "IND", "ZAF") ~ "Developing",
            TRUE ~ "Other"
          )
        ) %>%
        ggplot(aes(x = happiness_score, y = region, fill = region)) +
        geom_density_ridges(alpha = 0.7, scale = 2) +
        scale_fill_paletteer_d("ggsci::default_jco") +
        labs(
          title = "Distribución de Felicidad por Región",
          x = "Happiness Score",
          y = "Región"
        ) +
        theme_minimal(base_size = 14) +
        theme(legend.position = "none")
    }
  ),
  
  # -------------------------------------------------------------------------
  # FASE 13: REPORTES AUTOMATIZADOS
  # -------------------------------------------------------------------------
  
  tar_quarto(
    name = technical_report,
    path = "reports/technical_report.qmd",
    packages = core_pkgs,
    quiet = FALSE
  ),
  
  # -------------------------------------------------------------------------
  # FASE 14: DASHBOARD SHINY (definición)
  # -------------------------------------------------------------------------
  
  tar_target(
    name = dashboard_data,
    command = {
      list(
        forecast = forecast_future,
        accuracy = accuracy_metrics,
        importance = var_importance,
        fairness = fairness_audit,
        latest_data = data_integrated %>% filter(year == max(year))
      )
    }
  )
)

# ============================================================================
# APLICACIÓN SHINY AVANZADA
# ============================================================================

# Guardar como app.R en el directorio raíz

library(shiny)
library(bslib)
library(thematic)
library(plotly)
library(leaflet)
library(echarts4r)
library(gt)
library(targets)

# Tema moderno con Bootstrap 5
app_theme <- bs_theme(
  version = 5,
  bg = "#0a0e27",
  fg = "#e8eaed",
  primary = "#4285f4",
  secondary = "#34a853",
  success = "#34a853",
  info = "#4285f4",
  warning = "#fbbc04",
  danger = "#ea4335",
  base_font = font_google("Inter"),
  heading_font = font_google("Poppins"),
  code_font = font_google("Fira Code")
)

# Configurar tema para gráficos
thematic_shiny(font = "auto")

# ============================================================================
# UI - INTERFAZ DE USUARIO MODERNA
# ============================================================================

ui <- page_navbar(
  title = "🌍 Global Happiness MLOps Platform",
  theme = app_theme,
  fillable = TRUE,
  
  # Panel 1: Dashboard Principal
  nav_panel(
    title = "Dashboard",
    icon = icon("chart-line"),
    
    layout_sidebar(
      sidebar = sidebar(
        width = 300,
        
        card(
          card_header("Configuración de Análisis"),
          
          selectInput(
            "country_select",
            "Seleccionar País:",
            choices = c("Todos", "USA", "DEU", "JPN", "BRA", "IND", "ZAF"),
            selected = "Todos"
          ),
          
          sliderInput(
            "year_range",
            "Rango de Años:",
            min = 2005,
            max = 2027,
            value = c(2015, 2024),
            step = 1,
            sep = ""
          ),
          
          checkboxGroupInput(
            "metrics_display",
            "Métricas a Mostrar:",
            choices = c(
              "Happiness Score" = "happiness",
              "PIB per cápita" = "gdp",
              "Soporte Social" = "social",
              "GDELT Tone" = "gdelt"
            ),
            selected = c("happiness", "gdp")
          ),
          
          actionButton(
            "refresh_data",
            "Actualizar Análisis",
            icon = icon("refresh"),
            class = "btn-primary w-100 mt-3"
          )
        ),
        
        card(
          card_header("Estadísticas Globales"),
          value_box(
            title = "Felicidad Promedio Global",
            value = textOutput("avg_happiness"),
            showcase = icon("smile"),
            theme = "primary"
          ),
          value_box(
            title = "Países Analizados",
            value = textOutput("country_count"),
            showcase = icon("globe"),
            theme = "success"
          ),
          value_box(
            title = "RMSE Modelo",
            value = textOutput("model_rmse"),
            showcase = icon("chart-bar"),
            theme = "info"
          )
        )
      ),
      
      # Área principal con tarjetas
      navset_card_underline(
        title = "Análisis Temporal y Predicciones",
        
        nav_panel(
          "Forecast Interactivo",
          card_body(
            plotlyOutput("forecast_plot", height = "500px") %>%
              withSpinner(color = "#4285f4")
          )
        ),
        
        nav_panel(
          "Tendencias Comparativas",
          card_body(
            echarts4rOutput("trends_chart", height = "500px") %>%
              withSpinner(color = "#34a853")
          )
        ),
        
        nav_panel(
          "Distribuciones",
          card_body(
            plotOutput("distribution_plot", height = "500px") %>%
              withSpinner(color = "#fbbc04")
          )
        )
      )
    )
  ),
  
  # Panel 2: Mapa Global
  nav_panel(
    title = "Mapa Global",
    icon = icon("map"),
    
    card(
      full_screen = TRUE,
      card_header(
        "Distribución Geográfica de la Felicidad",
        class = "d-flex justify-content-between align-items-center"
      ),
      card_body(
        sliderInput(
          "map_year",
          "Año:",
          min = 2005,
          max = 2024,
          value = 2024,
          step = 1,
          sep = "",
          width = "100%",
          animate = animationOptions(interval = 1000, loop = TRUE)
        ),
        leafletOutput("happiness_map", height = "600px") %>%
          withSpinner(color = "#4285f4")
      )
    ),
    
    layout_columns(
      col_widths = c(6, 6),
      
      card(
        card_header("Top 10 Países Más Felices"),
        card_body(
          gt_output("top_countries_table")
        )
      ),
      
      card(
        card_header("Evolución Regional"),
        card_body(
          echarts4rOutput("regional_evolution", height = "350px")
        )
      )
    )
  ),
  
  # Panel 3: Explainable AI
  nav_panel(
    title = "Explainable AI",
    icon = icon("brain"),
    
    layout_columns(
      col_widths = c(12),
      
      card(
        card_header("Importancia Global de Features (SHAP)"),
        card_body(
          plotOutput("shap_summary", height = "400px") %>%
            withSpinner(color = "#4285f4")
        )
      )
    ),
    
    layout_columns(
      col_widths = c(6, 6),
      
      card(
        card_header("Variable Importance"),
        card_body(
          plotOutput("var_importance_plot", height = "400px")
        )
      ),
      
      card(
        card_header("Partial Dependence"),
        card_body(
          selectInput(
            "pdp_variable",
            "Seleccionar Variable:",
            choices = c("PIB per cápita" = "gdp_pc",
                        "Soporte Social" = "social_support",
                        "Libertad" = "freedom",
                        "Corrupción" = "corruption"),
            selected = "gdp_pc"
          ),
          plotOutput("pdp_plot", height = "350px")
        )
      )
    ),
    
    card(
      card_header("Análisis de Sensibilidad Temporal"),
      card_body(
        plotlyOutput("sensitivity_analysis", height = "400px")
      )
    )
  ),
  
  # Panel 4: Fairness & Bias
  nav_panel(
    title = "Fairness Audit",
    icon = icon("balance-scale"),
    
    layout_columns(
      col_widths = c(8, 4),
      
      card(
        card_header("Análisis de Sesgo Regional"),
        card_body(
          plotlyOutput("fairness_chart", height = "450px")
        )
      ),
      
      card(
        card_header("Métricas de Equidad"),
        card_body(
          gt_output("fairness_metrics_table")
        ),
        card_footer(
          "Statistical Parity Loss < 0.1 indica modelo justo"
        )
      )
    ),
    
    layout_columns(
      col_widths = c(6, 6),
      
      card(
        card_header("Residuos por Grupo"),
        card_body(
          plotOutput("residuals_by_group", height = "350px")
        )
      ),
      
      card(
        card_header("Calibración del Modelo"),
        card_body(
          plotlyOutput("calibration_plot", height = "350px")
        )
      )
    )
  ),
  
  # Panel 5: Performance
  nav_panel(
    title = "Model Performance",
    icon = icon("gauge-high"),
    
    layout_columns(
      col_widths = c(12),
      
      card(
        card_header("Comparación de Modelos"),
        card_body(
          gt_output("model_comparison_table")
        )
      )
    ),
    
    layout_columns(
      col_widths = c(6, 6),
      
      card(
        card_header("Métricas por Fold (Cross-Validation)"),
        card_body(
          plotlyOutput("cv_metrics_plot", height = "350px")
        )
      ),
      
      card(
        card_header("Residual Analysis"),
        card_body(
          plotOutput("residuals_plot", height = "350px")
        )
      )
    ),
    
    card(
      card_header("Learning Curves"),
      card_body(
        plotlyOutput("learning_curves", height = "400px")
      )
    )
  ),
  
  # Panel 6: Data Explorer
  nav_panel(
    title = "Data Explorer",
    icon = icon("database"),
    
    card(
      full_screen = TRUE,
      card_header("Explorador de Datos Integrados"),
      card_body(
        layout_columns(
          col_widths = c(3, 3, 3, 3),
          
          selectInput(
            "explorer_country",
            "País:",
            choices = NULL
          ),
          
          selectInput(
            "explorer_metric",
            "Métrica:",
            choices = NULL
          ),
          
          dateRangeInput(
            "explorer_dates",
            "Rango Temporal:",
            start = "2015-01-01",
            end = "2024-12-31"
          ),
          
          downloadButton(
            "download_data",
            "Descargar Dataset",
            class = "btn-success mt-4"
          )
        ),
        
        hr(),
        
        tabsetPanel(
          tabPanel(
            "Tabla de Datos",
            DTOutput("data_table")
          ),
          tabPanel(
            "Matriz de Correlación",
            plotlyOutput("correlation_matrix", height = "600px")
          ),
          tabPanel(
            "Estadísticas Descriptivas",
            verbatimTextOutput("summary_stats")
          )
        )
      )
    )
  ),
  
  # Panel 7: Pipeline Status
  nav_panel(
    title = "MLOps Status",
    icon = icon("gears"),
    
    card(
      card_header("Estado del Pipeline targets"),
      card_body(
        actionButton("run_pipeline", "Ejecutar Pipeline", 
                     icon = icon("play"), class = "btn-success"),
        actionButton("visualize_pipeline", "Visualizar Dependencias", 
                     icon = icon("diagram-project"), class = "btn-info ms-2"),
        hr(),
        verbatimTextOutput("pipeline_status")
      )
    ),
    
    layout_columns(
      col_widths = c(6, 6),
      
      card(
        card_header("Targets en Cache"),
        card_body(
          gt_output("targets_cache_table")
        )
      ),
      
      card(
        card_header("Tiempo de Ejecución"),
        card_body(
          plotlyOutput("execution_time_plot", height = "350px")
        )
      )
    ),
    
    card(
      card_header("Gráfico de Dependencias del Pipeline"),
      card_body(
        plotOutput("dependency_graph", height = "600px")
      )
    )
  )
)

# ============================================================================
# SERVER - LÓGICA DEL SERVIDOR
# ============================================================================

server <- function(input, output, session) {
  
  # Cargar datos del pipeline targets
  dashboard_data <- reactive({
    tar_read(dashboard_data)
  })
  
  # -------------------------------------------------------------------------
  # REACTIVE VALUES
  # -------------------------------------------------------------------------
  
  filtered_data <- reactive({
    req(dashboard_data())
    
    data <- dashboard_data()$latest_data
    
    if (input$country_select != "Todos") {
      data <- data %>% filter(country_code == input$country_select)
    }
    
    data %>%
      filter(year >= input$year_range[1], year <= input$year_range[2])
  })
  
  # -------------------------------------------------------------------------
  # VALUE BOXES
  # -------------------------------------------------------------------------
  
  output$avg_happiness <- renderText({
    mean_val <- mean(filtered_data()$happiness_score, na.rm = TRUE)
    format(round(mean_val, 2), nsmall = 2)
  })
  
  output$country_count <- renderText({
    n_distinct(filtered_data()$country_code)
  })
  
  output$model_rmse <- renderText({
    req(dashboard_data())
    rmse_val <- dashboard_data()$accuracy %>%
      filter(.model_desc == "ensemble_stack") %>%
      pull(rmse)
    format(round(rmse_val, 4), nsmall = 4)
  })
  
  # -------------------------------------------------------------------------
  # FORECAST PLOT
  # -------------------------------------------------------------------------
  
  output$forecast_plot <- renderPlotly({
    req(dashboard_data())
    
    forecast_data <- dashboard_data()$forecast
    
    if (input$country_select != "Todos") {
      forecast_data <- forecast_data %>%
        filter(country_code == input$country_select)
    }
    
    p <- forecast_data %>%
      plot_ly() %>%
      add_trace(
        x = ~year,
        y = ~.value,
        color = ~.model_desc,
        type = "scatter",
        mode = "lines",
        line = list(width = 2),
        hovertemplate = paste(
          "<b>%{fullData.name}</b><br>",
          "Año: %{x}<br>",
          "Valor: %{y:.2f}<br>",
          "<extra></extra>"
        )
      ) %>%
      layout(
        title = list(
          text = "Predicción de Felicidad con Intervalos de Confianza",
          font = list(size = 18, family = "Poppins")
        ),
        xaxis = list(title = "Año", gridcolor = "#2a2e43"),
        yaxis = list(title = "Happiness Score", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        hovermode = "x unified",
        legend = list(
          orientation = "h",
          y = -0.2,
          x = 0.5,
          xanchor = "center"
        )
      )
    
    p
  })
  
  # -------------------------------------------------------------------------
  # TRENDS CHART (echarts4r)
  # -------------------------------------------------------------------------
  
  output$trends_chart <- renderEcharts4r({
    req(filtered_data())
    
    metrics_map <- c(
      happiness = "happiness_score",
      gdp = "gdp_pc",
      social = "social_support",
      gdelt = "avg_tone"
    )
    
    selected_metrics <- metrics_map[input$metrics_display]
    
    chart_data <- filtered_data() %>%
      select(year, country_code, all_of(selected_metrics))
    
    chart_data %>%
      group_by(country_code) %>%
      e_charts(year) %>%
      e_line(happiness_score, smooth = TRUE) %>%
      e_tooltip(trigger = "axis") %>%
      e_title("Tendencias Temporales por País") %>%
      e_legend(bottom = 0) %>%
      e_theme("dark") %>%
      e_toolbox_feature(feature = "dataZoom") %>%
      e_toolbox_feature(feature = "saveAsImage")
  })
  
  # -------------------------------------------------------------------------
  # DISTRIBUTION PLOT
  # -------------------------------------------------------------------------
  
  output$distribution_plot <- renderPlot({
    req(filtered_data())
    
    filtered_data() %>%
      mutate(period = cut(year, breaks = 3, labels = c("2005-2011", "2012-2018", "2019-2024"))) %>%
      ggplot(aes(x = happiness_score, fill = period)) +
      geom_density(alpha = 0.6) +
      scale_fill_manual(values = c("#4285f4", "#34a853", "#fbbc04")) +
      labs(
        title = "Evolución de la Distribución de Felicidad",
        x = "Happiness Score",
        y = "Densidad",
        fill = "Período"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43"),
        legend.position = "top"
      )
  })
  
  # -------------------------------------------------------------------------
  # HAPPINESS MAP
  # -------------------------------------------------------------------------
  
  output$happiness_map <- renderLeaflet({
    # Datos simulados para el mapa
    map_data <- data.frame(
      country = c("USA", "DEU", "JPN", "BRA", "IND", "ZAF"),
      lat = c(37.09, 51.16, 36.20, -14.23, 20.59, -30.55),
      lng = c(-95.71, 10.45, 138.25, -51.92, 78.96, 22.93),
      happiness = c(7.2, 7.5, 6.8, 6.3, 5.9, 5.5)
    )
    
    pal <- colorNumeric(
      palette = c("#ea4335", "#fbbc04", "#34a853", "#4285f4"),
      domain = map_data$happiness
    )
    
    leaflet(map_data) %>%
      addProviderTiles(providers$CartoDB.DarkMatter) %>%
      addCircleMarkers(
        ~lng, ~lat,
        radius = ~happiness * 3,
        color = ~pal(happiness),
        fillOpacity = 0.7,
        popup = ~paste0(
          "<strong>", country, "</strong><br>",
          "Happiness: ", round(happiness, 2)
        )
      ) %>%
      addLegend(
        "bottomright",
        pal = pal,
        values = ~happiness,
        title = "Happiness Score",
        opacity = 0.7
      )
  })
  
  # -------------------------------------------------------------------------
  # TOP COUNTRIES TABLE
  # -------------------------------------------------------------------------
  
  output$top_countries_table <- render_gt({
    req(filtered_data())
    
    filtered_data() %>%
      filter(year == max(year)) %>%
      arrange(desc(happiness_score)) %>%
      slice_head(n = 10) %>%
      select(country_code, happiness_score, gdp_pc, social_support, freedom) %>%
      gt() %>%
      tab_header(
        title = md("**Top 10 Países Más Felices**"),
        subtitle = glue("Año {max(filtered_data()$year)}")
      ) %>%
      cols_label(
        country_code = "País",
        happiness_score = "Felicidad",
        gdp_pc = "PIB pc",
        social_support = "Soporte",
        freedom = "Libertad"
      ) %>%
      fmt_number(
        columns = where(is.numeric),
        decimals = 2
      ) %>%
      data_color(
        columns = happiness_score,
        colors = scales::col_numeric(
          palette = c("#ea4335", "#fbbc04", "#34a853"),
          domain = NULL
        )
      ) %>%
      opt_stylize(style = 6, color = "blue") %>%
      tab_options(
        table.background.color = "#0a0e27",
        heading.background.color = "#1a1e35"
      )
  })
  
  # -------------------------------------------------------------------------
  # REGIONAL EVOLUTION
  # -------------------------------------------------------------------------
  
  output$regional_evolution <- renderEcharts4r({
    req(filtered_data())
    
    filtered_data() %>%
      mutate(
        region = case_when(
          country_code %in% c("USA", "DEU") ~ "Developed",
          country_code %in% c("BRA", "IND", "ZAF") ~ "Developing",
          TRUE ~ "Other"
        )
      ) %>%
      group_by(year, region) %>%
      summarise(avg_happiness = mean(happiness_score, na.rm = TRUE), .groups = "drop") %>%
      group_by(region) %>%
      e_charts(year) %>%
      e_line(avg_happiness, smooth = TRUE) %>%
      e_tooltip(trigger = "axis") %>%
      e_theme("dark") %>%
      e_legend(bottom = 0)
  })
  
  # -------------------------------------------------------------------------
  # XAI OUTPUTS
  # -------------------------------------------------------------------------
  
  output$shap_summary <- renderPlot({
    req(dashboard_data())
    # Simulación - en producción usar tar_read(shap_values)
    data.frame(
      feature = c("PIB pc", "Soporte Social", "Libertad", "Corrupción", "GDELT Tone"),
      importance = c(0.35, 0.28, 0.18, 0.12, 0.07)
    ) %>%
      ggplot(aes(x = reorder(feature, importance), y = importance, fill = importance)) +
      geom_col() +
      coord_flip() +
      scale_fill_gradient(low = "#4285f4", high = "#ea4335") +
      labs(
        title = "SHAP Feature Importance",
        x = NULL,
        y = "Importancia Media |SHAP|"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43"),
        legend.position = "none"
      )
  })
  
  output$var_importance_plot <- renderPlot({
    data.frame(
      variable = c("social_support", "gdp_pc", "freedom", "corruption", "avg_tone"),
      dropout_loss = c(0.42, 0.38, 0.25, 0.19, 0.11)
    ) %>%
      ggplot(aes(x = reorder(variable, dropout_loss), y = dropout_loss)) +
      geom_point(size = 4, color = "#34a853") +
      geom_segment(aes(xend = variable, y = 0, yend = dropout_loss), 
                   color = "#34a853", size = 1.5) +
      coord_flip() +
      labs(
        title = "Variable Importance (Permutation)",
        x = NULL,
        y = "Dropout Loss"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43")
      )
  })
  
  output$pdp_plot <- renderPlot({
    # Simulación de PDP
    expand.grid(
      x = seq(0, 1, length.out = 100)
    ) %>%
      mutate(
        y = 5 + 2 * log1p(x * 10) + rnorm(100, 0, 0.1)
      ) %>%
      ggplot(aes(x, y)) +
      geom_line(color = "#4285f4", size = 1.5) +
      geom_ribbon(aes(ymin = y - 0.2, ymax = y + 0.2), 
                  fill = "#4285f4", alpha = 0.2) +
      labs(
        title = glue("Partial Dependence: {input$pdp_variable}"),
        x = "Valor de la Variable (normalizado)",
        y = "Efecto Parcial en Happiness"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43")
      )
  })
  
  output$sensitivity_analysis <- renderPlotly({
    # Análisis de sensibilidad temporal
    sensitivity_data <- expand.grid(
      year = 2005:2024,
      feature = c("PIB", "Social", "Libertad", "Corrupción")
    ) %>%
      mutate(
        importance = case_when(
          feature == "PIB" ~ 0.35 + 0.05 * sin((year - 2005) / 3),
          feature == "Social" ~ 0.28 + 0.03 * cos((year - 2005) / 2),
          feature == "Libertad" ~ 0.18 - 0.02 * (year - 2005) / 20,
          feature == "Corrupción" ~ 0.12 + 0.04 * (year - 2005) / 20
        )
      )
    
    plot_ly(sensitivity_data, x = ~year, y = ~importance, color = ~feature,
            type = "scatter", mode = "lines+markers") %>%
      layout(
        title = "Evolución Temporal de la Importancia de Features",
        xaxis = list(title = "Año", gridcolor = "#2a2e43"),
        yaxis = list(title = "Importancia Relativa", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        hovermode = "x unified"
      )
  })
  
  # -------------------------------------------------------------------------
  # FAIRNESS OUTPUTS
  # -------------------------------------------------------------------------
  
  output$fairness_chart <- renderPlotly({
    req(dashboard_data())
    
    fairness_data <- dashboard_data()$fairness
    
    plot_ly(fairness_data, x = ~region, y = ~mean_prediction, 
            type = "bar", name = "Predicción",
            marker = list(color = "#4285f4")) %>%
      add_trace(y = ~mean_actual, name = "Real",
                marker = list(color = "#34a853")) %>%
      layout(
        title = "Predicciones vs Realidad por Región",
        xaxis = list(title = "Región", gridcolor = "#2a2e43"),
        yaxis = list(title = "Happiness Score", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        barmode = "group"
      )
  })
  
  output$fairness_metrics_table <- render_gt({
    req(dashboard_data())
    
    dashboard_data()$fairness %>%
      gt() %>%
      tab_header(
        title = md("**Métricas de Fairness por Región**")
      ) %>%
      cols_label(
        region = "Región",
        mean_prediction = "Pred Media",
        mean_actual = "Real Media",
        bias = "Sesgo",
        rmse = "RMSE"
      ) %>%
      fmt_number(
        columns = where(is.numeric),
        decimals = 3
      ) %>%
      data_color(
        columns = bias,
        colors = scales::col_numeric(
          palette = c("#34a853", "#fbbc04", "#ea4335"),
          domain = c(-0.5, 0.5)
        )
      ) %>%
      opt_stylize(style = 6, color = "cyan")
  })
  
  output$residuals_by_group <- renderPlot({
    # Simulación de residuos
    residuals_data <- data.frame(
      region = rep(c("Developed", "Developing", "Other"), each = 100),
      residual = c(rnorm(100, 0, 0.3), rnorm(100, -0.1, 0.4), rnorm(100, 0.05, 0.35))
    )
    
    ggplot(residuals_data, aes(x = region, y = residual, fill = region)) +
      geom_violin(alpha = 0.7) +
      geom_boxplot(width = 0.2, alpha = 0.5) +
      geom_hline(yintercept = 0, linetype = "dashed", color = "#fbbc04", size = 1) +
      scale_fill_manual(values = c("#4285f4", "#34a853", "#ea4335")) +
      labs(
        title = "Distribución de Residuos por Grupo",
        x = "Región",
        y = "Residuo"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43"),
        legend.position = "none"
      )
  })
  
  output$calibration_plot <- renderPlotly({
    # Curva de calibración
    calibration_data <- data.frame(
      predicted = seq(4, 8, length.out = 50)
    ) %>%
      mutate(
        actual = predicted + rnorm(50, 0, 0.3),
        group = rep(c("Developed", "Developing"), each = 25)
      )
    
    plot_ly(calibration_data, x = ~predicted, y = ~actual, color = ~group,
            type = "scatter", mode = "markers") %>%
      add_trace(x = c(4, 8), y = c(4, 8), mode = "lines",
                line = list(dash = "dash", color = "#fbbc04"),
                name = "Calibración Perfecta", showlegend = TRUE) %>%
      layout(
        title = "Calibración del Modelo",
        xaxis = list(title = "Predicción", gridcolor = "#2a2e43"),
        yaxis = list(title = "Valor Real", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed")
      )
  })
  
  # -------------------------------------------------------------------------
  # MODEL PERFORMANCE OUTPUTS
  # -------------------------------------------------------------------------
  
  output$model_comparison_table <- render_gt({
    req(dashboard_data())
    
    dashboard_data()$accuracy %>%
      arrange(rmse) %>%
      select(.model_desc, rmse, mae, rsq, mape) %>%
      gt() %>%
      tab_header(
        title = md("**Comparación de Rendimiento de Modelos**"),
        subtitle = "Ordenado por RMSE (menor es mejor)"
      ) %>%
      cols_label(
        .model_desc = "Modelo",
        rmse = "RMSE",
        mae = "MAE",
        rsq = "R²",
        mape = "MAPE"
      ) %>%
      fmt_number(
        columns = c(rmse, mae, rsq, mape),
        decimals = 4
      ) %>%
      data_color(
        columns = rmse,
        colors = scales::col_numeric(
          palette = c("#34a853", "#fbbc04", "#ea4335"),
          domain = NULL,
          reverse = TRUE
        )
      ) %>%
      data_color(
        columns = rsq,
        colors = scales::col_numeric(
          palette = c("#ea4335", "#fbbc04", "#34a853"),
          domain = c(0, 1)
        )
      ) %>%
      tab_style(
        style = cell_text(weight = "bold"),
        locations = cells_body(rows = 1)
      ) %>%
      opt_stylize(style = 6, color = "blue") %>%
      tab_options(
        table.font.size = px(12),
        data_row.padding = px(8)
      )
  })
  
  output$cv_metrics_plot <- renderPlotly({
    # Simulación de métricas de CV
    cv_data <- expand.grid(
      fold = 1:5,
      model = c("LightGBM", "XGBoost", "Random Forest", "ARIMA", "Ensemble")
    ) %>%
      mutate(
        rmse = case_when(
          model == "Ensemble" ~ rnorm(5, 0.35, 0.02),
          model == "LightGBM" ~ rnorm(5, 0.38, 0.03),
          model == "XGBoost" ~ rnorm(5, 0.40, 0.03),
          model == "Random Forest" ~ rnorm(5, 0.42, 0.04),
          model == "ARIMA" ~ rnorm(5, 0.48, 0.05)
        )
      )
    
    plot_ly(cv_data, x = ~model, y = ~rmse, color = ~model,
            type = "box", boxpoints = "all", jitter = 0.3) %>%
      layout(
        title = "Distribución de RMSE en Cross-Validation",
        xaxis = list(title = "Modelo", gridcolor = "#2a2e43"),
        yaxis = list(title = "RMSE", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        showlegend = FALSE
      )
  })
  
  output$residuals_plot <- renderPlot({
    # Simulación de análisis de residuos
    residuals_data <- data.frame(
      fitted = seq(4, 8, length.out = 200),
      residuals = rnorm(200, 0, 0.3)
    )
    
    p1 <- ggplot(residuals_data, aes(x = fitted, y = residuals)) +
      geom_point(alpha = 0.5, color = "#4285f4") +
      geom_hline(yintercept = 0, linetype = "dashed", color = "#ea4335", size = 1) +
      geom_smooth(method = "loess", color = "#34a853", se = TRUE, alpha = 0.2) +
      labs(
        title = "Residuos vs Valores Ajustados",
        x = "Valores Ajustados",
        y = "Residuos"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43")
      )
    
    p2 <- ggplot(residuals_data, aes(sample = residuals)) +
      stat_qq(color = "#4285f4", alpha = 0.6) +
      stat_qq_line(color = "#ea4335", size = 1) +
      labs(
        title = "Q-Q Plot",
        x = "Cuantiles Teóricos",
        y = "Cuantiles de la Muestra"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        plot.background = element_rect(fill = "#0a0e27", color = NA),
        panel.background = element_rect(fill = "#0a0e27", color = NA),
        text = element_text(color = "#e8eaed"),
        panel.grid = element_line(color = "#2a2e43")
      )
    
    p1 + p2
  })
  
  output$learning_curves <- renderPlotly({
    # Curvas de aprendizaje
    learning_data <- expand.grid(
      train_size = seq(0.1, 1, by = 0.1),
      metric = c("train_rmse", "test_rmse")
    ) %>%
      mutate(
        value = case_when(
          metric == "train_rmse" ~ 0.3 + 0.1 * exp(-train_size * 3) + rnorm(20, 0, 0.01),
          metric == "test_rmse" ~ 0.5 - 0.15 * train_size + rnorm(20, 0, 0.02)
        )
      )
    
    plot_ly(learning_data, x = ~train_size, y = ~value, 
            color = ~metric, type = "scatter", mode = "lines+markers") %>%
      layout(
        title = "Learning Curves: RMSE vs Tamaño del Dataset",
        xaxis = list(title = "Proporción del Dataset de Entrenamiento", gridcolor = "#2a2e43"),
        yaxis = list(title = "RMSE", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        legend = list(
          title = list(text = "Métrica"),
          orientation = "h",
          y = -0.2
        )
      )
  })
  
  # -------------------------------------------------------------------------
  # DATA EXPLORER OUTPUTS
  # -------------------------------------------------------------------------
  
  observe({
    req(filtered_data())
    updateSelectInput(session, "explorer_country",
                      choices = c("Todos", unique(filtered_data()$country_code)))
    
    numeric_cols <- filtered_data() %>%
      select(where(is.numeric)) %>%
      names()
    updateSelectInput(session, "explorer_metric",
                      choices = numeric_cols)
  })
  
  output$data_table <- renderDT({
    req(filtered_data())
    
    datatable(
      filtered_data(),
      options = list(
        pageLength = 25,
        scrollX = TRUE,
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel')
      ),
      class = 'display nowrap',
      filter = 'top',
      rownames = FALSE
    ) %>%
      formatRound(columns = where(is.numeric), digits = 2)
  })
  
  output$correlation_matrix <- renderPlotly({
    req(filtered_data())
    
    cor_data <- filtered_data() %>%
      select(where(is.numeric)) %>%
      cor(use = "pairwise.complete.obs")
    
    plot_ly(
      x = colnames(cor_data),
      y = rownames(cor_data),
      z = cor_data,
      type = "heatmap",
      colors = colorRamp(c("#ea4335", "#fbbc04", "#34a853")),
      hovertemplate = paste(
        "X: %{x}<br>",
        "Y: %{y}<br>",
        "Correlación: %{z:.3f}<br>",
        "<extra></extra>"
      )
    ) %>%
      layout(
        title = "Matriz de Correlación",
        xaxis = list(tickangle = -45),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed")
      )
  })
  
  output$summary_stats <- renderPrint({
    req(filtered_data())
    
    filtered_data() %>%
      select(where(is.numeric)) %>%
      summary()
  })
  
  output$download_data <- downloadHandler(
    filename = function() {
      paste0("happiness_data_", Sys.Date(), ".csv")
    },
    content = function(file) {
      write_csv(filtered_data(), file)
    }
  )
  
  # -------------------------------------------------------------------------
  # MLOPS STATUS OUTPUTS
  # -------------------------------------------------------------------------
  
  observeEvent(input$run_pipeline, {
    showModal(modalDialog(
      title = "Ejecutando Pipeline targets",
      "El pipeline está ejecutándose. Esto puede tomar varios minutos...",
      footer = NULL,
      easyClose = FALSE
    ))
    
    tryCatch({
      tar_make()
      removeModal()
      showNotification("Pipeline ejecutado exitosamente", type = "message")
    }, error = function(e) {
      removeModal()
      showNotification(paste("Error:", e$message), type = "error")
    })
  })
  
  observeEvent(input$visualize_pipeline, {
    showModal(modalDialog(
      title = "Gráfico de Dependencias",
      size = "l",
      renderPlot({
        tar_visnetwork(
          targets_only = TRUE,
          level_separation = 150,
          degree_from = 1,
          degree_to = 1
        )
      }, height = 600),
      easyClose = TRUE
    ))
  })
  
  output$pipeline_status <- renderPrint({
    input$run_pipeline
    input$refresh_data
    
    tar_meta() %>%
      select(name, type, bytes, time, seconds) %>%
      arrange(desc(seconds)) %>%
      head(20)
  })
  
  output$targets_cache_table <- render_gt({
    input$run_pipeline
    input$refresh_data
    
    tar_meta() %>%
      mutate(
        size_mb = bytes / (1024^2),
        status = ifelse(is.na(error), "✓ OK", "✗ Error")
      ) %>%
      select(name, status, size_mb, seconds) %>%
      arrange(desc(size_mb)) %>%
      head(15) %>%
      gt() %>%
      tab_header(
        title = md("**Targets en Cache**")
      ) %>%
      cols_label(
        name = "Target",
        status = "Estado",
        size_mb = "Tamaño (MB)",
        seconds = "Tiempo (s)"
      ) %>%
      fmt_number(
        columns = c(size_mb, seconds),
        decimals = 2
      ) %>%
      opt_stylize(style = 6, color = "green")
  })
  
  output$execution_time_plot <- renderPlotly({
    input$run_pipeline
    input$refresh_data
    
    time_data <- tar_meta() %>%
      filter(!is.na(seconds)) %>%
      arrange(desc(seconds)) %>%
      head(15)
    
    plot_ly(time_data, x = ~seconds, y = ~reorder(name, seconds),
            type = "bar", orientation = "h",
            marker = list(color = "#4285f4")) %>%
      layout(
        title = "Tiempo de Ejecución por Target",
        xaxis = list(title = "Segundos", gridcolor = "#2a2e43"),
        yaxis = list(title = "", gridcolor = "#2a2e43"),
        plot_bgcolor = "#0a0e27",
        paper_bgcolor = "#0a0e27",
        font = list(color = "#e8eaed"),
        margin = list(l = 150)
      )
  })
  
  output$dependency_graph <- renderPlot({
    tar_glimpse()
  }, height = 600)
}

# ============================================================================
# EJECUTAR APLICACIÓN
# ============================================================================

shinyApp(ui = ui, server = server)

# ============================================================================
# SCRIPTS AUXILIARES Y FUNCIONES PERSONALIZADAS
# ============================================================================

# Guardar como R/functions.R

#' Calcular métricas de fairness personalizadas
#' @param predictions Vector de predicciones
#' @param actuals Vector de valores reales
#' @param protected_var Vector de la variable protegida
#' @return Data frame con métricas de fairness
calculate_fairness_metrics <- function(predictions, actuals, protected_var) {
  
  df <- tibble(
    pred = predictions,
    actual = actuals,
    group = protected_var
  )
  
  # Statistical Parity Difference
  positive_rate_by_group <- df %>%
    group_by(group) %>%
    summarise(
      positive_rate = mean(pred > median(pred)),
      .groups = "drop"
    )
  
  spd <- max(positive_rate_by_group$positive_rate) - 
    min(positive_rate_by_group$positive_rate)
  
  # Equal Opportunity Difference
  eod_data <- df %>%
    filter(actual > median(actual)) %>%
    group_by(group) %>%
    summarise(
      tpr = mean(pred > median(pred)),
      .groups = "drop"
    )
  
  eod <- max(eod_data$tpr) - min(eod_data$tpr)
  
  # Average Odds Difference
  aod_data <- df %>%
    group_by(group) %>%
    summarise(
      tpr = mean(pred[actual > median(actual)] > median(pred)),
      fpr = mean(pred[actual <= median(actual)] > median(pred)),
      .groups = "drop"
    )
  
  aod <- mean(c(
    max(aod_data$tpr) - min(aod_data$tpr),
    max(aod_data$fpr) - min(aod_data$fpr)
  ))
  
  tibble(
    metric = c("Statistical Parity Difference", 
               "Equal Opportunity Difference",
               "Average Odds Difference"),
    value = c(spd, eod, aod),
    threshold = 0.1,
    status = ifelse(c(spd, eod, aod) < 0.1, "✓ Fair", "✗ Bias Detected")
  )
}

#' Crear features de interacción automáticamente
#' @param data Data frame de entrada
#' @param target Nombre de la variable objetivo
#' @param max_interactions Máximo número de interacciones a crear
#' @return Data frame con features de interacción
create_interaction_features <- function(data, target, max_interactions = 10) {
  
  numeric_vars <- data %>%
    select(where(is.numeric), -all_of(target)) %>%
    names()
  
  # Calcular correlaciones con el target
  correlations <- map_dbl(numeric_vars, function(var) {
    abs(cor(data[[var]], data[[target]], use = "pairwise.complete.obs"))
  })
  
  # Seleccionar las variables más correlacionadas
  top_vars <- names(sort(correlations, decreasing = TRUE))[1:min(5, length(numeric_vars))]
  
  # Crear interacciones
  interactions <- combn(top_vars, 2, simplify = FALSE) %>%
    head(max_interactions)
  
  for (pair in interactions) {
    new_col <- paste0(pair[1], "_x_", pair[2])
    data[[new_col]] <- data[[pair[1]]] * data[[pair[2]]]
  }
  
  data
}

#' Detectar drift en los datos
#' @param reference_data Datos de referencia (entrenamiento)
#' @param current_data Datos actuales (producción)
#' @param threshold Umbral de KL divergence
#' @return Lista con estadísticas de drift
detect_data_drift <- function(reference_data, current_data, threshold = 0.1) {
  
  numeric_cols <- names(reference_data)[sapply(reference_data, is.numeric)]
  
  drift_results <- map_df(numeric_cols, function(col) {
    
    ref_vals <- reference_data[[col]][!is.na(reference_data[[col]])]
    cur_vals <- current_data[[col]][!is.na(current_data[[col]])]
    
    # Test de Kolmogorov-Smirnov
    ks_test <- ks.test(ref_vals, cur_vals)
    
    # Estadísticas descriptivas
    ref_mean <- mean(ref_vals)
    cur_mean <- mean(cur_vals)
    mean_shift <- (cur_mean - ref_mean) / ref_mean
    
    tibble(
      variable = col,
      ks_statistic = ks_test$statistic,
      ks_pvalue = ks_test$p.value,
      mean_shift_pct = mean_shift * 100,
      drift_detected = ks_test$p.value < 0.05
    )
  })
  
  list(
    drift_summary = drift_results,
    drift_count = sum(drift_results$drift_detected),
    severe_drift = drift_results %>% 
      filter(drift_detected & abs(mean_shift_pct) > threshold * 100)
  )
}

#' Generar reporte automatizado de modelo
#' @param model Modelo entrenado
#' @param test_data Datos de prueba
#' @param output_path Ruta del reporte de salida
generate_model_report <- function(model, test_data, output_path = "reports/model_report.html") {
  
  # Predicciones
  preds <- predict(model, test_data)
  
  # Métricas
  metrics <- tibble(
    actual = test_data$happiness_score,
    predicted = preds$.pred
  ) %>%
    summarise(
      RMSE = sqrt(mean((actual - predicted)^2)),
      MAE = mean(abs(actual - predicted)),
      R2 = cor(actual, predicted)^2,
      MAPE = mean(abs((actual - predicted) / actual)) * 100
    )
  
  # Variable importance
  importance <- model %>%
    extract_fit_parsnip() %>%
    vip::vi()
  
  # Crear reporte Quarto
  report_content <- glue::glue('
---
title: "Reporte Automatizado de Modelo"
date: "{Sys.Date()}"
format: 
  html:
    theme: darkly
    toc: true
    code-fold: true
---

## Resumen Ejecutivo

El modelo ha sido evaluado con un conjunto de prueba de **{nrow(test_data)} observaciones**.

### Métricas de Performance

- **RMSE**: {round(metrics$RMSE, 4)}
- **MAE**: {round(metrics$MAE, 4)}
- **R²**: {round(metrics$R2, 4)}
- **MAPE**: {round(metrics$MAPE, 2)}%

### Estado del Modelo

::{{.callout-{if(metrics$RMSE < 0.5) "note" else "warning"}}}
{if(metrics$RMSE < 0.5) "✓ Modelo dentro de los parámetros aceptables" else "⚠ Modelo requiere reentrenamiento"}
::

## Análisis Detallado

```{{r}}
#| echo: false
library(ggplot2)

# Gráfico de predicciones vs reales
ggplot(data.frame(actual = test_data$happiness_score, predicted = preds$.pred),
       aes(x = actual, y = predicted)) +
  geom_point(alpha = 0.5) +
  geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed") +
  labs(title = "Predicciones vs Valores Reales") +
  theme_minimal()
```

---

*Reporte generado automáticamente por el sistema MLOps*
  ')
  
  writeLines(report_content, output_path)
  quarto::quarto_render(output_path)
  
  invisible(metrics)
}

#' Enviar alertas por email
#' @param subject Asunto del email
#' @param body Cuerpo del mensaje
#' @param recipients Vector de emails destinatarios
send_alert_email <- function(subject, body, recipients) {
  
  email <- compose_email(
    body = md(body),
    footer = md(glue::glue("
---
*Sistema MLOps - Global Happiness Prediction*  
Enviado: {Sys.time()}
    "))
  )
  
  email %>%
    smtp_send(
      to = recipients,
      from = "mlops@happiness-platform.org",
      subject = subject,
      credentials = creds_file("~/.email_credentials")
    )
}

# ============================================================================
# ARCHIVO DE CONFIGURACIÓN GITHUB ACTIONS
# ============================================================================

# Guardar como .github/workflows/targets-pipeline.yml

#' ---
#' name: Run targets pipeline
#' 
#' on:
#'   push:
#'     branches: [main]
#'   schedule:
#'     - cron: '0 0 * * 0'  # Ejecutar semanalmente los domingos
#'   workflow_dispatch:
#' 
#' jobs:
#'   targets:
#'     runs-on: ubuntu-latest
#'     
#'     env:
#'       GITHUB_PAT: ${{ secrets.GITHUB_TOKEN }}
#'       RENV_PATHS_ROOT: ~/.local/share/renv
#'     
#'     steps:
#'       - uses: actions/checkout@v3
#'       
#'       - uses: r-lib/actions/setup-r@v2
#'         with:
#'           use-public-rspm: true
#'       
#'       - uses: r-lib/actions/setup-renv@v2
#'       
#'       - name: Install system dependencies
#'         run: |
#'           sudo apt-get update
#'           sudo apt-get install -y libgdal-dev libproj-dev libgeos-dev libudunits2-dev
#'       
#'       - name: Cache targets
#'         uses: actions/cache@v3
#'         with:
#'           path: _targets
#'           key: ${{ runner.os }}-targets-${{ hashFiles('_targets.R') }}
#'           restore-keys: ${{ runner.os }}-targets-
#'       
#'       - name: Run pipeline
#'         run: |
#'           targets::tar_make()
#'         shell: Rscript {0}
#'       
#'       - name: Generate reports
#'         run: |
#'           quarto::quarto_render("reports/")
#'         shell: Rscript {0}
#'       
#'       - name: Deploy to Posit Connect
#'         env:
#'           CONNECT_SERVER: ${{ secrets.CONNECT_SERVER }}
#'           CONNECT_API_KEY: ${{ secrets.CONNECT_API_KEY }}
#'         run: |
#'           rsconnect::deployApp(
#'             appDir = ".",
#'             appName = "happiness-mlops-dashboard",
#'             server = Sys.getenv("CONNECT_SERVER"),
#'             apiKey = Sys.getenv("CONNECT_API_KEY")
#'           )
#'         shell: Rscript {0}
#' ---



# ============================================================================
# FIN DEL SCRIPT - NOTAS DE IMPLEMENTACIÓN
# ============================================================================

#' GUÍA DE EJECUCIÓN:
#' 
#' 1. Ejecutar el pipeline:
#'    targets::tar_make()
#' 
#' 2. Visualizar dependencias:
#'    targets::tar_visnetwork()
#' 
#' 3. Verificar estado:
#'    targets::tar_meta()
#' 
#' 4. Lanzar dashboard:
#'    shiny::runApp("app.R")
#' 
#' 5. Generar reporte:
#'    quarto::quarto_render("reports/technical_report.qmd")
#' 
#' CARACTERÍSTICAS AVANZADAS IMPLEMENTADAS:
#' 
#' ✓ Orquestación completa con targets
#' ✓ Almacenamiento optimizado (Parquet para Big Data)
#' ✓ Feature Engineering avanzado (PCA, interacciones, sintéticas)
#' ✓ Workflow Sets para comparar recipes × models
#' ✓ Ensemble stacking para robustez
#' ✓ XAI completo (SHAP, PDP, Variable Importance)
#' ✓ Auditoría de fairness y sesgos
#' ✓ Dashboard moderno con bslib + Bootstrap 5
#' ✓ Visualizaciones interactivas (plotly, echarts4r, leaflet)
#' ✓ CI/CD con GitHub Actions
#' ✓ Reportes automatizados con Quarto
#' ✓ Detección de data drift
#' ✓ Sistema de alertas por email
#' ✓ Despliegue automatizado a Posit Connect
#' 
#' EXTENSIONES ADICIONALES RECOMENDADAS:
#' 
#' 1. Integración con bases de datos (pool + DBI)
#' 2. Monitoreo en tiempo real con Prometheus/Grafana
#' 3. A/B testing de modelos en producción
#' 4. Feature store con feast o similar
#' 5. MLflow para tracking de experimentos
#' 6. Kubernetes para escalabilidad
#' 7. API REST con plumber para servir predicciones
#' 8. Tests unitarios con testthat
#' 9. Validación de esquemas con pointblank
#' 10. Linaje de datos con Apache Atlas









# ============================================================================
# DOCKER-COMPOSE PARA DESARROLLO LOCAL
# ============================================================================

# Guardar como docker-compose.yml

#' version: '3.8'
#' 
#' services:
#'   app:
#'     build: .
#'     ports:
#'       - "8000:8000"
#'       - "3838:3838"
#'     volumes:
#'       - .:/app
#'       - r-packages:/usr/local/lib/R/site-library
#'     environment:
#'       - ENV=development
#'     depends_on:
#'       - postgres
#'       - prometheus
#'   
#'   postgres:
#'     image: postgres:15
#'     environment:
#'       POSTGRES_DB: happiness_db
#'       POSTGRES_USER: admin
#'       POSTGRES_PASSWORD: secret
#'     ports:
#'       - "5432:5432"
#'     volumes:
#'       - postgres-data:/var/lib/postgresql/data
#'   
#'   prometheus:
#'     image: prom/prometheus:latest
#'     ports:
#'       - "9090:9090"
#'     volumes:
#'       - ./prometheus.yml:/etc/prometheus/prometheus.yml
#'       - prometheus-data:/prometheus
#'   
#'   grafana:
#'     image: grafana/grafana:latest
#'     ports:
#'       - "3000:3000"
#'     environment:
#'       - GF_SECURITY_ADMIN_PASSWORD=admin
#'     volumes:
#'       - grafana-data:/var/lib/grafana
#'     depends_on:
#'       - prometheus
#' 
#' volumes:
#'   r-packages:
#'   postgres-data:
#'   prometheus-data:
#'   grafana-data:


