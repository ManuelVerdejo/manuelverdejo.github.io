
# ============================================================================
# EJECUTAR PIPELINE COMPLETO
# ============================================================================

library(targets)

# Visualizar pipeline
cat("📊 Visualizando pipeline...\n")
tar_visnetwork()

# Ejecutar pipeline
cat("🚀 Ejecutando pipeline...\n")
tar_make()

# Ver resultados
cat("\n📈 Resultados:\n")
tar_read(metrics)

# Lanzar dashboard
cat("\n🎯 Lanzando dashboard...\n")
shiny::runApp("app.R")

