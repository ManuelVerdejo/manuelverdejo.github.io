"""
Quick Start - Ejecución Rápida del Proyecto
Versión simplificada para demostración - CORREGIDA
"""

import numpy as np
import pandas as pd
from pathlib import Path
import logging

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def create_sample_data(n_samples=1000):
    """Crea datos de ejemplo para demostración"""
    logger.info("Generando datos de ejemplo...")
    
    np.random.seed(42)
    
    data = pd.DataFrame({
        'age': np.random.normal(65, 15, n_samples).clip(18, 100),
        'heart_rate': np.random.normal(85, 20, n_samples).clip(40, 200),
        'blood_pressure': np.random.normal(130, 25, n_samples).clip(80, 220),
        'oxygen_saturation': np.random.normal(95, 5, n_samples).clip(70, 100),
        'creatinine': np.random.gamma(2, 0.5, n_samples).clip(0.5, 8),
        'lactate': np.random.gamma(2, 1, n_samples).clip(0.5, 15),
        'race': np.random.choice(['White', 'Black', 'Hispanic'], n_samples),
        'gender': np.random.choice(['M', 'F'], n_samples)
    })
    
    # Generar target con relación a features
    mortality_risk = (
        0.05 * (data['age'] - 65) / 15 +
        0.15 * (data['creatinine'] > 2) +
        0.12 * (data['lactate'] > 3) +
        0.10 * (data['oxygen_saturation'] < 90) +
        np.random.normal(0, 0.1, n_samples)
    )
    
    data['mortality'] = (mortality_risk > np.percentile(mortality_risk, 70)).astype(int)
    
    logger.info(f"✓ Datos generados: {data.shape}")
    logger.info(f"  Tasa de mortalidad: {data['mortality'].mean():.2%}")
    
    return data


def train_simple_model(X_train, y_train):
    """Entrena un modelo simple para demostración"""
    from sklearn.ensemble import RandomForestClassifier
    
    logger.info("Entrenando modelo Random Forest...")
    
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train, y_train)
    
    logger.info("✓ Modelo entrenado")
    
    return model


def evaluate_model(model, X_test, y_test):
    """Evalúa el modelo"""
    from sklearn.metrics import roc_auc_score, classification_report
    
    logger.info("Evaluando modelo...")
    
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    
    auc = roc_auc_score(y_test, y_pred_proba)
    
    logger.info(f"✓ AUC: {auc:.3f}")
    logger.info("\nReporte de clasificación:")
    print(classification_report(y_test, y_pred, target_names=['Sobrevive', 'Mortalidad']))
    
    return {'auc': auc, 'y_pred': y_pred, 'y_pred_proba': y_pred_proba}


def explain_with_shap(model, X_train, X_test):
    """Genera explicaciones SHAP - CORREGIDO"""
    try:
        import shap
        
        logger.info("Generando explicaciones SHAP...")
        
        # Usar TreeExplainer para Random Forest
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test)
        
        # FIX: Manejar múltiples clases
        if isinstance(shap_values, list):
            shap_values = shap_values[1]  # Tomar clase positiva (mortalidad)
        
        # FIX: Garantizar que shap_values sea 2D
        if len(shap_values.shape) == 1:
            shap_values = shap_values.reshape(-1, 1)
        
        # FIX: Calcular importancia correctamente
        feature_importance_values = np.abs(shap_values).mean(axis=0)
        
        # FIX: Crear DataFrame de forma correcta
        feature_importance = pd.DataFrame({
            'feature': X_test.columns,
            'importance': feature_importance_values
        }).sort_values('importance', ascending=False)
        
        logger.info("✓ Explicaciones SHAP generadas")
        logger.info("\nTop 5 features más importantes:")
        print(feature_importance.head())
        
        return shap_values, feature_importance
        
    except ImportError:
        logger.warning("⚠️  SHAP no disponible. Instalando: pip install shap")
        return None, None
    except Exception as e:
        logger.error(f"Error en SHAP: {str(e)}")
        logger.warning("Continuando sin SHAP...")
        return None, None


def explain_with_lime(model, X_test):
    """Genera explicaciones LIME - ALTERNATIVA A SHAP"""
    try:
        import lime
        import lime.lime_tabular
        
        logger.info("\nGenerando explicaciones LIME...")
        
        # Crear explicador LIME
        explainer = lime.lime_tabular.LimeTabularExplainer(
            X_test.values,
            mode='classification',
            feature_names=X_test.columns,
            random_state=42
        )
        
        # Explicar primera instancia
        instance_idx = 0
        exp = explainer.explain_instance(
            X_test.iloc[instance_idx].values,
            model.predict_proba,
            num_features=10
        )
        
        logger.info("✓ Explicación LIME generada para primera instancia")
        logger.info("\nTop features (LIME):")
        
        # Mostrar top features
        for feature, weight in exp.as_list()[:5]:
            print(f"  {feature}: {weight:.4f}")
        
        return exp
        
    except ImportError:
        logger.warning("⚠️  LIME no disponible. Instalando: pip install lime")
        return None
    except Exception as e:
        logger.error(f"Error en LIME: {str(e)}")
        return None


def check_fairness(X_test, y_test, y_pred):
    """Verifica fairness básico"""
    logger.info("\n" + "="*60)
    logger.info("Analizando fairness...")
    logger.info("="*60)
    
    # Analizar por raza
    if 'race' in X_test.columns:
        for race in X_test['race'].unique():
            mask = X_test['race'] == race
            
            if mask.sum() > 10:  # Mínimo de muestras
                selection_rate = y_pred[mask].mean()
                actual_rate = y_test[mask].mean()
                
                logger.info(f"\nGrupo: {race}")
                logger.info(f"  Predicción positiva: {selection_rate:.2%}")
                logger.info(f"  Tasa real: {actual_rate:.2%}")
                logger.info(f"  Diferencia: {abs(selection_rate - actual_rate):.2%}")
    
    # Analizar por género
    if 'gender' in X_test.columns:
        logger.info("\nAnálisis por género:")
        for gender in X_test['gender'].unique():
            mask = X_test['gender'] == gender
            
            if mask.sum() > 10:
                selection_rate = y_pred[mask].mean()
                actual_rate = y_test[mask].mean()
                
                logger.info(f"\nGénero: {gender}")
                logger.info(f"  Predicción positiva: {selection_rate:.2%}")
                logger.info(f"  Tasa real: {actual_rate:.2%}")
    
    logger.info("\n✓ Análisis de fairness completado")


def main():
    """Función principal de ejecución rápida"""
    
    print("=" * 80)
    print("🚀 QUICK START - Proyecto XAI y Auditoría")
    print("=" * 80)
    print()
    
    # Crear directorios
    Path("output").mkdir(exist_ok=True)
    Path("output/figures").mkdir(exist_ok=True)
    
    try:
        # 1. Generar datos
        data = create_sample_data(n_samples=2000)
        
        # 2. Preparar datos
        logger.info("\nPreparando datos para modelado...")
        
        # Codificar categóricas
        from sklearn.preprocessing import LabelEncoder
        le_race = LabelEncoder()
        le_gender = LabelEncoder()
        
        data['race_encoded'] = le_race.fit_transform(data['race'])
        data['gender_encoded'] = le_gender.fit_transform(data['gender'])
        
        # Separar features y target
        feature_cols = ['age', 'heart_rate', 'blood_pressure', 'oxygen_saturation',
                        'creatinine', 'lactate', 'race_encoded', 'gender_encoded']
        
        X = data[feature_cols]
        y = data['mortality']
        
        # Split train/test
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        logger.info(f"✓ Train: {X_train.shape}, Test: {X_test.shape}")
        
        # 3. Entrenar modelo
        model = train_simple_model(X_train, y_train)
        
        # 4. Evaluar
        results = evaluate_model(model, X_test, y_test)
        
        # 5. Explicabilidad - Intentar SHAP, si falla usar LIME
        shap_values, feature_importance = explain_with_shap(model, X_train, X_test)
        
        if shap_values is None:
            logger.info("\nIntentando LIME como alternativa...")
            lime_exp = explain_with_lime(model, X_test)
        
        # 6. Fairness
        check_fairness(X_test, y_test, results['y_pred'])
        
        # Resumen final
        print("\n" + "=" * 80)
        print("✅ EJECUCIÓN COMPLETADA EXITOSAMENTE")
        print("=" * 80)
        print(f"\n📊 Resultados:")
        print(f"  • Modelo: Random Forest")
        print(f"  • AUC: {results['auc']:.3f}")
        print(f"  • Samples de test: {len(X_test)}")
        print(f"  • Tasa de mortalidad: {y_test.mean():.2%}")
        print(f"\n📁 Próximos pasos:")
        print("  1. Ejecutar pipeline completo: python main.py")
        print("  2. Ver dashboard interactivo: python dashboard.py")
        print("  3. Explorar notebooks/")
        print()
        
    except Exception as e:
        logger.error(f"❌ Error fatal: {str(e)}", exc_info=True)
        print(f"\n❌ Error: {str(e)}")
        print("\nSolución:")
        print("  1. Verifica que todas las dependencias estén instaladas:")
        print("     pip install numpy pandas scikit-learn shap lime matplotlib")
        print("  2. Si SHAP o LIME fallan, no son críticos (el script continúa)")
        print("  3. Para el pipeline completo, instala todas las dependencias:")
        print("     pip install -r requirements.txt")


if __name__ == "__main__":
    main()