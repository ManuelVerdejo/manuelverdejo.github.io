"""
Sistema Avanzado de XAI y Auditoría de Modelos Caja Negra
Pipeline Principal para Predicción de Mortalidad Hospitalaria
Autor: Sistema TAI (Trustworthy AI)
Versión: 2.0
"""

import numpy as np
import pandas as pd
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Importaciones de módulos propios
from src.data_processing import MIMICDataProcessor
from src.models.tabnet_model import TabNetClassifier
from src.explainability.shap_explainer import SHAPExplainer
from src.explainability.lime_explainer import LIMEExplainer
from src.explainability.counterfactual import DiCEGenerator
from src.fairness.bias_auditor import BiasAuditor
from src.evaluation.xai_evaluator import XAIEvaluator
from src.visualization.dashboard_generator import DashboardGenerator
from src.utils.config import Config
from src.utils.metrics import ModelMetrics


class XAIAuditPipeline:
    """Pipeline principal para el proyecto de XAI y auditoría"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Inicializa el pipeline con configuración
        
        Args:
            config_path: Ruta al archivo de configuración
        """
        self.config = Config.load(config_path)
        self.data_processor = None
        self.model = None
        self.explainers = {}
        self.results = {}
        
        logger.info("Pipeline XAI inicializado correctamente")
        print("--- DEBUG: Atributos de Config ---")
        print(self.config.__dict__) # Esto imprime todos los atributos internos del objeto
        print("---------------------------------") 
    
    def run(self) -> Dict:
        """
        Ejecuta el pipeline completo de XAI y auditoría
        
        Returns:
            Diccionario con todos los resultados del análisis
        """
        try:
            # 1. Carga y preprocesamiento de datos
            logger.info("=== FASE 1: Carga y Preprocesamiento de Datos ===")
            X_train, X_test, y_train, y_test = self._load_and_preprocess_data()
            
            # 2. Entrenamiento del modelo TabNet
            logger.info("=== FASE 2: Entrenamiento del Modelo TabNet ===")
            self.model = self._train_model(X_train, y_train)
            
            # 3. Evaluación del modelo
            logger.info("=== FASE 3: Evaluación del Rendimiento ===")
            metrics = self._evaluate_model(X_test, y_test)
            self.results['metrics'] = metrics
            
            # 4. Explicabilidad con SHAP
            logger.info("=== FASE 4: Explicabilidad con SHAP ===")
            shap_results = self._explain_with_shap(X_train, X_test)
            self.results['shap'] = shap_results
            
            # 5. Explicabilidad con LIME
            logger.info("=== FASE 5: Explicabilidad con LIME ===")
            lime_results = self._explain_with_lime(X_test)
            self.results['lime'] = lime_results
            
            # 6. Generación de contrafactuales
            logger.info("=== FASE 6: Explicaciones Contrafactuales (DiCE) ===")
            counterfactual_results = self._generate_counterfactuals(X_test)
            self.results['counterfactuals'] = counterfactual_results
            
            # 7. Auditoría de sesgos
            logger.info("=== FASE 7: Auditoría de Sesgos y Fairness ===")
            fairness_results = self._audit_fairness(X_test, y_test)
            self.results['fairness'] = fairness_results
            
            # 8. Evaluación de calidad XAI
            logger.info("=== FASE 8: Evaluación de Calidad XAI ===")
            xai_quality = self._evaluate_xai_quality(X_test)
            self.results['xai_quality'] = xai_quality
            
            # 9. Generación del dashboard
            logger.info("=== FASE 9: Generación del Dashboard Interactivo ===")
            self._generate_dashboard()
            
            # 10. Generación de reportes
            logger.info("=== FASE 10: Generación de Reportes ===")
            self._generate_reports()
            
            logger.info("✓ Pipeline completado exitosamente")
            return self.results
            
        except Exception as e:
            logger.error(f"Error en el pipeline: {str(e)}", exc_info=True)
            raise
    
    def _load_and_preprocess_data(self) -> Tuple[pd.DataFrame, ...]:
        """Carga y preprocesa los datos MIMIC-IV"""
        self.data_processor = MIMICDataProcessor(self.config)
        
        # Cargar datos
        data = self.data_processor.load_data()
        logger.info(f"Datos cargados: {data.shape}")
        
        # Feature engineering
        data = self.data_processor.engineer_features(data)
        logger.info(f"Features engineered: {data.shape[1]} características")
        
        # Identificar atributos protegidos
        protected_attrs = self.data_processor.identify_protected_attributes(data)
        self.config.protected_attributes = protected_attrs
        logger.info(f"Atributos protegidos identificados: {protected_attrs}")
        
        # Split train/test
        X_train, X_test, y_train, y_test = self.data_processor.split_data(
            data, 
            test_size=self.config.data_test_size,
            random_state=self.config.data_random_state
        )
        
        logger.info(f"Train: {X_train.shape}, Test: {X_test.shape}")
        return X_train, X_test, y_train, y_test
    
    def _train_model(self, X_train: pd.DataFrame, y_train: pd.Series) -> TabNetClassifier:
        """Entrena el modelo TabNet"""
        model = TabNetClassifier(self.config)
        
        # Entrenamiento con early stopping
        history = model.fit(
            X_train, 
            y_train,
            eval_set=[(X_train, y_train)],
            max_epochs=self.config.model_max_epochs,
            patience=self.config.model_patience,
            batch_size=self.config.model_batch_size
        )
        
        logger.info(f"Modelo entrenado. Best epoch: {model.best_epoch}")
        
        # Guardar modelo
        model.save(Path(self.config.output_base_dir) / "models" / "tabnet_model.pkl")
        
        return model
    
    def _evaluate_model(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict:
        """Evalúa el rendimiento del modelo"""
        metrics_calculator = ModelMetrics()
        
        # Predicciones
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)
        
        # Calcular métricas
        metrics = {
            'auc': metrics_calculator.auc_score(y_test, y_pred_proba),
            'accuracy': metrics_calculator.accuracy(y_test, y_pred),
            'precision': metrics_calculator.precision(y_test, y_pred),
            'recall': metrics_calculator.recall(y_test, y_pred),
            'f1': metrics_calculator.f1_score(y_test, y_pred),
            'fpr': metrics_calculator.false_positive_rate(y_test, y_pred),
            'fnr': metrics_calculator.false_negative_rate(y_test, y_pred),
            'confusion_matrix': metrics_calculator.confusion_matrix(y_test, y_pred)
        }
        
        logger.info(f"Métricas - AUC: {metrics['auc']:.3f}, F1: {metrics['f1']:.3f}")
        
        return metrics
    
    def _explain_with_shap(self, X_train: pd.DataFrame, X_test: pd.DataFrame) -> Dict:
        """Genera explicaciones SHAP"""
        shap_explainer = SHAPExplainer(self.model, X_train)
        
        # Valores SHAP globales
        n_global_shap_samples = self.config.explainability_shap['n_background_samples']
        
        if len(X_test) > n_global_shap_samples:
            X_test_sampled = X_test.sample(n_global_shap_samples, random_state=self.config.data_random_state)
        else:
            X_test_sampled = X_test
        
        # Valores SHAP globales
        # CAMBIO AQUÍ: Pasar X_test_sampled en lugar de X_test
        logger.info(f"Calculando SHAP global para {len(X_test_sampled)} instancias...")
        shap_values = shap_explainer.explain(X_test_sampled) # <--- ¡Cambiado!
        # Importancia global
        global_importance = shap_explainer.get_global_importance(shap_values)
        
        # Explicaciones locales para ejemplos específicos
        local_explanations = {}
        for idx in self.config.explainability_sample_indices:
            local_explanations[idx] = shap_explainer.explain_instance(
                X_test.iloc[idx:idx+1]
            )
        
        # Dependence plots para interacciones
        try:
            interactions = shap_explainer.compute_interactions(
                X_test_sampled, # Usar la muestra para evitar el problema de rendimiento
                max_samples=self.config.explainability_shap['max_interaction_samples']
            )
        except AttributeError:
            logger.warning("Omitting SHAP interaction calculation due to KernelExplainer limitation.")
            interactions = None
        
        self.explainers['shap'] = shap_explainer
        
        return {
            'values': shap_values,
            'global_importance': global_importance,
            'local_explanations': local_explanations,
            'interactions': interactions
        }
    
    def _explain_with_lime(self, X_test: pd.DataFrame) -> Dict:
        """Genera explicaciones LIME"""
        lime_explainer = LIMEExplainer(
            self.model, 
            X_test,
            mode='classification'
        )
        
        # Explicaciones locales
        local_explanations = {}
        for idx in self.config.explainability_sample_indices:
            exp = lime_explainer.explain_instance(
                X_test.iloc[idx],
                num_features=self.config.explainability_lime['num_features']
            )
            local_explanations[idx] = lime_explainer.extract_feature_contributions(exp)
        
        self.explainers['lime'] = lime_explainer
        
        return {
            'local_explanations': local_explanations
        }
    
    def _generate_counterfactuals(self, X_test: pd.DataFrame) -> Dict:
        """Genera explicaciones contrafactuales con DiCE"""
        dice_generator = DiCEGenerator(
            self.model,
            X_test,
            protected_attributes=self.config.protected_attributes
        )
        
        counterfactuals = {}
        for idx in self.config.explainability_sample_indices:
            cfs = dice_generator.generate(
                X_test.iloc[idx:idx+1],
                total_CFs=self.config.explainability_counterfactuals['total_CFs'],
                desired_class='opposite'
            )
            
            # Evaluar calidad
            cf_quality = dice_generator.evaluate_quality(cfs)
            
            counterfactuals[idx] = {
                'counterfactuals': cfs,
                'quality': cf_quality,
                'cfi_scores': dice_generator.compute_cfi(cfs)
            }
        
        return counterfactuals
    
    def _audit_fairness(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict:
        """Audita sesgos y fairness del modelo"""
        auditor = BiasAuditor(
            self.model,
            protected_attributes=self.config.protected_attributes
        )
        
        y_pred = self.model.predict(X_test)
        
        # Métricas de fairness
        fairness_metrics = auditor.compute_fairness_metrics(
            X_test, y_test, y_pred
        )
        
        # Fairness de subgrupos (interseccionalidad)
        subgroup_fairness = auditor.compute_subgroup_fairness(
            X_test, y_test, y_pred
        )
        
        # Descomposición de sesgo con SHAP
        bias_decomposition = None
        if 'shap' in self.explainers and self.results.get('shap', {}).get('values') is not None:
            try:
                bias_decomposition_list = []
                for protected_attr in self.config.protected_attributes:
                    bias_decomp = auditor.decompose_bias_with_shap(
                        X_test,
                        self.results['shap']['values'],
                        protected_attribute=protected_attr
                    )
                    bias_decomposition_list.append({
                        'attribute': protected_attr,
                        'decomposition': bias_decomp
                    })
                bias_decomposition = bias_decomposition_list
            except Exception as e:
                logger.warning(f"Error en descomposición de sesgo SHAP: {str(e)}")
                bias_decomposition = None
        
        # Detección de características proxy
        proxy_features = None
        try:
            proxy_features = auditor.detect_proxy_features(
                X_test,
                self.results.get('shap', {}).get('interactions')
            )
        except Exception as e:
            logger.warning(f"Error en detección de proxies: {str(e)}")
            proxy_features = {}
        
        # Recomendaciones de mitigación
        mitigation_strategies = auditor.generate_mitigation_strategies(
            fairness_metrics,
            proxy_features if proxy_features else {}
        )
        
        return {
            'fairness_metrics': fairness_metrics,
            'subgroup_fairness': subgroup_fairness,
            'bias_decomposition': bias_decomposition,
            'proxy_features': proxy_features,
            'mitigation_strategies': mitigation_strategies
        }
    
    def _evaluate_xai_quality(self, X_test: pd.DataFrame) -> Dict:
        """Evalúa la calidad de las explicaciones XAI"""
        evaluator = XAIEvaluator(
            self.model,
            self.explainers['shap'],
            self.explainers['lime']
        )
        
        # Fidelidad
        fidelity_scores = evaluator.compute_fidelity(X_test)
        
        # Consistencia entre métodos
        consistency = evaluator.compute_consistency(
            X_test,
            self.results['shap']['values'],
            self.results['lime']['local_explanations']
        )
        
        # Estabilidad
        stability = evaluator.compute_stability(
            X_test,
            num_perturbations=self.config.xai_evaluation_stability['n_perturbations']
        )
        
        # Acuerdo de características
        feature_agreement = evaluator.compute_feature_agreement(
            self.results['shap']['global_importance'],
            self.results['lime']['local_explanations']
        )
        
        return {
            'fidelity': fidelity_scores,
            'consistency': consistency,
            'stability': stability,
            'feature_agreement': feature_agreement
        }
    
    def _generate_dashboard(self):
        """Genera el dashboard interactivo"""
        dashboard_gen = DashboardGenerator(
            self.results,
            self.config
        )
        
        # Crear aplicación Dash
        app = dashboard_gen.create_app()
        
        # Guardar como HTML estático
        dashboard_gen.save_static_html(
            Path(self.config.output_base_dir) / "dashboard" / "xai_dashboard.html"
        )
        
        logger.info("Dashboard generado exitosamente")
    
    def _generate_reports(self):
        """Genera reportes en PDF y markdown"""
        from src.reporting.report_generator import ReportGenerator
        
        report_gen = ReportGenerator(self.results, self.config)
        
        # Reporte técnico completo
        report_gen.generate_technical_report(
            Path(self.config.output_base_dir) / "reports" / "technical_report.pdf"
        )
        
        # Reporte ejecutivo
        report_gen.generate_executive_summary(
            Path(self.config.output_base_dir) / "reports" / "executive_summary.pdf"
        )
        
        # Documentación markdown
        report_gen.generate_markdown_docs(
            Path(self.config.output_base_dir) / "reports" / "documentation.md"
        )
        
        logger.info("Reportes generados exitosamente")


def main():
    """Función principal"""
    try:
        # Crear directorios de salida
        output_dir = Path("output")
        for subdir in ['models', 'reports', 'dashboard', 'figures']:
            (output_dir / subdir).mkdir(parents=True, exist_ok=True)
        
        # Ejecutar pipeline
        pipeline = XAIAuditPipeline("config/config.yaml")
        results = pipeline.run()
        
        logger.info("=" * 80)
        logger.info("PROYECTO COMPLETADO EXITOSAMENTE")
        logger.info("=" * 80)
        logger.info(f"Resultados guardados en: {output_dir}")
        logger.info(f"AUC del modelo: {results['metrics']['auc']:.3f}")
        logger.info(f"Fidelidad SHAP: {results['xai_quality']['fidelity']['shap']:.3f}")
        logger.info(f"Sesgo detectado (DP): {results['fairness']['fairness_metrics']['demographic_parity']['difference']:.3f}")
        
        return results
        
    except Exception as e:
        logger.error(f"Error fatal en la ejecución: {str(e)}", exc_info=True)
        raise


if __name__ == "__main__":
    main()