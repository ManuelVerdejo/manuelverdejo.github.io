#!/usr/bin/env python3
"""
Script wrapper para ejecutar main.py correctamente
Configura el PYTHONPATH automáticamente
"""

import sys
import os
from pathlib import Path

# Obtener directorio raíz del proyecto
PROJECT_ROOT = Path(__file__).parent.absolute()

# Agregar al PYTHONPATH
sys.path.insert(0, str(PROJECT_ROOT))

# Cambiar directorio de trabajo
os.chdir(PROJECT_ROOT)

print(f"✓ Directorio de trabajo: {os.getcwd()}")
print(f"✓ PYTHONPATH configurado: {sys.path[0]}")
print()

# Importar y ejecutar main
try:
    from main import XAIAuditPipeline
    
    print("="*80)
    print("🚀 Ejecutando Pipeline XAI")
    print("="*80)
    print()
    
    # Crear y ejecutar pipeline
    pipeline = XAIAuditPipeline("config/config.yaml")
    results = pipeline.run()
    
    print("\n" + "="*80)
    print("✅ PIPELINE COMPLETADO EXITOSAMENTE")
    print("="*80)
    
except Exception as e:
    print(f"❌ Error: {str(e)}")
    import traceback
    traceback.print_exc()
    sys.exit(1)