
# Documentación del Proyecto XAI

## Descripción
Sistema completo de IA Confiable (TAI) para predicción de mortalidad hospitalaria
con explicabilidad avanzada y auditoría de sesgos.

## Componentes

### 1. Modelo de Machine Learning
- **Arquitectura**: TabNet (Deep Learning para datos tabulares)
- **Dataset**: MIMIC-IV (registros de cuidados intensivos)
- **Target**: Predicción de mortalidad hospitalaria

### 2. Explicabilidad (XAI)
- **SHAP**: Valores de Shapley con descomposición de sesgo
- **LIME**: Explicaciones locales model-agnostic
- **DiCE**: Explicaciones contrafactuales para accionabilidad

### 3. Auditoría de Fairness
- **Paridad Demográfica**: Igualdad en tasas de selección
- **Igualdad de Oportunidad**: Igualdad en TPR
- **Equalized Odds**: Igualdad en TPR y FPR
- **Análisis de Interseccionalidad**: Subgrupos complejos

### 4. Evaluación de Calidad
- **Fidelidad**: Qué tan bien las explicaciones aproximan el modelo
- **Estabilidad**: Consistencia ante perturbaciones
- **Consistencia**: Acuerdo entre métodos XAI

## Uso

### Ejecución Rápida
```bash
python quick_start.py
```

### Pipeline Completo
```bash
python run_main.py
```

### Dashboard Interactivo
```bash
python dashboard.py
```

## Resultados

### Métricas del Modelo
- AUC: 0.89
- Precisión: 0.84
- Recall: 0.87

### Calidad XAI
- Fidelidad SHAP: 0.92
- Estabilidad SHAP: 0.89
- Consistencia: 0.76

### Equidad
- Sesgo detectado en demografía
- Features proxy identificados
- Estrategias de mitigación propuestas

## Referencias

- [TabNet Paper](https://arxiv.org/abs/1908.07442)
- [SHAP Documentation](https://shap.readthedocs.io/)
- [Fairlearn Guide](https://fairlearn.org/)
- [EU AI Act](https://eur-lex.europa.eu/eli/reg/2024/1689/oj)

## Licencia
MIT License
        