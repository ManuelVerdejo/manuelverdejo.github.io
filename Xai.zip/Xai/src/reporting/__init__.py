"""Módulo de generación de reportes"""

# Se completa cuando se cree report_generator.py