"""
Auditor de Sesgos Algorítmicos y Fairness
Análisis multidimensional de equidad con descomposición SHAP
"""

import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Tuple, Optional
from sklearn.metrics import confusion_matrix
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


class BiasAuditor:
    """
    Auditor especializado en detección y análisis de sesgos algorítmicos
    """
    
    def __init__(
        self,
        model,
        protected_attributes: List[str],
        reference_groups: Optional[Dict[str, any]] = None
    ):
        """
        Inicializa el auditor de sesgos
        
        Args:
            model: Modelo a auditar
            protected_attributes: Lista de atributos protegidos
            reference_groups: Valores de referencia para cada atributo
        """
        self.model = model
        self.protected_attributes = protected_attributes
        self.reference_groups = reference_groups or {}
        
        logger.info(f"Bias Auditor inicializado para atributos: {protected_attributes}")
    
    def compute_fairness_metrics(
        self,
        X: pd.DataFrame,
        y_true: pd.Series,
        y_pred: np.ndarray,
        protected_attribute: Optional[str] = None
    ) -> Dict:
        """
        Calcula métricas de fairness multidimensionales
        
        Args:
            X: Features (incluye atributos protegidos)
            y_true: Etiquetas verdaderas
            y_pred: Predicciones
            protected_attribute: Atributo específico (None = todos)
            
        Returns:
            Diccionario con métricas de fairness
        """
        fairness_results = {}
        
        # Determinar qué atributos analizar
        attrs_to_analyze = (
            [protected_attribute] if protected_attribute 
            else self.protected_attributes
        )
        
        for attr in attrs_to_analyze:
            if attr not in X.columns:
                logger.warning(f"Atributo {attr} no encontrado en datos")
                continue
            
            logger.info(f"Analizando fairness para: {attr}")
            
            # Identificar grupos
            unique_values = X[attr].unique()
            
            if len(unique_values) <= 1:
                logger.warning(f"Solo un grupo en {attr}, saltando")
                continue
            
            # Determinar grupo de referencia
            reference_value = self.reference_groups.get(attr, unique_values[0])
            
            metrics = {}
            
            for value in unique_values:
                if value == reference_value:
                    continue
                
                # Máscaras de grupos
                mask_protected = X[attr] == value
                mask_reference = X[attr] == reference_value
                
                # Métricas básicas
                group_metrics = self._compute_group_metrics(
                    y_true, y_pred, mask_protected, mask_reference
                )
                
                metrics[f'{attr}_{value}_vs_{reference_value}'] = group_metrics
            
            fairness_results[attr] = metrics
        
        return fairness_results
    
    def _compute_group_metrics(
        self,
        y_true: pd.Series,
        y_pred: np.ndarray,
        mask_protected: pd.Series,
        mask_reference: pd.Series
    ) -> Dict:
        """Calcula métricas de fairness entre dos grupos"""
        
        # Datos de grupos
        y_true_prot = y_true[mask_protected]
        y_pred_prot = y_pred[mask_protected]
        y_true_ref = y_true[mask_reference]
        y_pred_ref = y_pred[mask_reference]
        
        # 1. Demographic Parity (Paridad Demográfica)
        selection_rate_prot = np.mean(y_pred_prot)
        selection_rate_ref = np.mean(y_pred_ref)
        demographic_parity_diff = selection_rate_prot - selection_rate_ref
        
        # 2. Equal Opportunity (Igualdad de Oportunidad)
        # TPR para positivos reales
        tpr_prot = self._compute_tpr(y_true_prot, y_pred_prot)
        tpr_ref = self._compute_tpr(y_true_ref, y_pred_ref)
        equal_opportunity_diff = tpr_prot - tpr_ref
        
        # 3. Equalized Odds (Igualdad de Probabilidades)
        # TPR y FPR iguales entre grupos
        fpr_prot = self._compute_fpr(y_true_prot, y_pred_prot)
        fpr_ref = self._compute_fpr(y_true_ref, y_pred_ref)
        equalized_odds_tpr_diff = tpr_prot - tpr_ref
        equalized_odds_fpr_diff = fpr_prot - fpr_ref
        
        # 4. Predictive Parity (Paridad Predictiva)
        ppv_prot = self._compute_ppv(y_true_prot, y_pred_prot)
        ppv_ref = self._compute_ppv(y_true_ref, y_pred_ref)
        predictive_parity_diff = ppv_prot - ppv_ref
        
        # 5. False Negative Rate Parity
        fnr_prot = self._compute_fnr(y_true_prot, y_pred_prot)
        fnr_ref = self._compute_fnr(y_true_ref, y_pred_ref)
        fnr_diff = fnr_prot - fnr_ref
        
        # Evaluación de severidad
        severity = self._evaluate_bias_severity(
            demographic_parity_diff,
            equal_opportunity_diff,
            equalized_odds_tpr_diff,
            equalized_odds_fpr_diff
        )
        
        return {
            'demographic_parity': {
                'protected': selection_rate_prot,
                'reference': selection_rate_ref,
                'difference': demographic_parity_diff,
                'ratio': selection_rate_prot / selection_rate_ref if selection_rate_ref > 0 else np.inf
            },
            'equal_opportunity': {
                'tpr_protected': tpr_prot,
                'tpr_reference': tpr_ref,
                'difference': equal_opportunity_diff
            },
            'equalized_odds': {
                'tpr_protected': tpr_prot,
                'tpr_reference': tpr_ref,
                'fpr_protected': fpr_prot,
                'fpr_reference': fpr_ref,
                'tpr_difference': equalized_odds_tpr_diff,
                'fpr_difference': equalized_odds_fpr_diff
            },
            'predictive_parity': {
                'ppv_protected': ppv_prot,
                'ppv_reference': ppv_ref,
                'difference': predictive_parity_diff
            },
            'false_negative_rate': {
                'fnr_protected': fnr_prot,
                'fnr_reference': fnr_ref,
                'difference': fnr_diff
            },
            'severity': severity,
            'n_protected': int(mask_protected.sum()),
            'n_reference': int(mask_reference.sum())
        }
    
    def _compute_tpr(self, y_true, y_pred) -> float:
        """Calcula True Positive Rate"""
        if len(y_true) == 0:
            return 0.0
        positives = y_true == 1
        if positives.sum() == 0:
            return 0.0
        return np.mean(y_pred[positives] == 1)
    
    def _compute_fpr(self, y_true, y_pred) -> float:
        """Calcula False Positive Rate"""
        if len(y_true) == 0:
            return 0.0
        negatives = y_true == 0
        if negatives.sum() == 0:
            return 0.0
        return np.mean(y_pred[negatives] == 1)
    
    def _compute_fnr(self, y_true, y_pred) -> float:
        """Calcula False Negative Rate"""
        if len(y_true) == 0:
            return 0.0
        positives = y_true == 1
        if positives.sum() == 0:
            return 0.0
        return np.mean(y_pred[positives] == 0)
    
    def _compute_ppv(self, y_true, y_pred) -> float:
        """Calcula Positive Predictive Value (Precision)"""
        if len(y_pred) == 0:
            return 0.0
        predicted_positive = y_pred == 1
        if predicted_positive.sum() == 0:
            return 0.0
        return np.mean(y_true[predicted_positive] == 1)
    
    def _evaluate_bias_severity(
        self,
        dp_diff: float,
        eop_diff: float,
        eo_tpr_diff: float,
        eo_fpr_diff: float
    ) -> str:
        """Evalúa la severidad del sesgo detectado"""
        max_diff = max(abs(dp_diff), abs(eop_diff), abs(eo_tpr_diff), abs(eo_fpr_diff))
        
        if max_diff < 0.05:
            return 'Negligible'
        elif max_diff < 0.10:
            return 'Bajo'
        elif max_diff < 0.15:
            return 'Moderado'
        elif max_diff < 0.25:
            return 'Alto'
        else:
            return 'Crítico'
    
    def compute_subgroup_fairness(
        self,
        X: pd.DataFrame,
        y_true: pd.Series,
        y_pred: np.ndarray,
        attributes: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        Analiza fairness en subgrupos (interseccionalidad)
        
        Args:
            X: Features
            y_true: Etiquetas verdaderas
            y_pred: Predicciones
            attributes: Atributos para intersección (None = todos)
            
        Returns:
            DataFrame con métricas por subgrupo
        """
        if attributes is None:
            attributes = self.protected_attributes[:2]  # Limitar a 2 para intersección
        
        logger.info(f"Analizando subgrupos para: {attributes}")
        
        subgroup_results = []
        
        # Generar combinaciones de subgrupos
        for attr1 in attributes:
            if attr1 not in X.columns:
                continue
            
            for value1 in X[attr1].unique():
                mask1 = X[attr1] == value1
                
                # Subgrupo simple
                subgroup_name = f"{attr1}_{value1}"
                metrics = self._compute_subgroup_metrics(
                    y_true[mask1], y_pred[mask1]
                )
                metrics['subgroup'] = subgroup_name
                metrics['n_samples'] = mask1.sum()
                subgroup_results.append(metrics)
                
                # Intersecciones
                for attr2 in attributes:
                    if attr2 == attr1 or attr2 not in X.columns:
                        continue
                    
                    for value2 in X[attr2].unique():
                        mask2 = X[attr2] == value2
                        mask_intersect = mask1 & mask2
                        
                        if mask_intersect.sum() < 10:  # Mínimo tamaño de muestra
                            continue
                        
                        subgroup_name = f"{attr1}_{value1}_{attr2}_{value2}"
                        metrics = self._compute_subgroup_metrics(
                            y_true[mask_intersect],
                            y_pred[mask_intersect]
                        )
                        metrics['subgroup'] = subgroup_name
                        metrics['n_samples'] = mask_intersect.sum()
                        subgroup_results.append(metrics)
        
        return pd.DataFrame(subgroup_results)
    
    def _compute_subgroup_metrics(self, y_true, y_pred) -> Dict:
        """Calcula métricas para un subgrupo"""
        if len(y_true) == 0:
            return {
                'selection_rate': 0,
                'tpr': 0,
                'fpr': 0,
                'accuracy': 0
            }
        
        return {
            'selection_rate': np.mean(y_pred),
            'tpr': self._compute_tpr(y_true, y_pred),
            'fpr': self._compute_fpr(y_true, y_pred),
            'accuracy': np.mean(y_true == y_pred)
        }
    
    def decompose_bias_with_shap(
        self,
        X: pd.DataFrame,
        shap_values: np.ndarray,
        protected_attribute: str
    ) -> pd.DataFrame:
        """
        Descompone el sesgo usando valores SHAP
        
        Args:
            X: Features
            shap_values: Valores SHAP
            protected_attribute: Atributo protegido
            
        Returns:
            DataFrame con descomposición de sesgo por feature
        """
        logger.info(f"Descomponiendo sesgo para {protected_attribute} usando SHAP")
        
        if protected_attribute not in X.columns:
            logger.error(f"Atributo {protected_attribute} no encontrado")
            return pd.DataFrame()
        
        # Separar grupos
        unique_values = X[protected_attribute].unique()
        if len(unique_values) < 2:
            logger.warning("Se necesitan al menos 2 grupos")
            return pd.DataFrame()
        
        reference_value = self.reference_groups.get(protected_attribute, unique_values[0])
        protected_value = [v for v in unique_values if v != reference_value][0]
        
        mask_prot = X[protected_attribute] == protected_value
        mask_ref = X[protected_attribute] == reference_value
        
        # SHAP promedio por grupo
        shap_prot = shap_values[mask_prot].mean(axis=0)
        shap_ref = shap_values[mask_ref].mean(axis=0)
        
        # Diferencia
        shap_diff = shap_prot - shap_ref
        
        # Crear DataFrame de descomposición
        decomposition = pd.DataFrame({
            'feature': X.columns,
            'shap_protected': shap_prot,
            'shap_reference': shap_ref,
            'shap_difference': shap_diff,
            'abs_contribution': np.abs(shap_diff),
            'contribution_pct': np.abs(shap_diff) / np.abs(shap_diff).sum() * 100
        }).sort_values('abs_contribution', ascending=False)
        
        # Identificar tipo de contribución
        decomposition['bias_type'] = decomposition['feature'].apply(
            lambda f: 'Protected' if f == protected_attribute 
            else 'Proxy' if self._is_likely_proxy(f, X, protected_attribute)
            else 'Legitimate'
        )
        
        logger.info(f"Descomposición completada. Top contributor: {decomposition.iloc[0]['feature']}")
        
        return decomposition
    
    def _is_likely_proxy(
        self,
        feature: str,
        X: pd.DataFrame,
        protected_attribute: str,
        correlation_threshold: float = 0.3
    ) -> bool:
        """
        Determina si una feature es probable proxy del atributo protegido
        """
        if feature not in X.columns or protected_attribute not in X.columns:
            return False
        
        try:
            # Calcular correlación
            if pd.api.types.is_numeric_dtype(X[feature]) and pd.api.types.is_numeric_dtype(X[protected_attribute]):
                correlation = abs(X[feature].corr(X[protected_attribute]))
                return correlation > correlation_threshold
            else:
                # Para categóricas, usar Cramér's V
                from scipy.stats import chi2_contingency
                
                contingency = pd.crosstab(X[feature], X[protected_attribute])
                chi2, _, _, _ = chi2_contingency(contingency)
                n = contingency.sum().sum()
                cramers_v = np.sqrt(chi2 / (n * (min(contingency.shape) - 1)))
                
                return cramers_v > correlation_threshold
        except:
            return False
    
    def detect_proxy_features(
        self,
        X: pd.DataFrame,
        shap_interaction_values: Optional[np.ndarray] = None,
        correlation_threshold: float = 0.3
    ) -> Dict:
        """
        Detecta features proxy de atributos protegidos
        
        Args:
            X: Features
            shap_interaction_values: Valores de interacción SHAP
            correlation_threshold: Umbral de correlación
            
        Returns:
            Diccionario con features proxy identificadas
        """
        logger.info("Detectando features proxy...")
        
        proxy_results = {}
        
        for protected_attr in self.protected_attributes:
            if protected_attr not in X.columns:
                continue
            
            proxies = []
            
            for feature in X.columns:
                if feature == protected_attr:
                    continue
                
                # Método 1: Correlación directa
                is_proxy = self._is_likely_proxy(feature, X, protected_attr, correlation_threshold)
                
                if is_proxy:
                    correlation = self._compute_correlation(X[feature], X[protected_attr])
                    
                    proxy_info = {
                        'feature': feature,
                        'correlation': correlation,
                        'method': 'correlation'
                    }
                    
                    # Método 2: Interacciones SHAP (si disponibles)
                    if shap_interaction_values is not None:
                        interaction_strength = self._compute_shap_interaction(
                            feature, protected_attr, X.columns, shap_interaction_values
                        )
                        proxy_info['shap_interaction'] = interaction_strength
                        proxy_info['method'] = 'correlation_and_shap'
                    
                    proxies.append(proxy_info)
            
            # Ordenar por fuerza de proxy
            proxies.sort(key=lambda x: abs(x['correlation']), reverse=True)
            proxy_results[protected_attr] = proxies
        
        logger.info(f"Proxy features detectadas: {sum(len(p) for p in proxy_results.values())}")
        
        return proxy_results
    
    def _compute_correlation(self, series1: pd.Series, series2: pd.Series) -> float:
        """Calcula correlación entre dos series"""
        try:
            if pd.api.types.is_numeric_dtype(series1) and pd.api.types.is_numeric_dtype(series2):
                return series1.corr(series2)
            else:
                # Cramér's V para categóricas
                from scipy.stats import chi2_contingency
                contingency = pd.crosstab(series1, series2)
                chi2, _, _, _ = chi2_contingency(contingency)
                n = contingency.sum().sum()
                return np.sqrt(chi2 / (n * (min(contingency.shape) - 1)))
        except:
            return 0.0
    
    def _compute_shap_interaction(
        self,
        feature1: str,
        feature2: str,
        feature_names: List[str],
        interaction_values: np.ndarray
    ) -> float:
        """Calcula fuerza de interacción SHAP entre dos features"""
        try:
            idx1 = list(feature_names).index(feature1)
            idx2 = list(feature_names).index(feature2)
            
            # Promedio de interacciones
            interaction = np.abs(interaction_values[:, idx1, idx2]).mean()
            return interaction
        except:
            return 0.0
    
    def generate_mitigation_strategies(
        self,
        fairness_metrics: Dict,
        proxy_features: Dict
    ) -> List[Dict]:
        """
        Genera estrategias de mitigación de sesgos
        
        Args:
            fairness_metrics: Métricas de fairness
            proxy_features: Features proxy detectadas
            
        Returns:
            Lista de estrategias recomendadas
        """
        strategies = []
        
        # Analizar severidad del sesgo
        for attr, metrics in fairness_metrics.items():
            for comparison, values in metrics.items():
                severity = values.get('severity', 'Unknown')
                
                if severity in ['Alto', 'Crítico']:
                    # Estrategia 1: Eliminación de features proxy
                    if attr in proxy_features and proxy_features[attr]:
                        strategies.append({
                            'strategy': 'Feature Removal',
                            'priority': 'High',
                            'description': f'Eliminar o reducir peso de features proxy para {attr}',
                            'features_to_remove': [p['feature'] for p in proxy_features[attr][:3]],
                            'expected_impact': 'Reducción de 30-50% en disparidad'
                        })
                    
                    # Estrategia 2: Re-balanceo
                    dp_diff = values.get('demographic_parity', {}).get('difference', 0)
                    if abs(dp_diff) > 0.15:
                        strategies.append({
                            'strategy': 'Data Re-balancing',
                            'priority': 'High',
                            'description': f'Aplicar SMOTE o re-weighting para {attr}',
                            'target_groups': [comparison],
                            'expected_impact': 'Mejora en paridad demográfica'
                        })
                    
                    # Estrategia 3: Constraints de fairness
                    eop_diff = values.get('equal_opportunity', {}).get('difference', 0)
                    if abs(eop_diff) > 0.10:
                        strategies.append({
                            'strategy': 'Fairness Constraints',
                            'priority': 'Medium',
                            'description': f'Incorporar penalización de equidad durante entrenamiento',
                            'constraint_type': 'Equal Opportunity',
                            'tools': ['Fairlearn', 'AIF360'],
                            'expected_impact': 'Igualar tasas de verdaderos positivos'
                        })
                
                elif severity == 'Moderado':
                    # Estrategia 4: Post-processing
                    strategies.append({
                        'strategy': 'Threshold Optimization',
                        'priority': 'Medium',
                        'description': f'Ajustar umbrales de decisión por grupo para {attr}',
                        'method': 'ROC-based threshold tuning',
                        'expected_impact': 'Mejora en igualdad de probabilidades'
                    })
        
        # Estrategia 5: Monitoreo continuo (siempre recomendada)
        strategies.append({
            'strategy': 'Continuous Monitoring',
            'priority': 'High',
            'description': 'Implementar sistema de monitoreo de fairness en producción',
            'metrics_to_track': ['Demographic Parity', 'Equal Opportunity', 'FPR/FNR by group'],
            'frequency': 'Weekly',
            'expected_impact': 'Detección temprana de drift de sesgo'
        })
        
        # Priorizar estrategias
        strategies.sort(key=lambda s: 0 if s['priority'] == 'High' else 1)
        
        return strategies
    
    def generate_fairness_report(
        self,
        fairness_metrics: Dict,
        subgroup_fairness: pd.DataFrame,
        bias_decomposition: pd.DataFrame,
        proxy_features: Dict
    ) -> str:
        """
        Genera reporte de auditoría de fairness en formato markdown
        
        Args:
            fairness_metrics: Métricas de fairness
            subgroup_fairness: Análisis de subgrupos
            bias_decomposition: Descomposición SHAP del sesgo
            proxy_features: Features proxy detectadas
            
        Returns:
            Reporte en markdown
        """
        report = []
        report.append("# Reporte de Auditoría de Fairness\n")
        report.append("## Resumen Ejecutivo\n")
        
        # Identificar problemas principales
        critical_issues = []
        for attr, metrics in fairness_metrics.items():
            for comparison, values in metrics.items():
                if values.get('severity') in ['Alto', 'Crítico']:
                    critical_issues.append(f"- **{comparison}**: Sesgo {values['severity']}")
        
        if critical_issues:
            report.append("### ⚠️ Problemas Críticos Identificados\n")
            report.extend(critical_issues)
            report.append("\n")
        else:
            report.append("✅ No se detectaron sesgos críticos.\n\n")
        
        # Métricas detalladas
        report.append("## Métricas de Fairness Detalladas\n")
        
        for attr, metrics in fairness_metrics.items():
            report.append(f"### Atributo Protegido: {attr}\n")
            
            for comparison, values in metrics.items():
                report.append(f"#### {comparison}\n")
                report.append("| Métrica | Grupo Protegido | Grupo Referencia | Diferencia | Severidad |\n")
                report.append("|---------|-----------------|------------------|------------|----------|\n")
                
                dp = values.get('demographic_parity', {})
                report.append(f"| Paridad Demográfica | {dp.get('protected', 0):.3f} | {dp.get('reference', 0):.3f} | {dp.get('difference', 0):.3f} | {values.get('severity', 'N/A')} |\n")
                
                eop = values.get('equal_opportunity', {})
                report.append(f"| Igualdad Oportunidad | {eop.get('tpr_protected', 0):.3f} | {eop.get('tpr_reference', 0):.3f} | {eop.get('difference', 0):.3f} | - |\n")
                
                report.append("\n")
        
        # Análisis de subgrupos
        if not subgroup_fairness.empty:
            report.append("## Análisis de Subgrupos (Interseccionalidad)\n")
            report.append("| Subgrupo | N | Selection Rate | TPR | FPR | Accuracy |\n")
            report.append("|----------|---|----------------|-----|-----|----------|\n")
            
            for _, row in subgroup_fairness.iterrows():
                report.append(f"| {row['subgroup']} | {row['n_samples']} | {row['selection_rate']:.3f} | {row['tpr']:.3f} | {row['fpr']:.3f} | {row['accuracy']:.3f} |\n")
            
            report.append("\n")
        
        # Descomposición de sesgo
        if not bias_decomposition.empty:
            report.append("## Descomposición del Sesgo (SHAP)\n")
            report.append("### Top Features Contribuyentes\n")
            report.append("| Feature | Contribución | Tipo |\n")
            report.append("|---------|--------------|------|\n")
            
            for _, row in bias_decomposition.head(10).iterrows():
                report.append(f"| {row['feature']} | {row['contribution_pct']:.2f}% | {row['bias_type']} |\n")
            
            report.append("\n")
        
        # Features proxy
        report.append("## Features Proxy Detectadas\n")
        for attr, proxies in proxy_features.items():
            if proxies:
                report.append(f"### Proxies de {attr}\n")
                report.append("| Feature | Correlación | Método |\n")
                report.append("|---------|-------------|--------|\n")
                
                for proxy in proxies[:5]:
                    report.append(f"| {proxy['feature']} | {proxy['correlation']:.3f} | {proxy['method']} |\n")
                
                report.append("\n")
        
        return "\n".join(report)


class FairnessVisualizer:
    """
    Visualizador especializado para métricas de fairness
    """
    
    @staticmethod
    def plot_fairness_comparison(
        fairness_metrics: Dict,
        save_path: Optional[str] = None
    ):
        """Visualiza comparación de métricas de fairness"""
        import matplotlib.pyplot as plt
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        for attr, metrics in fairness_metrics.items():
            data = []
            labels = []
            
            for comparison, values in metrics.items():
                dp = values.get('demographic_parity', {}).get('difference', 0)
                eop = values.get('equal_opportunity', {}).get('difference', 0)
                
                data.append([abs(dp), abs(eop)])
                labels.append(comparison.split('_vs_')[0])
            
            if data:
                data = np.array(data)
                
                # Plot barras
                x = np.arange(len(labels))
                width = 0.35
                
                axes[0, 0].bar(x - width/2, data[:, 0], width, label='Dem. Parity')
                axes[0, 0].bar(x + width/2, data[:, 1], width, label='Equal Opp.')
                axes[0, 0].set_ylabel('Diferencia Absoluta')
                axes[0, 0].set_title(f'Métricas de Fairness: {attr}')
                axes[0, 0].set_xticks(x)
                axes[0, 0].set_xticklabels(labels, rotation=45, ha='right')
                axes[0, 0].legend()
                axes[0, 0].axhline(y=0.1, color='r', linestyle='--', alpha=0.5, label='Umbral')
                axes[0, 0].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            plt.close()
        else:
            plt.show()
    
    @staticmethod
    def plot_subgroup_heatmap(
        subgroup_fairness: pd.DataFrame,
        metric: str = 'selection_rate',
        save_path: Optional[str] = None
    ):
        """Visualiza métricas de subgrupos como heatmap"""
        import matplotlib.pyplot as plt
        import seaborn as sns
        
        # Preparar datos para heatmap
        pivot_data = subgroup_fairness.pivot_table(
            values=metric,
            index='subgroup',
            aggfunc='mean'
        )
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(pivot_data, annot=True, fmt='.3f', cmap='RdYlGn', center=0.5)
        plt.title(f'Heatmap de {metric} por Subgrupo')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            plt.close()
        else:
            plt.show()