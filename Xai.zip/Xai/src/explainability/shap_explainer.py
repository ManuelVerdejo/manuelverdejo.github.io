"""
Explicador SHAP (SHapley Additive exPlanations)
Implementación robusta con valores de Shapley para interpretabilidad
"""

import numpy as np
import pandas as pd
import shap
import matplotlib.pyplot as plt
import logging
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


class SHAPExplainer:
    """
    Explicador SHAP con funcionalidades avanzadas
    """
    
    def __init__(
        self,
        model,
        X_background: pd.DataFrame,
        explainer_type: str = 'tree',
        n_background: int = 100
    ):
        """
        Inicializa el explicador SHAP
        
        Args:
            model: Modelo entrenado
            X_background: Datos de referencia para el explicador
            explainer_type: 'tree', 'kernel', o 'deep'
            n_background: Número de muestras de background
        """
        self.model = model
        self.explainer_type = explainer_type
        
        # Seleccionar muestra de background
        if len(X_background) > n_background:
            self.X_background = X_background.sample(n_background, random_state=42)
        else:
            self.X_background = X_background
        
        # Crear explicador apropiado
        self._create_explainer()
        
        logger.info(f"SHAP Explainer inicializado ({explainer_type})")
    
    def _create_explainer(self):
        """Crea el explicador SHAP apropiado"""
        if self.explainer_type == 'tree':
            # Para modelos basados en árboles
            try:
                self.explainer = shap.TreeExplainer(self.model.model)
            except:
                logger.warning("TreeExplainer falló, usando KernelExplainer")
                self.explainer = shap.KernelExplainer(
                    self.model.predict_proba,
                    self.X_background
                )
        elif self.explainer_type == 'kernel':
            # Kernel SHAP (model-agnostic)
            self.explainer = shap.KernelExplainer(
                self.model.predict_proba,
                self.X_background
            )
        elif self.explainer_type == 'deep':
            # Para redes neuronales profundas
            self.explainer = shap.DeepExplainer(
                self.model.model,
                self.X_background.values
            )
        else:
            raise ValueError(f"Tipo de explicador no soportado: {self.explainer_type}")
    
    def explain(
        self,
        X: pd.DataFrame,
        check_additivity: bool = False
    ) -> np.ndarray:
        """
        Calcula valores SHAP para un conjunto de datos
        
        Args:
            X: Datos a explicar
            check_additivity: Verificar propiedad de aditividad
            
        Returns:
            Valores SHAP
        """
        logger.info(f"Calculando valores SHAP para {len(X)} instancias...")
        
        try:
            if self.explainer_type == 'tree':
                shap_values = self.explainer.shap_values(X)
                
                # TreeExplainer puede retornar lista para clasificación multiclase
                if isinstance(shap_values, list):
                    shap_values = shap_values[1]  # Clase positiva
            else:
                shap_values = self.explainer.shap_values(
                    X,
                    check_additivity=check_additivity
                )
        except Exception as e:
            logger.error(f"Error calculando SHAP: {e}")
            raise
        
        logger.info("Valores SHAP calculados exitosamente")
        return shap_values
    
    def explain_instance(
        self,
        X_instance: pd.DataFrame
    ) -> Dict:
        """
        Explica una instancia individual
        
        Args:
            X_instance: Instancia a explicar (DataFrame de 1 fila)
            
        Returns:
            Diccionario con valores SHAP y metadata
        """
        shap_values = self.explain(X_instance)
        
        # Obtener predicción
        prediction = self.model.predict_proba(X_instance)[0]
        
        # Crear explicación estructurada
        feature_contributions = pd.DataFrame({
            'feature': X_instance.columns,
            'value': X_instance.values[0],
            'shap_value': shap_values[0],
            'abs_shap': np.abs(shap_values[0])
        }).sort_values('abs_shap', ascending=False)
        
        return {
            'shap_values': shap_values[0],
            'feature_contributions': feature_contributions,
            'prediction': prediction,
            'base_value': self.explainer.expected_value if hasattr(self.explainer, 'expected_value') else None
        }
    
    def get_global_importance(
        self,
        shap_values: np.ndarray,
        feature_names: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        Calcula importancia global de características
        
        Args:
            shap_values: Valores SHAP calculados
            feature_names: Nombres de características
            
        Returns:
            DataFrame con importancias ordenadas
        """
        # Importancia = media del valor absoluto de SHAP
        global_importance = np.abs(shap_values).mean(axis=0)
        
        if feature_names is None:
            feature_names = [f'feature_{i}' for i in range(len(global_importance))]
        
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': global_importance,
            'mean_shap': shap_values.mean(axis=0)
        }).sort_values('importance', ascending=False)
        
        return importance_df
    
    def compute_interactions(
        self,
        X: pd.DataFrame,
        max_samples: int = 100
    ) -> np.ndarray:
        """
        Calcula interacciones SHAP entre características
        
        Args:
            X: Datos
            max_samples: Máximo de muestras (computacionalmente costoso)
            
        Returns:
            Matriz de interacciones SHAP
        """
        logger.info("Calculando interacciones SHAP...")
        
        # Limitar muestras por eficiencia
        if len(X) > max_samples:
            X_sample = X.sample(max_samples, random_state=42)
        else:
            X_sample = X
        
        try:
            if self.explainer_type == 'tree':
                shap_interaction_values = self.explainer.shap_interaction_values(X_sample)
                
                if isinstance(shap_interaction_values, list):
                    shap_interaction_values = shap_interaction_values[1]
            else:
                logger.warning("Interacciones solo disponibles para TreeExplainer")
                return None
        except Exception as e:
            logger.error(f"Error calculando interacciones: {e}")
            return None
        
        logger.info("Interacciones SHAP calculadas")
        return shap_interaction_values
    
    def get_top_interactions(
        self,
        interaction_values: np.ndarray,
        feature_names: List[str],
        top_k: int = 10
    ) -> pd.DataFrame:
        """
        Obtiene las top interacciones entre características
        
        Args:
            interaction_values: Valores de interacción SHAP
            feature_names: Nombres de características
            top_k: Número de interacciones principales
            
        Returns:
            DataFrame con top interacciones
        """
        if interaction_values is None:
            return None
        
        # Promediar interacciones sobre todas las instancias
        avg_interactions = np.abs(interaction_values).mean(axis=0)
        
        # Extraer triángulo superior (sin diagonal)
        n_features = len(feature_names)
        interactions = []
        
        for i in range(n_features):
            for j in range(i+1, n_features):
                interactions.append({
                    'feature_1': feature_names[i],
                    'feature_2': feature_names[j],
                    'interaction_strength': avg_interactions[i, j]
                })
        
        interactions_df = pd.DataFrame(interactions).sort_values(
            'interaction_strength',
            ascending=False
        ).head(top_k)
        
        return interactions_df
    
    def plot_summary(
        self,
        shap_values: np.ndarray,
        X: pd.DataFrame,
        max_display: int = 20,
        save_path: Optional[str] = None
    ):
        """
        Crea summary plot de SHAP
        
        Args:
            shap_values: Valores SHAP
            X: Features
            max_display: Número máximo de características a mostrar
            save_path: Ruta para guardar la figura
        """
        plt.figure(figsize=(12, 8))
        shap.summary_plot(
            shap_values,
            X,
            max_display=max_display,
            show=False
        )
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            logger.info(f"Summary plot guardado en: {save_path}")
        
        plt.close()
    
    def plot_dependence(
        self,
        feature: str,
        shap_values: np.ndarray,
        X: pd.DataFrame,
        interaction_feature: Optional[str] = None,
        save_path: Optional[str] = None
    ):
        """
        Crea dependence plot para una característica
        
        Args:
            feature: Característica principal
            shap_values: Valores SHAP
            X: Features
            interaction_feature: Característica de interacción
            save_path: Ruta para guardar
        """
        plt.figure(figsize=(10, 6))
        shap.dependence_plot(
            feature,
            shap_values,
            X,
            interaction_index=interaction_feature,
            show=False
        )
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            logger.info(f"Dependence plot guardado en: {save_path}")
        
        plt.close()
    
    def plot_waterfall(
        self,
        instance_explanation: Dict,
        save_path: Optional[str] = None
    ):
        """
        Crea waterfall plot para una instancia
        
        Args:
            instance_explanation: Explicación de instancia
            save_path: Ruta para guardar
        """
        shap_values = instance_explanation['shap_values']
        base_value = instance_explanation.get('base_value', 0)
        
        plt.figure(figsize=(10, 8))
        
        # Crear Explanation object para waterfall plot
        explanation = shap.Explanation(
            values=shap_values,
            base_values=base_value if base_value is not None else 0
        )
        
        shap.plots.waterfall(explanation, show=False)
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            logger.info(f"Waterfall plot guardado en: {save_path}")
        
        plt.close()
    
    def explain_bias_decomposition(
        self,
        X: pd.DataFrame,
        protected_attribute: str,
        shap_values: np.ndarray
    ) -> Dict:
        """
        Descompone el sesgo usando valores SHAP
        
        Args:
            X: Features
            protected_attribute: Atributo protegido
            shap_values: Valores SHAP
            
        Returns:
            Diccionario con descomposición de sesgo
        """
        # Separar grupos
        protected_group = X[protected_attribute] == 1
        reference_group = X[protected_attribute] == 0
        
        # SHAP promedio por grupo
        shap_protected = shap_values[protected_group].mean(axis=0)
        shap_reference = shap_values[reference_group].mean(axis=0)
        
        # Diferencia
        shap_difference = shap_protected - shap_reference
        
        # Crear DataFrame explicativo
        feature_names = X.columns
        bias_decomp = pd.DataFrame({
            'feature': feature_names,
            'shap_protected': shap_protected,
            'shap_reference': shap_reference,
            'shap_difference': shap_difference,
            'abs_contribution': np.abs(shap_difference)
        }).sort_values('abs_contribution', ascending=False)
        
        return {
            'decomposition': bias_decomp,
            'total_bias': shap_difference.sum(),
            'top_contributors': bias_decomp.head(10)
        }


def compare_shap_stability(
    explainer: SHAPExplainer,
    X_instance: pd.DataFrame,
    n_trials: int = 10,
    noise_level: float = 0.01
) -> Dict:
    """
    Evalúa la estabilidad de las explicaciones SHAP
    
    Args:
        explainer: Explicador SHAP
        X_instance: Instancia a evaluar
        n_trials: Número de pruebas
        noise_level: Nivel de ruido a añadir
        
    Returns:
        Métricas de estabilidad
    """
    shap_values_trials = []
    
    for _ in range(n_trials):
        # Añadir ruido pequeño
        X_noisy = X_instance + np.random.normal(0, noise_level, X_instance.shape)
        shap_vals = explainer.explain(X_noisy)
        shap_values_trials.append(shap_vals[0])
    
    shap_values_trials = np.array(shap_values_trials)
    
    # Calcular estabilidad
    std_per_feature = shap_values_trials.std(axis=0)
    mean_std = std_per_feature.mean()
    max_std = std_per_feature.max()
    
    return {
        'mean_std': mean_std,
        'max_std': max_std,
        'std_per_feature': std_per_feature,
        'stability_score': 1 / (1 + mean_std)  # Score normalizado
    }