"""Módulo de explicabilidad (XAI)"""

from .shap_explainer import SHAPExplainer, compare_shap_stability
from .lime_explainer import LIMEExplainer, LIMEEvaluator, benchmark_lime_performance
from .counterfactual import DiCEGenerator, CounterfactualVisualizer, evaluate_counterfactual_robustness

__all__ = [
    'SHAPExplainer',
    'LIMEExplainer',
    'DiCEGenerator',
    'CounterfactualVisualizer',
    'compare_shap_stability',
    'LIMEEvaluator',
    'benchmark_lime_performance',
    'evaluate_counterfactual_robustness'
]