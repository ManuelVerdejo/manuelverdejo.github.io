"""
Generador de Explicaciones Contrafactuales con DiCE
(Diverse Counterfactual Explanations)
"""

import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Optional, Tuple
from sklearn.neighbors import NearestNeighbors
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


class DiCEGenerator:
    """
    Generador de explicaciones contrafactuales diversas
    """
    
    def __init__(
        self,
        model,
        X_train: pd.DataFrame,
        protected_attributes: List[str] = None,
        continuous_features: List[str] = None,
        immutable_features: List[str] = None
    ):
        """
        Inicializa el generador DiCE
        
        Args:
            model: Modelo entrenado
            X_train: Datos de entrenamiento
            protected_attributes: Atributos protegidos (inmutables)
            continuous_features: Features continuas
            immutable_features: Features que no pueden cambiar
        """
        self.model = model
        self.X_train = X_train
        self.feature_names = list(X_train.columns)
        
        # Configurar atributos inmutables
        self.immutable_features = immutable_features or []
        if protected_attributes:
            self.immutable_features.extend(protected_attributes)
        
        # Identificar features continuas vs categóricas
        if continuous_features:
            self.continuous_features = continuous_features
        else:
            self.continuous_features = list(X_train.select_dtypes(include=[np.number]).columns)
        
        # Calcular estadísticas para generación
        self._compute_feature_statistics()
        
        logger.info(f"DiCE Generator inicializado con {len(self.feature_names)} features")
        logger.info(f"Features inmutables: {self.immutable_features}")
    
    def _compute_feature_statistics(self):
        """Calcula estadísticas de features para generación"""
        self.feature_stats = {}
        
        for feature in self.feature_names:
            if feature in self.continuous_features:
                self.feature_stats[feature] = {
                    'type': 'continuous',
                    'mean': self.X_train[feature].mean(),
                    'std': self.X_train[feature].std(),
                    'min': self.X_train[feature].min(),
                    'max': self.X_train[feature].max(),
                    'median': self.X_train[feature].median()
                }
            else:
                self.feature_stats[feature] = {
                    'type': 'categorical',
                    'values': self.X_train[feature].unique().tolist()
                }
    
    def generate(
        self,
        X_instance: pd.DataFrame,
        total_CFs: int = 10,
        desired_class: str = 'opposite',
        proximity_weight: float = 0.5,
        diversity_weight: float = 0.3,
        sparsity_weight: float = 0.2,
        max_iterations: int = 1000,
        learning_rate: float = 0.01
    ) -> List[Dict]:
        """
        Genera explicaciones contrafactuales diversas
        
        Args:
            X_instance: Instancia a explicar
            total_CFs: Número de contrafactuales a generar
            desired_class: Clase deseada ('opposite' o valor específico)
            proximity_weight: Peso para proximidad
            diversity_weight: Peso para diversidad
            sparsity_weight: Peso para sparsity
            max_iterations: Iteraciones máximas
            learning_rate: Tasa de aprendizaje
            
        Returns:
            Lista de contrafactuales
        """
        logger.info(f"Generando {total_CFs} contrafactuales...")
        
        # Obtener predicción original
        original_pred = self.model.predict_proba(X_instance)[0]
        original_class = int(original_pred > 0.5)
        
        # Determinar clase objetivo
        if desired_class == 'opposite':
            target_class = 1 - original_class
        else:
            target_class = int(desired_class)
        
        logger.info(f"Clase original: {original_class}, Clase objetivo: {target_class}")
        
        # Generar contrafactuales usando diferentes estrategias
        counterfactuals = []
        
        # Estrategia 1: Búsqueda en vecindario
        cf_neighborhood = self._generate_by_neighborhood(
            X_instance,
            target_class,
            n_candidates=total_CFs
        )
        counterfactuals.extend(cf_neighborhood)
        
        # Estrategia 2: Optimización gradiente
        if len(counterfactuals) < total_CFs:
            cf_gradient = self._generate_by_gradient(
                X_instance,
                target_class,
                n_samples=total_CFs - len(counterfactuals),
                max_iterations=max_iterations,
                learning_rate=learning_rate
            )
            counterfactuals.extend(cf_gradient)
        
        # Estrategia 3: Muestreo genético
        if len(counterfactuals) < total_CFs:
            cf_genetic = self._generate_by_genetic(
                X_instance,
                target_class,
                n_samples=total_CFs - len(counterfactuals)
            )
            counterfactuals.extend(cf_genetic)
        
        # Seleccionar los mejores contrafactuales
        counterfactuals = self._select_diverse_counterfactuals(
            X_instance,
            counterfactuals,
            total_CFs,
            proximity_weight,
            diversity_weight,
            sparsity_weight
        )
        
        logger.info(f"{len(counterfactuals)} contrafactuales generados exitosamente")
        
        return counterfactuals
    
    def _generate_by_neighborhood(
        self,
        X_instance: pd.DataFrame,
        target_class: int,
        n_candidates: int = 10
    ) -> List[Dict]:
        """Genera contrafactuales buscando en el vecindario"""
        # Encontrar instancias de la clase objetivo
        target_mask = self.model.predict(self.X_train) == target_class
        X_target = self.X_train[target_mask]
        
        if len(X_target) == 0:
            logger.warning("No hay instancias de la clase objetivo en training")
            return []
        
        # Encontrar vecinos más cercanos
        nn = NearestNeighbors(n_neighbors=min(n_candidates * 2, len(X_target)))
        nn.fit(X_target)
        
        distances, indices = nn.kneighbors(X_instance)
        
        counterfactuals = []
        for idx in indices[0]:
            cf = X_target.iloc[idx].to_dict()
            
            # Aplicar restricciones de inmutabilidad
            for feature in self.immutable_features:
                if feature in cf:
                    cf[feature] = X_instance[feature].values[0]
            
            cf_df = pd.DataFrame([cf])
            pred = self.model.predict_proba(cf_df)[0]
            
            if (pred > 0.5 and target_class == 1) or (pred <= 0.5 and target_class == 0):
                counterfactuals.append({
                    'values': cf,
                    'prediction': pred,
                    'method': 'neighborhood'
                })
            
            if len(counterfactuals) >= n_candidates:
                break
        
        return counterfactuals
    
    def _generate_by_gradient(
        self,
        X_instance: pd.DataFrame,
        target_class: int,
        n_samples: int = 3,
        max_iterations: int = 1000,
        learning_rate: float = 0.01
    ) -> List[Dict]:
        """Genera contrafactuales mediante optimización por gradiente"""
        counterfactuals = []
        
        for sample_idx in range(n_samples):
            # Inicializar con la instancia original + ruido
            X_cf = X_instance.values.copy()
            X_cf = X_cf + np.random.normal(0, 0.1, X_cf.shape)
            
            for iteration in range(max_iterations):
                # Predicción actual
                X_cf_df = pd.DataFrame(X_cf, columns=self.feature_names)
                pred = self.model.predict_proba(X_cf_df)[0]
                
                # Si ya alcanzamos la clase objetivo, terminar
                if (pred > 0.5 and target_class == 1) or (pred <= 0.5 and target_class == 0):
                    break
                
                # Aproximar gradiente numéricamente
                gradient = self._numerical_gradient(X_cf, target_class)
                
                # Actualizar solo features mutables
                for i, feature in enumerate(self.feature_names):
                    if feature not in self.immutable_features:
                        X_cf[0, i] -= learning_rate * gradient[i]
                        
                        # Aplicar límites
                        if feature in self.continuous_features:
                            stats = self.feature_stats[feature]
                            X_cf[0, i] = np.clip(X_cf[0, i], stats['min'], stats['max'])
            
            # Validar contrafactual
            X_cf_df = pd.DataFrame(X_cf, columns=self.feature_names)
            pred = self.model.predict_proba(X_cf_df)[0]
            
            if (pred > 0.5 and target_class == 1) or (pred <= 0.5 and target_class == 0):
                counterfactuals.append({
                    'values': X_cf_df.iloc[0].to_dict(),
                    'prediction': pred,
                    'method': 'gradient'
                })
        
        return counterfactuals
    
    def _numerical_gradient(self, X: np.ndarray, target_class: int, epsilon: float = 1e-4) -> np.ndarray:
        """Calcula gradiente numérico"""
        gradient = np.zeros(X.shape[1])
        
        X_df = pd.DataFrame(X, columns=self.feature_names)
        base_pred = self.model.predict_proba(X_df)[0]
        
        for i in range(X.shape[1]):
            X_plus = X.copy()
            X_plus[0, i] += epsilon
            X_plus_df = pd.DataFrame(X_plus, columns=self.feature_names)
            pred_plus = self.model.predict_proba(X_plus_df)[0]
            
            # Gradiente en dirección del objetivo
            if target_class == 1:
                gradient[i] = (pred_plus - base_pred) / epsilon
            else:
                gradient[i] = -(pred_plus - base_pred) / epsilon
        
        return gradient
    
    def _generate_by_genetic(
        self,
        X_instance: pd.DataFrame,
        target_class: int,
        n_samples: int = 2,
        population_size: int = 50,
        n_generations: int = 100
    ) -> List[Dict]:
        """Genera contrafactuales usando algoritmo genético"""
        counterfactuals = []
        
        # Inicializar población
        population = []
        for _ in range(population_size):
            individual = X_instance.values.copy()
            
            # Mutar features mutables
            for i, feature in enumerate(self.feature_names):
                if feature not in self.immutable_features:
                    if feature in self.continuous_features:
                        stats = self.feature_stats[feature]
                        individual[0, i] += np.random.normal(0, stats['std'] * 0.3)
                        individual[0, i] = np.clip(individual[0, i], stats['min'], stats['max'])
            
            population.append(individual)
        
        # Evolucionar
        for generation in range(n_generations):
            # Evaluar fitness
            fitness_scores = []
            for individual in population:
                ind_df = pd.DataFrame(individual, columns=self.feature_names)
                pred = self.model.predict_proba(ind_df)[0]
                
                # Fitness: proximidad a clase objetivo + proximidad a original
                if target_class == 1:
                    class_fitness = pred
                else:
                    class_fitness = 1 - pred
                
                distance = np.linalg.norm(individual - X_instance.values)
                proximity_fitness = 1 / (1 + distance)
                
                fitness = 0.7 * class_fitness + 0.3 * proximity_fitness
                fitness_scores.append(fitness)
            
            # Selección y reproducción
            fitness_scores = np.array(fitness_scores)
            top_indices = np.argsort(fitness_scores)[-population_size//2:]
            
            new_population = [population[i] for i in top_indices]
            
            # Crossover y mutación
            while len(new_population) < population_size:
                parent1 = new_population[np.random.randint(len(new_population))]
                parent2 = new_population[np.random.randint(len(new_population))]
                
                child = parent1.copy()
                for i in range(child.shape[1]):
                    if np.random.random() < 0.5:
                        child[0, i] = parent2[0, i]
                
                new_population.append(child)
            
            population = new_population
        
        # Seleccionar mejores individuos
        for individual in population[:n_samples]:
            ind_df = pd.DataFrame(individual, columns=self.feature_names)
            pred = self.model.predict_proba(ind_df)[0]
            
            if (pred > 0.5 and target_class == 1) or (pred <= 0.5 and target_class == 0):
                counterfactuals.append({
                    'values': ind_df.iloc[0].to_dict(),
                    'prediction': pred,
                    'method': 'genetic'
                })
        
        return counterfactuals
    
    def _select_diverse_counterfactuals(
        self,
        X_instance: pd.DataFrame,
        candidates: List[Dict],
        n_select: int,
        proximity_weight: float,
        diversity_weight: float,
        sparsity_weight: float
    ) -> List[Dict]:
        """Selecciona contrafactuales diversos basado en múltiples criterios"""
        if len(candidates) <= n_select:
            return candidates
        
        # Calcular scores para cada candidato
        scores = []
        for cf in candidates:
            cf_values = pd.DataFrame([cf['values']])
            
            # Proximidad: distancia a la instancia original
            distance = np.linalg.norm(cf_values.values - X_instance.values)
            proximity_score = 1 / (1 + distance)
            
            # Sparsity: número de features cambiadas
            n_changes = np.sum(cf_values.values != X_instance.values)
            sparsity_score = 1 / (1 + n_changes)
            
            # Score total
            total_score = (
                proximity_weight * proximity_score +
                sparsity_weight * sparsity_score
            )
            
            scores.append(total_score)
        
        # Selección diversa usando algoritmo greedy
        selected_indices = []
        selected_indices.append(np.argmax(scores))
        
        while len(selected_indices) < n_select:
            best_score = -np.inf
            best_idx = None
            
            for i, cf in enumerate(candidates):
                if i in selected_indices:
                    continue
                
                # Calcular diversidad con respecto a los ya seleccionados
                min_diversity = np.inf
                for sel_idx in selected_indices:
                    sel_cf = candidates[sel_idx]
                    cf_vals = pd.DataFrame([cf['values']]).values
                    sel_vals = pd.DataFrame([sel_cf['values']]).values
                    diversity = np.linalg.norm(cf_vals - sel_vals)
                    min_diversity = min(min_diversity, diversity)
                
                # Score combinado
                combined_score = scores[i] + diversity_weight * min_diversity
                
                if combined_score > best_score:
                    best_score = combined_score
                    best_idx = i
            
            if best_idx is not None:
                selected_indices.append(best_idx)
        
        return [candidates[i] for i in selected_indices]
    
    def evaluate_quality(self, counterfactuals: List[Dict]) -> Dict:
        """
        Evalúa la calidad de los contrafactuales generados
        
        Args:
            counterfactuals: Lista de contrafactuales
            
        Returns:
            Métricas de calidad
        """
        if not counterfactuals:
            return {'error': 'No counterfactuals provided'}
        
        # Métricas de proximidad
        proximities = []
        sparsities = []
        feasibilities = []
        
        for cf in counterfactuals:
            cf_df = pd.DataFrame([cf['values']])
            
            # Calcular cambios
            changes = self._compute_changes(cf['values'])
            
            # Proximidad
            distance = np.sum([abs(c['delta']) for c in changes])
            proximities.append(distance)
            
            # Sparsity
            n_changes = len(changes)
            sparsities.append(n_changes)
            
            # Feasibilidad (simulada)
            feasibility = self._evaluate_feasibility(changes)
            feasibilities.append(feasibility)
        
        # Diversidad entre contrafactuales
        diversity = self._compute_diversity(counterfactuals)
        
        return {
            'mean_proximity': np.mean(proximities),
            'mean_sparsity': np.mean(sparsities),
            'mean_feasibility': np.mean(feasibilities),
            'diversity_score': diversity,
            'n_counterfactuals': len(counterfactuals),
            'validity_rate': sum([cf['prediction'] > 0.5 for cf in counterfactuals]) / len(counterfactuals)
        }
    
    def _compute_changes(self, cf_values: Dict) -> List[Dict]:
        """Calcula los cambios realizados"""
        changes = []
        
        for feature in self.feature_names:
            if feature not in self.immutable_features:
                original = self.X_train[feature].iloc[0]  # Simplificado
                new_value = cf_values[feature]
                
                if original != new_value:
                    changes.append({
                        'feature': feature,
                        'from': original,
                        'to': new_value,
                        'delta': new_value - original if feature in self.continuous_features else 1
                    })
        
        return changes
    
    def _evaluate_feasibility(self, changes: List[Dict]) -> float:
        """
        Evalúa la factibilidad de los cambios
        
        Args:
            changes: Lista de cambios
            
        Returns:
            Score de factibilidad (0-6)
        """
        # Factibilidad basada en:
        # 1. Número de cambios (menos es más factible)
        # 2. Magnitud de cambios
        # 3. Tipo de features modificadas
        
        if not changes:
            return 6.0
        
        n_changes = len(changes)
        feasibility = 6.0
        
        # Penalizar por número de cambios
        feasibility -= min(n_changes * 0.3, 2.0)
        
        # Penalizar por magnitud de cambios
        for change in changes:
            if change['feature'] in self.continuous_features:
                stats = self.feature_stats[change['feature']]
                normalized_change = abs(change['delta']) / (stats['max'] - stats['min'])
                feasibility -= min(normalized_change * 1.5, 1.0)
        
        return max(feasibility, 1.0)
    
    def _compute_diversity(self, counterfactuals: List[Dict]) -> float:
        """Calcula la diversidad entre contrafactuales"""
        if len(counterfactuals) <= 1:
            return 0.0
        
        distances = []
        for i in range(len(counterfactuals)):
            for j in range(i+1, len(counterfactuals)):
                cf1 = pd.DataFrame([counterfactuals[i]['values']]).values
                cf2 = pd.DataFrame([counterfactuals[j]['values']]).values
                distance = np.linalg.norm(cf1 - cf2)
                distances.append(distance)
        
        return np.mean(distances) if distances else 0.0
    
    def compute_cfi(self, counterfactuals: List[Dict]) -> List[Dict]:
        """
        Calcula Counterfactual Feature Importance (CFI)
        Similar a valores de Shapley pero para contrafactuales
        
        Args:
            counterfactuals: Lista de contrafactuales
            
        Returns:
            CFI scores para cada contrafactual
        """
        cfi_results = []
        
        for cf in counterfactuals:
            changes = self._compute_changes(cf['values'])
            
            if not changes:
                cfi_results.append([])
                continue
            
            # Calcular importancia de cada cambio
            cf_importances = []
            
            for change in changes:
                # Simular remover este cambio
                modified_cf = cf['values'].copy()
                modified_cf[change['feature']] = change['from']
                
                modified_df = pd.DataFrame([modified_cf])
                pred_without_change = self.model.predict_proba(modified_df)[0]
                
                # Importancia = cambio en predicción
                importance = abs(cf['prediction'] - pred_without_change)
                
                cf_importances.append({
                    'feature': change['feature'],
                    'importance': importance,
                    'delta': change['delta']
                })
            
            # Normalizar importancias
            total_importance = sum([ci['importance'] for ci in cf_importances])
            if total_importance > 0:
                for ci in cf_importances:
                    ci['importance'] /= total_importance
            
            # Ordenar por importancia
            cf_importances.sort(key=lambda x: x['importance'], reverse=True)
            
            cfi_results.append(cf_importances)
        
        return cfi_results
    
    def generate_recourse_path(
        self,
        X_instance: pd.DataFrame,
        counterfactual: Dict,
        n_steps: int = 5
    ) -> List[Dict]:
        """
        Genera un camino de recurso gradual desde la instancia original
        hasta el contrafactual
        
        Args:
            X_instance: Instancia original
            counterfactual: Contrafactual objetivo
            n_steps: Número de pasos intermedios
            
        Returns:
            Lista de estados intermedios
        """
        path = []
        
        original_values = X_instance.iloc[0].to_dict()
        cf_values = counterfactual['values']
        
        for step in range(n_steps + 1):
            alpha = step / n_steps
            
            intermediate = {}
            for feature in self.feature_names:
                if feature in self.continuous_features:
                    intermediate[feature] = (
                        (1 - alpha) * original_values[feature] +
                        alpha * cf_values[feature]
                    )
                else:
                    # Para categóricas, cambiar en el paso final
                    intermediate[feature] = (
                        cf_values[feature] if alpha >= 0.5 
                        else original_values[feature]
                    )
            
            # Predecir en este punto
            intermediate_df = pd.DataFrame([intermediate])
            pred = self.model.predict_proba(intermediate_df)[0]
            
            path.append({
                'step': step,
                'values': intermediate,
                'prediction': pred,
                'progress': alpha
            })
        
        return path


class CounterfactualVisualizer:
    """
    Visualizador especializado para explicaciones contrafactuales
    """
    
    @staticmethod
    def plot_counterfactual_comparison(
        original: pd.DataFrame,
        counterfactuals: List[Dict],
        feature_names: List[str],
        save_path: Optional[str] = None
    ):
        """
        Visualiza comparación entre original y contrafactuales
        """
        import matplotlib.pyplot as plt
        
        n_cf = len(counterfactuals)
        fig, axes = plt.subplots(1, n_cf + 1, figsize=(4 * (n_cf + 1), 6))
        
        if n_cf == 0:
            axes = [axes]
        
        # Plot original
        original_vals = original.iloc[0].values
        axes[0].barh(feature_names, original_vals)
        axes[0].set_title('Original')
        axes[0].set_xlabel('Valor')
        
        # Plot contrafactuales
        for i, cf in enumerate(counterfactuals):
            cf_vals = [cf['values'][f] for f in feature_names]
            axes[i+1].barh(feature_names, cf_vals)
            axes[i+1].set_title(f'CF {i+1}\n(pred: {cf["prediction"]:.2f})')
            axes[i+1].set_xlabel('Valor')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            plt.close()
        else:
            plt.show()
    
    @staticmethod
    def plot_recourse_path(
        recourse_path: List[Dict],
        key_features: List[str],
        save_path: Optional[str] = None
    ):
        """
        Visualiza el camino de recurso gradual
        """
        import matplotlib.pyplot as plt
        
        steps = [p['step'] for p in recourse_path]
        predictions = [p['prediction'] for p in recourse_path]
        
        fig, axes = plt.subplots(len(key_features) + 1, 1, figsize=(12, 3 * (len(key_features) + 1)))
        
        # Plot predicción
        axes[0].plot(steps, predictions, 'o-', linewidth=2, markersize=8)
        axes[0].set_ylabel('Predicción')
        axes[0].set_title('Evolución de la Predicción')
        axes[0].axhline(y=0.5, color='r', linestyle='--', alpha=0.5)
        axes[0].grid(True, alpha=0.3)
        
        # Plot features clave
        for i, feature in enumerate(key_features):
            feature_values = [p['values'][feature] for p in recourse_path]
            axes[i+1].plot(steps, feature_values, 'o-', linewidth=2, markersize=8)
            axes[i+1].set_ylabel(feature)
            axes[i+1].grid(True, alpha=0.3)
        
        axes[-1].set_xlabel('Paso')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            plt.close()
        else:
            plt.show()


def evaluate_counterfactual_robustness(
    dice_generator: DiCEGenerator,
    X_instance: pd.DataFrame,
    n_trials: int = 10
) -> Dict:
    """
    Evalúa la robustez de los contrafactuales generados
    
    Args:
        dice_generator: Generador DiCE
        X_instance: Instancia
        n_trials: Número de trials
        
    Returns:
        Métricas de robustez
    """
    all_counterfactuals = []
    
    for _ in range(n_trials):
        cfs = dice_generator.generate(X_instance, total_CFs=3)
        all_counterfactuals.extend(cfs)
    
    if not all_counterfactuals:
        return {'error': 'No counterfactuals generated'}
    
    # Analizar consistencia
    feature_changes = {}
    for cf in all_counterfactuals:
        changes = dice_generator._compute_changes(cf['values'])
        for change in changes:
            feature = change['feature']
            if feature not in feature_changes:
                feature_changes[feature] = []
            feature_changes[feature].append(change['delta'])
    
    # Calcular varianza de cambios
    variance_scores = {}
    for feature, deltas in feature_changes.items():
        variance_scores[feature] = np.std(deltas)
    
    return {
        'n_total_generated': len(all_counterfactuals),
        'mean_variance': np.mean(list(variance_scores.values())),
        'max_variance': np.max(list(variance_scores.values())),
        'consistency_score': 1 / (1 + np.mean(list(variance_scores.values())))
    }