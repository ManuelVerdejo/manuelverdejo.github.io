"""
Explicador LIME (Local Interpretable Model-agnostic Explanations)
Implementación con evaluación de estabilidad y fidelidad
"""

import numpy as np
import pandas as pd
from lime import lime_tabular
import logging
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


class LIMEExplainer:
    """
    Explicador LIME con funcionalidades extendidas
    """
    
    def __init__(
        self,
        model,
        X_train: pd.DataFrame,
        mode: str = 'classification',
        feature_names: Optional[List[str]] = None,
        categorical_features: Optional[List[int]] = None,
        discretize_continuous: bool = True
    ):
        """
        Inicializa el explicador LIME
        
        Args:
            model: Modelo entrenado
            X_train: Datos de entrenamiento (para estadísticas)
            mode: 'classification' o 'regression'
            feature_names: Nombres de características
            categorical_features: Índices de features categóricas
            discretize_continuous: Discretizar features continuas
        """
        self.model = model
        self.mode = mode
        
        if feature_names is None:
            if isinstance(X_train, pd.DataFrame):
                feature_names = list(X_train.columns)
            else:
                feature_names = [f'feature_{i}' for i in range(X_train.shape[1])]
        
        self.feature_names = feature_names
        
        # Crear explicador LIME
        self.explainer = lime_tabular.LimeTabularExplainer(
            training_data=X_train.values if isinstance(X_train, pd.DataFrame) else X_train,
            mode=mode,
            feature_names=feature_names,
            categorical_features=categorical_features,
            discretize_continuous=discretize_continuous,
            random_state=42
        )
        
        logger.info(f"LIME Explainer inicializado ({mode})")
    
    def explain_instance(
        self,
        X_instance: pd.Series,
        num_features: int = 100,
        num_samples: int = 500
    ):
        """
        Explica una instancia individual
        
        Args:
            X_instance: Instancia a explicar
            num_features: Número de features en la explicación
            num_samples: Número de muestras para perturbación
            
        Returns:
            Objeto de explicación LIME
        """
        # Convertir a numpy array
        if isinstance(X_instance, pd.Series):
            X_instance_np = X_instance.values
        else:
            X_instance_np = X_instance
        
        # Función de predicción
        if self.mode == 'classification':
            predict_fn = lambda x: np.column_stack([
                1 - self.model.predict_proba(x),
                self.model.predict_proba(x)
            ])
        else:
            predict_fn = self.model.predict
        
        # Generar explicación
        explanation = self.explainer.explain_instance(
            data_row=X_instance_np,
            predict_fn=predict_fn,
            num_features=num_features,
            num_samples=num_samples
        )
        
        return explanation
    
    def extract_feature_contributions(self, explanation) -> pd.DataFrame:
        """
        Extrae contribuciones de features de una explicación LIME
        
        Args:
            explanation: Objeto de explicación LIME
            
        Returns:
            DataFrame con contribuciones
        """
        # Obtener pares (feature_id, contribution)
        if self.mode == 'classification':
            feature_weights = explanation.as_list(label=1)
        else:
            feature_weights = explanation.as_list()
        
        contributions = []
        for feature_desc, weight in feature_weights:
            # Extraer nombre de feature de la descripción
            feature_name = feature_desc.split('<=')[0].split('>')[0].split('=')[0].strip()
            contributions.append({
                'feature': feature_name,
                'contribution': weight,
                'abs_contribution': abs(weight)
            })
        
        return pd.DataFrame(contributions).sort_values('abs_contribution', ascending=False)
    
    def batch_explain(
        self,
        X: pd.DataFrame,
        num_features: int = 100,
        num_samples: int = 500
    ) -> List[Dict]:
        """
        Explica múltiples instancias
        
        Args:
            X: DataFrame con instancias
            num_features: Número de features por explicación
            num_samples: Muestras para perturbación
            
        Returns:
            Lista de explicaciones
        """
        logger.info(f"Explicando {len(X)} instancias con LIME...")
        
        explanations = []
        for idx, (_, row) in enumerate(X.iterrows()):
            if idx % 100 == 0:
                logger.info(f"Procesando instancia {idx}/{len(X)}")
            
            exp = self.explain_instance(row, num_features, num_samples)
            contributions = self.extract_feature_contributions(exp)
            
            explanations.append({
                'index': idx,
                'explanation': exp,
                'contributions': contributions
            })
        
        logger.info("Explicaciones LIME completadas")
        return explanations
    
    def evaluate_fidelity(
        self,
        X_instance: pd.Series,
        explanation,
        n_samples: int = 300
    ) -> float:
        """
        Evalúa la fidelidad de una explicación LIME
        
        Args:
            X_instance: Instancia explicada
            explanation: Explicación LIME
            n_samples: Muestras para evaluación
            
        Returns:
            Score de fidelidad
        """
        # Obtener predicción original
        X_np = X_instance.values.reshape(1, -1)
        original_pred = self.model.predict_proba(X_np)[0]
        
        # Obtener modelo local de LIME
        local_model = explanation.local_pred
        
        # Fidelidad = qué tan bien el modelo local aproxima el modelo original
        # en el vecindario de la instancia
        
        # Generar muestras en el vecindario
        samples = self._generate_neighborhood_samples(X_instance, n_samples)
        
        # Predicciones del modelo original
        original_preds = self.model.predict_proba(samples)
        
        # Predicciones del modelo local (aproximadas)
        # Nota: LIME no expone directamente el modelo local, usamos R² como proxy
        fidelity_score = explanation.score
        
        return fidelity_score
    
    def _generate_neighborhood_samples(
        self,
        X_instance: pd.Series,
        n_samples: int
    ) -> np.ndarray:
        """
        Genera muestras en el vecindario de una instancia
        
        Args:
            X_instance: Instancia central
            n_samples: Número de muestras
            
        Returns:
            Array de muestras
        """
        X_np = X_instance.values
        std = np.std(X_np) * 0.1  # 10% de desviación estándar
        
        samples = np.random.normal(
            loc=X_np,
            scale=std,
            size=(n_samples, len(X_np))
        )
        
        return samples
    
    def evaluate_stability(
        self,
        X_instance: pd.Series,
        n_trials: int = 50,
        num_features: int = 50
    ) -> Dict:
        """
        Evalúa la estabilidad de las explicaciones LIME
        
        Args:
            X_instance: Instancia a evaluar
            n_trials: Número de trials
            num_features: Número de features
            
        Returns:
            Métricas de estabilidad
        """
        explanations = []
        
        for _ in range(n_trials):
            exp = self.explain_instance(X_instance, num_features)
            contributions = self.extract_feature_contributions(exp)
            explanations.append(contributions)
        
        # Calcular consistencia en top features
        top_features_per_trial = [
            set(exp.head(5)['feature'].values) for exp in explanations
        ]
        
        # Jaccard similarity entre trials
        similarities = []
        for i in range(len(top_features_per_trial)):
            for j in range(i+1, len(top_features_per_trial)):
                intersection = len(top_features_per_trial[i] & top_features_per_trial[j])
                union = len(top_features_per_trial[i] | top_features_per_trial[j])
                similarities.append(intersection / union if union > 0 else 0)
        
        avg_similarity = np.mean(similarities) if similarities else 0
        
        # Varianza en los pesos
        all_contributions = pd.concat(explanations)
        variance_per_feature = all_contributions.groupby('feature')['contribution'].std()
        
        return {
            'average_jaccard_similarity': avg_similarity,
            'stability_score': avg_similarity,
            'weight_variance': variance_per_feature.mean(),
            'max_weight_variance': variance_per_feature.max()
        }
    
    def compare_with_shap(
        self,
        X_instance: pd.Series,
        shap_values: np.ndarray,
        top_k: int = 10
    ) -> Dict:
        """
        Compara explicaciones LIME con SHAP
        
        Args:
            X_instance: Instancia explicada
            shap_values: Valores SHAP para la instancia
            top_k: Top features a comparar
            
        Returns:
            Métricas de comparación
        """
        # Explicación LIME
        lime_exp = self.explain_instance(X_instance, num_features=top_k)
        lime_contrib = self.extract_feature_contributions(lime_exp)
        
        # Top features de cada método
        lime_top = set(lime_contrib.head(top_k)['feature'].values)
        
        shap_importance = pd.DataFrame({
            'feature': self.feature_names,
            'shap_value': shap_values,
            'abs_shap': np.abs(shap_values)
        }).sort_values('abs_shap', ascending=False)
        
        shap_top = set(shap_importance.head(top_k)['feature'].values)
        
        # Jaccard similarity
        intersection = len(lime_top & shap_top)
        union = len(lime_top | shap_top)
        jaccard = intersection / union if union > 0 else 0
        
        # Sign agreement (para features comunes)
        common_features = lime_top & shap_top
        sign_agreements = []
        
        for feature in common_features:
            lime_sign = np.sign(lime_contrib[lime_contrib['feature'] == feature]['contribution'].values[0])
            shap_sign = np.sign(shap_importance[shap_importance['feature'] == feature]['shap_value'].values[0])
            sign_agreements.append(lime_sign == shap_sign)
        
        sign_agreement = np.mean(sign_agreements) if sign_agreements else 0
        
        return {
            'jaccard_similarity': jaccard,
            'sign_agreement': sign_agreement,
            'lime_top_features': lime_top,
            'shap_top_features': shap_top,
            'common_features': common_features
        }
    
    def visualize_explanation(
        self,
        explanation,
        save_path: Optional[str] = None
    ):
        """
        Visualiza una explicación LIME
        
        Args:
            explanation: Objeto de explicación LIME
            save_path: Ruta para guardar
        """
        import matplotlib.pyplot as plt
        
        fig = explanation.as_pyplot_figure(label=1 if self.mode == 'classification' else None)
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            logger.info(f"Visualización LIME guardada en: {save_path}")
            plt.close()
        else:
            plt.show()


class LIMEEvaluator:
    """
    Evaluador especializado para análisis de calidad LIME
    """
    
    @staticmethod
    def compute_consistency_metrics(
        lime_explainer: LIMEExplainer,
        X_test: pd.DataFrame,
        n_samples: int = 300
    ) -> Dict:
        """
        Computa métricas de consistencia para LIME
        
        Args:
            lime_explainer: Explicador LIME
            X_test: Datos de test
            n_samples: Número de muestras a evaluar
            
        Returns:
            Métricas de consistencia
        """
        if len(X_test) > n_samples:
            X_sample = X_test.sample(n_samples, random_state=42)
        else:
            X_sample = X_test
        
        stability_scores = []
        fidelity_scores = []
        
        for _, row in X_sample.iterrows():
            # Estabilidad
            stability = lime_explainer.evaluate_stability(row, n_trials=5)
            stability_scores.append(stability['stability_score'])
            
            # Fidelidad
            exp = lime_explainer.explain_instance(row)
            fidelity = lime_explainer.evaluate_fidelity(row, exp)
            fidelity_scores.append(fidelity)
        
        return {
            'mean_stability': np.mean(stability_scores),
            'std_stability': np.std(stability_scores),
            'mean_fidelity': np.mean(fidelity_scores),
            'std_fidelity': np.std(fidelity_scores),
            'min_stability': np.min(stability_scores),
            'max_stability': np.max(stability_scores)
        }
    
    @staticmethod
    def identify_unstable_features(
        lime_explainer: LIMEExplainer,
        X_instance: pd.Series,
        n_trials: int = 20,
        threshold: float = 0.3
    ) -> List[str]:
        """
        Identifica features con explicaciones inestables
        
        Args:
            lime_explainer: Explicador LIME
            X_instance: Instancia a analizar
            n_trials: Número de trials
            threshold: Umbral de varianza
            
        Returns:
            Lista de features inestables
        """
        explanations = []
        
        for _ in range(n_trials):
            exp = lime_explainer.explain_instance(X_instance)
            contrib = lime_explainer.extract_feature_contributions(exp)
            explanations.append(contrib)
        
        # Consolidar todas las contribuciones
        all_contrib = pd.concat(explanations)
        
        # Calcular varianza por feature
        variance = all_contrib.groupby('feature')['contribution'].std()
        
        # Identificar features inestables
        unstable = variance[variance > threshold].index.tolist()
        
        logger.info(f"Features inestables identificadas: {unstable}")
        
        return unstable


def benchmark_lime_performance(
    lime_explainer: LIMEExplainer,
    X_test: pd.DataFrame,
    n_instances: int = 100
) -> Dict:
    """
    Benchmark de rendimiento computacional de LIME
    
    Args:
        lime_explainer: Explicador LIME
        X_test: Datos de test
        n_instances: Número de instancias a evaluar
        
    Returns:
        Métricas de rendimiento
    """
    import time
    
    X_sample = X_test.sample(min(n_instances, len(X_test)), random_state=42)
    
    times = []
    for _, row in X_sample.iterrows():
        start = time.time()
        lime_explainer.explain_instance(row)
        elapsed = time.time() - start
        times.append(elapsed)
    
    return {
        'mean_time': np.mean(times),
        'median_time': np.median(times),
        'std_time': np.std(times),
        'total_time': np.sum(times),
        'explanations_per_second': 1 / np.mean(times)
    }