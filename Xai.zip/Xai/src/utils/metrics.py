"""
Métricas personalizadas para evaluación del modelo
"""

import numpy as np
from sklearn.metrics import (
    roc_auc_score, accuracy_score, precision_score,
    recall_score, f1_score, confusion_matrix,
    roc_curve, precision_recall_curve
)
from typing import Tuple


class ModelMetrics:
    """Calculador de métricas del modelo"""
    
    @staticmethod
    def auc_score(y_true: np.ndarray, y_pred_proba: np.ndarray) -> float:
        """Calcula AUC-ROC"""
        return roc_auc_score(y_true, y_pred_proba)
    
    @staticmethod
    def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula accuracy"""
        return accuracy_score(y_true, y_pred)
    
    @staticmethod
    def precision(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula precision"""
        return precision_score(y_true, y_pred, zero_division=0)
    
    @staticmethod
    def recall(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula recall"""
        return recall_score(y_true, y_pred, zero_division=0)
    
    @staticmethod
    def f1_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula F1-score"""
        return f1_score(y_true, y_pred, zero_division=0)
    
    @staticmethod
    def confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        """Calcula matriz de confusión"""
        return confusion_matrix(y_true, y_pred)
    
    @staticmethod
    def false_positive_rate(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula tasa de falsos positivos"""
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        return fp / (fp + tn) if (fp + tn) > 0 else 0.0
    
    @staticmethod
    def false_negative_rate(y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """Calcula tasa de falsos negativos"""
        tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
        return fn / (fn + tp) if (fn + tp) > 0 else 0.0
    
    @staticmethod
    def get_roc_curve(y_true: np.ndarray, y_pred_proba: np.ndarray) -> Tuple:
        """Retorna curva ROC"""
        return roc_curve(y_true, y_pred_proba)
    
    @staticmethod
    def get_pr_curve(y_true: np.ndarray, y_pred_proba: np.ndarray) -> Tuple:
        """Retorna curva Precision-Recall"""
        return precision_recall_curve(y_true, y_pred_proba)