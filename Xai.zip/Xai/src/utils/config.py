"""
Utilidades para manejo de configuración
"""

import yaml
from pathlib import Path
from typing import Any, Dict
import logging

logger = logging.getLogger(__name__)


class Config:
    """Clase para manejar configuración del proyecto"""
    
    def __init__(self, config_dict: Dict[str, Any]):
        """
        Inicializa configuración
        
        Args:
            config_dict: Diccionario con configuración
        """
        self._config = config_dict
        self._flatten_config()
    
    def _flatten_config(self):
        """Aplana la configuración para acceso fácil"""
        for key, value in self._config.items():
            if isinstance(value, dict):
                for subkey, subvalue in value.items():
                    setattr(self, f"{key}_{subkey}", subvalue)
            else:
                setattr(self, key, value)
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Obtiene valor de configuración
        
        Args:
            key: Clave a buscar
            default: Valor por defecto
            
        Returns:
            Valor de configuración
        """
        # Buscar en atributos
        if hasattr(self, key):
            return getattr(self, key)
        
        # Buscar en diccionario anidado
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    @classmethod
    def load(cls, config_path: str) -> 'Config':
        """
        Carga configuración desde archivo YAML
        
        Args:
            config_path: Ruta al archivo de configuración
            
        Returns:
            Objeto Config
        """
        path = Path(config_path)
        
        if not path.exists():
            logger.error(f"Archivo de configuración no encontrado: {config_path}")
            # Crear configuración por defecto
            return cls(cls._default_config())
        
        with open(path, 'r', encoding='utf-8') as f:
            config_dict = yaml.safe_load(f)
        
        logger.info(f"Configuración cargada desde: {config_path}")
        return cls(config_dict)
    
    @staticmethod
    def _default_config() -> Dict[str, Any]:
        """Retorna configuración por defecto"""
        return {
            'data': {
                'test_size': 0.2,
                'random_state': 42,
                'protected_attributes': ['race', 'gender']
            },
            'model': {
                'n_d': 64,
                'n_a': 64,
                'n_steps': 5,
                'max_epochs': 100,
                'patience': 15
            },
            'explainability': {
                'sample_indices': [0, 10, 50, 100],
                'num_features': 10
            },
            'fairness': {
                'thresholds': {
                    'demographic_parity': 0.10
                }
            },
            'xai_evaluation': {
                'fidelity': {
                    'n_samples': 100
                },
                'stability': {
                    'n_trials': 10,
                    'num_perturbations': 20
                }
            },
            'output': {
                'base_dir': 'output/'
            }
        }
    
    def save(self, path: str):
        """
        Guarda configuración a archivo YAML
        
        Args:
            path: Ruta donde guardar
        """
        with open(path, 'w') as f:
            yaml.dump(self._config, f, default_flow_style=False)
        
        logger.info(f"Configuración guardada en: {path}")
    
    def __repr__(self) -> str:
        return f"Config({list(self._config.keys())})"