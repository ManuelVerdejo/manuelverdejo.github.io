# Vacío o con:
"""Paquete principal del proyecto XAI"""