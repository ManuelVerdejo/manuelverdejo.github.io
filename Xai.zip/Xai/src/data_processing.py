"""
Procesador de Datos MIMIC-IV para Predicción de Mortalidad
Feature Engineering Avanzado y Preprocesamiento
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import KNNImputer
from typing import Tuple, List, Dict
import logging

logger = logging.getLogger(__name__)


class MIMICDataProcessor:
    """Procesador avanzado de datos MIMIC-IV"""
    
    def __init__(self, config):
        self.config = config
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_names = []
        self.protected_attributes = ['race', 'gender', 'insurance_type']
        
    def load_data(self) -> pd.DataFrame:
        """
        Carga datos MIMIC-IV
        
        Returns:
            DataFrame con datos crudos
        """
        logger.info("Cargando datos MIMIC-IV...")
        
        # En producción, esto cargaría desde la base de datos MIMIC-IV
        # Para este proyecto, simulamos datos realistas
        data = self._simulate_mimic_data()
        
        logger.info(f"Datos cargados: {data.shape}")
        return data
    
    def _simulate_mimic_data(self, n_samples: int = 10000) -> pd.DataFrame:
        """Simula datos realistas de MIMIC-IV"""
        np.random.seed(42)
        
        data = pd.DataFrame({
            # Demografía
            'age': np.random.normal(65, 15, n_samples).clip(18, 100),
            'gender': np.random.choice(['M', 'F'], n_samples),
            'race': np.random.choice(
                ['White', 'Black', 'Hispanic', 'Asian', 'Other'],
                n_samples,
                p=[0.6, 0.15, 0.15, 0.05, 0.05]
            ),
            
            # Signos vitales
            'heart_rate': np.random.normal(85, 20, n_samples).clip(40, 200),
            'blood_pressure_systolic': np.random.normal(130, 25, n_samples).clip(80, 220),
            'blood_pressure_diastolic': np.random.normal(75, 15, n_samples).clip(40, 140),
            'respiratory_rate': np.random.normal(18, 5, n_samples).clip(8, 40),
            'temperature': np.random.normal(37.0, 1.0, n_samples).clip(35, 41),
            'oxygen_saturation': np.random.normal(95, 5, n_samples).clip(70, 100),
            
            # Laboratorios
            'white_blood_cells': np.random.normal(10, 5, n_samples).clip(2, 30),
            'hemoglobin': np.random.normal(12, 2, n_samples).clip(6, 18),
            'platelets': np.random.normal(200, 80, n_samples).clip(20, 500),
            'creatinine': np.random.gamma(2, 0.5, n_samples).clip(0.5, 8),
            'bun': np.random.gamma(3, 5, n_samples).clip(5, 100),
            'lactate': np.random.gamma(2, 1, n_samples).clip(0.5, 15),
            'glucose': np.random.normal(120, 40, n_samples).clip(50, 400),
            
            # Scores clínicos
            'sofa_score': np.random.poisson(3, n_samples).clip(0, 15),
            'apache_ii_score': np.random.poisson(15, n_samples).clip(0, 50),
            
            # Variables socioeconómicas (potenciales proxies)
            'insurance_type': np.random.choice(
                ['Private', 'Medicare', 'Medicaid', 'Self-pay'],
                n_samples,
                p=[0.4, 0.35, 0.2, 0.05]
            ),
            'zipcode_median_income': np.random.gamma(5, 10000, n_samples).clip(20000, 150000),
            
            # Admisión
            'admission_type': np.random.choice(
                ['Emergency', 'Elective', 'Urgent'],
                n_samples,
                p=[0.6, 0.2, 0.2]
            ),
            'icu_los_days': np.random.gamma(2, 2, n_samples).clip(0.5, 30),
        })
        
        # Generar target con relaciones realistas
        mortality_risk = (
            0.05 * (data['age'] - 65) / 15 +
            0.15 * (data['creatinine'] > 2) +
            0.12 * (data['lactate'] > 3) +
            0.10 * (data['oxygen_saturation'] < 90) +
            0.08 * (data['blood_pressure_systolic'] > 160) +
            0.10 * (data['sofa_score'] > 6) +
            0.08 * (data['apache_ii_score'] > 20) +
            # Sesgo: diferentes outcomes por raza
            0.05 * (data['race'] == 'Black') +
            0.03 * (data['race'] == 'Hispanic') -
            0.02 * (data['insurance_type'] == 'Private') +
            np.random.normal(0, 0.1, n_samples)
        )
        
        data['mortality'] = (mortality_risk > np.percentile(mortality_risk, 70)).astype(int)
        
        # Introducir missing values realistas
        for col in ['creatinine', 'lactate', 'glucose', 'platelets']:
            missing_mask = np.random.random(n_samples) < 0.1
            data.loc[missing_mask, col] = np.nan
        
        logger.info(f"Datos simulados: {data.shape}, Mortalidad: {data['mortality'].mean():.2%}")
        
        return data
    
    def engineer_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Feature engineering avanzado
        
        Args:
            data: DataFrame con datos crudos
            
        Returns:
            DataFrame con features engineered
        """
        logger.info("Iniciando feature engineering...")
        
        df = data.copy()
        
        # 1. Features derivados de signos vitales
        df['shock_index'] = df['heart_rate'] / df['blood_pressure_systolic']
        df['pulse_pressure'] = df['blood_pressure_systolic'] - df['blood_pressure_diastolic']
        df['map'] = df['blood_pressure_diastolic'] + df['pulse_pressure'] / 3
        
        # 2. Features de laboratorio combinados
        df['anion_gap'] = 140 - (110 + 24)  # Simplificado
        df['bun_creatinine_ratio'] = df['bun'] / (df['creatinine'] + 0.01)
        
        # 3. Categorización de edad
        df['age_group'] = pd.cut(
            df['age'],
            bins=[0, 40, 60, 75, 100],
            labels=['young', 'middle_aged', 'elderly', 'very_elderly']
        )
        
        # 4. Flags de valores críticos
        df['critical_oxygen'] = (df['oxygen_saturation'] < 90).astype(int)
        df['critical_bp'] = (df['blood_pressure_systolic'] > 180).astype(int)
        df['critical_hr'] = ((df['heart_rate'] < 50) | (df['heart_rate'] > 120)).astype(int)
        df['elevated_lactate'] = (df['lactate'] > 2).astype(int)
        df['aki_risk'] = (df['creatinine'] > 1.5).astype(int)
        
        # 5. Interacciones importantes
        df['age_x_sofa'] = df['age'] * df['sofa_score'] / 100
        df['lactate_x_creatinine'] = df['lactate'] * df['creatinine']
        
        # 6. Features temporales (simulados)
        df['hour_of_admission'] = np.random.randint(0, 24, len(df))
        df['night_admission'] = ((df['hour_of_admission'] >= 22) | (df['hour_of_admission'] <= 6)).astype(int)
        df['weekend_admission'] = np.random.choice([0, 1], len(df), p=[0.7, 0.3])
        
        # 7. Encoding de variables categóricas
        categorical_cols = ['gender', 'race', 'insurance_type', 'admission_type', 'age_group']
        for col in categorical_cols:
            if col in df.columns:
                le = LabelEncoder()
                df[f'{col}_encoded'] = le.fit_transform(df[col].astype(str))
                self.label_encoders[col] = le
        
        logger.info(f"Feature engineering completado. Features finales: {df.shape[1]}")
        
        return df
    
    def handle_missing_values(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Maneja valores faltantes con KNN Imputer
        
        Args:
            data: DataFrame con missing values
            
        Returns:
            DataFrame sin missing values
        """
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        
        if data[numeric_cols].isnull().sum().sum() > 0:
            logger.info("Imputando valores faltantes...")
            imputer = KNNImputer(n_neighbors=5)
            data[numeric_cols] = imputer.fit_transform(data[numeric_cols])
        
        return data
    
    def identify_protected_attributes(self, data: pd.DataFrame) -> List[str]:
        """
        Identifica atributos protegidos en el dataset
        
        Args:
            data: DataFrame
            
        Returns:
            Lista de nombres de atributos protegidos
        """
        protected = []
        
        for attr in self.protected_attributes:
            if attr in data.columns:
                protected.append(attr)
        
        # Buscar columnas codificadas
        encoded_protected = [col for col in data.columns if any(p in col for p in self.protected_attributes)]
        protected.extend(encoded_protected)
        
        logger.info(f"Atributos protegidos identificados: {protected}")
        
        return protected
    
    def split_data(
        self,
        data: pd.DataFrame,
        test_size: float = 0.2,
        random_state: int = 42
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
        """
        Divide datos en train/test con estratificación
        
        Args:
            data: DataFrame completo
            test_size: Proporción de test
            random_state: Semilla aleatoria
            
        Returns:
            X_train, X_test, y_train, y_test
        """
        # Separar target
        X = data.drop('mortality', axis=1)
        y = data['mortality']
        
        # Manejar missing values
        X = self.handle_missing_values(X)
        
        # Seleccionar solo columnas numéricas para el modelo
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        X = X[numeric_cols]
        
        self.feature_names = list(X.columns)
        
        # Split estratificado
        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=test_size,
            random_state=random_state,
            stratify=y
        )
        
        # Normalización
        X_train = pd.DataFrame(
            self.scaler.fit_transform(X_train),
            columns=X_train.columns,
            index=X_train.index
        )
        
        X_test = pd.DataFrame(
            self.scaler.transform(X_test),
            columns=X_test.columns,
            index=X_test.index
        )
        
        logger.info(f"Train: {X_train.shape}, Test: {X_test.shape}")
        logger.info(f"Train mortality rate: {y_train.mean():.2%}")
        logger.info(f"Test mortality rate: {y_test.mean():.2%}")
        
        return X_train, X_test, y_train, y_test
    
    def get_feature_descriptions(self) -> Dict[str, str]:
        """Retorna descripciones de features para interpretabilidad"""
        descriptions = {
            'age': 'Edad del paciente en años',
            'heart_rate': 'Frecuencia cardíaca (latidos/min)',
            'blood_pressure_systolic': 'Presión arterial sistólica (mmHg)',
            'oxygen_saturation': 'Saturación de oxígeno (%)',
            'creatinine': 'Nivel de creatinina sérica (mg/dL)',
            'lactate': 'Nivel de lactato sérico (mmol/L)',
            'sofa_score': 'SOFA score (evaluación de fallo orgánico)',
            'apache_ii_score': 'APACHE II score (severidad de enfermedad)',
            'shock_index': 'Índice de shock (FC/PAS)',
            'critical_oxygen': 'Indicador de oxigenación crítica',
            'elevated_lactate': 'Indicador de lactato elevado'
        }
        return descriptions