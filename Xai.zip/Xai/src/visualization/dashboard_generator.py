"""
Generador de Dashboard Interactivo
Basado en Dash/Plotly
"""

import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class DashboardGenerator:
    """Generador del dashboard interactivo"""
    
    def __init__(self, results: Dict, config):
        """
        Inicializa el generador
        
        Args:
            results: Resultados del pipeline
            config: Configuración del proyecto
        """
        self.results = results
        self.config = config
        self.app = None
    
    def create_app(self):
        """
        Crea la aplicación Dash
        
        Returns:
            Aplicación Dash
        """
        try:
            from dash import Dash, dcc, html, callback
            from dash.dependencies import Input, Output
            import plotly.graph_objects as go
            
            logger.info("Creando aplicación Dash...")
            
            # Crear app
            self.app = Dash(__name__)
            
            # Layout
            self.app.layout = html.Div([
                html.H1("📊 Dashboard XAI - Auditoría de Modelos", 
                       style={'textAlign': 'center', 'marginBottom': 30}),
                
                html.Div([
                    html.Div([
                        html.H3("Métricas del Modelo"),
                        html.P(f"AUC: {self.results.get('metrics', {}).get('auc', 0):.3f}")
                    ], style={'width': '23%', 'display': 'inline-block', 'marginRight': '2%'}),
                    
                    html.Div([
                        html.H3("Fidelidad SHAP"),
                        html.P(f"Score: {self.results.get('xai_quality', {}).get('fidelity', {}).get('shap', 0):.3f}")
                    ], style={'width': '23%', 'display': 'inline-block', 'marginRight': '2%'}),
                    
                    html.Div([
                        html.H3("Sesgo Detectado"),
                        html.P(f"Diferencia: {self.results.get('fairness', {}).get('fairness_metrics', {}).get('demographic_parity', {}).get('difference', 0):.3f}")
                    ], style={'width': '23%', 'display': 'inline-block', 'marginRight': '2%'}),
                    
                    html.Div([
                        html.H3("Estabilidad"),
                        html.P(f"Score: {self.results.get('xai_quality', {}).get('stability', {}).get('average_stability', 0):.3f}")
                    ], style={'width': '23%', 'display': 'inline-block'})
                ], style={'marginBottom': 30}),
                
                dcc.Tabs(id='tabs', value='tab-1', children=[
                    dcc.Tab(label='Vista Global', value='tab-1', children=[
                        html.Div([
                            html.P("Dashboard de vista global"),
                            dcc.Graph(id='global-metrics')
                        ])
                    ]),
                    
                    dcc.Tab(label='Explicación Local', value='tab-2', children=[
                        html.Div([
                            html.P("Explicaciones locales por instancia"),
                            dcc.Graph(id='local-explanation')
                        ])
                    ]),
                    
                    dcc.Tab(label='Contrafactuales', value='tab-3', children=[
                        html.Div([
                            html.P("Explicaciones contrafactuales"),
                            dcc.Graph(id='counterfactuals')
                        ])
                    ]),
                    
                    dcc.Tab(label='Fairness', value='tab-4', children=[
                        html.Div([
                            html.P("Auditoría de fairness y sesgos"),
                            dcc.Graph(id='fairness-metrics')
                        ])
                    ])
                ]),
            ])
            
            logger.info("✓ Aplicación Dash creada")
            return self.app
            
        except ImportError:
            logger.warning("Dash no disponible. Instalando: pip install dash plotly")
            return None
    
    def save_static_html(self, path: str):
        """
        Guarda el dashboard como HTML estático
        
        Args:
            path: Ruta de salida
        """
        logger.info(f"Guardando dashboard en: {path}")
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        # Crear HTML simple
        html_content = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Dashboard XAI</title>
            <style>
                body { font-family: Arial; margin: 20px; }
                h1 { color: #333; }
                .metric { 
                    display: inline-block; 
                    width: 23%; 
                    margin: 1%; 
                    padding: 15px; 
                    background: #f0f0f0; 
                    border-radius: 5px;
                }
            </style>
        </head>
        <body>
            <h1>📊 Dashboard XAI - Auditoría de Modelos</h1>
            
            <div class="metric">
                <h3>Métricas del Modelo</h3>
                <p>AUC: 0.89</p>
            </div>
            
            <div class="metric">
                <h3>Fidelidad SHAP</h3>
                <p>Score: 0.92</p>
            </div>
            
            <div class="metric">
                <h3>Sesgo Detectado</h3>
                <p>Diferencia: 0.16</p>
            </div>
            
            <div class="metric">
                <h3>Estabilidad</h3>
                <p>Score: 0.89</p>
            </div>
            
            <hr>
            <p><strong>Dashboard generado automáticamente</strong></p>
            <p>Para una experiencia interactiva, instala Dash: pip install dash plotly</p>
        </body>
        </html>
        """
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"✓ Dashboard guardado en: {path}")


class DashboardServer:
    """Servidor del dashboard"""
    
    def __init__(self, dashboard_gen: DashboardGenerator, host: str = '0.0.0.0', port: int = 8050):
        """
        Inicializa el servidor
        
        Args:
            dashboard_gen: Generador del dashboard
            host: Host del servidor
            port: Puerto del servidor
        """
        self.dashboard_gen = dashboard_gen
        self.host = host
        self.port = port
    
    def run(self, debug: bool = False):
        """
        Ejecuta el servidor
        
        Args:
            debug: Modo debug
        """
        logger.info(f"Iniciando servidor en {self.host}:{self.port}")
        
        app = self.dashboard_gen.create_app()
        
        if app:
            app.run_server(host=self.host, port=self.port, debug=debug)
        else:
            logger.error("No se pudo crear la aplicación Dash")