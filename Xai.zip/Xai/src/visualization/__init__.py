"""Módulo de visualización"""

# Se completa cuando se cree dashboard_generator.py