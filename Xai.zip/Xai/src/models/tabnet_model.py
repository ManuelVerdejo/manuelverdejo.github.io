"""
Implementación del Modelo TabNet para Clasificación
Arquitectura de Deep Learning para Datos Tabulares con Interpretabilidad Inherente
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from pytorch_tabnet.tab_model import TabNetClassifier as PyTabNetClassifier
from sklearn.metrics import roc_auc_score
import logging
from typing import Tuple, Optional, List, Dict
import joblib

logger = logging.getLogger(__name__)


class TabNetClassifier:
    """
    Wrapper para TabNet con funcionalidades extendidas
    """
    
    def __init__(self, config):
        """
        Inicializa el clasificador TabNet
        
        Args:
            config: Objeto de configuración con hiperparámetros
        """
        self.config = config
        self.model = None
        self.best_epoch = 0
        self.history = {}
        self.feature_importances_ = None
        
        # Hiperparámetros de TabNet
        self.n_d = config.get('n_d', 64)  # Dimensión de la capa de decisión
        self.n_a = config.get('n_a', 64)  # Dimensión de atención
        self.n_steps = config.get('n_steps', 5)  # Número de pasos de decisión
        self.gamma = config.get('gamma', 1.5)  # Coeficiente para el balance de atención
        self.n_independent = config.get('n_independent', 2)
        self.n_shared = config.get('n_shared', 2)
        self.lambda_sparse = config.get('lambda_sparse', 1e-4)
        
        logger.info(f"TabNet inicializado con n_d={self.n_d}, n_steps={self.n_steps}")
    
    def fit(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        eval_set: Optional[List[Tuple]] = None,
        max_epochs: int = 100,
        patience: int = 15,
        batch_size: int = 256,
        virtual_batch_size: int = 128
    ):
        """
        Entrena el modelo TabNet
        
        Args:
            X_train: Features de entrenamiento
            y_train: Target de entrenamiento
            eval_set: Conjunto de validación [(X_val, y_val)]
            max_epochs: Número máximo de épocas
            patience: Paciencia para early stopping
            batch_size: Tamaño de batch
            virtual_batch_size: Tamaño de batch virtual para Ghost Batch Normalization
            
        Returns:
            Historia del entrenamiento
        """
        logger.info("Iniciando entrenamiento de TabNet...")
        
        # Inicializar modelo
        self.model = PyTabNetClassifier(
            n_d=self.n_d,
            n_a=self.n_a,
            n_steps=self.n_steps,
            gamma=self.gamma,
            n_independent=self.n_independent,
            n_shared=self.n_shared,
            lambda_sparse=self.lambda_sparse,
            optimizer_fn=torch.optim.Adam,
            optimizer_params=dict(lr=2e-2),
            scheduler_params={
                "step_size": 50,
                "gamma": 0.9
            },
            scheduler_fn=torch.optim.lr_scheduler.StepLR,
            mask_type='entmax',  # Para mejor sparsity
            verbose=1,
            device_name='auto'
        )
        
        # Preparar datos
        X_train_np = X_train.values if isinstance(X_train, pd.DataFrame) else X_train
        y_train_np = y_train.values if isinstance(y_train, pd.Series) else y_train
        
        # Preparar eval_set
        eval_set_np = None
        if eval_set is not None:
            eval_set_np = [(
                X.values if isinstance(X, pd.DataFrame) else X,
                y.values if isinstance(y, pd.Series) else y
            ) for X, y in eval_set]
        
        # Entrenar
        self.model.fit(
            X_train=X_train_np,
            y_train=y_train_np,
            eval_set=eval_set_np,
            eval_name=['train'] if eval_set_np else None,
            eval_metric=['auc', 'accuracy'],
            max_epochs=max_epochs,
            patience=patience,
            batch_size=batch_size,
            virtual_batch_size=virtual_batch_size,
            num_workers=0,
            drop_last=False
        )
        
        # Guardar historia
        self.history = self.model.history
        self.best_epoch = self.model.best_epoch
        
        # Calcular importancias de características
        self.feature_importances_ = self.model.feature_importances_
        
        logger.info(f"Entrenamiento completado. Best epoch: {self.best_epoch}")
        logger.info(f"Best AUC: {max(self.history['train_auc']):.4f}")
        
        return self.history
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predice clases
        
        Args:
            X: Features
            
        Returns:
            Predicciones de clase
        """
        if self.model is None:
            raise ValueError("El modelo debe ser entrenado primero")
        
        X_np = X.values if isinstance(X, pd.DataFrame) else X
        return self.model.predict(X_np)
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """
        Predice probabilidades
        
        Args:
            X: Features
            
        Returns:
            Probabilidades de clase
        """
        if self.model is None:
            raise ValueError("El modelo debe ser entrenado primero")
        
        X_np = X.values if isinstance(X, pd.DataFrame) else X
        return self.model.predict_proba(X_np)[:, 1]
    
    def get_feature_importances(self) -> Dict[str, float]:
        """
        Obtiene importancias globales de características
        
        Returns:
            Diccionario con importancias por característica
        """
        if self.feature_importances_ is None:
            raise ValueError("El modelo debe ser entrenado primero")
        
        return dict(zip(
            range(len(self.feature_importances_)),
            self.feature_importances_
        ))
    
    def explain_instance(self, X_instance: pd.DataFrame) -> Dict:
        """
        Explica una instancia usando las máscaras de atención de TabNet
        
        Args:
            X_instance: Instancia individual
            
        Returns:
            Diccionario con explicación
        """
        if self.model is None:
            raise ValueError("El modelo debe ser entrenado primero")
        
        X_np = X_instance.values if isinstance(X_instance, pd.DataFrame) else X_instance
        
        # Obtener máscaras de atención
        explain_matrix, masks = self.model.explain(X_np)
        
        return {
            'feature_importance': explain_matrix[0],
            'attention_masks': masks[0],
            'prediction': self.predict_proba(X_instance)[0]
        }
    
    def get_attention_masks(self, X: pd.DataFrame) -> np.ndarray:
        """
        Obtiene las máscaras de atención para un conjunto de datos
        
        Args:
            X: Features
            
        Returns:
            Máscaras de atención
        """
        X_np = X.values if isinstance(X, pd.DataFrame) else X
        _, masks = self.model.explain(X_np)
        return masks
    
    def save(self, path: str):
        """
        Guarda el modelo
        
        Args:
            path: Ruta donde guardar
        """
        if self.model is None:
            raise ValueError("No hay modelo para guardar")
        
        # Guardar modelo de PyTorch
        self.model.save_model(path)
        
        # Guardar metadata adicional
        metadata = {
            'feature_importances': self.feature_importances_,
            'best_epoch': self.best_epoch,
            'history': self.history,
            'config': {
                'n_d': self.n_d,
                'n_a': self.n_a,
                'n_steps': self.n_steps,
                'gamma': self.gamma
            }
        }
        joblib.dump(metadata, str(path).replace('.pkl', '_metadata.pkl'))
        
        logger.info(f"Modelo guardado en: {path}")
    
    def load(self, path: str):
        """
        Carga un modelo guardado
        
        Args:
            path: Ruta del modelo
        """
        self.model = PyTabNetClassifier()
        self.model.load_model(path)
        
        # Cargar metadata
        try:
            metadata = joblib.load(path.replace('.pkl', '_metadata.pkl'))
            self.feature_importances_ = metadata['feature_importances']
            self.best_epoch = metadata['best_epoch']
            self.history = metadata['history']
        except FileNotFoundError:
            logger.warning("No se encontró archivo de metadata")
        
        logger.info(f"Modelo cargado desde: {path}")


class TabNetEnsemble:
    """
    Ensemble de múltiples modelos TabNet para mayor robustez
    """
    
    def __init__(self, n_models: int = 5, config=None):
        """
        Args:
            n_models: Número de modelos en el ensemble
            config: Configuración base
        """
        self.n_models = n_models
        self.config = config
        self.models = []
        
    def fit(self, X_train, y_train, **kwargs):
        """Entrena múltiples modelos con diferentes seeds"""
        logger.info(f"Entrenando ensemble de {self.n_models} modelos...")
        
        for i in range(self.n_models):
            logger.info(f"Entrenando modelo {i+1}/{self.n_models}")
            
            model = TabNetClassifier(self.config)
            
            # Usar diferentes seeds para cada modelo
            torch.manual_seed(42 + i)
            np.random.seed(42 + i)
            
            model.fit(X_train, y_train, **kwargs)
            self.models.append(model)
        
        logger.info("Ensemble entrenado completamente")
    
    def predict_proba(self, X):
        """Predice promediando las probabilidades de todos los modelos"""
        predictions = np.array([model.predict_proba(X) for model in self.models])
        return predictions.mean(axis=0)
    
    def predict(self, X):
        """Predice usando votación por mayoría"""
        proba = self.predict_proba(X)
        return (proba > 0.5).astype(int)
    
    def get_feature_importances(self):
        """Promedia las importancias de todos los modelos"""
        importances = np.array([
            model.feature_importances_ for model in self.models
        ])
        return importances.mean(axis=0)


def evaluate_tabnet(
    model: TabNetClassifier,
    X_test: pd.DataFrame,
    y_test: pd.Series
) -> Dict:
    """
    Evalúa un modelo TabNet
    
    Args:
        model: Modelo entrenado
        X_test: Features de test
        y_test: Target de test
        
    Returns:
        Diccionario con métricas
    """
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)
    
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score,
        f1_score, confusion_matrix
    )
    
    metrics = {
        'auc': roc_auc_score(y_test, y_pred_proba),
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1': f1_score(y_test, y_pred),
        'confusion_matrix': confusion_matrix(y_test, y_pred)
    }
    
    return metrics