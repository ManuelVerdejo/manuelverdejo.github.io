"""Módulo de evaluación de calidad XAI"""

# Se completa cuando se cree xai_evaluator.py