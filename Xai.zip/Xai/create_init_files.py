

from pathlib import Path

# Contenido de cada __init__.py
init_files = {
    'src/__init__.py': '"""Paquete principal del proyecto XAI"""',
    
    'src/models/__init__.py': '''"""Modelos de machine learning"""

from .tabnet_model import TabNetClassifier, TabNetEnsemble, evaluate_tabnet

__all__ = [
    'TabNetClassifier',
    'TabNetEnsemble',
    'evaluate_tabnet'
]''',
    
    'src/explainability/__init__.py': '''"""Módulo de explicabilidad (XAI)"""

from .shap_explainer import SHAPExplainer, compare_shap_stability
from .lime_explainer import LIMEExplainer, LIMEEvaluator
from .counterfactual import DiCEGenerator, CounterfactualVisualizer

__all__ = [
    'SHAPExplainer',
    'LIMEExplainer',
    'DiCEGenerator',
    'CounterfactualVisualizer',
    'compare_shap_stability',
    'LIMEEvaluator'
]''',
    
    'src/fairness/__init__.py': '''"""Módulo de auditoría de fairness y sesgos"""

from .bias_auditor import BiasAuditor, FairnessVisualizer

__all__ = [
    'BiasAuditor',
    'FairnessVisualizer'
]''',
    
    'src/evaluation/__init__.py': '''"""Módulo de evaluación de calidad XAI"""

# Se completa cuando se cree xai_evaluator.py''',
    
    'src/visualization/__init__.py': '''"""Módulo de visualización"""

# Se completa cuando se cree dashboard_generator.py''',
    
    'src/reporting/__init__.py': '''"""Módulo de generación de reportes"""

# Se completa cuando se cree report_generator.py''',
    
    'src/utils/__init__.py': '''"""Utilidades y funciones auxiliares"""

from .config import Config
from .metrics import ModelMetrics

__all__ = [
    'Config',
    'ModelMetrics'
]'''
}

# Crear todos los archivos
for filepath, content in init_files.items():
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(path, 'w') as f:
        f.write(content)
    
    print(f"✓ Creado: {filepath}")

print("\n✅ Todos los __init__.py han sido creados")