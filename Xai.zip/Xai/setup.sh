#!/bin/bash

# Script de Instalación Automática del Proyecto XAI
# Este script configura todo el entorno necesario

echo "🚀 Iniciando instalación del Proyecto XAI y Auditoría..."

# Colores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 1. Verificar Python
echo -e "${BLUE}[1/8] Verificando Python...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 no encontrado. Por favor instala Python 3.8+${NC}"
    exit 1
fi
PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
echo -e "${GREEN}✓ Python $PYTHON_VERSION encontrado${NC}"

# 2. Crear estructura de directorios
echo -e "${BLUE}[2/8] Creando estructura de directorios...${NC}"
mkdir -p src/{models,explainability,fairness,evaluation,visualization,reporting,utils}
mkdir -p config/experiments
mkdir -p data/{raw,processed,cache}
mkdir -p output/{models,figures,reports,dashboard}
mkdir -p notebooks tests templates assets logs docs

# Crear __init__.py en todos los directorios de src
touch src/__init__.py
touch src/models/__init__.py
touch src/explainability/__init__.py
touch src/fairness/__init__.py
touch src/evaluation/__init__.py
touch src/visualization/__init__.py
touch src/reporting/__init__.py
touch src/utils/__init__.py

echo -e "${GREEN}✓ Estructura de directorios creada${NC}"

# 3. Crear entorno virtual
echo -e "${BLUE}[3/8] Creando entorno virtual...${NC}"
python3 -m venv venv
echo -e "${GREEN}✓ Entorno virtual creado${NC}"

# 4. Activar entorno virtual
echo -e "${BLUE}[4/8] Activando entorno virtual...${NC}"
source venv/bin/activate  # En Windows: venv\Scripts\activate
echo -e "${GREEN}✓ Entorno virtual activado${NC}"

# 5. Actualizar pip
echo -e "${BLUE}[5/8] Actualizando pip...${NC}"
pip install --upgrade pip setuptools wheel
echo -e "${GREEN}✓ pip actualizado${NC}"

# 6. Instalar dependencias
echo -e "${BLUE}[6/8] Instalando dependencias (esto puede tardar varios minutos)...${NC}"
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
    echo -e "${GREEN}✓ Dependencias instaladas${NC}"
else
    echo -e "${RED}❌ requirements.txt no encontrado${NC}"
    exit 1
fi

# 7. Crear archivo .env
echo -e "${BLUE}[7/8] Creando archivo de configuración .env...${NC}"
cat > .env << EOF
# Configuración del Proyecto XAI
PROJECT_NAME=xai-audit-project
ENVIRONMENT=development

# Paths
DATA_PATH=data/
OUTPUT_PATH=output/
LOGS_PATH=logs/

# Model
MODEL_NAME=tabnet
USE_GPU=false

# Logging
LOG_LEVEL=INFO

# Dashboard
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=8050
DASHBOARD_DEBUG=true
EOF
echo -e "${GREEN}✓ Archivo .env creado${NC}"

# 8. Verificar instalación
echo -e "${BLUE}[8/8] Verificando instalación...${NC}"
python3 << EOF
try:
    import numpy
    import pandas
    import torch
    import shap
    print("✓ Numpy, Pandas, PyTorch, SHAP: OK")
    
    try:
        from pytorch_tabnet.tab_model import TabNetClassifier
        print("✓ TabNet: OK")
    except ImportError:
        print("⚠ TabNet no disponible (opcional)")
    
    print("\n${GREEN}✅ Instalación completada exitosamente!${NC}")
    print("\n📋 Próximos pasos:")
    print("1. Activar entorno: source venv/bin/activate")
    print("2. Ejecutar pipeline: python main.py")
    print("3. Lanzar dashboard: python dashboard.py")
except ImportError as e:
    print(f"❌ Error en instalación: {e}")
    exit(1)
EOF

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   ✅ INSTALACIÓN COMPLETADA           ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "📋 Comandos útiles:"
echo "  • Activar entorno:  source venv/bin/activate"
echo "  • Ejecutar pipeline: python main.py"
echo "  • Lanzar dashboard:  python dashboard.py"
echo "  • Ejecutar tests:    pytest tests/"
echo "  • Ver logs:          tail -f logs/xai_audit.log"
echo ""