"""
Motor de Simulación de Ecosistemas Avanzado 2.1
Versión mejorada con costo de movimiento dinámico basado en el terreno, animaciones, 
especies diversas y efectos visuales.
"""

import pygame
import random
import math
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Set
from collections import defaultdict
from enum import Enum
from collections import deque
import heapq

# Configuración del ecosistema
CELL_SIZE = 3
GRID_WIDTH = 200
GRID_HEIGHT = 200
FPS_INITIAL = 40

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARK_GREEN = (34, 139, 34)
LIGHT_GREEN = (144, 238, 144)
RED = (220, 20, 60)
ORANGE = (255, 140, 0)
BLUE = (30, 144, 255)
PURPLE = (138, 43, 226)
GRAY = (220, 220, 220)
DARK_GRAY = (60, 60, 60)
BROWN = (139, 69, 19)
YELLOW = (255, 223, 0)
CYAN = (0, 206, 209)
PINK = (255, 182, 193)

# Clima
SEASON_LENGTH = 150
SEASONS = ['Primavera', 'Verano', 'Otoño', 'Invierno']


class TerrainType(Enum):
    GRASSLAND = "Pradera"
    FOREST = "Bosque"
    WATER = "Agua"
    MOUNTAIN = "Montaña"


class SpeciesType(Enum):
    # Herbívoros
    RABBIT = "Conejo"
    DEER = "Ciervo"
    BUFFALO = "Búfalo"
    SHEEP = "Oveja"          # NUEVO: Herbívoro de manada
    BOAR = "Jabalí"          # NUEVO: Omnívoro resistente
    
    # Depredadores
    WOLF = "Lobo"
    BEAR = "Oso"
    FOX = "Zorro"            # NUEVO: Pequeño y ágil
    EAGLE = "Águila"         # NUEVO: Cazador aéreo de visión amplia
    
class PlantType(Enum):
    GRASS = "Hierba"
    BUSH = "Arbusto"
    TREE = "Árbol"
    
class DiseaseType(Enum):
    NONE = "Ninguna"
    PARASITES = "Parásitos"
    INFECTION = "Infección"
    PLAGUE = "Plaga"
    
class PathfindingCache:
    """Cache de rutas calculadas para evitar recalcular A* constantemente"""
    
    def __init__(self, max_cache_size: int = 500, cache_duration: int = 8):
        self.cache: Dict[Tuple, Tuple[List[Tuple[int, int]], int]] = {}
        self.max_cache_size = max_cache_size
        self.cache_duration = cache_duration  # Turnos antes de invalidar
    
    def get_path(self, start: Tuple[int, int], goal: Tuple[int, int], current_turn: int) -> Optional[List[Tuple[int, int]]]:
        """Obtiene ruta cacheada si es válida"""
        key = (start, goal)
        if key in self.cache:
            path, cached_turn = self.cache[key]
            if current_turn - cached_turn < self.cache_duration:
                return path
            else:
                del self.cache[key]
        return None
    
    def set_path(self, start: Tuple[int, int], goal: Tuple[int, int], path: List[Tuple[int, int]], current_turn: int) -> None:
        """Guarda ruta en cache"""
        if len(self.cache) >= self.max_cache_size:
            # Eliminar entrada más antigua
            oldest = min(self.cache.items(), key=lambda x: x[1][1])
            del self.cache[oldest[0]]
        
        self.cache[(start, goal)] = (path, current_turn)
    
    def invalidate_around(self, pos: Tuple[int, int], radius: int = 3) -> None:
        """Invalida rutas cercanas a una posición (útil cuando cambia el terreno)"""
        to_remove = []
        for (start, goal) in self.cache.keys():
            if (abs(start[0] - pos[0]) <= radius and abs(start[1] - pos[1]) <= radius) or \
               (abs(goal[0] - pos[0]) <= radius and abs(goal[1] - pos[1]) <= radius):
                to_remove.append((start, goal))
        
        for key in to_remove:
            del self.cache[key]


class Pathfinder:
    """Sistema de pathfinding A* optimizado para el ecosistema"""
    
    @staticmethod
    def heuristic(a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """Distancia Manhattan (más rápida que Euclidiana)"""
        return abs(a[0] - b[0]) + abs(a[1] - b[1])
    
    @staticmethod
    def get_terrain_cost(terrain: TerrainType, is_herbivore: bool) -> float:
        """Coste de movimiento según terreno y tipo de animal"""
        if is_herbivore:
            costs = {
                TerrainType.GRASSLAND: 1.0,
                TerrainType.FOREST: 1.8,
                TerrainType.WATER: 50.0,  # Evitar agua
                TerrainType.MOUNTAIN: 3.0
            }
        else:  # Depredador
            costs = {
                TerrainType.GRASSLAND: 1.2,
                TerrainType.FOREST: 1.5,
                TerrainType.WATER: 50.0,
                TerrainType.MOUNTAIN: 2.5
            }
        return costs.get(terrain, 1.0)
    
    @staticmethod
    def find_path(start: Tuple[int, int], goal: Tuple[int, int], 
                  terrain_map: Dict, width: int, height: int, 
                  is_herbivore: bool, max_iterations: int = 150) -> Optional[List[Tuple[int, int]]]:
        """
        A* pathfinding optimizado
        max_iterations limita el coste computacional
        """
        if start == goal:
            return [start]
        
        # Priority queue: (f_score, counter, pos, path)
        counter = 0
        heap = [(0, counter, start, [start])]
        visited = {start: 0}  # pos -> g_score
        
        iterations = 0
        
        while heap and iterations < max_iterations:
            iterations += 1
            f_score, _, current, path = heapq.heappop(heap)
            
            if current == goal:
                return path
            
            current_g = visited[current]
            
            # Explorar vecinos (8 direcciones)
            for dx, dy in [(-1,0), (1,0), (0,-1), (0,1), (-1,-1), (-1,1), (1,-1), (1,1)]:
                neighbor = (current[0] + dx, current[1] + dy)
                
                # Límites del mapa
                if not (0 <= neighbor[0] < width and 0 <= neighbor[1] < height):
                    continue
                
                # Coste de movimiento diagonal
                move_cost = 1.414 if abs(dx) + abs(dy) == 2 else 1.0
                
                # Coste de terreno
                terrain = terrain_map.get(neighbor, TerrainType.GRASSLAND)
                terrain_cost = Pathfinder.get_terrain_cost(terrain, is_herbivore)
                
                # g_score = coste acumulado
                tentative_g = current_g + move_cost * terrain_cost
                
                # Si encontramos mejor camino o es nuevo
                if neighbor not in visited or tentative_g < visited[neighbor]:
                    visited[neighbor] = tentative_g
                    h_score = Pathfinder.heuristic(neighbor, goal)
                    f_score = tentative_g + h_score
                    
                    counter += 1
                    heapq.heappush(heap, (f_score, counter, neighbor, path + [neighbor]))
        
        # No se encontró camino o se agotaron iteraciones
        return None
    
    @staticmethod
    def get_next_step(path: Optional[List[Tuple[int, int]]], current_pos: Tuple[int, int]) -> Optional[Tuple[int, int]]:
        """Obtiene el siguiente paso de una ruta"""
        if not path or len(path) < 2:
            return None
        
        # Buscar posición actual en la ruta
        try:
            idx = path.index(current_pos)
            if idx < len(path) - 1:
                return path[idx + 1]
        except ValueError:
            pass
        
        # Si no está en la ruta, ir al primer paso
        return path[1] if len(path) > 1 else path[0]    
    
    
    
@dataclass
class Corpse:
    x: int
    y: int
    energy_remaining: int
    decay_timer: int = 30
    species: SpeciesType = None


  
@dataclass
class Plant:
    x: int
    y: int
    plant_type: PlantType
    growth_stage: int = 0
    max_growth: int = 8
    energy_value: int = 15  # Energía que da al comer
    
    def is_mature(self) -> bool:
        return self.growth_stage >= self.max_growth
    
    def grow(self, season_mult: float = 1.0, terrain_bonus: float = 1.0) -> None:
        if self.growth_stage < self.max_growth:
            if random.random() < season_mult * terrain_bonus * 0.35:
                self.growth_stage += 1

# En Ecosystem._spawn_plants modificar para asignar plant_type según terreno
def _spawn_plants(self, count: int) -> None:
    spawned = 0
    attempts = 0
    while spawned < count and attempts < count * 3:
        x = random.randint(0, self.width - 1)
        y = random.randint(0, self.height - 1)
        terrain = self.terrain_map.get((x, y))
        if terrain in [TerrainType.GRASSLAND, TerrainType.FOREST] and (x, y) not in self.plant_map:
            if terrain == TerrainType.FOREST:
                plant_type = random.choices(
                    [PlantType.BUSH, PlantType.TREE], weights=[0.6, 0.4])[0]
                max_growth = 8 if plant_type == PlantType.TREE else 6
                energy_value = 30 if plant_type == PlantType.TREE else 20
            else:
                plant_type = PlantType.GRASS
                max_growth = 6
                energy_value = 15
            plant = Plant(x=x, y=y, plant_type=plant_type, growth_stage=random.randint(0, max_growth),
                          max_growth=max_growth, energy_value=energy_value)
            self.plants.append(plant)
            self.plant_map[(x, y)] = plant
            spawned += 1
        attempts += 1
@dataclass
class Allele:
    value: float
    dominant: bool
@dataclass
class ExpressedGenetics:
    max_energy: float
    speed: float
    efficiency: float
    reproduction_rate: float
    vision_range: float    
@dataclass
class Genetics:
    max_energy_alleles: Tuple[Allele, Allele]
    speed_alleles: Tuple[Allele, Allele]
    efficiency_alleles: Tuple[Allele, Allele]
    reproduction_rate_alleles: Tuple[Allele, Allele]
    vision_range_alleles: Tuple[Allele, Allele]
    preferred_plant_type: PlantType = PlantType.GRASS
    drought_susceptibility: float = 0.5  # 0 (resistente) a 1 (muy susceptible)
    def expressed(self) -> ExpressedGenetics:
        def expr(alleles):
            if alleles[0].dominant:
                return alleles[0].value
            elif alleles[1].dominant:
                return alleles[1].value
            else:
                return (alleles[0].value + alleles[1].value) / 2

        return ExpressedGenetics(
            max_energy=expr(self.max_energy_alleles),
            speed=expr(self.speed_alleles),
            efficiency=expr(self.efficiency_alleles),
            reproduction_rate=expr(self.reproduction_rate_alleles),
            vision_range=expr(self.vision_range_alleles)
            )

    
    def mutate(self) -> 'Genetics':
        # Mutar alelos con pequeña probabilidad
        def mutate_allele(allele):
            if random.random() < 0.1:
                return Allele(
                    value=max(0.1, allele.value + random.uniform(-0.2, 0.2)),
                    dominant=allele.dominant
                )
            return allele
        
        return Genetics(
            max_energy_alleles=(mutate_allele(self.max_energy_alleles[0]), mutate_allele(self.max_energy_alleles[1])),
            speed_alleles=(mutate_allele(self.speed_alleles[0]), mutate_allele(self.speed_alleles[1])),
            efficiency_alleles=(mutate_allele(self.efficiency_alleles[0]), mutate_allele(self.efficiency_alleles[1])),
            reproduction_rate_alleles=(mutate_allele(self.reproduction_rate_alleles[0]), mutate_allele(self.reproduction_rate_alleles[1])),
            vision_range_alleles=(mutate_allele(self.vision_range_alleles[0]), mutate_allele(self.vision_range_alleles[1]))
        )
@dataclass
class Animal:
    x: float
    y: float
    target_x: int
    target_y: int
    energy: int
    age: int
    max_age: int
    species: SpeciesType
    genetics: Genetics
    reproduction_cooldown: int = 0
    generation: int = 0
    is_herbivore: bool = True
    health: int = 100  # Ya debe estar aquí
    disease: DiseaseType = DiseaseType.NONE
    disease_duration: int = 0
    dominance: float = 1.0  # 0.5 = sumiso, 1.5 = dominante
    territory_center: Optional[Tuple[int, int]] = None
    current_path: Optional[List[Tuple[int, int]]] = None
    path_recalc_cooldown: int = 0
    stuck_counter: int = 0  # Detectar si el animal está atascado
    last_position: Optional[Tuple[int, int]] = None
    def age_one_turn(self, season_multiplier: float = 1.0) -> None:
        self.age += 1
        if self.reproduction_cooldown > 0:
            self.reproduction_cooldown -= 1
        
        # Efectos de enfermedad
        if self.disease != DiseaseType.NONE:
            self.disease_duration -= 1
            self.health -= 2
            self.energy -= 1
            
            # Contagio a animales cercanos
            if self.disease == DiseaseType.PLAGUE and random.random() < 0.15:
                # Se maneja en Ecosystem.update()
                pass
            
            if self.disease_duration <= 0:
                if random.random() < 0.6:  # 60% recuperación
                    self.disease = DiseaseType.NONE
                    self.health = min(100, self.health + 20)
        
        self.energy -= int((1.2 - season_multiplier) * 1.5)
    def nearby_allies(self, spatial_grid: Dict, grid_cell_size: int, radius: float = 3.0) -> List['Animal']:
        """Busca aliados usando distancia al cuadrado"""
        allies = []
        grid_x = self.target_x // grid_cell_size
        grid_y = self.target_y // grid_cell_size
        cell_radius = (int(radius) // grid_cell_size) + 1
        radius_sq = radius * radius
        
        for dx in range(-cell_radius, cell_radius + 1):
            for dy in range(-cell_radius, cell_radius + 1):
                cell = (grid_x + dx, grid_y + dy)
                for animal in spatial_grid.get(cell, []):
                    if (animal.species == self.species and 
                        animal != self and 
                        self.distance_squared_to(animal.target_x, animal.target_y) <= radius_sq):
                        allies.append(animal)
        
        return allies
    def effective_speed(self) -> float:
    # Velocidad ajustada por salud (ejemplo: salud 50 reduce velocidad a 75%)
        return self.genetics.expressed().speed * (0.5 + 0.5 * self.health / 100)

    def effective_efficiency(self) -> float:
        return self.genetics.expressed().efficiency * (0.5 + 0.5 * self.health / 100)
    
    def __post_init__(self):
        self.is_herbivore = self.species in [SpeciesType.RABBIT, SpeciesType.DEER, SpeciesType.BUFFALO, SpeciesType.SHEEP, SpeciesType.BOAR]
        self.dominance = random.uniform(0.7, 1.3)
    def interpolate_position(self, speed: float = 0.3):
        """Interpola suavemente hacia la posición objetivo"""
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        
        move_speed = speed * self.genetics.expressed().speed
        
        if abs(dx) > 0.05:
            self.x += dx * move_speed
        else:
            self.x = self.target_x
            
        if abs(dy) > 0.05:
            self.y += dy * move_speed
        else:
            self.y = self.target_y
    
    def move_with_pathfinding(self, width: int, height: int, 
                             target: Optional[Tuple[int, int]], 
                             terrain_map: Dict,
                             pathfinder_cache: PathfindingCache,
                             current_turn: int) -> None:
        """Movimiento mejorado con A* pathfinding"""
        
        # Detectar si está atascado
        if self.last_position == (self.target_x, self.target_y):
            self.stuck_counter += 1
        else:
            self.stuck_counter = 0
        
        self.last_position = (self.target_x, self.target_y)
        
        # Si está muy atascado, resetear ruta
        if self.stuck_counter > 5:
            self.current_path = None
            self.stuck_counter = 0
        
        # Decidir si necesita nueva ruta
        needs_new_path = (
            self.current_path is None or 
            self.path_recalc_cooldown <= 0 or
            target != self.current_path[-1] if self.current_path and target else True
        )
        
        if target and needs_new_path:
            # Intentar obtener ruta del cache
            start = (self.target_x, self.target_y)
            cached_path = pathfinder_cache.get_path(start, target, current_turn)
            
            if cached_path:
                self.current_path = cached_path
            else:
                # Calcular nueva ruta (limitada para no sobrecargar)
                # Solo calcular si el objetivo está razonablemente cerca
                dist = abs(target[0] - self.target_x) + abs(target[1] - self.target_y)
                
                if dist < 20:  # Solo pathfinding para objetivos cercanos
                    new_path = Pathfinder.find_path(
                        start, target, terrain_map, width, height, 
                        self.is_herbivore, max_iterations=100
                    )
                    
                    if new_path:
                        self.current_path = new_path
                        pathfinder_cache.set_path(start, target, new_path, current_turn)
                    else:
                        # Fallback: movimiento directo
                        self.current_path = None
                else:
                    # Objetivo lejano: movimiento aproximado sin A*
                    self.current_path = None
            
            # Cooldown antes de recalcular (8-12 turnos)
            self.path_recalc_cooldown = random.randint(8, 12)
        
        # Seguir la ruta si existe
        if self.current_path and len(self.current_path) > 1:
            next_step = Pathfinder.get_next_step(self.current_path, (self.target_x, self.target_y))
            
            if next_step:
                new_x, new_y = next_step
                
                # Verificar si el movimiento es válido
                terrain = terrain_map.get((new_x, new_y))
                
                # Evitar terrenos imposibles
                if terrain == TerrainType.WATER and random.random() < 0.95:
                    self.current_path = None  # Invalidar ruta
                    return
                
                self.target_x = new_x
                self.target_y = new_y
            else:
                # Llegó al objetivo o ruta inválida
                self.current_path = None
        else:
            # Sin ruta: movimiento aleatorio simple (fallback)
            if target:
                dx = 1 if target[0] > self.target_x else -1 if target[0] < self.target_x else 0
                dy = 1 if target[1] > self.target_y else -1 if target[1] < self.target_y else 0
            else:
                dx = random.choice([-1, 0, 1])
                dy = random.choice([-1, 0, 1])
            
            new_x = max(0, min(width - 1, self.target_x + dx))
            new_y = max(0, min(height - 1, self.target_y + dy))
            
            terrain = terrain_map.get((new_x, new_y))
            if terrain != TerrainType.WATER or random.random() < 0.1:
                self.target_x = new_x
                self.target_y = new_y
        
        # Reducir cooldown
        if self.path_recalc_cooldown > 0:
            self.path_recalc_cooldown -= 1
        
        # Calcular coste de energía (igual que antes)
        base_cost = 2 if not self.is_herbivore else 1
        terrain = terrain_map.get((self.target_x, self.target_y), TerrainType.GRASSLAND)
        terrain_costs = {
            TerrainType.GRASSLAND: 0.9,
            TerrainType.FOREST: 1.2,
            TerrainType.WATER: 5.0,
            TerrainType.MOUNTAIN: 1.8
        }
        cost_multiplier = terrain_costs.get(terrain, 1.0)
        final_cost = max(1, int(base_cost * cost_multiplier / self.genetics.expressed().efficiency))
        self.energy -= final_cost
            
            # --- FIN DE LA MEJORA ---
    
    def eat(self, energy_gain: int) -> None:
        self.energy = min(self.genetics.expressed().max_energy, self.energy + energy_gain)
    
    def can_reproduce(self) -> bool:
        threshold = 40 if self.is_herbivore else 55
        prob = 0.12 if self.is_herbivore else 0.08
        
        return (self.energy >= threshold and 
                self.reproduction_cooldown <= 0 and
                random.random() < prob * self.genetics.expressed().reproduction_rate)
    
    def reproduce(self, partner: Optional['Animal'] = None, on_mutation_callback=None) -> Optional['Animal']:

        if not self.can_reproduce():
            return None
        
        cost = 20 if self.is_herbivore else 28
        self.energy -= cost
        self.reproduction_cooldown = 18
        
        if partner:
            def mix_alleles(a1, a2):
                return (random.choice([a1[0], a2[0]]), random.choice([a1[1], a2[1]]))
    
            max_energy_alleles = mix_alleles(self.genetics.max_energy_alleles, partner.genetics.max_energy_alleles)
            speed_alleles = mix_alleles(self.genetics.speed_alleles, partner.genetics.speed_alleles)
            efficiency_alleles = mix_alleles(self.genetics.efficiency_alleles, partner.genetics.efficiency_alleles)
            reproduction_rate_alleles = mix_alleles(self.genetics.reproduction_rate_alleles, partner.genetics.reproduction_rate_alleles)
            vision_range_alleles = mix_alleles(self.genetics.vision_range_alleles, partner.genetics.vision_range_alleles)

            new_genetics = Genetics(
                max_energy_alleles=max_energy_alleles,
                speed_alleles=speed_alleles,
                efficiency_alleles=efficiency_alleles,
                reproduction_rate_alleles=reproduction_rate_alleles,
                vision_range_alleles=vision_range_alleles
            )
        else:
            new_genetics = self.genetics

# Mutar genética
        if random.random() < 0.12:
            new_genetics = new_genetics.mutate()
            if on_mutation_callback:
                on_mutation_callback()
                
# Obtener valores expresados para inicializar energía y edad
        expressed = new_genetics.expressed()
        initial_energy = 28 if self.is_herbivore else 45
        max_age = 140 if self.is_herbivore else 180

        return Animal(
            x=float(self.target_x),
            y=float(self.target_y),
            target_x=self.target_x + random.choice([-1, 0, 1]),
            target_y=self.target_y + random.choice([-1, 0, 1]),
            energy=initial_energy,
            age=0,
            max_age=max_age + random.randint(-25, 25),
            species=self.species,
            genetics=new_genetics,
            generation=self.generation + 1,
            health=100  # AÑADIR esta línea si no está
        )
    
    def is_alive(self) -> bool:
        return self.energy > 0 and self.age < self.max_age
    
    
    def distance_squared_to(self, x: float, y: float) -> float:
        """Distancia al cuadrado (más rápida, evita sqrt)"""
        return (self.target_x - x)**2 + (self.target_y - y)**2
    
    def distance_to(self, x: float, y: float) -> float:
        """Solo cuando necesites la distancia real"""
        return math.sqrt(self.distance_squared_to(x, y))






class WeatherEvent(Enum):
    NONE = "Ninguno"
    RAIN = "Lluvia"
    DROUGHT = "Sequía"
    FIRE = "Incendio"


class Ecosystem:
    """Gestiona el ecosistema completo"""
    
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.animals: List[Animal] = []
        self.plants: List[Plant] = []
        self.plant_map: Dict[Tuple[int, int], Plant] = {}
        self.terrain_map: Dict[Tuple[int, int], TerrainType] = {}
        self.turn = 0
        self.weather_event = WeatherEvent.NONE
        self.weather_duration = 0
        self.selected_animal: Optional[Animal] = None
        self.spatial_grid: Dict[Tuple[int, int], List[Animal]] = defaultdict(list)
        self.pathfinding_cache = PathfindingCache(max_cache_size=500, cache_duration=8)
        self.grid_cell_size = 5
        self.stats = {
            'herbivores': [],
            'predators': [],
            'plants': [],
            'births': 0,
            'deaths': 0,
            'hunts': 0,
            'events': [],
            'hunt_attempts': 0,  # Intentos de caza
            'plants_eaten': 0,
            'carrion_consumed': 0,
            'deaths_by_species': defaultdict(int),
            'hunts_by_predator': defaultdict(int),
            'hunts_by_prey': defaultdict(int),
            'age_at_death': defaultdict(list),  # Por especie
            'energy_history': defaultdict(list),  # Promedio por especie por turno
            'disease_count': 0,
            'population_peaks': defaultdict(lambda: {'max': 0, 'min': float('inf'), 'turn_max': 0, 'turn_min': 0}),
            'extinctions': [],  # (especie, turno_extinción, turno_reaparición)
            'mutations': 0,
            'max_generation': defaultdict(int),
            'distances_traveled': [],  # Distancia total recorrida
            'climate_impact_deaths': 0,
            'total_climate_duration': defaultdict(int),
        }
        
        # Generar terreno
        self._generate_terrain()
        
        # Población inicial variada
        self._spawn_animals(SpeciesType.RABBIT, 30)
        self._spawn_animals(SpeciesType.DEER, 20)
        self._spawn_animals(SpeciesType.BUFFALO, 18)
        self._spawn_animals(SpeciesType.SHEEP, 26)    # NUEVO
        self._spawn_animals(SpeciesType.BOAR, 6)      # NUEVO
        self._spawn_animals(SpeciesType.WOLF, 5)
        self._spawn_animals(SpeciesType.BEAR, 3)
        self._spawn_animals(SpeciesType.FOX, 5)       # NUEVO
        self._spawn_animals(SpeciesType.EAGLE, 3)     # NUEVO
        
        self._spawn_plants(250)
        self.fertility_map: Dict[Tuple[int, int], float] = {(x, y): 1.0 for x in range(width) for y in range(height)}
        self.plant_spatial_grid: Dict[Tuple[int, int], List[Plant]] = defaultdict(list)
        self.corpses: List[Corpse] = []
        self.corpse_map: Dict[Tuple[int, int], Corpse] = {}
        
    
 # Tamaño de celda para particionado espacial
        
    def _update_spatial_grid(self) -> None:
        """Actualiza el grid espacial con posiciones de animales"""
        self.spatial_grid.clear()
        for animal in self.animals:
            grid_x = animal.target_x // self.grid_cell_size
            grid_y = animal.target_y // self.grid_cell_size
            self.spatial_grid[(grid_x, grid_y)].append(animal)
            
    def _update_plant_spatial_grid(self) -> None:
        self.plant_spatial_grid.clear()
        for plant in self.plants:
            if plant.is_mature():  # Solo plantas maduras
                grid_x = plant.x // self.grid_cell_size
                grid_y = plant.y // self.grid_cell_size
                self.plant_spatial_grid[(grid_x, grid_y)].append(plant)
                
    def _get_nearby_cells(self, x: int, y: int, radius: int) -> List[Tuple[int, int]]:
        """Obtiene celdas del grid cercanas"""
        grid_x = x // self.grid_cell_size
        grid_y = y // self.grid_cell_size
        cell_radius = (radius // self.grid_cell_size) + 1
        
        cells = []
        for dx in range(-cell_radius, cell_radius + 1):
            for dy in range(-cell_radius, cell_radius + 1):
                cells.append((grid_x + dx, grid_y + dy))
        return cells         
    
    def _generate_terrain(self) -> None:
        """Genera un mapa de terreno variado"""
        # Base: pradera
        for x in range(self.width):
            for y in range(self.height):
                self.terrain_map[(x, y)] = TerrainType.GRASSLAND
        
        # Bosques (clusters)
        num_forests = random.randint(4, 7)
        for _ in range(num_forests):
            cx = random.randint(5, self.width - 5)
            cy = random.randint(5, self.height - 5)
            radius = random.randint(4, 8)
            
            for x in range(max(0, cx - radius), min(self.width, cx + radius + 1)):
                for y in range(max(0, cy - radius), min(self.height, cy + radius)):
                    if math.sqrt((x - cx)**2 + (y - cy)**2) < radius:
                        self.terrain_map[(x, y)] = TerrainType.FOREST
        
        # Agua (ríos y lagos)
        num_water = random.randint(2, 4)
        for _ in range(num_water):
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
            
            # Río o lago pequeño
            if random.random() < 0.5:
                # Río
                for i in range(random.randint(10, 25)):
                    self.terrain_map[(x, y)] = TerrainType.WATER
                    x += random.choice([-1, 0, 1])
                    y += random.choice([-1, 0, 1])
                    x = max(0, min(self.width - 1, x))
                    y = max(0, min(self.height - 1, y))
            else:
                # Lago
                radius = random.randint(2, 4)
                for dx in range(-radius, radius + 1):
                    for dy in range(-radius, radius + 1):
                        if dx*dx + dy*dy <= radius*radius:
                            nx, ny = x + dx, y + dy
                            if 0 <= nx < self.width and 0 <= ny < self.height:
                                self.terrain_map[(nx, ny)] = TerrainType.WATER
        
        # Montañas
        num_mountains = random.randint(2, 4)
        for _ in range(num_mountains):
            x = random.randint(3, self.width - 3)
            y = random.randint(3, self.height - 3)
            radius = random.randint(2, 4)
            
            for dx in range(-radius, radius + 1):
                for dy in range(-radius, radius + 1):
                    if abs(dx) + abs(dy) <= radius:
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.width and 0 <= ny < self.height:
                            self.terrain_map[(nx, ny)] = TerrainType.MOUNTAIN
    
    def _spawn_animals(self, species: SpeciesType, count: int) -> None:
        """Crea población inicial de una especie"""
        # Configuración por especie
        configs = {
            SpeciesType.RABBIT: {
                'energy': 22, 'max_age': 80, 'max_e': 35, 'speed': 1.2, 
                'eff': 1.2, 'repr': 3, 'vision': 4.0
            },
            SpeciesType.DEER: {
                'energy': 30, 'max_age': 130, 'max_e': 50, 'speed': 1.6, 
                'eff': 1.1, 'repr': 1.7, 'vision': 5.0
            },
            SpeciesType.BUFFALO: {
                'energy': 40, 'max_age': 200, 'max_e': 70, 'speed': 0.9, 
                'eff': 0.9, 'repr': 1, 'vision': 4.5
            },
            SpeciesType.WOLF: {
                'energy': 55, 'max_age': 150, 'max_e': 75, 'speed': 1.9, 
                'eff': 0.85, 'repr': 1.1, 'vision': 6.0
            },
            SpeciesType.BEAR: {
                'energy': 60, 'max_age': 200, 'max_e': 100, 'speed': 1.1, 
                'eff': 0.75, 'repr': 1, 'vision': 5.5
            },
            SpeciesType.SHEEP: {
            'energy': 28, 'max_age': 110, 'max_e': 42, 'speed': 1.1, 
            'eff': 1.15, 'repr': 2.2, 'vision': 4.2
            },
            SpeciesType.BOAR: {
                'energy': 38, 'max_age': 140, 'max_e': 58, 'speed': 1.0, 
                'eff': 1.0, 'repr': 1.1, 'vision': 4.8
            },
            SpeciesType.FOX: {
                'energy': 35, 'max_age': 120, 'max_e': 55, 'speed': 1.9, 
                'eff': 1.0, 'repr': 1.4, 'vision': 5.5
            },
            SpeciesType.EAGLE: {
                'energy': 40, 'max_age': 170, 'max_e': 65, 'speed': 1.7, 
                'eff': 0.9, 'repr': 1, 'vision': 8.0  # Visión excepcional
            }
        }
        
        cfg = configs[species]
        
        for _ in range(count):
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
        
        # Trade-off velocidad vs energía
            speed = random.uniform(0.5, 2.0)
            max_energy = max(15, int(100 - speed * 30 + random.randint(-5, 5)))
        
        # Crear alelos para speed y max_energy (simplificado)
            speed_alleles = (Allele(value=speed, dominant=True), Allele(value=speed, dominant=False))
            max_energy_alleles = (Allele(value=max_energy, dominant=True), Allele(value=max_energy, dominant=False))
        
        # Crear alelos para otros rasgos con valores base o aleatorios
            efficiency_alleles = (Allele(value=1.0, dominant=True), Allele(value=1.0, dominant=False))
            reproduction_rate_alleles = (Allele(value=1.0, dominant=True), Allele(value=1.0, dominant=False))
            vision_range_alleles = (Allele(value=5.0, dominant=True), Allele(value=5.0, dominant=False))
        
            genetics = Genetics(
                max_energy_alleles=max_energy_alleles,
                speed_alleles=speed_alleles,
                efficiency_alleles=efficiency_alleles,
                reproduction_rate_alleles=reproduction_rate_alleles,
                vision_range_alleles=vision_range_alleles
                )
        
            animal = Animal(
                x=float(x), y=float(y),
                target_x=x, target_y=y,
                energy=max_energy,
                age=random.randint(0, 25),
                max_age=130 + random.randint(-20, 20),  # Ajustar según especie
                species=species,
                genetics=genetics
            )
            self.animals.append(animal)
    
    def _spawn_plants(self, count: int) -> None:
        spawned = 0
        attempts = 0
    
        while spawned < count and attempts < count * 3:
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
        
            terrain = self.terrain_map.get((x, y))
            if terrain in [TerrainType.GRASSLAND, TerrainType.FOREST] and (x, y) not in self.plant_map:
                if terrain == TerrainType.FOREST:
                    plant_type = random.choices(
                        [PlantType.BUSH, PlantType.TREE], weights=[0.6, 0.4])[0]
                    max_growth = 8 if plant_type == PlantType.TREE else 6
                    energy_value = 30 if plant_type == PlantType.TREE else 20
                else:
                    plant_type = PlantType.GRASS
                    max_growth = 6
                    energy_value = 15
            
                plant = Plant(
                    x=x,
                    y=y,
                    plant_type=plant_type,
                    growth_stage=random.randint(0, max_growth),
                    max_growth=max_growth,
                    energy_value=energy_value
                    )
                self.plants.append(plant)
                self.plant_map[(x, y)] = plant
                spawned += 1
        
            attempts += 1
    
    def get_season_multiplier(self) -> float:
        season_index = (self.turn // SEASON_LENGTH) % 4
        multipliers = [1.4, 1.1, 0.85, 0.6]  # Primavera, Verano, Otoño, Invierno
        return multipliers[season_index]
    
    def get_current_season(self) -> str:
        return SEASONS[(self.turn // SEASON_LENGTH) % 4]
    
    def trigger_random_event(self) -> None:
        """Genera eventos climáticos aleatorios"""
        if self.weather_duration > 0:
            self.weather_duration -= 1
            if self.weather_duration == 0:
                self.weather_event = WeatherEvent.NONE
            return
        
        if random.random() < 0.005:  # 0.5% por turno
            event = random.choice([WeatherEvent.RAIN, WeatherEvent.DROUGHT, WeatherEvent.FIRE])
            self.weather_event = event
            self.weather_duration = random.randint(20, 50)
            self.stats['events'].append((self.turn, event.value))
            
            if event == WeatherEvent.FIRE:
                # Quemar algunas plantas
                to_remove = random.sample(self.plants, min(len(self.plants) // 5, 30))
                for plant in to_remove:
                    self.plants.remove(plant)
                    del self.plant_map[(plant.x, plant.y)]
    
    def find_nearby(self, animal: Animal, target_type: str) -> Optional:
        """Encuentra objetivo cercano usando distancia al cuadrado"""
        nearest = None
        min_dist_sq = float('inf')
        vision = animal.genetics.expressed().vision_range
        vision_sq = vision * vision  # Comparar cuadrados
        
        if target_type == 'plant' and animal.is_herbivore:
            preferred = animal.genetics.preferred_plant_type
            nearby_cells = self._get_nearby_cells(animal.target_x, animal.target_y, int(vision))
            
            # Buscar SOLO en celdas cercanas del grid de plantas
            for cell in nearby_cells:
                for plant in self.plant_spatial_grid.get(cell, []):
                    if plant.plant_type == preferred:
                        dist_sq = animal.distance_squared_to(plant.x, plant.y)
                        if dist_sq <= vision_sq and dist_sq < min_dist_sq:
                            min_dist_sq = dist_sq
                            nearest = (plant.x, plant.y)
        
        elif target_type == 'prey' and not animal.is_herbivore:
            nearby_cells = self._get_nearby_cells(animal.target_x, animal.target_y, int(vision))
            
            for cell in nearby_cells:
                for other in self.spatial_grid.get(cell, []):
                    if other.is_herbivore and other.is_alive():
                        manhattan = abs(other.target_x - animal.target_x) + abs(other.target_y - animal.target_y)
                        if manhattan > vision * 1.4:
                            continue
                        
                        dist_sq = animal.distance_squared_to(other.target_x, other.target_y)
                        if dist_sq <= vision_sq and dist_sq < min_dist_sq:
                            min_dist_sq = dist_sq
                            nearest = other
        
        return nearest
    
    def update(self) -> None:
        """Actualiza un turno del ecosistema"""
        self.turn += 1
        season_mult = self.get_season_multiplier()
        
        self._update_spatial_grid()
        self._update_plant_spatial_grid()
        # Eventos climáticos
        self.trigger_random_event()
        
        if self.weather_event != WeatherEvent.NONE:
            self.stats['total_climate_duration'][self.weather_event.value] += 1
        weather_plant_mult = 1.0
        if self.weather_event == WeatherEvent.RAIN:
            weather_plant_mult = 1.5
        elif self.weather_event == WeatherEvent.DROUGHT:
            weather_plant_mult = 0.3
        
        # Actualizar animales
        new_animals = []
        dead_animals = []
        
        for animal in self.animals:
            old_pos = (animal.target_x, animal.target_y)
            animal.age_one_turn(season_mult)
            animal.interpolate_position(0.25)
            if self.weather_event == WeatherEvent.DROUGHT:
                animal.health = max(0, animal.health - int(1 * animal.genetics.drought_susceptibility))
                if animal.health <= 0:
                    self.stats['climate_impact_deaths'] += 1
            # INICIALIZAR target AQUÍ (antes del if/else)
            target = None
            if animal.disease != DiseaseType.NONE:
                self.stats['disease_count'] += 1
        
            target = None
            # Comportamiento según tipo
            if animal.is_herbivore:
                target = self.find_nearby(animal, 'plant')
                animal.move_with_pathfinding(
                    self.width, self.height, target, self.terrain_map,
                    self.pathfinding_cache, self.turn
                )
                new_pos = (animal.target_x, animal.target_y)
                dist = abs(new_pos[0] - old_pos[0]) + abs(new_pos[1] - old_pos[1])
                if dist > 0:
                    self.stats['distances_traveled'].append(dist)                
                # Comer planta
                plant = self.plant_map.get((animal.target_x, animal.target_y))
                self.fertility_map[(animal.target_x, animal.target_y)] = max(
                    0.1, self.fertility_map[(animal.target_x, animal.target_y)] - 0.3
                )
                if plant and plant.is_mature():
                    animal.eat(plant.energy_value)
                    self.plants.remove(plant)
                    del self.plant_map[(animal.target_x, animal.target_y)]
                    self.stats['plants_eaten'] += 1
            
            else:  # Depredador
                prey = self.find_nearby(animal, 'prey')
                if animal.species == SpeciesType.WOLF:
                    allies = animal.nearby_allies(self.spatial_grid, self.grid_cell_size)
                    group_bonus = 1 + 0.1 * len(allies)
                else:
                    group_bonus = 1.0
                
                if prey:
                    target = (prey.target_x, prey.target_y)
                    animal.move_with_pathfinding(
                        self.width, self.height, target, self.terrain_map,
                        self.pathfinding_cache, self.turn
                    )
                    # TRACKING: Distancia
                    new_pos = (animal.target_x, animal.target_y)
                    dist = abs(new_pos[0] - old_pos[0]) + abs(new_pos[1] - old_pos[1])
                    if dist > 0:
                        self.stats['distances_traveled'].append(dist)
                    
                    # Cazar si está en la misma celda
                    if animal.target_x == prey.target_x and animal.target_y == prey.target_y:
                        self.stats['hunt_attempts'] += 1
                        # Defensa de manada para herbívoros
                        prey_allies = prey.nearby_allies(self.spatial_grid, self.grid_cell_size)
                        defense_factor = 1 + 0.15 * len(prey_allies)
                        
                        # Probabilidad de éxito ajustada
                        if random.random() < 0.7 / defense_factor * group_bonus:
                            hunt_energy = prey.energy // 2 + 15
                            animal.eat(hunt_energy)
                            dead_animals.append(prey)
                            self.stats['hunts'] += 1
                            self.stats['hunts_by_predator'][animal.species.value] += 1
                            self.stats['hunts_by_prey'][prey.species.value] += 1
                else:
                    # Sin presa: movimiento aleatorio
                    animal.move_with_pathfinding(
                        self.width, self.height, None, self.terrain_map,
                        self.pathfinding_cache, self.turn
                    )
                    # TRACKING: Carroña
                    corpse = self.corpse_map.get((animal.target_x, animal.target_y))
                    if corpse and corpse.energy_remaining > 0:
                        eaten = min(20, corpse.energy_remaining)
                        animal.eat(eaten)
                        corpse.energy_remaining -= eaten
                        self.stats['carrion_consumed'] += 1
                        
              # Reproducción
            if animal.can_reproduce():
                partner = self._find_mate(animal)
                offspring = animal.reproduce(partner)
                if offspring:
                    offspring.target_x = max(0, min(self.width - 1, offspring.target_x))
                    offspring.target_y = max(0, min(self.height - 1, offspring.target_y))
                    new_animals.append(offspring)
                    self.stats['births'] += 1
                    if offspring.generation > self.stats['max_generation'][offspring.species.value]:
                        self.stats['max_generation'][offspring.species.value] = offspring.generation

            if not animal.is_alive():
                dead_animals.append(animal)
                self.stats['deaths'] += 1
                self.stats['deaths_by_species'][animal.species.value] += 1
                self.stats['age_at_death'][animal.species.value].append(animal.age)
        
        # Remover muertos
        self.animals = [a for a in self.animals if a not in dead_animals]
        self.animals.extend(new_animals)
 
        # TRACKING: Picos de población y extinciones
        species_counts = defaultdict(int)
        for animal in self.animals:
            species_counts[animal.species.value] += 1
        for species in SpeciesType:
            species_name = species.value
            current_count = species_counts.get(species_name, 0)
            
            # Buscar si hay extinción previa sin reaparición
            for ext_data in self.stats['extinctions']:
                if ext_data[0] == species_name and ext_data[2] is None:
                    if current_count > 0:
                        ext_data[2] = self.turn  # Reaparición
                    break
            else:
                # No hay extinción previa
                if current_count == 0 and self.stats['population_peaks'][species_name]['max'] > 0:
                    self.stats['extinctions'].append([species_name, self.turn, None])
        
        if self.turn % 2 == 0:
            for plant in self.plants:
                terrain = self.terrain_map.get((plant.x, plant.y), TerrainType.GRASSLAND)
                terrain_bonus = 1.3 if terrain == TerrainType.FOREST else 1.0
                fertility = self.fertility_map.get((plant.x, plant.y), 1.0)
                plant.grow(season_mult * weather_plant_mult, terrain_bonus * fertility)
            
            # Recuperar fertilidad
            if self.turn % 10 == 0:  # Cada 10 turnos
                for pos in list(self.fertility_map.keys())[:1000]:  # Limitar actualizaciones
                    self.fertility_map[pos] = min(1.0, self.fertility_map[pos] + 0.01)
        if self.turn % 10 == 0:  # Cada 10 turnos
            for species in SpeciesType:
                animals_of_species = [a for a in self.animals if a.species == species]
                if animals_of_species:
                    avg_energy = sum(a.energy for a in animals_of_species) / len(animals_of_species)
                    self.stats['energy_history'][species.value].append((self.turn, avg_energy))
              
        # Propagar plantas
        if self.weather_event != WeatherEvent.FIRE:
            for plant in list(self.plants):
                if plant.is_mature() and random.random() < 0.12 * season_mult * weather_plant_mult:
                    dx = random.randint(-3, 3)
                    dy = random.randint(-3, 3)
                    nx, ny = plant.x + dx, plant.y + dy
                    
                    if 0 <= nx < self.width and 0 <= ny < self.height:
                        terrain = self.terrain_map.get((nx, ny))
                        if terrain in [TerrainType.GRASSLAND, TerrainType.FOREST] and (nx, ny) not in self.plant_map:
                            
                            # 🟢 NEW LOGIC: Determine plant type and energy based on terrain
                            if terrain == TerrainType.FOREST:
                                # A propagating plant in a forest becomes a Bush or Tree
                                new_plant_type = random.choices(
                                    [PlantType.BUSH, PlantType.TREE], weights=[0.6, 0.4])[0]
                                max_growth = 8 if new_plant_type == PlantType.TREE else 6
                                energy_value = 30 if new_plant_type == PlantType.TREE else 20
                            else: # GRASSLAND
                                # A propagating plant in grassland becomes Grass
                                new_plant_type = PlantType.GRASS
                                max_growth = 6
                                energy_value = 15
                            
                            # 🟢 CORRECTION: Pass the required 'plant_type' and 'energy_value'
                            new_plant = Plant(
                                x=nx, 
                                y=ny, 
                                plant_type=new_plant_type, 
                                growth_stage=0, 
                                max_growth=max_growth, 
                                energy_value=energy_value
                            )
                            
                            self.plants.append(new_plant)
                            self.plant_map[(nx, ny)] = new_plant
        if not animal.is_alive():
            # Crear cadáver
            corpse = Corpse(
                x=animal.target_x,
                y=animal.target_y,
                energy_remaining=animal.energy // 2 + 10,
                species=animal.species
            )
            self.corpses.append(corpse)
            self.corpse_map[(corpse.x, corpse.y)] = corpse
            
            dead_animals.append(animal)
            self.stats['deaths'] += 1
        
        # Depredadores pueden comer cadáveres (más fácil que cazar)
        if not animal.is_herbivore:
            corpse = self.corpse_map.get((animal.target_x, animal.target_y))
            if corpse and corpse.energy_remaining > 0:
                eaten = min(20, corpse.energy_remaining)
                animal.eat(eaten)
                corpse.energy_remaining -= eaten
        
        # Actualizar cadáveres
        for corpse in list(self.corpses):
            corpse.decay_timer -= 1
            if corpse.decay_timer <= 0 or corpse.energy_remaining <= 0:
                self.corpses.remove(corpse)
                if (corpse.x, corpse.y) in self.corpse_map:
                    del self.corpse_map[(corpse.x, corpse.y)]                    
        if animal.disease == DiseaseType.PLAGUE:
            nearby_cells = self._get_nearby_cells(animal.target_x, animal.target_y, 2)
            for cell in nearby_cells:
                for other in self.spatial_grid.get(cell, []):
                    if other.disease == DiseaseType.NONE and random.random() < 0.05:
                        other.disease = DiseaseType.PLAGUE
                        other.disease_duration = random.randint(20, 40)
        
        # Evento aleatorio: Brote de enfermedad
        if random.random() < 0.002:  # 0.2% por turno
            infected_count = min(len(self.animals) // 10, 5)
            for animal in random.sample(self.animals, infected_count):
                animal.disease = random.choice([DiseaseType.PARASITES, DiseaseType.INFECTION, DiseaseType.PLAGUE])
                animal.disease_duration = random.randint(15, 50)
            self.stats['events'].append((self.turn, f"Brote de {animal.disease.value}"))
        
        # Estadísticas
        herbivore_count = sum(1 for a in self.animals if a.is_herbivore)
        predator_count = len(self.animals) - herbivore_count
        
        self.stats['herbivores'].append(herbivore_count)
        self.stats['predators'].append(predator_count)
        self.stats['plants'].append(len(self.plants))
    
    def _find_mate(self, animal: Animal) -> Optional[Animal]:
        for other in self.animals:
            if (other != animal and 
                other.species == animal.species and 
                animal.distance_to(other.target_x, other.target_y) <= 2.5):
                return other
        return None
    
    def select_animal_at(self, grid_x: int, grid_y: int) -> Optional[Animal]:
        """Selecciona un animal en la posición clickeada"""
        for animal in self.animals:
            if animal.target_x == grid_x and animal.target_y == grid_y:
                return animal
        return None


class Renderer:
    """Renderizado avanzado con efectos visuales"""
    
    def __init__(self, ecosystem: Ecosystem):
        pygame.init()
        self.ecosystem = ecosystem
        self.screen_width = ecosystem.width * CELL_SIZE + 280
        self.screen_height = ecosystem.height * CELL_SIZE
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("🌍 Ecosistema Avanzado 2.1")
        self.font = pygame.font.Font(None, 20)
        self.title_font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 18)
        self.clock = pygame.time.Clock()
        
        # Partículas para efectos
        self.particles = []
    
    def add_particles(self, x: int, y: int, color: Tuple[int, int, int], count: int = 5):
        """Añade partículas para efectos visuales"""
        for _ in range(count):
            self.particles.append({
                'x': x,
                'y': y,
                'vx': random.uniform(-2, 2),
                'vy': random.uniform(-2, 2),
                'color': color,
                'life': random.randint(10, 30)
            })
    
    def update_particles(self):
        """Actualiza y dibuja partículas"""
        for particle in list(self.particles):
            particle['x'] += particle['vx']
            particle['y'] += particle['vy']
            particle['life'] -= 1
            
            if particle['life'] <= 0:
                self.particles.remove(particle)
            else:
                alpha = int(255 * (particle['life'] / 30))
                color = (*particle['color'][:3], alpha)
                pygame.draw.circle(self.screen, particle['color'], 
                                   (int(particle['x']), int(particle['y'])), 2)
    
    def draw(self) -> None:
        self.screen.fill(WHITE)
        
        # Fondo de temporada
        season_colors = [(235, 255, 235), (255, 250, 200), (255, 235, 205), (235, 245, 255)]
        season_index = (self.ecosystem.turn // SEASON_LENGTH) % 4
        bg_color = season_colors[season_index]
        pygame.draw.rect(self.screen, bg_color, 
                         (0, 0, self.ecosystem.width * CELL_SIZE, self.ecosystem.height * CELL_SIZE))
        

        # Dibujar terreno con texturas visuales mejoradas
        for (x, y), terrain in self.ecosystem.terrain_map.items():
            base_rect = (x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
            
            if terrain == TerrainType.GRASSLAND:
                # Pradera con variación de verde
                variation = (x + y) % 3
                colors = [(180, 230, 180), (170, 225, 170), (190, 235, 190)]
                pygame.draw.rect(self.screen, colors[variation], base_rect)
                # Pequeñas líneas de hierba
                if (x * y) % 5 == 0:
                    pygame.draw.line(self.screen, (150, 200, 150), 
                                   (x * CELL_SIZE + 2, y * CELL_SIZE + CELL_SIZE - 2),
                                   (x * CELL_SIZE + 2, y * CELL_SIZE + CELL_SIZE - 5), 1)
            
            elif terrain == TerrainType.FOREST:
                # Bosque con textura de troncos
                pygame.draw.rect(self.screen, (40, 100, 40), base_rect)
                # Troncos aleatorios
                if (x + y * 7) % 4 == 0:
                    pygame.draw.circle(self.screen, (80, 60, 40), 
                                     (x * CELL_SIZE + CELL_SIZE//2, y * CELL_SIZE + CELL_SIZE//2), 2)
            
            elif terrain == TerrainType.WATER:
                # Agua con efecto de ondas
                base_blue = 100 + (self.ecosystem.turn + x + y) % 30
                pygame.draw.rect(self.screen, (base_blue, 180, 255), base_rect)
                # Ondas sutiles
                if (self.ecosystem.turn + x) % 8 == 0:
                    pygame.draw.circle(self.screen, (120, 200, 255), 
                                     (x * CELL_SIZE + CELL_SIZE//2, y * CELL_SIZE + CELL_SIZE//2), 
                                     CELL_SIZE//3, 1)
            
            elif terrain == TerrainType.MOUNTAIN:
                # Montaña con textura rocosa
                pygame.draw.rect(self.screen, (120, 120, 120), base_rect)
                # Detalles de rocas
                if (x * 3 + y * 5) % 3 == 0:
                    pygame.draw.rect(self.screen, (100, 100, 100),
                                   (x * CELL_SIZE + 1, y * CELL_SIZE + 1, 
                                    CELL_SIZE - 4, CELL_SIZE - 4))
                # Nieve en cumbres (parte superior)
                if (x + y) % 7 == 0:
                    pygame.draw.line(self.screen, (240, 240, 240),
                                   (x * CELL_SIZE, y * CELL_SIZE + 1),
                                   (x * CELL_SIZE + CELL_SIZE, y * CELL_SIZE + 1), 2)
        
        # Efecto climático
        if self.ecosystem.weather_event == WeatherEvent.RAIN:
            for _ in range(50):
                x = random.randint(0, self.ecosystem.width * CELL_SIZE)
                y = random.randint(0, self.ecosystem.height * CELL_SIZE)
                pygame.draw.line(self.screen, CYAN, (x, y), (x, y + 4), 1)
        
        elif self.ecosystem.weather_event == WeatherEvent.FIRE:
            # Efecto de fuego (partículas naranjas)
            if random.random() < 0.3:
                x = random.randint(0, self.ecosystem.width * CELL_SIZE)
                y = random.randint(0, self.ecosystem.height * CELL_SIZE)
                self.add_particles(x, y, ORANGE, 3)

        # Dibujar plantas
        for plant in self.ecosystem.plants:
            size_ratio = plant.growth_stage / plant.max_growth
            px = plant.x * CELL_SIZE + CELL_SIZE // 2
            py = plant.y * CELL_SIZE + CELL_SIZE // 2
            
            if plant.plant_type == PlantType.GRASS:
                # Hierba: líneas verticales
                if plant.is_mature():
                    color = (40, 180, 40)
                    height = CELL_SIZE // 2
                else:
                    color = (120, 220, 120)
                    height = int((CELL_SIZE // 2) * size_ratio)
                
                if height > 2:
                    pygame.draw.line(self.screen, color, 
                                   (px - 1, py), (px - 1, py - height), 2)
                    pygame.draw.line(self.screen, color, 
                                   (px + 1, py), (px + 1, py - height + 1), 2)
            
            elif plant.plant_type == PlantType.BUSH:
                # Arbusto: círculo con textura
                if plant.is_mature():
                    radius = CELL_SIZE // 2 - 1
                    color = (34, 139, 34)
                else:
                    radius = int((CELL_SIZE // 2 - 1) * size_ratio)
                    color = (100, 200, 100)
                
                if radius > 1:
                    pygame.draw.circle(self.screen, color, (px, py), radius)
                    # Detalles de hojas
                    if plant.is_mature():
                        pygame.draw.circle(self.screen, (50, 160, 50), (px - 2, py - 1), 2)
                        pygame.draw.circle(self.screen, (50, 160, 50), (px + 2, py + 1), 2)
            
            elif plant.plant_type == PlantType.TREE:
                # Árbol: tronco + copa
                if plant.is_mature():
                    trunk_height = 5
                    crown_radius = 4
                    color = (20, 120, 20)
                else:
                    trunk_height = int(5 * size_ratio)
                    crown_radius = int(4 * size_ratio)
                    color = (80, 180, 80)
                
                if trunk_height > 0:
                    # Tronco
                    pygame.draw.rect(self.screen, (101, 67, 33),
                                   (px - 1, py - trunk_height, 2, trunk_height))
                    # Copa
                    if crown_radius > 1:
                        pygame.draw.circle(self.screen, color, 
                                         (px, py - trunk_height - 2), crown_radius)
                        # Detalles de copa
                        if plant.is_mature():
                            pygame.draw.circle(self.screen, (30, 140, 30), 
                                             (px - 2, py - trunk_height - 3), 2)
                            pygame.draw.circle(self.screen, (30, 140, 30), 
                                             (px + 2, py - trunk_height - 1), 2)
        
        # Dibujar cadáveres
        for corpse in self.ecosystem.corpses:
            px = corpse.x * CELL_SIZE + CELL_SIZE // 2
            py = corpse.y * CELL_SIZE + CELL_SIZE // 2
            alpha_ratio = corpse.decay_timer / 30
            
            # Cruz de huesos
            bone_color = (200, 200, 200) if alpha_ratio > 0.5 else (150, 150, 150)
            pygame.draw.line(self.screen, bone_color, 
                           (px - 3, py), (px + 3, py), 2)
            pygame.draw.line(self.screen, bone_color, 
                           (px, py - 3), (px, py + 3), 2)
        
        # Dibujar animales con sprites simples
        for animal in self.ecosystem.animals:
            px = int(animal.x * CELL_SIZE + CELL_SIZE // 2)
            py = int(animal.y * CELL_SIZE + CELL_SIZE // 2)
            
            # Colores y formas por especie
            if animal.species == SpeciesType.RABBIT:
                # Conejo - círculo pequeño azul claro
                energy_ratio = min(1.0, animal.energy / 30)
                color = (100, 150 + int(105 * energy_ratio), 255)
                pygame.draw.circle(self.screen, color, (px, py), CELL_SIZE // 3)
                # Orejas
                pygame.draw.circle(self.screen, color, (px - 2, py - 4), 2)
                pygame.draw.circle(self.screen, color, (px + 2, py - 4), 2)
            
            elif animal.species == SpeciesType.DEER:
                # Ciervo - círculo mediano marrón
                energy_ratio = min(1.0, animal.energy / 50)
                color = (150 + int(50 * energy_ratio), 120, 80)
                pygame.draw.circle(self.screen, color, (px, py), CELL_SIZE // 2 - 1)
                # Cuernos
                pygame.draw.line(self.screen, BROWN, (px - 3, py - 4), (px - 5, py - 7), 2)
                pygame.draw.line(self.screen, BROWN, (px + 3, py - 4), (px + 5, py - 7), 2)
            
            elif animal.species == SpeciesType.BUFFALO:
                # Búfalo - rectángulo grande
                energy_ratio = min(1.0, animal.energy / 70)
                color = (80 + int(60 * energy_ratio), 60, 40)
                size = CELL_SIZE // 2
                pygame.draw.rect(self.screen, color, 
                               (px - size//2, py - size//2, size, size))
                # Cuernos curvos
                pygame.draw.arc(self.screen, BLACK, 
                              (px - size//2, py - size//2 - 3, size, 6), 0, 3.14, 2)
            
            elif animal.species == SpeciesType.WOLF:
                # Lobo - triángulo rojo
                energy_ratio = min(1.0, animal.energy / 75)
                color = (200 + int(55 * energy_ratio), 40, 40)
                size = CELL_SIZE // 2
                points = [
                    (px, py - size),
                    (px - size, py + size//2),
                    (px + size, py + size//2)
                ]
                pygame.draw.polygon(self.screen, color, points)
                # Ojos
                pygame.draw.circle(self.screen, YELLOW, (px - 2, py - 2), 2)
                pygame.draw.circle(self.screen, YELLOW, (px + 2, py - 2), 2)
            
            elif animal.species == SpeciesType.BEAR:
                # Oso - círculo grande púrpura
                energy_ratio = min(1.0, animal.energy / 100)
                color = (100 + int(80 * energy_ratio), 50, 80)
                pygame.draw.circle(self.screen, color, (px, py), CELL_SIZE // 2)
                # Orejas redondeadas
                pygame.draw.circle(self.screen, color, (px - 4, py - 5), 3)
                pygame.draw.circle(self.screen, color, (px + 4, py - 5), 3)
            elif animal.species == SpeciesType.SHEEP:
                # Oveja mejorada con más detalle
                energy_ratio = min(1.0, animal.energy / 42)
                color = (230 + int(25 * energy_ratio), 230 + int(25 * energy_ratio), 230)
                # Cuerpo lanudo (círculos superpuestos)
                pygame.draw.circle(self.screen, color, (px, py), CELL_SIZE // 2 - 1)
                pygame.draw.circle(self.screen, (245, 245, 245), (px - 2, py - 1), 3)
                pygame.draw.circle(self.screen, (245, 245, 245), (px + 2, py + 1), 3)
                # Cabeza negra
                pygame.draw.circle(self.screen, (50, 50, 50), (px, py - 4), 2)
                # Patas
                pygame.draw.line(self.screen, (100, 100, 100), (px - 2, py + 3), (px - 2, py + 6), 1)
                pygame.draw.line(self.screen, (100, 100, 100), (px + 2, py + 3), (px + 2, py + 6), 1)
            
            elif animal.species == SpeciesType.FOX:
                # Zorro mejorado
                energy_ratio = min(1.0, animal.energy / 55)
                color = (255, 100 + int(80 * energy_ratio), 20)
                size = CELL_SIZE // 2
                # Cuerpo
                pygame.draw.ellipse(self.screen, color, 
                                   (px - size//2, py - size//3, size, size//2 + 2))
                # Cabeza
                pygame.draw.circle(self.screen, color, (px, py - 3), 3)
                # Orejas puntiagudas
                points_ear1 = [(px - 3, py - 5), (px - 4, py - 8), (px - 2, py - 6)]
                points_ear2 = [(px + 3, py - 5), (px + 4, py - 8), (px + 2, py - 6)]
                pygame.draw.polygon(self.screen, color, points_ear1)
                pygame.draw.polygon(self.screen, color, points_ear2)
                # Cola esponjosa
                pygame.draw.circle(self.screen, color, (px - 1, py + 4), 3)
                pygame.draw.circle(self.screen, (255, 255, 255), (px - 2, py + 5), 2)  # Punta blanca
            
            elif animal.species == SpeciesType.EAGLE:
                # Águila mejorada con alas detalladas
                energy_ratio = min(1.0, animal.energy / 65)
                color = (80 + int(60 * energy_ratio), 60, 30)
                # Cuerpo
                pygame.draw.ellipse(self.screen, color, (px - 2, py - 3, 4, 6))
                # Cabeza
                pygame.draw.circle(self.screen, (100, 80, 50), (px, py - 5), 3)
                # Pico amarillo
                pygame.draw.polygon(self.screen, YELLOW, 
                                   [(px, py - 5), (px - 2, py - 4), (px, py - 3)])
                # Alas extendidas con plumas
                wing_points_left = [(px - 7, py - 1), (px - 3, py), (px - 2, py + 2)]
                wing_points_right = [(px + 7, py - 1), (px + 3, py), (px + 2, py + 2)]
                pygame.draw.polygon(self.screen, color, wing_points_left)
                pygame.draw.polygon(self.screen, color, wing_points_right)
                # Detalles de plumas
                pygame.draw.line(self.screen, (60, 40, 20), (px - 5, py), (px - 6, py + 1), 1)
                pygame.draw.line(self.screen, (60, 40, 20), (px + 5, py), (px + 6, py + 1), 1)
            
            # Indicador de selección
            if animal == self.ecosystem.selected_animal:
                pygame.draw.circle(self.screen, YELLOW, (px, py), 
                                 CELL_SIZE // 2 + 3, 2)
            
            # Indicador de reproducción (brillo)
            if animal.can_reproduce():
                pygame.draw.circle(self.screen, PINK, (px, py), 
                                 CELL_SIZE // 2 + 2, 1)
        
        # Actualizar partículas
        self.update_particles()
        
        # Panel de estadísticas
        self._draw_stats_panel()
        
        pygame.display.flip()
    
    def _draw_stats_panel(self) -> None:
        panel_x = self.ecosystem.width * CELL_SIZE + 10
        panel_width = 260
        
        # Fondo
        pygame.draw.rect(self.screen, DARK_GRAY, 
                        (panel_x - 5, 0, panel_width + 5, self.screen_height))
        
        # Título
        title = self.title_font.render("📊 ECOSISTEMA 2.0", True, YELLOW)
        self.screen.blit(title, (panel_x + 15, 10))
        
        y = 45
        
        # Información básica
        info = [
            f"Turno: {self.ecosystem.turn}",
            f"Estación: {self.ecosystem.get_current_season()}",
            "",
            "POBLACIÓN:",
            f"🐰 Herbívoros: {sum(1 for a in self.ecosystem.animals if a.is_herbivore)}",
            f"  • Conejos: {sum(1 for a in self.ecosystem.animals if a.species == SpeciesType.RABBIT)}",
            f"  • Ciervos: {sum(1 for a in self.ecosystem.animals if a.species == SpeciesType.DEER)}",
            f"  • Búfalos: {sum(1 for a in self.ecosystem.animals if a.species == SpeciesType.BUFFALO)}",
            f"🦁 Depredadores: {sum(1 for a in self.ecosystem.animals if not a.is_herbivore)}",
            f"  • Lobos: {sum(1 for a in self.ecosystem.animals if a.species == SpeciesType.WOLF)}",
            f"  • Osos: {sum(1 for a in self.ecosystem.animals if a.species == SpeciesType.BEAR)}",
            f"🌿 Plantas: {len(self.ecosystem.plants)}",
            "",
            f"⚔️ Cacerías: {self.ecosystem.stats['hunts']}",
            f"📈 Nacimientos: {self.ecosystem.stats['births']}",
            f"💀 Muertes: {self.ecosystem.stats['deaths']}"
        ]
        
        for line in info:
            text = self.small_font.render(line, True, WHITE)
            self.screen.blit(text, (panel_x, y))
            y += 20
        
        # Evento climático
        if self.ecosystem.weather_event != WeatherEvent.NONE:
            y += 5
            event_colors = {
                WeatherEvent.RAIN: CYAN,
                WeatherEvent.DROUGHT: ORANGE,
                WeatherEvent.FIRE: RED
            }
            color = event_colors.get(self.ecosystem.weather_event, WHITE)
            event_text = self.font.render(f"⚠ {self.ecosystem.weather_event.value}", True, color)
            self.screen.blit(event_text, (panel_x, y))
            y += 20
            duration_text = self.small_font.render(f"Duración: {self.ecosystem.weather_duration}", True, WHITE)
            self.screen.blit(duration_text, (panel_x, y))
            y += 25
        
        # Animal seleccionado
        if self.ecosystem.selected_animal:
            y += 5
            animal = self.ecosystem.selected_animal
            
            pygame.draw.rect(self.screen, (80, 80, 80), (panel_x - 5, y - 5, panel_width, 140))
            
            select_title = self.font.render("🔍 SELECCIONADO", True, YELLOW)
            self.screen.blit(select_title, (panel_x + 30, y))
            y += 25
            
            animal_info = [
                f"Especie: {animal.species.value}",
                f"Energía: {animal.energy}/{animal.genetics.expressed().max_energy}",
                f"Edad: {animal.age}/{animal.max_age}",
                f"Generación: {animal.generation}",
                "",
                "GENÉTICA:",
                f"  Velocidad: {animal.genetics.expressed().speed:.2f}",
                f"  Eficiencia: {animal.genetics.expressed().efficiency:.2f}",
                f"  Visión: {animal.genetics.expressed().vision_range:.1f}",
                f"  Reproducción: {animal.genetics.expressed().reproduction_rate:.2f}"
            ]
            
            for line in animal_info:
                text = self.small_font.render(line, True, WHITE)
                self.screen.blit(text, (panel_x, y))
                y += 18
        
        # Gráfico de población (parte inferior)
        graph_y = self.screen_height - 180
        self._draw_population_graph(panel_x, graph_y, panel_width - 20)
        
        # Controles
        y = self.screen_height - 120
        controls_title = self.small_font.render("CONTROLES:", True, YELLOW)
        self.screen.blit(controls_title, (panel_x, y))
        y += 20
        
        controls = [
            "ESPACIO: Pausar",
            "+/-: Velocidad",
            "CLICK: Seleccionar",
            "R: Reiniciar",
            "ESC: Salir"
        ]
        
        for text in controls:
            surface = self.small_font.render(text, True, WHITE)
            self.screen.blit(surface, (panel_x, y))
            y += 18
    
    def _draw_population_graph(self, x: int, y: int, width: int) -> None:
        height = 90
        
        pygame.draw.rect(self.screen, WHITE, (x, y, width, height))
        pygame.draw.rect(self.screen, BLACK, (x, y, width, height), 2)
        
        if len(self.ecosystem.stats['herbivores']) < 2:
            return
        
        recent = 120
        h_data = self.ecosystem.stats['herbivores'][-recent:]
        p_data = self.ecosystem.stats['predators'][-recent:]
        pl_data = self.ecosystem.stats['plants'][-recent:]
        
        max_val = max(
            max(h_data, default=1),
            max(p_data, default=1),
            max(pl_data, default=1) // 2  # Escalar plantas
        )
        if max_val == 0:
            max_val = 1
        
        def draw_line(data, color, scale=1.0):
            points = []
            for i, val in enumerate(data):
                px = x + (i / len(data)) * width
                py = y + height - ((val * scale) / max_val) * (height - 10)
                points.append((px, py))
            
            if len(points) > 1:
                pygame.draw.lines(self.screen, color, False, points, 2)
        
        draw_line(pl_data, DARK_GREEN, 0.5)  # Plantas escaladas
        draw_line(h_data, BLUE)
        draw_line(p_data, RED)
        
        # Leyenda en el gráfico
        legend_x = x + 5
        legend_y = y + 5
        
        pygame.draw.line(self.screen, BLUE, (legend_x, legend_y), (legend_x + 15, legend_y), 2)
        legend_text = self.small_font.render("Herbívoros", True, BLACK)
        self.screen.blit(legend_text, (legend_x + 20, legend_y - 5))
        
        legend_y += 15
        pygame.draw.line(self.screen, RED, (legend_x, legend_y), (legend_x + 15, legend_y), 2)
        legend_text = self.small_font.render("Depredadores", True, BLACK)
        self.screen.blit(legend_text, (legend_x + 20, legend_y - 5))
        
        legend_y += 15
        pygame.draw.line(self.screen, DARK_GREEN, (legend_x, legend_y), (legend_x + 15, legend_y), 2)
        legend_text = self.small_font.render("Plantas/2", True, BLACK)
        self.screen.blit(legend_text, (legend_x + 20, legend_y - 5))
    
    def handle_click(self, pos: Tuple[int, int]) -> None:
        """Maneja clicks del mouse para seleccionar animales"""
        grid_x = pos[0] // CELL_SIZE
        grid_y = pos[1] // CELL_SIZE
        
        if grid_x < self.ecosystem.width and grid_y < self.ecosystem.height:
            selected = self.ecosystem.select_animal_at(grid_x, grid_y)
            self.ecosystem.selected_animal = selected


def run_simulation(turns: int = 15000, fps: int = FPS_INITIAL) -> None:
    """Ejecuta la simulación mejorada"""
    ecosystem = Ecosystem(GRID_WIDTH, GRID_HEIGHT)
    renderer = Renderer(ecosystem)
    
    running = True
    paused = False
    turn_count = 0
    
    print("=" * 60)
    print("🌍 SIMULADOR DE ECOSISTEMA AVANZADO 2.0 🌍")
    print("=" * 60)
    print("\n✨ CARACTERÍSTICAS:")
    print("  • 5 especies diferentes (3 herbívoros, 2 depredadores)")
    print("  • Sistema genético con herencia y mutaciones")
    print("  • Terrenos variados: praderas, bosques, agua, montañas")
    print("  • Sistema de estaciones con efectos climáticos")
    print("  • Eventos aleatorios: lluvia, sequía, incendios")
    print("  • Animaciones suaves de movimiento")
    print("  • Sprites visuales diferenciados por especie")
    print("  • Gráficos de población en tiempo real")
    print("  • Click en animales para ver información detallada")
    print("\n🎮 CONTROLES:")
    print("  ESPACIO     → Pausar/Reanudar simulación")
    print("  +/-         → Aumentar/Disminuir velocidad")
    print("  CLICK       → Seleccionar animal y ver detalles")
    print("  R           → Reiniciar simulación")
    print("  ESC         → Salir del programa")
    print("=" * 60)
    print()
    
    last_report = 0
    
    while running and turn_count < turns:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Click izquierdo
                    renderer.handle_click(event.pos)
            
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                
                elif event.key == pygame.K_SPACE:
                    paused = not paused
                    print(f"⏸️  {'PAUSADO' if paused else '▶️  REANUDADO'}")
                
                elif event.key in [pygame.K_PLUS, pygame.K_EQUALS]:
                    fps = min(60, fps + 5)
                    print(f"⚡ Velocidad: {fps} FPS")
                
                elif event.key == pygame.K_MINUS:
                    fps = max(5, fps - 5)
                    print(f"🐌 Velocidad: {fps} FPS")
                
                elif event.key == pygame.K_r:
                    print("\n🔄 Reiniciando simulación...")
                    ecosystem = Ecosystem(GRID_WIDTH, GRID_HEIGHT)
                    renderer.ecosystem = ecosystem
                    turn_count = 0
                    last_report = 0
        
        if not paused:
            ecosystem.update()
            turn_count += 1
            
            # Verificar extinciones
            herbivores = sum(1 for a in ecosystem.animals if a.is_herbivore)
            predators = len(ecosystem.animals) - herbivores
            
            if len(ecosystem.animals) == 0:
                print(f"\n💀 ¡EXTINCIÓN TOTAL! Todas las especies murieron en el turno {turn_count}")
                print("   Presiona R para reiniciar o ESC para salir")
                paused = True
            
            elif herbivores == 0 and predators > 0:
                print(f"\n🦌 ¡Herbívoros extintos en turno {turn_count}!")
                print("   Los depredadores morirán de hambre pronto...")
            
            # Reportes periódicos
            if turn_count - last_report >= 50:
                herbivores = sum(1 for a in ecosystem.animals if a.is_herbivore)
                predators = len(ecosystem.animals) - herbivores
                
                # Contar por especie
                species_counts = defaultdict(int)
                species_energy = defaultdict(list)
                diseased = 0
                
                for animal in ecosystem.animals:
                    species_counts[animal.species.value] += 1
                    species_energy[animal.species.value].append(animal.energy)
                    if animal.disease != DiseaseType.NONE:
                        diseased += 1
                
                print(f"\n📊 Turno {turn_count:5d} | Estación: {ecosystem.get_current_season():10s}")
                print(f"   🐰 Herbívoros: {herbivores:3d} | 🦁 Depredadores: {predators:3d} | 🌿 Plantas: {len(ecosystem.plants):4d}")
                
                # Desglose por especie con energía
                print("   Especies vivas:")
                for species_name, count in sorted(species_counts.items()):
                    if count > 0:
                        avg_energy = sum(species_energy[species_name]) / len(species_energy[species_name])
                        print(f"      • {species_name}: {count:2d} (E̅={avg_energy:.1f})")
                
                if diseased > 0:
                    print(f"   ⚠️ Individuos enfermos: {diseased} ({100*diseased/len(ecosystem.animals):.1f}%)")
                
                if ecosystem.weather_event != WeatherEvent.NONE:
                    print(f"   🌦️ Evento activo: {ecosystem.weather_event.value} (quedan {ecosystem.weather_duration} turnos)")
                
                last_report = turn_count
                last_report_births = ecosystem.stats['births']
                last_report_deaths = ecosystem.stats['deaths']
                last_report_hunts = ecosystem.stats['hunts']
        
        renderer.draw()
        renderer.clock.tick(fps)
    
    # Estadísticas finales
    print("\n" + "=" * 70)
    print("📈 ESTADÍSTICAS FINALES DE LA SIMULACIÓN")
    print("=" * 70)
    print(f"\n⏱️ Turnos totales: {turn_count} | Estación final: {ecosystem.get_current_season()}")
    
    # Población final
    herbivores_final = sum(1 for a in ecosystem.animals if a.is_herbivore)
    predators_final = len(ecosystem.animals) - herbivores_final
    
    print(f"\n👥 POBLACIÓN FINAL: {len(ecosystem.animals)} individuos")
    print(f"   Herbívoros: {herbivores_final} | Depredadores: {predators_final} | Plantas: {len(ecosystem.plants)}")
    
    species_final = defaultdict(int)
    for animal in ecosystem.animals:
        species_final[animal.species.value] += 1
    
    for species in SpeciesType:
        count = species_final.get(species.value, 0)
        if count > 0 or ecosystem.stats['population_peaks'][species.value]['max'] > 0:
            print(f"   • {species.value}: {count}")
    
    # Métricas acumuladas
    print(f"\n📊 MÉTRICAS ACUMULADAS:")
    print(f"   👶 Nacimientos: {ecosystem.stats['births']}")
    print(f"   💀 Muertes: {ecosystem.stats['deaths']}")
    print(f"   ⚔️ Cacerías exitosas: {ecosystem.stats['hunts']}/{ecosystem.stats['hunt_attempts']} " +
          f"({100*ecosystem.stats['hunts']/max(1, ecosystem.stats['hunt_attempts']):.1f}% éxito)")
    print(f"   🌿 Plantas consumidas: {ecosystem.stats['plants_eaten']}")
    print(f"   💀 Carroña aprovechada: {ecosystem.stats['carrion_consumed']}")
    print(f"   🧬 Mutaciones: {ecosystem.stats['mutations']}")
    print(f"   🦠 Enfermedades detectadas: {ecosystem.stats['disease_count']}")
    print(f"   ☠️ Muertes por clima extremo: {ecosystem.stats['climate_impact_deaths']}")
    
    # Presión de depredación
    if ecosystem.stats['hunts_by_prey']:
        print(f"\n🎯 PRESIÓN DE DEPREDACIÓN:")
        for prey, count in sorted(ecosystem.stats['hunts_by_prey'].items(), key=lambda x: -x[1]):
            print(f"   • {prey}: {count} cazados")
    
    if ecosystem.stats['hunts_by_predator']:
        print(f"\n🦁 EFICIENCIA DE DEPREDADORES:")
        for pred, count in sorted(ecosystem.stats['hunts_by_predator'].items(), key=lambda x: -x[1]):
            print(f"   • {pred}: {count} capturas")
    
    # Picos de población
    print(f"\n📈 PICOS DE POBLACIÓN:")
    for species_name, data in ecosystem.stats['population_peaks'].items():
        if data['max'] > 0:
            print(f"   • {species_name}: Máx={data['max']} (turno {data['turn_max']}), " +
                  f"Mín={data['min']} (turno {data['turn_min']})")
    
    # Extinciones
    if ecosystem.stats['extinctions']:
        print(f"\n💀 EXTINCIONES:")
        for species_name, turn_ext, turn_reap in ecosystem.stats['extinctions']:
            if turn_reap:
                print(f"   • {species_name}: Extinto en turno {turn_ext}, reaparición en {turn_reap}")
            else:
                print(f"   • {species_name}: Extinto en turno {turn_ext} (sin recuperación)")
    
    # Esperanza de vida
    print(f"\n⏳ ESPERANZA DE VIDA (edad promedio al morir):")
    for species_name, ages in ecosystem.stats['age_at_death'].items():
        if ages:
            avg_age = sum(ages) / len(ages)
            max_age = max(ages)
            min_age = min(ages)
            print(f"   • {species_name}: {avg_age:.1f} turnos (rango: {min_age}-{max_age})")
    
    # Eventos climáticos
    if ecosystem.stats['total_climate_duration']:
        print(f"\n🌦️ EVENTOS CLIMÁTICOS ({len(ecosystem.stats['events'])} ocurrencias):")
        for event_type, duration in ecosystem.stats['total_climate_duration'].items():
            print(f"   • {event_type}: {duration} turnos acumulados")
    
    # Análisis genético
    print(f"\n🧬 EVOLUCIÓN GENÉTICA:")
    for species in SpeciesType:
        animals_sp = [a for a in ecosystem.animals if a.species == species]
        if animals_sp:
            avg_speed = sum(a.genetics.expressed().speed for a in animals_sp) / len(animals_sp)
            avg_energy = sum(a.genetics.expressed().max_energy for a in animals_sp) / len(animals_sp)
            avg_vision = sum(a.genetics.expressed().vision_range for a in animals_sp) / len(animals_sp)
            max_gen = ecosystem.stats['max_generation'].get(species.value, 0)
            
            print(f"\n   {species.value} (Gen máx: {max_gen}):")
            print(f"      Velocidad: {avg_speed:.2f} | Energía máx: {avg_energy:.1f} | Visión: {avg_vision:.1f}")
    
    # Cobertura vegetal
    total_cells = ecosystem.width * ecosystem.height
    plant_coverage = 100 * len(ecosystem.plants) / total_cells
    print(f"\n🌳 COBERTURA VEGETAL: {plant_coverage:.1f}% ({len(ecosystem.plants)}/{total_cells} celdas)")
    
    # Distancia promedio recorrida
    if ecosystem.stats['distances_traveled']:
        avg_dist = sum(ecosystem.stats['distances_traveled']) / len(ecosystem.stats['distances_traveled'])
        print(f"\n🚶 DISTANCIA PROMEDIO RECORRIDA POR MOVIMIENTO: {avg_dist:.2f} celdas")
    
    print("\n" + "=" * 70)
    print("✨ Simulación completada")
    print("=" * 70)
    
    pygame.quit()


if __name__ == "__main__":
    run_simulation(turns=15000, fps=FPS_INITIAL)